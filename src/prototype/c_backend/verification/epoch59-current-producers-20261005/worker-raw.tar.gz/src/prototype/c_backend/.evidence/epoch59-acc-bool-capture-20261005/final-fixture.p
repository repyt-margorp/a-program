import Bool;
import Nat;
import LT;
import Acc;
import SizedList;
import List;
import Measured;
import Partition;
import accessibleSucc;
import natAccessible;
import natLessOrEqual;
import quickSortAcc;
import partition;
import partitionByDecision;
import partitionLower;
import partitionUpper;
import append;
import measure;
import quickSort;

bool_type := Bool;
nat_type := Nat;
lt_family := LT;
acc_family := Acc Nat LT;
sized_family := SizedList Nat;
measured_type := Measured Nat;
partition_type := Partition Nat Nat.zero;
list_type := List Nat;
empty := (List Nat).nil;
succ_access := accessibleSucc;
nat_access := natAccessible;
compare_fn := natLessOrEqual;
sort_acc := quickSortAcc Nat &natLessOrEqual;
partition_fn := partition;
partition_nat := partition Nat &natLessOrEqual;
decision_fn := partitionByDecision;
lower_fn := partitionLower;
upper_fn := partitionUpper;
append_fn := append;
append_nat := append Nat;
measure_fn := measure Nat;
measure_generic := measure;
sort_generic := quickSortAcc;
outer_fn := quickSort Nat &natLessOrEqual;
sort := \xs : List Nat => quickSort Nat &natLessOrEqual xs;
count := \n : Nat => n @zero => #0 @succ k => #int_add #1 *k;
fingerprint := \xs : List Nat => xs @nil => #0
	@cons n tail => #int_add (#int_mul #5 *tail) (#int_add #1 (count n));
bool_value := \b : Bool => b @true => #1 @false => #0;
zero := Nat.zero;
one := Nat.succ zero;
two := Nat.succ one;
three := Nat.succ two;
mixed := (List Nat).cons three ((List Nat).cons zero ((List Nat).cons two ((List Nat).cons one ((List Nat).cons two empty))));
print_list := \xs : List Nat => xs @nil => #print #"|"
	@cons n tail => { #print (#int_to_text (count n)); #print #","; *tail; };
// Unrelated admitted bodies must not inherit imported executable Folds.
wrong_measure := \xs : List Nat => (Measured Nat).measured zero (SizedList Nat).nil;
wrong_outer := \xs : List Nat => xs;
reference := print_list (sort mixed);
measure_reference := measure_fn mixed @measured size values =>
	#print (#int_to_text (count size));

// Exact alias and admitted different successor remain separate target selections.
exact_successor := accessibleSucc;
changed_successor := \n : Nat => \proof : Acc Nat LT n => nat_access (Nat.succ n);


// Admitted source declarations with explicitly unsupported target index/fields.
two_successors_lt := @\left : Nat => @\right : Nat => {
	step : (n : Nat) -> * n (Nat.succ (Nat.succ n));
	weakenRight : (m : Nat) -> (n : Nat) -> * m n -> * m (Nat.succ n);
	lift : (m : Nat) -> (n : Nat) -> * m n -> * (Nat.succ m) (Nat.succ n);
};

extra_field_lt := @\left : Nat => @\right : Nat => {
	step : (n : Nat) -> (extra : Nat) -> * n (Nat.succ n);
	weakenRight : (m : Nat) -> (n : Nat) -> * m n -> * m (Nat.succ n);
	lift : (m : Nat) -> (n : Nat) -> * m n -> * (Nat.succ m) (Nat.succ n);
};

wrong_prior_lt := @\left : Nat => @\right : Nat => {
	step : (n : Nat) -> * n (Nat.succ n);
	weakenRight : (m : Nat) -> (n : Nat) -> (prior : Nat) -> * m (Nat.succ n);
	lift : (m : Nat) -> (n : Nat) -> * m n -> * (Nat.succ m) (Nat.succ n);
};

// The actual comparator stays a parameter rather than a closed Nat choice.
outer_parameter := quickSort Nat;
reverse_compare := \left : Nat => \right : Nat => natLessOrEqual right left;
descending_sort := quickSort Nat &reverse_compare;
reference_descending := print_list (descending_sort mixed);
// Admitted parameter shapes with unsupported bodies must remain refused.
wrong_parameter := \compare : Nat -> Nat -> Bool => \xs : List Nat => xs;
unary_parameter := \compare : Nat -> Bool => \xs : List Nat => xs;

// The actual source selects comparator operands in its closed capture.
forward_compare := \left : Nat => \right : Nat => natLessOrEqual left right;
forward_sort := quickSort Nat &forward_compare;
reference_forward := print_list (forward_sort mixed);
// These pure-total source comparators are outside the bounded reader.
constant_compare := \left : Nat => \right : Nat => Bool.true;
constant_sort := quickSort Nat &constant_compare;
repeated_compare := \left : Nat => \right : Nat => natLessOrEqual left left;
repeated_sort := quickSort Nat &repeated_compare;

// An actual closed Bool value remains comparator context through Acc recursion.
choose_compare := \reverse : Bool => \left : Nat => \right : Nat =>
	reverse @true => natLessOrEqual right left @false => natLessOrEqual left right;
true_sort := quickSort Nat &(choose_compare Bool.true);
false_sort := quickSort Nat &(choose_compare Bool.false);
reference_true := print_list (true_sort mixed);
reference_false := print_list (false_sort mixed);
// Opposite source clauses ensure constructor positions are not C truth guesses.
opposite_compare := \reverse : Bool => \left : Nat => \right : Nat =>
	reverse @true => natLessOrEqual left right @false => natLessOrEqual right left;
opposite_true_sort := quickSort Nat &(opposite_compare Bool.true);
opposite_false_sort := quickSort Nat &(opposite_compare Bool.false);
reference_opposite_true := print_list (opposite_true_sort mixed);
reference_opposite_false := print_list (opposite_false_sort mixed);
// Unsupported environments/unused fields/bad inactive branches remain explicit.
unused_mode_compare := \reverse : Bool => \left : Nat => \right : Nat => natLessOrEqual left right;
unused_mode_sort := quickSort Nat &(unused_mode_compare Bool.true);
nat_mode_compare := \mode : Nat => \left : Nat => \right : Nat =>
	mode @zero => natLessOrEqual left right @succ prior => natLessOrEqual right left;
nat_mode_sort := quickSort Nat &(nat_mode_compare Nat.zero);
bad_mode_compare := \reverse : Bool => \left : Nat => \right : Nat =>
	reverse @true => natLessOrEqual left left @false => natLessOrEqual right left;
bad_mode_sort := quickSort Nat &(bad_mode_compare Bool.false);

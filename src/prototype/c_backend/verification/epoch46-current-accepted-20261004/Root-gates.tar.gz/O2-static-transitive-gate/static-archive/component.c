/* A Program native realization of admitted pure total computations. */
#include <stdint.h>
#include <limits.h>
_Static_assert(sizeof(int) <= sizeof(uint32_t), "unsupported integer promotion model");

static uint64_t c1(uint64_t a1);
static uint64_t c2(uint64_t a1);
static uint64_t c3(uint64_t a1);
static uint64_t c4(uint64_t a1, uint64_t a2);
static uint64_t c5(uint64_t a1, uint64_t a2);
static uint64_t c6(uint64_t a1, uint64_t a2);
static uint64_t c7(uint64_t a1);
static uint64_t c8(uint64_t a1);
static uint64_t c9(uint64_t a1, uint64_t a2);
static uint64_t c10(uint64_t a1, uint64_t a2);
static uint64_t c11(uint64_t a1);
static uint64_t c12(uint64_t a1);
static uint64_t c13(uint64_t a1);
static uint64_t c14(uint64_t a1);
static uint64_t c15(uint64_t a1);
static uint64_t c16(uint64_t a1, uint64_t a2);
static uint64_t c17(uint64_t a1);
static uint64_t c18(uint64_t a1);
static uint64_t c19(uint64_t a1, uint64_t a2);
static uint64_t c20(uint64_t a1, uint64_t a2);
static uint64_t c21(uint64_t a1, uint64_t a2);
static uint64_t c22(uint64_t a1, uint64_t a2);
static uint64_t c23(uint64_t a1, uint64_t a2);
static uint64_t c24(uint64_t a1, uint64_t a2);
static uint64_t c25(uint64_t a1, uint64_t a2);
static uint64_t c26(uint64_t a1, uint64_t a2);
static uint64_t c27(uint64_t a1, uint64_t a2);
static uint64_t c28(uint64_t a1, uint64_t a2);
static uint64_t c29(uint64_t a1, uint64_t a2);
static uint64_t c30(uint64_t a1, uint64_t a2);
static uint64_t c31(uint64_t a1);
static uint64_t c32(uint64_t a1);

static uint64_t c1(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c2(a1));
	(void)v1;
	return v1;
}

static uint64_t c2(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c3(a1));
	(void)v1;
	return v1;
}

static uint64_t c3(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	uint64_t v2 = (uint32_t)(a1 + v1);
	(void)v2;
	return v2;
}

static uint64_t c4(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c5(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c5(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c6(a2, a1));
	(void)v1;
	return v1;
}

static uint64_t c6(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c7(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c8(a1));
	(void)v1;
	return v1;
}

static uint64_t c8(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x7));
	(void)v1;
	uint64_t v2 = (uint32_t)(c9(v1, a1));
	(void)v2;
	return v2;
}

static uint64_t c9(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c10(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c10(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c11(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c12(a1));
	(void)v1;
	return v1;
}

static uint64_t c12(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c13(a1));
	(void)v1;
	uint64_t v2 = (uint32_t)(c13(a1));
	(void)v2;
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	return v3;
}

static uint64_t c13(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	uint64_t v2 = (uint32_t)(a1 + v1);
	(void)v2;
	return v2;
}

static uint64_t c14(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c15(a1));
	(void)v1;
	return v1;
}

static uint64_t c15(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x7));
	(void)v1;
	uint64_t v2 = (uint32_t)(c16(v1, a1));
	(void)v2;
	return v2;
}

static uint64_t c16(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c17(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c18(a1));
	(void)v1;
	return v1;
}

static uint64_t c18(uint64_t a1)
{
	(void)a1;
	return a1;
}

static uint64_t c19(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(c20(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c20(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(c21(a2, a1));
	(void)v1;
	return v1;
}

static uint64_t c21(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c22(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c23(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c23(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c24(a2, a1));
	(void)v1;
	return v1;
}

static uint64_t c24(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c25(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c25(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c26(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c27(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c27(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c28(a2, a1));
	(void)v1;
	return v1;
}

static uint64_t c28(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c29(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c29(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c30(a1, a2));
	(void)v1;
	return v1;
}

static uint64_t c30(uint64_t a1, uint64_t a2)
{
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	return v1;
}

static uint64_t c31(uint64_t a1)
{
	(void)a1;
	uint64_t v1 = (uint32_t)(c32(a1));
	(void)v1;
	return v1;
}

static uint64_t c32(uint64_t a1)
{
	(void)a1;
	return a1;
}

int ap_export_closed_block(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c1((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_captured_block(int32_t a1, int32_t a2, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c4((uint32_t)a1, (uint32_t)a2);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_shadowed_block(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c7((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_repeated_block(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c11((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_curried_block(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c14((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_unused_block(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c17((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_captured64(int64_t a1, int64_t a2, int64_t *out)
{
	if (!out) return 1;
	uint64_t result = c19((uint64_t)a1, (uint64_t)a2);
	*out = result <= INT64_MAX ? (int64_t)result : -1 - (int64_t)(UINT64_MAX - result);
	return 0;
}

int ap_export_nested_two(int32_t a1, int32_t a2, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c22((uint32_t)a1, (uint32_t)a2);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_three(int32_t a1, int32_t a2, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c26((uint32_t)a1, (uint32_t)a2);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_unused_effect(int32_t a1, int32_t *out)
{
	if (!out) return 1;
	uint64_t result = c31((uint32_t)a1);
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}


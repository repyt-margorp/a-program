#pragma once
/* ABI 1: 0 success; 1 null output; 2 invalid tag input. Output must be writable. */
#include <stdint.h>
#ifndef AP_C_SCALAR_ABI
#define AP_C_SCALAR_ABI 1
#elif AP_C_SCALAR_ABI != 1
#error incompatible_A_Program_scalar_ABI
#endif
#ifdef __cplusplus
extern "C" {
#endif
int ap_export_chain_three(int32_t a1, int32_t a2, int32_t *out);
int ap_export_chain_four(int32_t a1, int32_t a2, int32_t *out);
int ap_export_chain_eight(int32_t a1, int32_t a2, int32_t *out);
int ap_export_shadowed(int32_t a1, int32_t a2, int32_t *out);
int ap_export_repeated(int32_t a1, int32_t a2, int32_t *out);
int ap_export_unused_effect(int32_t a1, int32_t a2, int32_t *out);
int ap_export_chain64(int64_t a1, int64_t a2, int64_t *out);
#ifdef __cplusplus
}
#endif

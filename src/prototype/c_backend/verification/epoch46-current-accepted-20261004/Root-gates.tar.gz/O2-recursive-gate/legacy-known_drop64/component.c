/* A Program native realization of admitted pure total computations. */
#include <stdint.h>
#include <limits.h>
_Static_assert(sizeof(int) <= sizeof(uint32_t), "unsupported integer promotion model");

#include <stdlib.h>
struct ap_enum_Bool { uint32_t tag; };
#define AP_ENUM_Bool_C0 UINT32_C(0)
#define AP_ENUM_Bool_C1 UINT32_C(1)
struct ap_enum_Reverse { uint32_t tag; };
#define AP_ENUM_Reverse_C0 UINT32_C(0)
#define AP_ENUM_Reverse_C1 UINT32_C(1)
struct ap_data_Numbers32 { uint32_t tag; union {
	struct { int32_t f0; const struct ap_data_Numbers32 * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers32_C0 UINT32_C(0)
#define AP_DATA_Numbers32_C1 UINT32_C(1)
struct ap_data_Numbers64 { uint32_t tag; union {
	struct { const struct ap_data_Numbers64 * f0; int64_t f1; } c0;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers64_C0 UINT32_C(0)
#define AP_DATA_Numbers64_C1 UINT32_C(1)
#include <stddef.h>
#ifndef AP_C_ARENA_ABI
#define AP_C_ARENA_ABI 1
struct ap_c_allocation;
/* Zero initialize. Borrowed input nodes outlive every result sharing them.
	* Result storage is separate from inputs and arena metadata.
	* capacity 0 is unlimited; depth_limit 0 selects 256, maximum 256. */
struct ap_c_arena { struct ap_c_allocation *first; size_t count, capacity, depth, depth_limit; int status; };
#elif AP_C_ARENA_ABI != 1
#error incompatible_A_Program_arena_ABI
#endif
void ap_arena_Numbers32_destroy(struct ap_c_arena *);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers32(const struct ap_data_Numbers32 *, int32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers32(struct ap_c_arena *, const int32_t *, size_t count, const struct ap_data_Numbers32 **out);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers64(const struct ap_data_Numbers64 *, int64_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers64(struct ap_c_arena *, const int64_t *, size_t count, const struct ap_data_Numbers64 **out);
struct ap_c_allocation { struct ap_c_allocation *next; union { max_align_t alignment; unsigned char bytes[1]; } payload; };
static void ap_release(struct ap_c_arena *arena, struct ap_c_allocation *mark)
{
	while (arena->first != mark) {
		struct ap_c_allocation *node = arena->first;
		arena->first = node->next; free(node); --arena->count;
	}
}
static void *ap_allocate(struct ap_c_arena *arena, size_t size)
{
	if (arena->status) return NULL;
	if (size > SIZE_MAX - sizeof(struct ap_c_allocation) || arena->count == SIZE_MAX ||
		(arena->capacity && arena->count >= arena->capacity)) { arena->status = 3; return NULL; }
	struct ap_c_allocation *node = malloc(sizeof(*node) + size);
	if (!node) { arena->status = 3; return NULL; }
	node->next = arena->first; arena->first = node; ++arena->count;
	return node->payload.bytes;
}
void ap_arena_Numbers32_destroy(struct ap_c_arena *arena)
{
	if (arena) { ap_release(arena, NULL); arena->status = 0; arena->depth = 0; }
}
static const struct ap_data_Numbers32 *ap_step_Numbers32(const struct ap_data_Numbers32 *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		return NULL;
	case 1:
		if (!node->fields.c1.f1) *valid = 0;
		return node->fields.c1.f1;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Numbers32(const struct ap_data_Numbers32 *node)
{
	const struct ap_data_Numbers32 *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Numbers32(slow, &valid);
		fast = ap_step_Numbers32(fast, &valid);
		if (fast && valid) fast = ap_step_Numbers32(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Numbers32(const struct ap_data_Numbers32 *input, int32_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Numbers32(input)) return 2;
	size_t count = 0;
	const struct ap_data_Numbers32 *node = input;
	while (node->tag == 1) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c1.f1;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c1.f0; node = node->fields.c1.f1;
	}
	*written = count;
	return 0;
}
int ap_from_Numbers32(struct ap_c_arena *arena, const int32_t *input, size_t count, const struct ap_data_Numbers32 **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Numbers32 *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Numbers32){.tag = 0};
	const struct ap_data_Numbers32 *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Numbers32){.tag = 1, .fields.c1 = {.f0 = input[count], .f1 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static const struct ap_data_Numbers64 *ap_step_Numbers64(const struct ap_data_Numbers64 *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		if (!node->fields.c0.f0) *valid = 0;
		return node->fields.c0.f0;
	case 1:
		return NULL;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Numbers64(const struct ap_data_Numbers64 *node)
{
	const struct ap_data_Numbers64 *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Numbers64(slow, &valid);
		fast = ap_step_Numbers64(fast, &valid);
		if (fast && valid) fast = ap_step_Numbers64(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Numbers64(const struct ap_data_Numbers64 *input, int64_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Numbers64(input)) return 2;
	size_t count = 0;
	const struct ap_data_Numbers64 *node = input;
	while (node->tag == 0) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c0.f0;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c0.f1; node = node->fields.c0.f0;
	}
	*written = count;
	return 0;
}
int ap_from_Numbers64(struct ap_c_arena *arena, const int64_t *input, size_t count, const struct ap_data_Numbers64 **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Numbers64 *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Numbers64){.tag = 1};
	const struct ap_data_Numbers64 *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Numbers64){.tag = 0, .fields.c0 = {.f1 = input[count], .f0 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static const struct ap_data_Numbers64 * c1(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c2(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c3(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c4(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static uint64_t c5(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Numbers64 * c6(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c7(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c8(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c9(struct ap_c_arena *arena);

static const struct ap_data_Numbers64 * c1(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c2(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c2(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c3(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c3(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1)); break;
	case 1: v1 = c9(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c4(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c5(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2;
	switch (v1) {
	case 0: v2 = c6(arena, a1); break;
	case 1: v2 = c7(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c5(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c6(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c3(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c7(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c3(arena, a2);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c8(arena, v1, a1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers64 * c8(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers64));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers64 *)v1 = (struct ap_data_Numbers64){.tag = UINT32_C(0), .fields.c0.f0 = a1, .fields.c0.f1 = (a2 <= INT64_MAX ? (int64_t)a2 : -1 - (int64_t)(UINT64_MAX - a2))};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c9(struct ap_c_arena *arena)
{
	(void)arena;
	const struct ap_data_Numbers64 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers64));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers64 *)v1 = (struct ap_data_Numbers64){.tag = UINT32_C(1)};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

int ap_export_known_drop64(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	if (!ap_validate_Numbers64(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c1(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}


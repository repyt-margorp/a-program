#pragma once
/* ABI 1: 0 success; 1 null output; 2 invalid tag input. Output must be writable. */
#include <stdint.h>
/* Recursive profile: 1 also null arena; 2 also null tail/cycle; 3 allocation;
	* 4 depth limit. Failures preserve output and roll back new allocations. */
#ifndef AP_C_NATIVE_ABI
#define AP_C_NATIVE_ABI 1
#elif AP_C_NATIVE_ABI != 1
#error incompatible_A_Program_native_ABI
#endif
struct ap_enum_Bool { uint32_t tag; };
#define AP_ENUM_Bool_C0 UINT32_C(0)
#define AP_ENUM_Bool_C1 UINT32_C(1)
struct ap_enum_Reverse { uint32_t tag; };
#define AP_ENUM_Reverse_C0 UINT32_C(0)
#define AP_ENUM_Reverse_C1 UINT32_C(1)
struct ap_data_Numbers32 { uint32_t tag; union {
	struct { int32_t f0; const struct ap_data_Numbers32 * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers32_C0 UINT32_C(0)
#define AP_DATA_Numbers32_C1 UINT32_C(1)
struct ap_data_Numbers64 { uint32_t tag; union {
	struct { const struct ap_data_Numbers64 * f0; int64_t f1; } c0;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers64_C0 UINT32_C(0)
#define AP_DATA_Numbers64_C1 UINT32_C(1)
#ifdef __cplusplus
extern "C" {
#endif
#include <stddef.h>
#ifndef AP_C_ARENA_ABI
#define AP_C_ARENA_ABI 1
struct ap_c_allocation;
/* Zero initialize. Borrowed input nodes outlive every result sharing them.
	* Result storage is separate from inputs and arena metadata.
	* capacity 0 is unlimited; depth_limit 0 selects 256, maximum 256. */
struct ap_c_arena { struct ap_c_allocation *first; size_t count, capacity, depth, depth_limit; int status; };
#elif AP_C_ARENA_ABI != 1
#error incompatible_A_Program_arena_ABI
#endif
void ap_arena_Numbers32_destroy(struct ap_c_arena *);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers32(const struct ap_data_Numbers32 *, int32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers32(struct ap_c_arena *, const int32_t *, size_t count, const struct ap_data_Numbers32 **out);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers64(const struct ap_data_Numbers64 *, int64_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers64(struct ap_c_arena *, const int64_t *, size_t count, const struct ap_data_Numbers64 **out);
int ap_export_known_keep32(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, const struct ap_data_Numbers32 * *out);
#ifdef __cplusplus
}
#endif

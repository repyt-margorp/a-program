/* A Program native realization of admitted pure total computations. */
#include <stdint.h>
#include <limits.h>
_Static_assert(sizeof(int) <= sizeof(uint32_t), "unsupported integer promotion model");

#include <stdlib.h>
struct ap_enum_Bool { uint32_t tag; };
#define AP_ENUM_Bool_C0 UINT32_C(0)
#define AP_ENUM_Bool_C1 UINT32_C(1)
/* Nat: zero = 0, successor = checked increment; status 5 on overflow. */
struct ap_data_Numbers32 { uint32_t tag; union {
	struct { int32_t f0; const struct ap_data_Numbers32 * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers32_C0 UINT32_C(0)
#define AP_DATA_Numbers32_C1 UINT32_C(1)
struct ap_data_Numbers64 { uint32_t tag; union {
	struct { const struct ap_data_Numbers64 * f0; int64_t f1; } c0;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers64_C0 UINT32_C(0)
#define AP_DATA_Numbers64_C1 UINT32_C(1)
struct ap_data_Naturals { uint32_t tag; union {
	struct { uint32_t f0; const struct ap_data_Naturals * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Naturals_C0 UINT32_C(0)
#define AP_DATA_Naturals_C1 UINT32_C(1)
#include <stddef.h>
#ifndef AP_C_ARENA_ABI
#define AP_C_ARENA_ABI 1
struct ap_c_allocation;
/* Zero initialize. Borrowed input nodes outlive every result sharing them.
	* Result storage is separate from inputs and arena metadata.
	* capacity 0 is unlimited; depth_limit 0 selects 256, maximum 256. */
struct ap_c_arena { struct ap_c_allocation *first; size_t count, capacity, depth, depth_limit; int status; };
#elif AP_C_ARENA_ABI != 1
#error incompatible_A_Program_arena_ABI
#endif
void ap_arena_Nat_destroy(struct ap_c_arena *);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers32(const struct ap_data_Numbers32 *, int32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers32(struct ap_c_arena *, const int32_t *, size_t count, const struct ap_data_Numbers32 **out);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers64(const struct ap_data_Numbers64 *, int64_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers64(struct ap_c_arena *, const int64_t *, size_t count, const struct ap_data_Numbers64 **out);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Naturals(const struct ap_data_Naturals *, uint32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Naturals(struct ap_c_arena *, const uint32_t *, size_t count, const struct ap_data_Naturals **out);
struct ap_c_allocation { struct ap_c_allocation *next; union { max_align_t alignment; unsigned char bytes[1]; } payload; };
static void ap_release(struct ap_c_arena *arena, struct ap_c_allocation *mark)
{
	while (arena->first != mark) {
		struct ap_c_allocation *node = arena->first;
		arena->first = node->next; free(node); --arena->count;
	}
}
static void *ap_allocate(struct ap_c_arena *arena, size_t size)
{
	if (arena->status) return NULL;
	if (size > SIZE_MAX - sizeof(struct ap_c_allocation) || arena->count == SIZE_MAX ||
		(arena->capacity && arena->count >= arena->capacity)) { arena->status = 3; return NULL; }
	struct ap_c_allocation *node = malloc(sizeof(*node) + size);
	if (!node) { arena->status = 3; return NULL; }
	node->next = arena->first; arena->first = node; ++arena->count;
	return node->payload.bytes;
}
void ap_arena_Nat_destroy(struct ap_c_arena *arena)
{
	if (arena) { ap_release(arena, NULL); arena->status = 0; arena->depth = 0; }
}
static const struct ap_data_Numbers32 *ap_step_Numbers32(const struct ap_data_Numbers32 *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		return NULL;
	case 1:
		if (!node->fields.c1.f1) *valid = 0;
		return node->fields.c1.f1;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Numbers32(const struct ap_data_Numbers32 *node)
{
	const struct ap_data_Numbers32 *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Numbers32(slow, &valid);
		fast = ap_step_Numbers32(fast, &valid);
		if (fast && valid) fast = ap_step_Numbers32(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Numbers32(const struct ap_data_Numbers32 *input, int32_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Numbers32(input)) return 2;
	size_t count = 0;
	const struct ap_data_Numbers32 *node = input;
	while (node->tag == 1) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c1.f1;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c1.f0; node = node->fields.c1.f1;
	}
	*written = count;
	return 0;
}
int ap_from_Numbers32(struct ap_c_arena *arena, const int32_t *input, size_t count, const struct ap_data_Numbers32 **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Numbers32 *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Numbers32){.tag = 0};
	const struct ap_data_Numbers32 *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Numbers32){.tag = 1, .fields.c1 = {.f0 = input[count], .f1 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static const struct ap_data_Numbers64 *ap_step_Numbers64(const struct ap_data_Numbers64 *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		if (!node->fields.c0.f0) *valid = 0;
		return node->fields.c0.f0;
	case 1:
		return NULL;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Numbers64(const struct ap_data_Numbers64 *node)
{
	const struct ap_data_Numbers64 *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Numbers64(slow, &valid);
		fast = ap_step_Numbers64(fast, &valid);
		if (fast && valid) fast = ap_step_Numbers64(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Numbers64(const struct ap_data_Numbers64 *input, int64_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Numbers64(input)) return 2;
	size_t count = 0;
	const struct ap_data_Numbers64 *node = input;
	while (node->tag == 0) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c0.f0;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c0.f1; node = node->fields.c0.f0;
	}
	*written = count;
	return 0;
}
int ap_from_Numbers64(struct ap_c_arena *arena, const int64_t *input, size_t count, const struct ap_data_Numbers64 **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Numbers64 *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Numbers64){.tag = 1};
	const struct ap_data_Numbers64 *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Numbers64){.tag = 0, .fields.c0 = {.f1 = input[count], .f0 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static const struct ap_data_Naturals *ap_step_Naturals(const struct ap_data_Naturals *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		return NULL;
	case 1:
		if (!node->fields.c1.f1) *valid = 0;
		return node->fields.c1.f1;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Naturals(const struct ap_data_Naturals *node)
{
	const struct ap_data_Naturals *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Naturals(slow, &valid);
		fast = ap_step_Naturals(fast, &valid);
		if (fast && valid) fast = ap_step_Naturals(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Naturals(const struct ap_data_Naturals *input, uint32_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Naturals(input)) return 2;
	size_t count = 0;
	const struct ap_data_Naturals *node = input;
	while (node->tag == 1) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c1.f1;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c1.f0; node = node->fields.c1.f1;
	}
	*written = count;
	return 0;
}
int ap_from_Naturals(struct ap_c_arena *arena, const uint32_t *input, size_t count, const struct ap_data_Naturals **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Naturals *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Naturals){.tag = 0};
	const struct ap_data_Naturals *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Naturals){.tag = 1, .fields.c1 = {.f0 = input[count], .f1 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static const struct ap_data_Numbers32 * c1(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c2(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c3(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c4(struct ap_c_arena *arena);
static const struct ap_data_Numbers32 * c5(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static uint64_t c6(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Numbers32 * c7(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c8(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c9(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c10(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c11(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c12(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c13(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static uint64_t c14(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Numbers32 * c15(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static const struct ap_data_Numbers32 * c16(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c17(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c18(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c19(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c20(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static uint64_t c21(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Numbers64 * c22(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c23(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c24(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c25(struct ap_c_arena *arena);
static const struct ap_data_Numbers64 * c26(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c27(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c28(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c29(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static uint64_t c30(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Numbers64 * c31(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static const struct ap_data_Numbers64 * c32(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers32 * c33(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c34(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c35(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c36(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static uint64_t c37(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c38(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c39(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers64 * c40(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c41(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c42(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c43(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3);
static uint64_t c44(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers64 * c45(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c46(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3);
static const struct ap_data_Numbers32 * c47(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static const struct ap_data_Numbers32 * c48(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static const struct ap_data_Numbers32 * c49(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c50(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3, uint64_t a4);
static uint64_t c51(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c52(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c53(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3, uint64_t a4);
static const struct ap_data_Numbers64 * c54(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3);
static const struct ap_data_Numbers64 * c55(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3);
static const struct ap_data_Numbers64 * c56(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers64 * c57(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3, uint64_t a4);
static uint64_t c58(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers64 * c59(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers64 * c60(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3, uint64_t a4);
static uint64_t c61(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static uint64_t c62(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static uint64_t c63(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1);
static uint64_t c64(struct ap_c_arena *arena);
static uint64_t c65(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static uint64_t c66(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static uint64_t c67(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static uint64_t c68(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1);
static uint64_t c69(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c70(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c71(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c72(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c73(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static uint64_t c74(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c75(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c76(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c77(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c78(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c79(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c80(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c81(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static const struct ap_data_Numbers32 * c82(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c83(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static uint64_t c84(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c85(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c86(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c87(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c88(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c89(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c90(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c91(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static uint64_t c92(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers64 * c93(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c94(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2);
static const struct ap_data_Numbers64 * c95(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2);
static const struct ap_data_Numbers64 * c96(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3);
static uint64_t c97(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c98(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c99(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3);
static const struct ap_data_Numbers32 * c100(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Numbers32 * c101(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3, uint64_t a4);
static uint64_t c102(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c103(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c104(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c105(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c106(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2);
static const struct ap_data_Numbers32 * c107(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c108(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3);
static uint64_t c109(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Numbers32 * c110(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2);
static const struct ap_data_Numbers32 * c111(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3);
static const struct ap_data_Naturals * c112(struct ap_c_arena *arena, const struct ap_data_Naturals * a1);
static const struct ap_data_Naturals * c113(struct ap_c_arena *arena, const struct ap_data_Naturals * a1);
static const struct ap_data_Naturals * c114(struct ap_c_arena *arena, const struct ap_data_Naturals * a1);
static const struct ap_data_Naturals * c115(struct ap_c_arena *arena);
static const struct ap_data_Naturals * c116(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2);
static uint64_t c117(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c118(struct ap_c_arena *arena);
static uint64_t c119(struct ap_c_arena *arena, uint64_t a1);
static const struct ap_data_Naturals * c120(struct ap_c_arena *arena, const struct ap_data_Naturals * a1);
static const struct ap_data_Naturals * c121(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2);
static const struct ap_data_Naturals * c122(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2);
static const struct ap_data_Naturals * c123(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2);
static const struct ap_data_Naturals * c124(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2);
static const struct ap_data_Naturals * c125(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2);
static const struct ap_data_Naturals * c126(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2, uint64_t a3);
static uint64_t c127(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c128(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c129(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c130(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c131(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static const struct ap_data_Naturals * c132(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2);
static const struct ap_data_Naturals * c133(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2, uint64_t a3);

static const struct ap_data_Numbers32 * c1(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c2(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c2(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c3(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c3(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c5(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c4(struct ap_c_arena *arena)
{
	(void)arena;
	const struct ap_data_Numbers32 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers32));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers32 *)v1 = (struct ap_data_Numbers32){.tag = UINT32_C(0)};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c5(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c6(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c7(arena, a2); break;
	case 1: v2 = c8(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c6(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c7(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c3(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c8(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c3(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers32 * c9(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers32));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers32 *)v1 = (struct ap_data_Numbers32){.tag = UINT32_C(1), .fields.c1.f0 = (a1 <= INT32_MAX ? (int32_t)a1 : -1 - (int32_t)(UINT32_MAX - a1)), .fields.c1.f1 = a2};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c10(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c11(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c11(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c12(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c12(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c13(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c13(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c14(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c15(arena, a2); break;
	case 1: v2 = c16(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c14(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c15(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers32 * v1 = c12(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c16(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c12(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers64 * c17(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c18(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c18(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c19(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c19(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c20(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1)); break;
	case 1: v1 = c25(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c20(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c21(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2;
	switch (v1) {
	case 0: v2 = c22(arena, a1); break;
	case 1: v2 = c23(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c21(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c22(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c19(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c23(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c19(arena, a2);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c24(arena, v1, a1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers64 * c24(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers64));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers64 *)v1 = (struct ap_data_Numbers64){.tag = UINT32_C(0), .fields.c0.f0 = a1, .fields.c0.f1 = (a2 <= INT64_MAX ? (int64_t)a2 : -1 - (int64_t)(UINT64_MAX - a2))};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c25(struct ap_c_arena *arena)
{
	(void)arena;
	const struct ap_data_Numbers64 * v1 = ap_allocate(arena, sizeof(struct ap_data_Numbers64));
	if (!v1) { return 0; }
	*(struct ap_data_Numbers64 *)v1 = (struct ap_data_Numbers64){.tag = UINT32_C(1)};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c26(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c27(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c27(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c28(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c28(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c29(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1)); break;
	case 1: v1 = c25(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c29(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c30(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2;
	switch (v1) {
	case 0: v2 = c31(arena, a1); break;
	case 1: v2 = c32(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c30(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c31(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Numbers64 * v1 = c28(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c32(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c28(arena, a2);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c24(arena, v1, a1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers32 * c33(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c34(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c34(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c35(arena, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c35(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c36(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c36(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c37(arena, a1, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c38(arena, a2, a3); break;
	case 1: v2 = c39(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c37(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	return a2;
}

static const struct ap_data_Numbers32 * c38(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c35(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c39(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c35(arena, a1, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers64 * c40(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c41(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c41(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c42(arena, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c42(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c43(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1), a2); break;
	case 1: v1 = c25(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c43(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c44(arena, a2, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2;
	switch (v1) {
	case 0: v2 = c45(arena, a1, a3); break;
	case 1: v2 = c46(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c44(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	return a2;
}

static const struct ap_data_Numbers64 * c45(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c42(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c46(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers64 * v1 = c42(arena, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c24(arena, v1, a1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers32 * c47(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c48(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c48(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c49(arena, a2, a3, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c49(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c50(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c50(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3, uint64_t a4)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	(void)a4;
	uint64_t v1 = (uint32_t)(c51(arena, a3, a1, a4));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c52(arena, a2, a4, a3); break;
	case 1: v2 = c53(arena, a2, a1, a4, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c51(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	return a1;
}

static const struct ap_data_Numbers32 * c52(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c49(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c53(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3, uint64_t a4)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	(void)a4;
	const struct ap_data_Numbers32 * v1 = c49(arena, a1, a3, a4);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers64 * c54(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers64 * v1 = c55(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c55(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers64 * v1 = c56(arena, a2, a3, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c56(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c57(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1), a3, a2); break;
	case 1: v1 = c25(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c57(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3, uint64_t a4)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	(void)a4;
	uint64_t v1 = (uint32_t)(c58(arena, a3, a2, a4));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2;
	switch (v1) {
	case 0: v2 = c59(arena, a1, a4, a3); break;
	case 1: v2 = c60(arena, a2, a1, a4, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c58(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	return a1;
}

static const struct ap_data_Numbers64 * c59(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers64 * v1 = c56(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c60(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2, uint64_t a3, uint64_t a4)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	(void)a4;
	const struct ap_data_Numbers64 * v1 = c56(arena, a2, a3, a4);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c24(arena, v1, a1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c61(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c62(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c62(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c63(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c63(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1->tag) {
	case 0: v1 = c64(arena); break;
	case 1: v1 = c65(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c64(struct ap_c_arena *arena)
{
	(void)arena;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c65(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c63(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c66(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c67(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c67(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c68(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c68(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1->tag) {
	case 0: v1 = c69(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1)); break;
	case 1: v1 = c64(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c69(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c68(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static const struct ap_data_Numbers32 * c70(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c71(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c71(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c72(arena, a3, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c72(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c73(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c73(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c74(arena, a1, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c77(arena, a2, a3); break;
	case 1: v2 = c78(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c74(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c75(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c75(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c76(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c76(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	return a2;
}

static const struct ap_data_Numbers32 * c77(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c72(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c78(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c72(arena, a1, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers32 * c79(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c80(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c80(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c81(arena, a2, a3, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c81(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c82(arena, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c82(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c83(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c83(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c84(arena, a1, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c86(arena, a2, a3); break;
	case 1: v2 = c87(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c84(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c85(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c85(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	return a2;
}

static const struct ap_data_Numbers32 * c86(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c82(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c87(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c82(arena, a1, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Numbers32 * c88(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c89(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c89(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c90(arena, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c90(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c91(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c91(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c90(arena, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c92(arena, a1, a3));
	(void)v2;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v3 = c9(arena, v2, v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c92(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c93(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c94(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c94(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers64 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1 = c95(arena, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers64 * c95(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers64 * v1;
	switch (a1->tag) {
	case 0: v1 = c96(arena, a1->fields.c0.f0, (uint64_t)(a1->fields.c0.f1), a2); break;
	case 1: v1 = c25(arena); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers64 * c96(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint64_t)(c97(arena, a2, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v2 = c95(arena, a1, a3);
	(void)v2;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers64 * v3 = c24(arena, v2, v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c97(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(a1 + a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c98(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c99(arena, a1, a2, a3);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c99(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers32 * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c100(arena, a3, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c100(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c101(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c101(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3, uint64_t a4)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	(void)a4;
	const struct ap_data_Numbers32 * v1 = c100(arena, a2, a4, a3);
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c102(arena, a1, a4, a3));
	(void)v2;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v3 = c9(arena, v2, v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c102(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c103(arena, a1, a3, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c103(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c104(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(v1 + a3);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c104(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c105(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c106(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c106(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c107(arena, a2, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c107(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c108(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Numbers32 * c108(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers32 * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c109(arena, a1, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2;
	switch (v1) {
	case 0: v2 = c110(arena, a2, a3); break;
	case 1: v2 = c111(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c109(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	return a2;
}

static const struct ap_data_Numbers32 * c110(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Numbers32 * v1 = c107(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Numbers32 * c111(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Numbers32 * v1 = c107(arena, a1, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Numbers32 * v2 = c9(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Naturals * c112(struct ap_c_arena *arena, const struct ap_data_Naturals * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Naturals * v1 = c113(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c113(struct ap_c_arena *arena, const struct ap_data_Naturals * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Naturals * v1 = c114(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c114(struct ap_c_arena *arena, const struct ap_data_Naturals * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	const struct ap_data_Naturals * v1;
	switch (a1->tag) {
	case 0: v1 = c115(arena); break;
	case 1: v1 = c116(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Naturals * c115(struct ap_c_arena *arena)
{
	(void)arena;
	const struct ap_data_Naturals * v1 = ap_allocate(arena, sizeof(struct ap_data_Naturals));
	if (!v1) { return 0; }
	*(struct ap_data_Naturals *)v1 = (struct ap_data_Naturals){.tag = UINT32_C(0)};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c116(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c117(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Naturals * v2;
	switch (v1) {
	case 0: v2 = c120(arena, a2); break;
	case 1: v2 = c121(arena, a2, a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c117(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c118(arena); break;
	case 1: v1 = c119(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c118(struct ap_c_arena *arena)
{
	(void)arena;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c119(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c120(struct ap_c_arena *arena, const struct ap_data_Naturals * a1)
{
	(void)arena;
	(void)a1;
	const struct ap_data_Naturals * v1 = c114(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c121(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1 = c114(arena, a1);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Naturals * v2 = c122(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static const struct ap_data_Naturals * c122(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1 = ap_allocate(arena, sizeof(struct ap_data_Naturals));
	if (!v1) { return 0; }
	*(struct ap_data_Naturals *)v1 = (struct ap_data_Naturals){.tag = UINT32_C(1), .fields.c1.f0 = a1, .fields.c1.f1 = a2};
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c123(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1 = c124(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c124(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1 = c125(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c125(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1;
	switch (a1->tag) {
	case 0: v1 = c115(arena); break;
	case 1: v1 = c126(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static const struct ap_data_Naturals * c126(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Naturals * a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c127(arena, a1, a3));
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Naturals * v2;
	switch (v1) {
	case 0: v2 = c132(arena, a2, a3); break;
	case 1: v2 = c133(arena, a2, a1, a3); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c127(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c128(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c128(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c129(arena, a2); break;
	case 1: v1 = c130(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c129(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(UINT64_C(0x1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c130(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a2 == 0 ? 0 : 1) {
	case 0: v1 = c118(arena); break;
	case 1: v1 = c131(arena, (a2 - UINT32_C(1)), a1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c131(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c128(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c132(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	const struct ap_data_Naturals * v1 = c125(arena, a1, a2);
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static const struct ap_data_Naturals * c133(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	const struct ap_data_Naturals * v1 = c125(arena, a1, a3);
	(void)v1;
	if (arena->status) { return 0; }
	const struct ap_data_Naturals * v2 = c122(arena, a2, v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

int ap_export_known_keep32(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers32(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c1(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_known_drop32(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers32(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c10(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_known_keep64(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers64(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c17(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_known_drop64(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers64(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c26(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_captured_filter32(struct ap_c_arena *arena, struct ap_enum_Bool a1, const struct ap_data_Numbers32 * a2, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers32(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c33(arena, (uint32_t)a1.tag, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_captured_filter64(struct ap_c_arena *arena, struct ap_enum_Bool a1, const struct ap_data_Numbers64 * a2, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers64(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c40(arena, (uint32_t)a1.tag, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_captured_select32(struct ap_c_arena *arena, struct ap_enum_Bool a1, const struct ap_data_Numbers32 * a2, int32_t a3, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers32(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c47(arena, (uint32_t)a1.tag, a2, (uint32_t)a3);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_captured_select64(struct ap_c_arena *arena, struct ap_enum_Bool a1, const struct ap_data_Numbers64 * a2, int64_t a3, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers64(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c54(arena, (uint32_t)a1.tag, a2, (uint64_t)a3);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_length32(struct ap_c_arena *arena, const struct ap_data_Numbers32 * a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers32(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c61(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_length64(struct ap_c_arena *arena, const struct ap_data_Numbers64 * a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers64(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c66(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_chain_filter32(struct ap_c_arena *arena, struct ap_enum_Bool a1, struct ap_enum_Bool a2, const struct ap_data_Numbers32 * a3, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if ((uint64_t)a2.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers32(a3)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c70(arena, (uint32_t)a1.tag, (uint32_t)a2.tag, a3);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_shadow_filter32(struct ap_c_arena *arena, struct ap_enum_Bool a1, struct ap_enum_Bool a2, const struct ap_data_Numbers32 * a3, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if ((uint64_t)a2.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers32(a3)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c79(arena, (uint32_t)a1.tag, (uint32_t)a2.tag, a3);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_shift32(struct ap_c_arena *arena, int32_t a1, const struct ap_data_Numbers32 * a2, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers32(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c88(arena, (uint32_t)a1, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_shift64(struct ap_c_arena *arena, int64_t a1, const struct ap_data_Numbers64 * a2, const struct ap_data_Numbers64 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers64(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers64 * result = c93(arena, (uint64_t)a1, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_chain_map32(struct ap_c_arena *arena, int32_t a1, int32_t a2, const struct ap_data_Numbers32 * a3, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Numbers32(a3)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c98(arena, (uint32_t)a1, (uint32_t)a2, a3);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_unused_effect(struct ap_c_arena *arena, struct ap_enum_Bool a1, const struct ap_data_Numbers32 * a2, const struct ap_data_Numbers32 * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	if (!ap_validate_Numbers32(a2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Numbers32 * result = c105(arena, (uint32_t)a1.tag, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_known_filter_nat(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, const struct ap_data_Naturals * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Naturals(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Naturals * result = c112(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}

int ap_export_known_select_nat(struct ap_c_arena *arena, const struct ap_data_Naturals * a1, uint32_t a2, const struct ap_data_Naturals * *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers32;
	(void)ap_validate_Numbers64;
	(void)ap_validate_Naturals;
	if (!ap_validate_Naturals(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	const struct ap_data_Naturals * result = c123(arena, a1, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}


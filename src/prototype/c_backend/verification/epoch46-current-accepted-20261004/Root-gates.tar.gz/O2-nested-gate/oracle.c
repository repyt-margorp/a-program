#include "component.h"
#include <assert.h>
int main(void) { struct ap_c_arena arena = {0}; int32_t out32; int64_t out64;
assert(!ap_export_count(&arena, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_sum(&arena, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_known(&arena, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_unused(&arena, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_twice(&arena, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){0}, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){1}, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_seed32(&arena, -1, 0, &out32) && out32 == INT64_C(-1));
assert(!ap_export_nested_seed64(&arena, -1, 0, &out64) && out64 == INT64_C(-1));
assert(!ap_export_nested_curried(&arena, 0, -1, &out32) && out32 == INT64_C(-1));
assert(!ap_export_nested_seed32(&arena, 0, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_seed64(&arena, 0, 0, &out64) && out64 == INT64_C(0));
assert(!ap_export_nested_curried(&arena, 0, 0, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_seed32(&arena, 1, 0, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_seed64(&arena, 1, 0, &out64) && out64 == INT64_C(1));
assert(!ap_export_nested_curried(&arena, 0, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_count(&arena, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_sum(&arena, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_known(&arena, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_unused(&arena, 1, &out32) && out32 == INT64_C(7));
assert(!ap_export_nested_twice(&arena, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){0}, 1, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){1}, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_seed32(&arena, -1, 1, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_seed64(&arena, -1, 1, &out64) && out64 == INT64_C(-2));
assert(!ap_export_nested_curried(&arena, 1, -1, &out32) && out32 == INT64_C(0));
assert(!ap_export_nested_seed32(&arena, 0, 1, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_seed64(&arena, 0, 1, &out64) && out64 == INT64_C(0));
assert(!ap_export_nested_curried(&arena, 1, 0, &out32) && out32 == INT64_C(1));
assert(!ap_export_nested_seed32(&arena, 1, 1, &out32) && out32 == INT64_C(2));
assert(!ap_export_nested_seed64(&arena, 1, 1, &out64) && out64 == INT64_C(2));
assert(!ap_export_nested_curried(&arena, 1, 1, &out32) && out32 == INT64_C(2));
assert(!ap_export_count(&arena, 2, &out32) && out32 == INT64_C(2));
assert(!ap_export_nested_sum(&arena, 2, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_known(&arena, 2, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_unused(&arena, 2, &out32) && out32 == INT64_C(7));
assert(!ap_export_nested_twice(&arena, 2, &out32) && out32 == INT64_C(4));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){0}, 2, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){1}, 2, &out32) && out32 == INT64_C(2));
assert(!ap_export_nested_seed32(&arena, -1, 2, &out32) && out32 == INT64_C(2));
assert(!ap_export_nested_seed64(&arena, -1, 2, &out64) && out64 == INT64_C(-4));
assert(!ap_export_nested_curried(&arena, 2, -1, &out32) && out32 == INT64_C(2));
assert(!ap_export_nested_seed32(&arena, 0, 2, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_seed64(&arena, 0, 2, &out64) && out64 == INT64_C(0));
assert(!ap_export_nested_curried(&arena, 2, 0, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_seed32(&arena, 1, 2, &out32) && out32 == INT64_C(4));
assert(!ap_export_nested_seed64(&arena, 1, 2, &out64) && out64 == INT64_C(4));
assert(!ap_export_nested_curried(&arena, 2, 1, &out32) && out32 == INT64_C(4));
assert(!ap_export_count(&arena, 3, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_sum(&arena, 3, &out32) && out32 == INT64_C(6));
assert(!ap_export_nested_known(&arena, 3, &out32) && out32 == INT64_C(6));
assert(!ap_export_nested_unused(&arena, 3, &out32) && out32 == INT64_C(7));
assert(!ap_export_nested_twice(&arena, 3, &out32) && out32 == INT64_C(11));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){0}, 3, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){1}, 3, &out32) && out32 == INT64_C(3));
assert(!ap_export_nested_seed32(&arena, -1, 3, &out32) && out32 == INT64_C(5));
assert(!ap_export_nested_seed64(&arena, -1, 3, &out64) && out64 == INT64_C(-7));
assert(!ap_export_nested_curried(&arena, 3, -1, &out32) && out32 == INT64_C(5));
assert(!ap_export_nested_seed32(&arena, 0, 3, &out32) && out32 == INT64_C(6));
assert(!ap_export_nested_seed64(&arena, 0, 3, &out64) && out64 == INT64_C(0));
assert(!ap_export_nested_curried(&arena, 3, 0, &out32) && out32 == INT64_C(6));
assert(!ap_export_nested_seed32(&arena, 1, 3, &out32) && out32 == INT64_C(7));
assert(!ap_export_nested_seed64(&arena, 1, 3, &out64) && out64 == INT64_C(7));
assert(!ap_export_nested_curried(&arena, 3, 1, &out32) && out32 == INT64_C(7));
assert(!ap_export_count(&arena, 4, &out32) && out32 == INT64_C(4));
assert(!ap_export_nested_sum(&arena, 4, &out32) && out32 == INT64_C(10));
assert(!ap_export_nested_known(&arena, 4, &out32) && out32 == INT64_C(10));
assert(!ap_export_nested_unused(&arena, 4, &out32) && out32 == INT64_C(7));
assert(!ap_export_nested_twice(&arena, 4, &out32) && out32 == INT64_C(26));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){0}, 4, &out32) && out32 == INT64_C(0));
assert(!ap_export_branch_sum(&arena, (struct ap_enum_Bool){1}, 4, &out32) && out32 == INT64_C(4));
assert(!ap_export_nested_seed32(&arena, -1, 4, &out32) && out32 == INT64_C(9));
assert(!ap_export_nested_seed64(&arena, -1, 4, &out64) && out64 == INT64_C(-11));
assert(!ap_export_nested_curried(&arena, 4, -1, &out32) && out32 == INT64_C(9));
assert(!ap_export_nested_seed32(&arena, 0, 4, &out32) && out32 == INT64_C(10));
assert(!ap_export_nested_seed64(&arena, 0, 4, &out64) && out64 == INT64_C(0));
assert(!ap_export_nested_curried(&arena, 4, 0, &out32) && out32 == INT64_C(10));
assert(!ap_export_nested_seed32(&arena, 1, 4, &out32) && out32 == INT64_C(11));
assert(!ap_export_nested_seed64(&arena, 1, 4, &out64) && out64 == INT64_C(11));
assert(!ap_export_nested_curried(&arena, 4, 1, &out32) && out32 == INT64_C(11));
{ int32_t a[3] = {0,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 0, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 1, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 1, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 1, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 2, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,-1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-3)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,-1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,-1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,0,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,0,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,0,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,1,-1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,-1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,0,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,1,0}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,-1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(-1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,-1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,-1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,0,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(0)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,0,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,0,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {-1,1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(1)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {0,1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(2)); ap_arena_Nat_destroy(&arena); }
{ int32_t a[3] = {1,1,1}; const struct ap_data_Numbers *input; assert(!ap_from_Numbers(&arena, a, 3, &input));
assert(!ap_export_nested_list(&arena, input, &out32) && out32 == INT64_C(3)); ap_arena_Nat_destroy(&arena); }
ap_arena_Nat_destroy(&arena); return 0; }

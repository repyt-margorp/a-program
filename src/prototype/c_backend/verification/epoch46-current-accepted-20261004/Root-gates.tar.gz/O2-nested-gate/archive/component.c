/* A Program native realization of admitted pure total computations. */
#include <stdint.h>
#include <limits.h>
_Static_assert(sizeof(int) <= sizeof(uint32_t), "unsupported integer promotion model");

#include <stdlib.h>
struct ap_enum_Bool { uint32_t tag; };
#define AP_ENUM_Bool_C0 UINT32_C(0)
#define AP_ENUM_Bool_C1 UINT32_C(1)
/* Nat: zero = 0, successor = checked increment; status 5 on overflow. */
struct ap_data_Numbers { uint32_t tag; union {
	struct { int32_t f0; const struct ap_data_Numbers * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers_C0 UINT32_C(0)
#define AP_DATA_Numbers_C1 UINT32_C(1)
#include <stddef.h>
#ifndef AP_C_ARENA_ABI
#define AP_C_ARENA_ABI 1
struct ap_c_allocation;
/* Zero initialize. Borrowed input nodes outlive every result sharing them.
	* Result storage is separate from inputs and arena metadata.
	* capacity 0 is unlimited; depth_limit 0 selects 256, maximum 256. */
struct ap_c_arena { struct ap_c_allocation *first; size_t count, capacity, depth, depth_limit; int status; };
#elif AP_C_ARENA_ABI != 1
#error incompatible_A_Program_arena_ABI
#endif
void ap_arena_Nat_destroy(struct ap_c_arena *);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers(const struct ap_data_Numbers *, int32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers(struct ap_c_arena *, const int32_t *, size_t count, const struct ap_data_Numbers **out);
struct ap_c_allocation { struct ap_c_allocation *next; union { max_align_t alignment; unsigned char bytes[1]; } payload; };
static void ap_release(struct ap_c_arena *arena, struct ap_c_allocation *mark)
{
	while (arena->first != mark) {
		struct ap_c_allocation *node = arena->first;
		arena->first = node->next; free(node); --arena->count;
	}
}
static void *ap_allocate(struct ap_c_arena *arena, size_t size)
{
	if (arena->status) return NULL;
	if (size > SIZE_MAX - sizeof(struct ap_c_allocation) || arena->count == SIZE_MAX ||
		(arena->capacity && arena->count >= arena->capacity)) { arena->status = 3; return NULL; }
	struct ap_c_allocation *node = malloc(sizeof(*node) + size);
	if (!node) { arena->status = 3; return NULL; }
	node->next = arena->first; arena->first = node; ++arena->count;
	return node->payload.bytes;
}
void ap_arena_Nat_destroy(struct ap_c_arena *arena)
{
	if (arena) { ap_release(arena, NULL); arena->status = 0; arena->depth = 0; }
}
static const struct ap_data_Numbers *ap_step_Numbers(const struct ap_data_Numbers *node, int *valid)
{
	if (!node) { *valid = 0; return NULL; }
	switch (node->tag) {
	case 0:
		return NULL;
	case 1:
		if (!node->fields.c1.f1) *valid = 0;
		return node->fields.c1.f1;
	default: *valid = 0; return NULL;
	}
}
static int ap_validate_Numbers(const struct ap_data_Numbers *node)
{
	const struct ap_data_Numbers *slow = node, *fast = node;
	int valid = 1;
	if (!node) return 0;
	while (fast && valid) {
		slow = ap_step_Numbers(slow, &valid);
		fast = ap_step_Numbers(fast, &valid);
		if (fast && valid) fast = ap_step_Numbers(fast, &valid);
		if (fast && slow == fast) return 0;
	}
	return valid;
}
int ap_copy_Numbers(const struct ap_data_Numbers *input, int32_t *buffer, size_t capacity, size_t *written)
{
	if (!written) return 1;
	if (!ap_validate_Numbers(input)) return 2;
	size_t count = 0;
	const struct ap_data_Numbers *node = input;
	while (node->tag == 1) {
		if (count == SIZE_MAX) return 6;
		++count; node = node->fields.c1.f1;
	}
	if (count > capacity) return 6;
	if (count && !buffer) return 1;
	node = input;
	for (size_t i = 0; i < count; ++i) {
		buffer[i] = node->fields.c1.f0; node = node->fields.c1.f1;
	}
	*written = count;
	return 0;
}
int ap_from_Numbers(struct ap_c_arena *arena, const int32_t *input, size_t count, const struct ap_data_Numbers **out)
{
	if (!arena || !out || (count && !input)) return 1;
	if (arena->depth) return 4;
	if (count == SIZE_MAX) return 6;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	struct ap_data_Numbers *node = ap_allocate(arena, sizeof(*node));
	if (node) *node = (struct ap_data_Numbers){.tag = 0};
	const struct ap_data_Numbers *result = node;
	while (count && !arena->status) {
		node = ap_allocate(arena, sizeof(*node));
		if (node) {
			--count;
			*node = (struct ap_data_Numbers){.tag = 1, .fields.c1 = {.f0 = input[count], .f1 = result}};
			result = node;
		}
	}
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result;
	return 0;
}
static uint64_t c1(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c2(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c3(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c4(struct ap_c_arena *arena);
static uint64_t c5(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c6(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c7(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c8(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c9(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c10(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c11(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c12(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c13(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c14(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c15(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c16(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c17(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c18(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c19(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c20(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c21(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c22(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c23(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c24(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c25(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c26(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c27(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c28(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c29(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c30(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c31(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c32(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c33(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c34(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c35(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c36(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c37(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c38(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c39(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c40(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c41(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c42(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c43(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c44(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c45(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c46(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c47(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c48(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c49(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c50(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3);
static uint64_t c51(struct ap_c_arena *arena, const struct ap_data_Numbers * a1);
static uint64_t c52(struct ap_c_arena *arena, const struct ap_data_Numbers * a1);
static uint64_t c53(struct ap_c_arena *arena, const struct ap_data_Numbers * a1);
static uint64_t c54(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers * a2);
static uint64_t c55(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c56(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers * a2, uint64_t a3);
static uint64_t c57(struct ap_c_arena *arena, const struct ap_data_Numbers * a1);
static uint64_t c58(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers * a3);
static uint64_t c59(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c60(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c61(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c62(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c63(struct ap_c_arena *arena);
static uint64_t c64(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c65(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c66(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c67(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c68(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c69(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);
static uint64_t c70(struct ap_c_arena *arena, uint64_t a1);
static uint64_t c71(struct ap_c_arena *arena, uint64_t a1, uint64_t a2);

static uint64_t c1(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c2(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c2(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c3(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c3(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c5(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c4(struct ap_c_arena *arena)
{
	(void)arena;
	uint64_t v1 = (uint32_t)(UINT64_C(0x0));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c5(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c3(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c6(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c7(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c7(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c8(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c8(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c9(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c9(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a2) {
	case 0: v1 = c10(arena, a1, a2); break;
	case 1: v1 = c11(arena, a1, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c10(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c8(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c11(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c8(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c12(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c13(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c13(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c14(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c14(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c15(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c15(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c16(arena, v1, a1));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c16(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c17(arena, a2); break;
	case 1: v1 = c18(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c17(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c14(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c18(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c16(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c19(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c20(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c20(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c21(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c21(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c22(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c22(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c23(arena, v1, a1));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c23(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c24(arena, a2); break;
	case 1: v1 = c26(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c24(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(0);
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c25(arena, v1, a1));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c25(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c21(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c26(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c23(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c27(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c28(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c28(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c29(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c29(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c30(arena, a2); break;
	case 1: v1 = c31(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c30(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	return a1;
}

static uint64_t c31(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c32(arena, v1, a1, a2));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c32(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c33(arena, a3, a2); break;
	case 1: v1 = c34(arena, (a1 - UINT32_C(1)), a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c33(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c29(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c34(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c32(arena, a1, a3, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c35(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(c36(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c36(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(c37(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c37(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c38(arena, a2); break;
	case 1: v1 = c39(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c38(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	return a1;
}

static uint64_t c39(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint64_t)(c40(arena, v1, a1, a2));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c40(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c41(arena, a3, a2); break;
	case 1: v1 = c42(arena, (a1 - UINT32_C(1)), a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c41(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint64_t)(c37(arena, a2, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c42(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint64_t)(c40(arena, a1, a3, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint64_t)(a2 + v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c43(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c44(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c44(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c45(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c45(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c46(arena, a2); break;
	case 1: v1 = c47(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c46(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	return a1;
}

static uint64_t c47(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c48(arena, v1, a2, a1));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c48(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c49(arena, a3, a2); break;
	case 1: v1 = c50(arena, (a1 - UINT32_C(1)), a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c49(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c45(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c50(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, uint64_t a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c48(arena, a1, a3, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c51(struct ap_c_arena *arena, const struct ap_data_Numbers * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c52(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c52(struct ap_c_arena *arena, const struct ap_data_Numbers * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c53(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c53(struct ap_c_arena *arena, const struct ap_data_Numbers * a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1->tag) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c54(arena, (uint32_t)(a1->fields.c1.f0), a1->fields.c1.f1); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c54(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers * a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(0);
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c55(arena, v1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(c56(arena, v2, a2, a1));
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

static uint64_t c55(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c56(struct ap_c_arena *arena, uint64_t a1, const struct ap_data_Numbers * a2, uint64_t a3)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c57(arena, a2); break;
	case 1: v1 = c58(arena, (a1 - UINT32_C(1)), a3, a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c57(struct ap_c_arena *arena, const struct ap_data_Numbers * a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c53(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c58(struct ap_c_arena *arena, uint64_t a1, uint64_t a2, const struct ap_data_Numbers * a3)
{
	(void)arena;
	(void)a1;
	(void)a2;
	(void)a3;
	uint64_t v1 = (uint32_t)(c56(arena, a1, a3, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(a2 + v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c59(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c60(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c60(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c61(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c61(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c62(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c62(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(0);
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2;
	switch (v1 == 0 ? 0 : 1) {
	case 0: v2 = c63(arena); break;
	case 1: v2 = c64(arena, (v1 - UINT32_C(1)), a1); break;
	default: abort();
	}
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c63(struct ap_c_arena *arena)
{
	(void)arena;
	uint64_t v1 = (uint32_t)(UINT64_C(0x7));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c64(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c61(arena, a2));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c65(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c66(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c66(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c67(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	return v1;
}

static uint64_t c67(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c4(arena); break;
	case 1: v1 = c68(arena, (a1 - UINT32_C(1))); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c68(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(a1 + UINT64_C(1));
	(void)v1;
	if (a1 == UINT32_MAX) { arena->status = 5; return 0; }
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(c69(arena, v1, a1));
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c69(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	if (arena->depth >= (arena->depth_limit ? arena->depth_limit : 256)) { arena->status = 4; return 0; }
	++arena->depth;
	(void)a1;
	(void)a2;
	uint64_t v1;
	switch (a1 == 0 ? 0 : 1) {
	case 0: v1 = c70(arena, a2); break;
	case 1: v1 = c71(arena, (a1 - UINT32_C(1)), a2); break;
	default: abort();
	}
	(void)v1;
	if (arena->status) { --arena->depth; return 0; }
	--arena->depth;
	return v1;
}

static uint64_t c70(struct ap_c_arena *arena, uint64_t a1)
{
	(void)arena;
	(void)a1;
	uint64_t v1 = (uint32_t)(c67(arena, a1));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(v1 + v1);
	(void)v2;
	if (arena->status) { return 0; }
	return v2;
}

static uint64_t c71(struct ap_c_arena *arena, uint64_t a1, uint64_t a2)
{
	(void)arena;
	(void)a1;
	(void)a2;
	uint64_t v1 = (uint32_t)(c69(arena, a1, a2));
	(void)v1;
	if (arena->status) { return 0; }
	uint64_t v2 = (uint32_t)(UINT64_C(0x1));
	(void)v2;
	if (arena->status) { return 0; }
	uint64_t v3 = (uint32_t)(v2 + v1);
	(void)v3;
	if (arena->status) { return 0; }
	return v3;
}

int ap_export_count(struct ap_c_arena *arena, uint32_t a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c1(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_branch_sum(struct ap_c_arena *arena, struct ap_enum_Bool a1, uint32_t a2, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	if ((uint64_t)a1.tag >= UINT64_C(2)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c6(arena, (uint32_t)a1.tag, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_sum(struct ap_c_arena *arena, uint32_t a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c12(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_known(struct ap_c_arena *arena, uint32_t a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c19(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_seed32(struct ap_c_arena *arena, int32_t a1, uint32_t a2, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c27(arena, (uint32_t)a1, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_seed64(struct ap_c_arena *arena, int64_t a1, uint32_t a2, int64_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c35(arena, (uint64_t)a1, a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT64_MAX ? (int64_t)result : -1 - (int64_t)(UINT64_MAX - result);
	return 0;
}

int ap_export_nested_curried(struct ap_c_arena *arena, uint32_t a1, int32_t a2, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c43(arena, a1, (uint32_t)a2);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_list(struct ap_c_arena *arena, const struct ap_data_Numbers * a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	if (!ap_validate_Numbers(a1)) return 2;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c51(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_unused(struct ap_c_arena *arena, uint32_t a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c59(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}

int ap_export_nested_twice(struct ap_c_arena *arena, uint32_t a1, int32_t *out)
{
	if (!out) return 1;
	if (!arena) return 1;
	if (arena->depth || arena->depth_limit > 256) return 4;
	(void)ap_allocate;
	(void)ap_validate_Numbers;
	struct ap_c_allocation *mark = arena->first;
	arena->status = 0;
	uint64_t result = c65(arena, a1);
	if (arena->status) { ap_release(arena, mark); return arena->status; }
	*out = result <= INT32_MAX ? (int32_t)result : -1 - (int32_t)(UINT32_MAX - result);
	return 0;
}


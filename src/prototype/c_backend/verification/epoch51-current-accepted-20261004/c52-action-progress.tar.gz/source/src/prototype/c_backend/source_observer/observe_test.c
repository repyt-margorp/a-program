#include "observe.h"
#include "evidence.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
	struct pg_graph graph; struct pg_typing typing;
	assert(!pg_graph_init(&graph) && !pg_typing_init(&typing,&graph));
	size_t occurrences=typing.occurrences.count,contexts=typing.contexts.count,
		scopes=typing.scopes.count,maps=typing.context_maps.count;
	struct pg_c_source_snapshot *snapshot=pg_c_source_snapshot_create(&graph,&typing);
	assert(snapshot && pg_c_source_snapshot_unchanged(snapshot));
	/* On the native producer this admits its already interned empty Scope.
		* Its descriptive counts remain fixed; the admission mark must be seen. */
	assert(pg_prove_empty_context(&typing));
	assert(typing.occurrences.count==occurrences && typing.contexts.count==contexts &&
		typing.scopes.count==scopes && typing.context_maps.count==maps);
	assert(!pg_c_source_snapshot_unchanged(snapshot)); pg_c_source_snapshot_destroy(snapshot);
	snapshot=pg_c_source_snapshot_create(&graph,&typing);
	assert(snapshot && pg_c_source_snapshot_unchanged(snapshot));
	assert(pg_prove_empty_context(&typing) && pg_c_source_snapshot_unchanged(snapshot));
	assert(pg_reference(&graph,pg_binder(&graph)));
	assert(!pg_c_source_snapshot_unchanged(snapshot)); pg_c_source_snapshot_destroy(snapshot);
	pg_typing_destroy(&typing); pg_graph_destroy(&graph);
	puts("observer: stable read/repeated admission pass; new admission/new Core detected");
	return 0;
}

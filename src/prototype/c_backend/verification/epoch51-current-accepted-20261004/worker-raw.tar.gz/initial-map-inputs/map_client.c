/* Retain all existing map/endpoint/frame refusal controls on this new module. */
#define main c49_map_client_main
#include "../acc_frame/map_client.c"
#undef main

int main(void)
{
	assert(!c49_map_client_main());
	struct qs_arena arena={0}; const struct qs_acc *proof=gn_nat_accessible(&arena,4);
	assert(proof && !arena.status);
	const struct qs_lt *prior=lt_weaken(&arena,2,3,lt_step(&arena,2));
	const struct qs_lt *edges[]={lt_step(&arena,4),lt_weaken(&arena,2,4,prior),lt_lift(&arena,2,4,prior)};
	for (size_t branch=0; branch<3; ++branch) {
		struct gd_refinement refinement; const struct qs_lt *edge=edges[branch];
		assert(gd_refine(&arena,proof,edge->left,edge,&refinement) && gd_path_valid(&arena,&refinement));
		const struct ga_boundary *recipe=refinement.recipe;
		assert(recipe==ga_boundaries+branch && recipe->map==refinement.maps.boundary);
		assert(recipe->source==!!branch && recipe->destination==!branch);
		assert(recipe->kind==(branch ? GA_LT : GA_QUOTED_ACC) && recipe->down==(branch ? NULL : &ga_down_recipe));
		struct ga_boundary foreign=*recipe; struct gd_refinement changed=refinement; changed.recipe=&foreign;
		size_t count=arena.count;
		assert(!gd_path_valid(&arena,&changed) && arena.status==2 && arena.count==count); arena.status=0;
	}
	uint32_t values[2]={77,88}; size_t count=arena.count;
	assert(ga_domain_values(&arena,&ga_down_recipe,2,4,values) && values[0]==2 && values[1]==4);
	struct ga_down foreign=ga_down_recipe; values[0]=77; values[1]=88;
	assert(!ga_domain_values(&arena,&foreign,2,4,values) && arena.status==2 && arena.count==count);
	assert(values[0]==77 && values[1]==88); arena.status=0;
	struct ga_operand unknown={(enum ga_role)99,0};
	assert(!ga_nat_value(&arena,&unknown,2,4,values) && arena.status==2 && arena.count==count && values[0]==77); arena.status=0;
	unknown=(struct ga_operand){GA_ARGUMENT,1};
	assert(!ga_nat_value(&arena,&unknown,2,4,values) && arena.status==2 && arena.count==count && values[0]==77); arena.status=0;
	unknown=(struct ga_operand){GA_CAPTURE,1};
	assert(!ga_nat_value(&arena,&unknown,2,4,values) && arena.status==2 && arena.count==count && values[0]==77); arena.status=0;
	assert(ga_nat_value(&arena,&ga_down_recipe.result,2,4,values) && values[0]==2 && arena.count==count);
	clear(&arena); puts("Actual Acc down/action recipe: three directions/domain-result projections and seven foreign-recipe/role/slot refusals");
	return 0;
}

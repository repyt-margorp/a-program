/* A Program C backend: structural closures; acceptance belongs to the caller. */
#include "runtime.h"
#include <stdlib.h>
_Static_assert(AP_C_RUNTIME_ABI == 2, "incompatible A Program C runtime");

/* shared Core terms: 24; exports: 1 */
static struct ap_value *t1(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t2(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t3(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t4(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t5(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t6(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t7(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t8(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t9(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t10(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t11(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t12(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t13(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t14(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t15(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t16(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t17(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t18(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t19(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t20(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t21(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t22(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t23(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t24(struct ap_runtime *, const struct ap_env *, enum ap_projection);

static struct ap_value *t1(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_FORCE, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t2(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_THUNK, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t3(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_MATCH, 3, 0, 3, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t4(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_CONSTRUCTOR, 0, 0, 3, 1, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t5(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t3(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t4, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t4, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t4, e, p));
	}
	struct ap_value *f = t3(r, e, p);
	return ap_apply(r, f, ap_delay(r, t4, e, p));
}

static struct ap_value *t6(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_REQUEST, 3, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t7(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_LABEL, 0, 0, 6, 0, 0, labels, 1};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t8(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t6(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t7, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t7, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t7, e, p));
	}
	struct ap_value *f = t6(r, e, p);
	return ap_apply(r, f, ap_delay(r, t7, e, p));
}

static struct ap_value *t9(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 7, p);
}

static struct ap_value *t10(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t8(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t9, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t9, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t9, e, p));
	}
	struct ap_value *f = t8(r, e, p);
	return ap_apply(r, f, ap_delay(r, t9, e, p));
}

static struct ap_value *t11(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_RETURN, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t12(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 9, p);
}

static struct ap_value *t13(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t11(r, e, AP_VALUE), ap_delay(r, t12, e, p));
	}
	struct ap_value *f = t11(r, e, p);
	return ap_apply(r, f, ap_delay(r, t12, e, p));
}

static struct ap_value *t14(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 9, t13, e, p);
}

static struct ap_value *t15(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t10(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t14, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t14, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t14, e, p));
	}
	struct ap_value *f = t10(r, e, p);
	return ap_apply(r, f, ap_delay(r, t14, e, p));
}

static struct ap_value *t16(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 7, t15, e, p);
}

static struct ap_value *t17(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const unsigned char bytes[] = {0x77,0x72,0x6f,0x6e,0x67,0};
	struct ap_value *v = ap_text(r, bytes, 5);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t18(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t16(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t17, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t17, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t17, e, p));
	}
	struct ap_value *f = t16(r, e, p);
	return ap_apply(r, f, ap_delay(r, t17, e, p));
}

static struct ap_value *t19(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t5(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t18, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t18, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t18, e, p));
	}
	struct ap_value *f = t5(r, e, p);
	return ap_apply(r, f, ap_delay(r, t18, e, p));
}

static struct ap_value *t20(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const unsigned char bytes[] = {0x43,0};
	struct ap_value *v = ap_text(r, bytes, 1);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t21(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t16(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t20, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t20, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t20, e, p));
	}
	struct ap_value *f = t16(r, e, p);
	return ap_apply(r, f, ap_delay(r, t20, e, p));
}

static struct ap_value *t22(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t19(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t21, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t21, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t21, e, p));
	}
	struct ap_value *f = t19(r, e, p);
	return ap_apply(r, f, ap_delay(r, t21, e, p));
}

static struct ap_value *t23(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t2(r, e, AP_VALUE), ap_delay(r, t22, e, p));
	}
	struct ap_value *f = t2(r, e, p);
	return ap_apply(r, f, ap_delay(r, t22, e, p));
}

static struct ap_value *t24(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t1(r, e, AP_VALUE), ap_delay(r, t23, e, p));
	}
	struct ap_value *f = t1(r, e, p);
	return ap_apply(r, f, ap_delay(r, t23, e, p));
}

static int run_entry(struct ap_value *(*body)(struct ap_runtime *, const struct ap_env *, enum ap_projection), int mode)
{
	struct ap_runtime *r = calloc(1, sizeof(*r));
	if (!r) return 2;
	if (!setjmp(r->failure)) ap_run(r, body(r, NULL, AP_VALUE), mode);
	int status = r->status;
	ap_destroy(r);
	free(r);
	return status;
}

int ap_export_other(void)
{
	return run_entry(t24, 0);
}

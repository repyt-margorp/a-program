#pragma once
/* ABI 1: 0 success; 1 null output; 2 invalid tag input. Output must be writable. */
#include <stdint.h>
/* Recursive profile: 1 also null arena; 2 also null tail/cycle; 3 allocation;
	* 4 depth limit. Failures preserve output and roll back new allocations. */
/* nat32: uint32 magnitude; status 5 on successor overflow. */
#ifndef AP_C_NATIVE_ABI
#define AP_C_NATIVE_ABI 1
#elif AP_C_NATIVE_ABI != 1
#error incompatible_A_Program_native_ABI
#endif
/* Nat: zero = 0, successor = checked increment; status 5 on overflow. */
struct ap_data_Numbers { uint32_t tag; union {
	struct { uint32_t f0; const struct ap_data_Numbers * f1; } c1;
	unsigned char empty;
} fields; };
#define AP_DATA_Numbers_C0 UINT32_C(0)
#define AP_DATA_Numbers_C1 UINT32_C(1)
#ifdef __cplusplus
extern "C" {
#endif
#include <stddef.h>
#ifndef AP_C_ARENA_ABI
#define AP_C_ARENA_ABI 1
struct ap_c_allocation;
/* Zero initialize. Borrowed input nodes outlive every result sharing them.
	* Result storage is separate from inputs and arena metadata.
	* capacity 0 is unlimited; depth_limit 0 selects 256, maximum 256. */
struct ap_c_arena { struct ap_c_allocation *first; size_t count, capacity, depth, depth_limit; int status; };
#elif AP_C_ARENA_ABI != 1
#error incompatible_A_Program_arena_ABI
#endif
void ap_arena_Nat_destroy(struct ap_c_arena *);
/* Copy finite List to a separate writable buffer. Inputs, buffer and
	* written must not overlap. 6: insufficient capacity; failures preserve
	* buffer and written. Empty List accepts a null buffer. */
int ap_copy_Numbers(const struct ap_data_Numbers *, uint32_t *, size_t capacity, size_t *written);
/* Copy an array slice into arena-owned List nodes, including its terminal.
	* Input, output and arena metadata must not overlap. Empty input accepts
	* a null array. 1: null argument; 2: invalid active tag; 3: allocation; 4: active arena; 6: length
	* overflow. Failures preserve output and prior arena allocations. */
int ap_from_Numbers(struct ap_c_arena *, const uint32_t *, size_t count, const struct ap_data_Numbers **out);
int ap_export_empty(struct ap_c_arena *arena, const struct ap_data_Numbers * *out);
int ap_export_identity(struct ap_c_arena *arena, const struct ap_data_Numbers * a1, const struct ap_data_Numbers * *out);
int ap_export_prepend(struct ap_c_arena *arena, uint32_t a1, const struct ap_data_Numbers * a2, const struct ap_data_Numbers * *out);
int ap_export_length(struct ap_c_arena *arena, const struct ap_data_Numbers * a1, int32_t *out);
int ap_export_append(struct ap_c_arena *arena, const struct ap_data_Numbers * a1, const struct ap_data_Numbers * a2, const struct ap_data_Numbers * *out);
#ifdef __cplusplus
}
#endif

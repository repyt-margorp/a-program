/* A Program C backend: structural closures; acceptance belongs to the caller. */
#include "runtime.h"
#include <stdlib.h>
_Static_assert(AP_C_RUNTIME_ABI == 2, "incompatible A Program C runtime");

/* shared Core terms: 1; exports: 1 */
static struct ap_value *t1(struct ap_runtime *, const struct ap_env *, enum ap_projection);

static struct ap_value *t1(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_CONSTRUCTOR, 0, 0, 2, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static int run_entry(struct ap_value *(*body)(struct ap_runtime *, const struct ap_env *, enum ap_projection), int mode)
{
	struct ap_runtime *r = calloc(1, sizeof(*r));
	if (!r) return 2;
	if (!setjmp(r->failure)) ap_run(r, body(r, NULL, AP_VALUE), mode);
	int status = r->status;
	ap_destroy(r);
	free(r);
	return status;
}

int ap_export_entry(void)
{
	return run_entry(t1, 2);
}

int main(void)
{
	return ap_export_entry();
}

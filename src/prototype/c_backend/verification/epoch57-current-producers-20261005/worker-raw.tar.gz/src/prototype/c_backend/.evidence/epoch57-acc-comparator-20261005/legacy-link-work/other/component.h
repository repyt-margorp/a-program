/* A Program isolated-call ABI: no values or handles cross this boundary. */
#ifndef AP_C_ISOLATED_ABI
#define AP_C_ISOLATED_ABI 1
#elif AP_C_ISOLATED_ABI != 1
#error incompatible_A_Program_isolated_ABI
#endif
#ifdef __cplusplus
extern "C" {
#endif
int ap_export_other(void);
#ifdef __cplusplus
}
#endif

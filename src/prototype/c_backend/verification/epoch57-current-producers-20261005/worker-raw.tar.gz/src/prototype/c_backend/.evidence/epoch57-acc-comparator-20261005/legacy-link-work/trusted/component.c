/* A Program C backend: structural closures; acceptance belongs to the caller. */
#include "runtime.h"
#include <stdlib.h>
_Static_assert(AP_C_RUNTIME_ABI == 2, "incompatible A Program C runtime");

/* shared Core terms: 37; exports: 4 */
static struct ap_value *t1(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t2(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t3(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t4(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t5(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t6(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t7(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t8(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t9(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t10(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t11(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t12(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t13(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t14(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t15(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t16(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t17(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t18(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t19(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t20(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t21(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t22(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t23(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t24(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t25(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t26(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t27(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t28(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t29(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t30(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t31(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t32(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t33(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t34(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t35(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t36(struct ap_runtime *, const struct ap_env *, enum ap_projection);
static struct ap_value *t37(struct ap_runtime *, const struct ap_env *, enum ap_projection);

static struct ap_value *t1(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_THUNK, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t2(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_FOLD, 2, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t3(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_FORCE, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t4(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_ADD, 2, 4, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t5(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	struct ap_value *v = ap_integer(r, UINT64_C(0x14), 4);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t6(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t4(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t5, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t5, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t5, e, p));
	}
	struct ap_value *f = t4(r, e, p);
	return ap_apply(r, f, ap_delay(r, t5, e, p));
}

static struct ap_value *t7(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	struct ap_value *v = ap_integer(r, UINT64_C(0x16), 4);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t8(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t6(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t7, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t7, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t7, e, p));
	}
	struct ap_value *f = t6(r, e, p);
	return ap_apply(r, f, ap_delay(r, t7, e, p));
}

static struct ap_value *t9(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t1(r, e, AP_VALUE), ap_delay(r, t8, e, p));
	}
	struct ap_value *f = t1(r, e, p);
	return ap_apply(r, f, ap_delay(r, t8, e, p));
}

static struct ap_value *t10(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t3(r, e, AP_VALUE), ap_delay(r, t9, e, p));
	}
	struct ap_value *f = t3(r, e, p);
	return ap_apply(r, f, ap_delay(r, t9, e, p));
}

static struct ap_value *t11(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t2(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t10, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t10, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t10, e, p));
	}
	struct ap_value *f = t2(r, e, p);
	return ap_apply(r, f, ap_delay(r, t10, e, p));
}

static struct ap_value *t12(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_DECIMAL, 1, 4, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t13(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 8, p);
}

static struct ap_value *t14(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t12(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t13, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t13, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t13, e, p));
	}
	struct ap_value *f = t12(r, e, p);
	return ap_apply(r, f, ap_delay(r, t13, e, p));
}

static struct ap_value *t15(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 8, t14, e, p);
}

static struct ap_value *t16(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t11(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t15, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t15, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t15, e, p));
	}
	struct ap_value *f = t11(r, e, p);
	return ap_apply(r, f, ap_delay(r, t15, e, p));
}

static struct ap_value *t17(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t2(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t16, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t16, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t16, e, p));
	}
	struct ap_value *f = t2(r, e, p);
	return ap_apply(r, f, ap_delay(r, t16, e, p));
}

static struct ap_value *t18(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_REQUEST, 3, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t19(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_LABEL, 0, 0, 10, 0, 0, labels, 1};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t20(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t18(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t19, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t19, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t19, e, p));
	}
	struct ap_value *f = t18(r, e, p);
	return ap_apply(r, f, ap_delay(r, t19, e, p));
}

static struct ap_value *t21(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 11, p);
}

static struct ap_value *t22(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t20(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t21, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t21, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t21, e, p));
	}
	struct ap_value *f = t20(r, e, p);
	return ap_apply(r, f, ap_delay(r, t21, e, p));
}

static struct ap_value *t23(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const size_t labels[] = {0};
	static const struct ap_descriptor d = {AP_RETURN, 1, 0, 0, 0, 0, labels, 0};
	struct ap_value *v = ap_primitive(r, &d);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t24(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 13, p);
}

static struct ap_value *t25(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t23(r, e, AP_VALUE), ap_delay(r, t24, e, p));
	}
	struct ap_value *f = t23(r, e, p);
	return ap_apply(r, f, ap_delay(r, t24, e, p));
}

static struct ap_value *t26(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 13, t25, e, p);
}

static struct ap_value *t27(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t22(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t26, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t26, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t26, e, p));
	}
	struct ap_value *f = t22(r, e, p);
	return ap_apply(r, f, ap_delay(r, t26, e, p));
}

static struct ap_value *t28(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 11, t27, e, p);
}

static struct ap_value *t29(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_lookup(r, e, 14, p);
}

static struct ap_value *t30(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t28(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t29, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t29, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t29, e, p));
	}
	struct ap_value *f = t28(r, e, p);
	return ap_apply(r, f, ap_delay(r, t29, e, p));
}

static struct ap_value *t31(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	return ap_function(r, 14, t30, e, p);
}

static struct ap_value *t32(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t17(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t31, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t31, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t31, e, p));
	}
	struct ap_value *f = t17(r, e, p);
	return ap_apply(r, f, ap_delay(r, t31, e, p));
}

static struct ap_value *t33(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t1(r, e, AP_VALUE), ap_delay(r, t32, e, p));
	}
	struct ap_value *f = t1(r, e, p);
	return ap_apply(r, f, ap_delay(r, t32, e, p));
}

static struct ap_value *t34(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	static const unsigned char bytes[] = {0x42,0};
	struct ap_value *v = ap_text(r, bytes, 1);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static struct ap_value *t35(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		struct ap_value *f = t28(r, e, p);
		f = ap_apply(r, f, ap_delay(r, t34, e, AP_LEFT));
		f = ap_apply(r, f, ap_delay(r, t34, e, AP_RIGHT));
		return ap_apply(r, f, ap_delay(r, t34, e, p));
	}
	struct ap_value *f = t28(r, e, p);
	return ap_apply(r, f, ap_delay(r, t34, e, p));
}

static struct ap_value *t36(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	if (p == AP_RELATION) {
		return ap_apply(r, t1(r, e, AP_VALUE), ap_delay(r, t35, e, p));
	}
	struct ap_value *f = t1(r, e, p);
	return ap_apply(r, f, ap_delay(r, t35, e, p));
}

static struct ap_value *t37(struct ap_runtime *r, const struct ap_env *e, enum ap_projection p)
{
	(void)e;
	struct ap_value *v = ap_integer(r, UINT64_C(0x0), 4);
	return p == AP_RELATION ? ap_action(r, v) : v;
}

static int run_entry(struct ap_value *(*body)(struct ap_runtime *, const struct ap_env *, enum ap_projection), int mode)
{
	struct ap_runtime *r = calloc(1, sizeof(*r));
	if (!r) return 2;
	if (!setjmp(r->failure)) ap_run(r, body(r, NULL, AP_VALUE), mode);
	int status = r->status;
	ap_destroy(r);
	free(r);
	return status;
}

int ap_export_first(void)
{
	return run_entry(t33, 1);
}

int ap_export_second(void)
{
	return run_entry(t36, 1);
}

int ap_export_duplicate(void)
{
	return run_entry(t33, 1);
}

int ap_export_noop(void)
{
	return run_entry(t37, 2);
}

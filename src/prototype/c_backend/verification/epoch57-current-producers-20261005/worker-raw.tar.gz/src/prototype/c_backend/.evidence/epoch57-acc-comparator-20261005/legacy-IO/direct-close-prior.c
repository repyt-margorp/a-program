prior output canary

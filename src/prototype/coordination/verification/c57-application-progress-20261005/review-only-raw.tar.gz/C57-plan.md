# Actual Acc QuickSort Comparator Capture

Date: 2026-10-05
Status: source probe and bounded implementation in progress, distinct C57.
Baseline: original worker cc3cba3495; immutable C56 manifest47246a05,
published C55 taskc2dccb72. Original Goal/model remain active.
Related: open #61, [C56](2026-10-05-C-BACKEND-ACC-LINKERSCRIPT-PLAN.md).

## Problem List

1. Preserve the actual QuickSort comparator parameter through recursive Acc
 closures and expose it to ordinary C callers in a labeled candidate product.

## 1. Admitted Comparator Parameter

### Subjective (User)

Inherited2026-10-04 conveyed human clarification via inquiry desk/Merge, English
paraphrase; original wording not supplied: deliver readable executable C that
faithfully follows actual admitted Acc QuickSort, retaining Acc/down recursion,
indices, partition and captured parameters. A labeled faithful manual candidate
is acceptable; no alternate algorithm or false generalized-native claim.
Preserve sealed C32, original Goal/model and defer List conveniences.
Inherited2026-10-03 human paraphrase: .a/LinkerScript products should serve
ordinary external C modules without target-driven producer/schema/checker/
source-erasure authority. Workers continue independent epochs; Merge integrates.
These are inherited requirements, not new comparator/ABI/effect approval.

### Objective (Code)

Fresh initial native126 source admission0 and parameter-body emission0 preserve
all seven body/creation bytes; source graph/typing owner snapshot and four source
advance wrappers remain inert during emission. Initial unsupported4 was a probe
setup lacking the explicit provider imports; qualified C53 fixture/provider
bytes plus the fragment admit normally. Both records are retained in
src/prototype/c_backend/.evidence/epoch57-acc-comparator-20261005/.

Fresh inspection: actual clause/partition/outer C bodies already pass struct
qs_compare through gs_fold/gs_force_down/gs_apply and both recursive branches.
The public gs_sort creates only gc_compare; acc_measure/emit.c currently checks
a closed outer_fn bound to the known Nat comparator. Actual source quickSort
has an explicit comparator parameter; selected source views retain its lambdas/
classifier. No producer gap has been demonstrated. C56 local four67 O2/SAN
and both original link/I-O19 controls pass; its immutable exact15 archive stays
unchanged. No C57 source admission or runtime success is claimed yet.

### Assessment

Agent candidate: ordinarily admit quickSort Nat before applying a comparator,
inspect its existing pure-total borrowed Nat/Nat/Bool parameter classifier and
derive the same actual outer body with that live parameter. Carry an explicit
borrowed C code/context descriptor through existing Acc closures; expose
gs_sort_with in an explicitly labeled target profile, with fixed Nat32 storage
and source-derived algorithm bodies. Retain old gs_sort and ordinary native
refusals. No comparator law/source proof is invented from C return values.

Caller success/pure-total interpretation/code-context lifetime remain explicit
preconditions; malformed Bool codes must fail transactionally. No foreign effect
rollback or ownership transfer. First prove source admission/parameter shape,
then implement only this bounded path. A concrete frontend/view gap routes through
Merge before shared-owner edits. Full Scope/equivalence/general native stay open.

### Plan

- [ ] Admit actual unapplied comparator form and inspect existing classifier/views.
- [ ] Emit source-parameter outer body, preserve actual recursive comparator capture.
- [ ] Provide labeled ordinary C source/object/archive and LinkerScript selection.
- [ ] Verify actual source ascending/descending correspondence, both recursive
 branches/captures, descriptor/refusal/transactional/resource/I-O controls O2/SAN.
- [ ] Preserve initial records/frozen history, style and exact reviewable handoff.
- [ ] General native/full Scope/source equivalence/full61/adoption/cost remain open.

#include "program.h"
#include "source_io.h"
#include "synthesis_function_internal.h"
#include "synthesis_work.h"
#include "artifact/source.h"
#include "../tests/native_admissions.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Isolate actual application-owner transport while retaining the existing
 * canonical children, reusable results and scheduler in their original owner.
 * This is authenticated same-owner cursor reuse, not a general Program reload
 * or an admission policy for arbitrary serialized progress. */
static size_t restored, frames_restored, intrinsic_restored;

static struct pg_program *start(const char *text)
{
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *syntax = pg_parser_program(&program->parser);
	assert(syntax && !program->parser.error && syntax->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, syntax->items[0].expression);
	assert(program->root);
	return program;
}

static uint64_t finish(struct pg_program *program)
{
	while (program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		pg_synthesis_advance(&program->synthesis, 1);
		assert(program->synthesis.steps < 10000);
	}
	assert(pg_synthesis_result(program->root));
	return program->synthesis.steps;
}

static FILE *result(struct pg_program *program)
{
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	FILE *file = tmpfile();
	assert(file && !pg_sources_write(file, &program->synthesis, 1, &root));
	return file;
}

static void equal(FILE *left, FILE *right)
{
	rewind(left); rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); assert(a == b); } while (a != EOF);
	assert(!ferror(left) && !ferror(right));
}

static void checkpoint(struct pg_program *program)
{
	struct pg_synthesis *synthesis = &program->synthesis;
	size_t count = synthesis->jobs.count, next = 0;
	struct pg_synthesis_job **jobs = malloc(count * sizeof(*jobs));
	assert(jobs);
	for (size_t i = 0; i < synthesis->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = synthesis->jobs.buckets[i]; entry; entry = entry->next)
			jobs[next++] = (void *)entry;
	assert(next == count);
	for (size_t i = 0; i < count; ++i) {
		struct pg_synthesis_job *job = jobs[i];
		const struct source_application_work *cursor = pg_synthesis_source_application_cursor(synthesis, job);
		if (!cursor || job->status != PG_SYNTHESIS_PENDING) continue;
		struct pg_graph storage = {0};
		const struct pg_artifact_source *saved = pg_artifact_source_capture(&storage, synthesis, count, jobs, 1, &job);
		if (!saved) { pg_graph_destroy(&storage); continue; }
		struct source_application_work original = *cursor;
		uint64_t steps = synthesis->steps;
		size_t admitted = native_admissions(&program->typing);
		FILE *file = tmpfile(), *copy = tmpfile();
		assert(file && copy && !pg_artifact_source_write(file, saved));
		rewind(file);
		const struct pg_artifact_source *loaded = pg_artifact_source_read(file, &storage, 100000);
		assert(loaded && fgetc(file) == EOF && !pg_artifact_source_write(copy, loaded));
		equal(file, copy);
		assert(synthesis->steps == steps && native_admissions(&program->typing) == admitted);
		struct pg_synthesis_job copied = *job;
		assert(!pg_synthesis_source_application_cursor(synthesis, &copied));
		jobs[i] = &copied;
		assert(pg_artifact_source_prepare(synthesis, loaded, count, jobs)
			&& pg_artifact_source_attach_with_frontiers(synthesis, loaded, count, jobs));
		jobs[i] = job;
		/* The canonical children and scheduler remain authentic. Reset only
		 * this private cursor to emulate its fresh factory before attachment. */
		struct source_application_work *local = (void *)cursor;
		*local = (struct source_application_work){0};
		if (original.left) {
			struct source_application_work wrong = original;
			wrong.left = original.application.argument;
			assert(pg_synthesis_source_application_resume(synthesis, job, &wrong));
			assert(!local->stage && !local->left);
		}
		assert(pg_artifact_source_attach(synthesis, loaded, count, jobs));
		assert(!local->stage && !local->left && !local->application.frames);
		assert(!pg_artifact_source_prepare(synthesis, loaded, count, jobs));
		assert(!pg_artifact_source_attach_with_frontiers(synthesis, loaded, count, jobs));
		assert(local->stage == original.stage && local->left == original.left
			&& local->application.callee == original.application.callee
			&& local->application.argument == original.application.argument
			&& local->application.tail == original.application.tail
			&& local->application.context.checked == original.application.context.checked
			&& local->application.context.pending == original.application.context.pending
			&& local->application.constraint_source == original.application.constraint_source
			&& local->application.constraint_type == original.application.constraint_type
			&& local->application.constraint_check == original.application.constraint_check
			&& local->application.binding_count == original.application.binding_count);
		const struct pg_synthesis_sequence_frame *before = original.application.frames;
		const struct pg_synthesis_sequence_frame *after = local->application.frames;
		while (before) {
			assert(after && before != after && before->input == after->input
				&& before->context.pending == after->context.pending && before->binds == after->binds);
			before = before->parent; after = after->parent; ++frames_restored;
		}
		assert(!after);
		if (local->stage) assert(pg_artifact_source_attach_with_frontiers(synthesis, loaded, count, jobs));
		intrinsic_restored += local->stage && !local->left;
		assert(synthesis->steps == steps && synthesis->jobs.count == count
			&& native_admissions(&program->typing) == admitted);
		pg_graph_destroy(&storage);
		/* attach_application already destroyed its decoding scratch arena.
		 * Traverse the retained tail after both temporary owners are gone. */
		for (after = local->application.frames; after; after = after->parent)
			assert(after->input && after->context.pending && after->binds == 1);
		assert(!fclose(file) && !fclose(copy));
		++restored;
	}
	free(jobs);
}

static void lifecycle(const char *text, unsigned ordinal)
{
	struct pg_program *program = start(text);
	uint64_t total = finish(program);
	FILE *expected = result(program);
	pg_program_destroy(program);
	for (uint64_t cut = 0; cut <= total; ++cut) {
		program = start(text);
		pg_synthesis_advance(&program->synthesis, cut);
		assert(program->synthesis.steps == cut);
		checkpoint(program);
		pg_synthesis_advance(&program->synthesis, 0);
		assert(program->synthesis.steps == cut);
		assert(finish(program) == total);
		FILE *actual = result(program);
		equal(expected, actual);
		assert(!fclose(actual));
		pg_program_destroy(program);
	}
	assert(!fclose(expected));
	printf("application-owner=%u cuts=%" PRIu64 " total=%" PRIu64 " restored=%zu frames=%zu intrinsic=%zu\n",
		ordinal, total + 1, total, restored, frames_restored, intrinsic_restored);
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	lifecycle("v := (\\x : @ => x) (@{unit:*;});", 0);
	lifecycle("v := (\\x : @ => x) ((\\x : @ => x) (@{unit:*;}));", 1);
	/* TERMINATION_FORM requires a suspended value; a computation without
	 * its explicit quote is an ordinary type rejection, not a reload defect. */
	lifecycle("v := #Terminates &((\\x : @ => x) (@{unit:*;}));", 2);
	assert(restored && frames_restored && intrinsic_restored);
	puts("application cursor: inert metadata, strict rejection, authentic same-owner reuse, owned escaped scratch frames, exact useful fuel/results");
	return 0;
}

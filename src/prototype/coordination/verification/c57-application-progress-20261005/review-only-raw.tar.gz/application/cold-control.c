#include "program.h"
#include "source_io.h"
#include "synthesis_function_internal.h"
#include "synthesis_work.h"
#include "artifact/source.h"
#include "artifact/schedule.h"
#include "../tests/native_admissions.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct checkpoint {
	const struct pg_artifact_source *source;
	const struct pg_artifact_schedule *schedule;
};

static int solving;
void __real_pg_synthesis_advance(struct pg_synthesis *, uint64_t);
void __wrap_pg_synthesis_advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	assert(!fuel || solving);
	__real_pg_synthesis_advance(synthesis, fuel);
}

static void advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	solving = 1;
	pg_synthesis_advance(synthesis, fuel);
	solving = 0;
}

static struct pg_program *start(void)
{
	const char *text = "v := (\\x : @ => x) (@{unit:*;});";
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *syntax = pg_parser_program(&program->parser);
	assert(syntax && !program->parser.error && syntax->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, syntax->items[0].expression);
	assert(program->root);
	return program;
}

static uint64_t finish(struct pg_program *program)
{
	while (program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		advance(&program->synthesis, 1);
		assert(program->synthesis.steps < 10000);
	}
	assert(pg_synthesis_result(program->root));
	return program->synthesis.steps;
}

static int write_extra(FILE *file, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	(void)codec; (void)objects;
	const struct checkpoint *checkpoint = opaque;
	return pg_artifact_source_write(file, checkpoint->source)
		|| pg_artifact_schedule_save(file, checkpoint->schedule);
}

static int read_extra(FILE *file, struct pg_typing *typing, size_t limit, size_t names,
	const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	(void)names; (void)codec; (void)objects;
	struct checkpoint *checkpoint = opaque;
	checkpoint->source = pg_artifact_source_read(file, typing->graph, limit);
	checkpoint->schedule = pg_artifact_schedule_read(file, typing->graph, limit);
	return !checkpoint->source || !checkpoint->schedule;
}

static void equal(FILE *left, FILE *right)
{
	rewind(left); rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); assert(a == b); } while (a != EOF);
	assert(!ferror(left) && !ferror(right));
}

static void check(uint64_t cut)
{
	struct pg_program *program = start();
	uint64_t total = finish(program);
	FILE *expected = tmpfile();
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	assert(expected && !pg_sources_write(expected, &program->synthesis, 1, &root));
	pg_program_destroy(program);
	program = start();
	advance(&program->synthesis, cut);
	struct pg_synthesis *synthesis = &program->synthesis;
	size_t count = synthesis->jobs.count, next = 1;
	struct pg_synthesis_job **jobs = calloc(count, sizeof(*jobs));
	struct pg_synthesis_input *roots = calloc(count, sizeof(*roots));
	assert(jobs && roots);
	jobs[0] = program->root;
	for (size_t i = 0; i < synthesis->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = synthesis->jobs.buckets[i]; entry; entry = entry->next) {
			struct pg_synthesis_job *job = (void *)entry;
			if (job != program->root) jobs[next++] = job;
		}
	assert(next == count);
	for (size_t i = 0; i < count; ++i) roots[i].pending = pg_synthesis_pending(jobs[i]);
	const struct source_application_work *cursor = pg_synthesis_source_application_cursor(synthesis, program->root);
	assert(cursor);
	unsigned stage = cursor->stage;
	struct checkpoint saved = {
		.source = pg_artifact_source_capture(&program->graph, synthesis, count, jobs, 1, &program->root),
		.schedule = pg_artifact_schedule_capture(&program->graph, synthesis, count, jobs)};
	FILE *file = tmpfile();
	assert(saved.source && saved.schedule && file);
	int written = pg_sources_write_with(file, synthesis, count, roots, 0, write_extra, &saved);
	fprintf(stderr, "cold application cut=%" PRIu64 " stage=%u jobs=%zu write=%d\n", cut, stage, count, written);
	assert(!written && synthesis->steps == cut);
	free(roots); free(jobs);
	pg_program_destroy(program);
	rewind(file);
	struct checkpoint loaded = {0};
	size_t restored_count;
	struct pg_synthesis_job *const *restored;
	program = pg_sources_read_with(file, 100000, &restored_count, &restored, read_extra, &loaded);
	assert(program && restored_count == count && !program->synthesis.steps
		&& native_admissions(&program->typing) == 1 && fgetc(file) == EOF);
	program->root = restored[0];
	roots = calloc(count, sizeof(*roots));
	assert(roots);
	for (size_t i = 0; i < count; ++i) roots[i].pending = pg_synthesis_pending(restored[i]);
	FILE *copy = tmpfile();
	assert(copy && !pg_sources_write_with(copy, &program->synthesis, count, roots, 0, write_extra, &loaded));
	equal(file, copy);
	assert(!fclose(copy));
	assert(!pg_artifact_source_prepare(&program->synthesis, loaded.source, count, restored));
	assert(pg_artifact_source_attach(&program->synthesis, loaded.source, count, restored));
	/* This exact self-produced image explicitly selects authentic reuse.
	 * No arbitrary input is admitted; original children/facts still require
	 * their own owner transport before a later cut can qualify here. */
	assert(!pg_artifact_source_attach_with_frontiers(&program->synthesis, loaded.source, count, restored));
	assert(!pg_artifact_schedule_attach(&program->synthesis, loaded.schedule, count, restored));
	assert(!program->synthesis.steps);
	pg_synthesis_advance(&program->synthesis, 0);
	assert(!program->synthesis.steps);
	uint64_t useful = finish(program);
	assert(useful == total - cut);
	root.pending = pg_synthesis_pending(program->root);
	copy = tmpfile();
	assert(copy && !pg_sources_write(copy, &program->synthesis, 1, &root));
	equal(expected, copy);
	assert(!fclose(file) && !fclose(copy) && !fclose(expected));
	free(roots);
	pg_program_destroy(program);
	printf("cold-application cut=%" PRIu64 " stage=%u validation=0 useful=%" PRIu64 " total=%" PRIu64 " jobs=%zu\n",
		cut, stage, useful, total, count);
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	for (uint64_t cut = 0; cut < 4; ++cut) check(cut);
	return 0;
}

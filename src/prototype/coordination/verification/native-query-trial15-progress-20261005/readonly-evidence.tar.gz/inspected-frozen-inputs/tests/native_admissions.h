#ifndef A_PROGRAM_TEST_NATIVE_ADMISSIONS_H
#define A_PROGRAM_TEST_NATIVE_ADMISSIONS_H

#include "scope.h"

/* Test observation only: replacement for the deleted receipt-index count.
 * Counting descriptive members would miss admission of an existing tuple. */
static size_t native_admissions(const struct pg_typing *typing)
{
	size_t count = 0;
	for (size_t b = 0; b < typing->occurrences.capacity; ++b)
		for (const struct pg_index_entry *p = typing->occurrences.buckets[b]; p; p = p->next)
			count += ((const struct pg_occurrence *)(const void *)p)->admission_owner != NULL;
	for (size_t b = 0; b < typing->scopes.capacity; ++b)
		for (const struct pg_index_entry *p = typing->scopes.buckets[b]; p; p = p->next)
			count += ((const struct pg_scope *)(const void *)p)->admission_owner != NULL;
	for (size_t b = 0; b < typing->context_maps.capacity; ++b)
		for (const struct pg_index_entry *p = typing->context_maps.buckets[b]; p; p = p->next)
			count += ((const struct pg_context_map *)(const void *)p)->admission_owner != NULL;
	return count;
}

#endif

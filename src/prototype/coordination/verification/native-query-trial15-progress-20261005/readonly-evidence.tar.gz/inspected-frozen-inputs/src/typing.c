#include "typing.h"
#include "typing_internal.h"
#include "scope.h"
#include "classifier.h"
#include "typed_query.h"
#include "dag.h"

#include <string.h>
#include <stdlib.h>

struct context_entry {
	struct pg_index_entry index;
	struct pg_context context;
};

int pg_occurrence_owned_by(const struct pg_occurrence *subject, const struct pg_typing *typing)
{
	if (!subject || !typing || !typing->occurrences.capacity) return 0;
	for (const struct pg_index_entry *p = pg_index_candidates(&typing->occurrences, subject->index.hash);
		p; p = p->next)
		if (p == &subject->index) return 1;
	return 0;
}

int pg_context_map_owned_by(const struct pg_context_map *map, const struct pg_typing *typing)
{
	if (!map || !typing || !typing->context_maps.capacity) return 0;
	for (const struct pg_index_entry *p = pg_index_candidates(&typing->context_maps, map->index.hash);
		p; p = p->next)
		if (p == &map->index) return 1;
	return 0;
}

int pg_typing_init(struct pg_typing *typing, struct pg_graph *graph)
{
	memset(typing, 0, sizeof(*typing));
	typing->graph = graph;
	typing->owner_key = pg_alloc(graph, sizeof(struct pg_typing_owner));
	if (!typing->owner_key) return -1;
	if (pg_index_init(&typing->contexts) != 0) goto fail;
	if (pg_index_init(&typing->occurrences) != 0) goto fail;
	if (pg_index_init(&typing->context_maps) != 0) goto fail;
	if (pg_index_init(&typing->context_projections) != 0) goto fail;
	if (pg_index_init(&typing->context_lifts) != 0) goto fail;
	if (pg_index_init(&typing->occurrence_actions) != 0) goto fail;
	if (pg_index_init(&typing->occurrence_inputs) != 0) goto fail;
	if (pg_index_init(&typing->typed_queries) != 0) goto fail;
	if (pg_substitution_work_init(&typing->substitutions, graph) == 0) return 0;
fail:
	pg_typing_destroy(typing);
	return -1;
}

void pg_typing_destroy(struct pg_typing *typing)
{
	pg_typed_query_destroy(typing);
	pg_index_destroy(&typing->contexts);
	pg_index_destroy(&typing->scopes);
	pg_index_destroy(&typing->occurrences);
	pg_index_destroy(&typing->context_maps);
	pg_index_destroy(&typing->context_projections);
	pg_index_destroy(&typing->context_lifts);
	pg_index_destroy(&typing->occurrence_actions);
	pg_index_destroy(&typing->occurrence_inputs);
	pg_index_destroy(&typing->typed_queries);
	pg_index_destroy(&typing->induction_requests);
	pg_substitution_work_destroy(&typing->substitutions);
	memset(typing, 0, sizeof(*typing));
}

int pg_typing_wait_push(struct pg_typing *typing, struct pg_typing_wait **stack, void *work)
{
	struct pg_typing_wait *frame = typing->free_waits;
	if (frame) typing->free_waits = frame->parent;
	else frame = pg_alloc(typing->graph, sizeof(*frame));
	if (!frame) return -1;
	*frame = (struct pg_typing_wait){work, *stack};
	*stack = frame;
	return 0;
}

void pg_typing_wait_pop(struct pg_typing *typing, struct pg_typing_wait **stack)
{
	struct pg_typing_wait *frame = *stack;
	if (!frame) return;
	*stack = frame->parent;
	*frame = (struct pg_typing_wait){NULL, typing->free_waits};
	typing->free_waits = frame;
}

void pg_typing_wait_clear(struct pg_typing *typing, struct pg_typing_wait **stack)
{
	while (*stack) pg_typing_wait_pop(typing, stack);
}

static uint64_t context_hash(const struct pg_context *parent,
	const struct pg_object *binder, const struct pg_term *declared_type)
{
	uint64_t hash = (uintptr_t)parent;
	hash = (hash ^ (uintptr_t)binder) * UINT64_C(1099511628211);
	return (hash ^ (uintptr_t)declared_type) * UINT64_C(1099511628211);
}

static uint64_t declaration_hash(const struct pg_context *context)
{
	uint64_t hash = context_hash(context->parent, context->binder, context->declared_type);
	hash = (hash ^ context->judgement) * UINT64_C(1099511628211);
	return (hash ^ (uintptr_t)context->indices) * UINT64_C(1099511628211);
}

int pg_context_owned_by(const struct pg_context *context, const struct pg_typing *typing)
{
	if (!typing || !typing->owner_key) return 0;
	if (!context) return 1;
	uint64_t hash = declaration_hash(context);
	for (const struct pg_index_entry *entry = pg_index_candidates(&typing->contexts, hash); entry; entry = entry->next)
		if (entry->hash == hash && &((const struct context_entry *)entry)->context == context) return 1;
	return 0;
}

const struct pg_context *pg_context_bind(struct pg_typing *typing,
	const struct pg_context *parent, const struct pg_object *binder,
	const struct pg_term *declared_type, enum pg_evidence_judgement judgement)
{
	return pg_context_intern(typing, &(struct pg_context){
		.parent = parent, .binder = binder, .declared_type = declared_type, .judgement = judgement});
}

const struct pg_context *pg_context_intern(struct pg_typing *typing,
	const struct pg_context *declaration)
{
	if (!declaration) return NULL;
	const struct pg_context *parent = declaration->parent;
	const struct pg_object *binder = declaration->binder;
	const struct pg_term *declared_type = declaration->declared_type;
	enum pg_evidence_judgement judgement = declaration->judgement;
	if (!binder || !declared_type) return NULL;
	if (binder->kind != PG_BINDER) return NULL;
	if (judgement != PG_JUDGEMENT_VALUE && judgement != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (declaration->indices) {
		size_t count;
		if (judgement != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
		if (pg_context_extension_size(declaration->indices, parent, &count) || !count) return NULL;
	}
	uint64_t hash = declaration_hash(declaration);
	for (struct pg_index_entry *candidate = pg_index_candidates(&typing->contexts, hash); candidate; candidate = candidate->next) {
		if (candidate->hash != hash) continue;
		const struct context_entry *entry = (const struct context_entry *)candidate;
		if (entry->context.parent != parent) continue;
		if (entry->context.binder != binder) continue;
		if (entry->context.judgement != judgement) continue;
		if (entry->context.indices != declaration->indices) continue;
		if (entry->context.declared_type == declared_type) return &entry->context;
	}
	struct context_entry *entry = pg_alloc(typing->graph, sizeof(*entry));
	if (!entry) return NULL;
	entry->context = *declaration;
	entry->context.checked_scope = NULL;
	if (pg_index_insert(&typing->contexts, &entry->index, hash) != 0) return NULL;
	return &entry->context;
}

const struct pg_context *pg_context_lookup(const struct pg_context *context,
	const struct pg_object *binder)
{
	for (; context; context = context->parent) {
		if (context->binder == binder) return context;
	}
	return NULL;
}

const struct pg_term *pg_context_signature(struct pg_graph *graph,
	const struct pg_context *parent, const struct pg_context *indices,
	const struct pg_term *universe)
{
	const struct pg_term *signature = universe;
	for (const struct pg_context *slot = indices; slot != parent; slot = slot->parent) {
		if (!slot) return NULL;
		signature = pg_pi(graph, slot->declared_type, slot->binder, signature);
		if (!signature) return NULL;
	}
	return signature;
}

int pg_context_extension_size(const struct pg_context *context,
	const struct pg_context *prefix, size_t *count)
{
	if (!count) return -1;
	size_t length = 0;
	for (; context != prefix; context = context->parent) {
		if (!context) return -1;
		++length;
	}
	*count = length;
	return 0;
}

int pg_context_same_allocation_shape(const struct pg_context *left,
	const struct pg_context *right)
{
	for (; left != right; left = left->parent, right = right->parent) {
		if (!left || !right || left->binder != right->binder || left->judgement != right->judgement)
			return 0;
		if (!pg_context_same_allocation_shape(left->indices, right->indices)) return 0;
	}
	return 1;
}

uint64_t pg_induction_allocation_hash(const struct pg_induction_allocation *allocation)
{
	if (!allocation) return 0;
	uint64_t hash = (uintptr_t)allocation->recursion;
	hash = (hash ^ (uintptr_t)allocation->argument) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)allocation->self) * UINT64_C(1099511628211);
	hash = (hash ^ allocation->count) * UINT64_C(1099511628211);
	for (size_t i = 0; i < allocation->count; ++i)
		hash = (hash ^ (uintptr_t)allocation->clauses[i]) * UINT64_C(1099511628211);
	return hash;
}

int pg_induction_allocation_equal(const struct pg_induction_allocation *left,
	const struct pg_induction_allocation *right)
{
	if (left == right) return 1;
	if (!left || !right) return 0;
	if (left->recursion != right->recursion || left->argument != right->argument ||
		left->self != right->self || left->count != right->count) return 0;
	for (size_t i = 0; i < left->count; ++i)
		if (left->clauses[i] != right->clauses[i]) return 0;
	return 1;
}

uint64_t pg_occurrence_native_hash(const struct pg_occurrence *header,
	const struct pg_occurrence *const *operands, const struct pg_context_map *const *maps)
{
	uint64_t hash = (uintptr_t)header->context;
	hash = (hash ^ (uintptr_t)header->origin) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)header->map) * UINT64_C(1099511628211);
	hash = (hash ^ header->selection) * UINT64_C(1099511628211);
	hash = (hash ^ header->operand_count) * UINT64_C(1099511628211);
	hash = (hash ^ header->map_count) * UINT64_C(1099511628211);
	for (size_t i = 0; i < header->map_count; ++i)
		hash = (hash ^ (uintptr_t)maps[i]) * UINT64_C(1099511628211);
	for (size_t i = 0; i < header->operand_count; ++i)
		hash = (hash ^ (uintptr_t)operands[i]) * UINT64_C(1099511628211);
	return hash;
}

static int scope_member_input(void *owner, const void *key, size_t index, const void **child)
{
	const struct pg_typing *typing = owner;
	const struct pg_scope *scope = key;
	if (!pg_scope_owned_by(scope, typing)) return -1;
	if (!pg_context_owned_by(scope->context, typing)) return -1;
	if (scope->type && !pg_occurrence_owned_by(scope->type, typing)) return -1;
	if (scope->admission_owner == typing->owner_key || index > 1) return 0;
	*child = index ? scope->indices : scope->parent;
	return *child ? 1 : 2;
}

static int scope_inputs_owned(struct pg_typing *typing, const struct pg_scope *scope)
{
	const void *child;
	int status = scope_member_input(typing, scope, 0, &child);
	if (status <= 0) return !status;
	struct pg_dag dag = {0};
	int valid = !pg_dag_init(&dag, scope_member_input, typing) && !pg_dag_add(&dag, scope);
	pg_dag_destroy(&dag);
	return valid;
}

static int declaration_use_owned(const struct pg_typing *typing,
	const struct pg_context *context, const struct pg_scope *declaration)
{
	while (context != declaration->context) {
		if (!context || !pg_context_owned_by(context, typing)) return 0;
		const struct pg_scope *checked = context->checked_scope;
		if (checked && checked->context == context && pg_scope_owned_by(checked, typing) &&
			checked->admission_owner == typing->owner_key) return 1;
		context = context->parent;
	}
	return 1;
}

const struct pg_occurrence *pg_occurrence_intern(struct pg_typing *typing,
	const struct pg_occurrence *header, const struct pg_occurrence *const *operands,
	const struct pg_context_map *const *maps)
{
	if (!header) return NULL;
	enum pg_evidence_judgement judgement = header->judgement;
	const struct pg_context *context = header->context;
	const struct pg_term *core = header->core, *classifier = header->classifier, *annotation = header->annotation;
	const struct pg_occurrence *origin = header->origin, *type = header->type;
	const struct pg_context_map *map = header->map;
	const struct pg_induction_allocation *induction = header->induction;
	size_t selection = header->selection, operand_count = header->operand_count, map_count = header->map_count;
	if (!core) return NULL;
	if (header->scope && (judgement != PG_JUDGEMENT_TYPE_FAMILY ||
		core->kind != PG_REFERENCE || core->as.reference->kind != PG_BINDER ||
		header->scope->context != pg_context_lookup(context, core->as.reference) || origin || operand_count || map_count ||
		!scope_inputs_owned(typing, header->scope) ||
		!declaration_use_owned(typing, context, header->scope))) return NULL;
	if (judgement < PG_JUDGEMENT_VALUE_TYPE || judgement > PG_JUDGEMENT_INPUT) return NULL;
	if (judgement == PG_JUDGEMENT_SUBSTITUTION) return NULL;
	if ((judgement == PG_JUDGEMENT_INPUT) != (classifier == NULL)) return NULL;
	if (type && (type->context != context || type->core != classifier)) return NULL;
	if (operand_count && !operands) return NULL;
	if (selection && (!origin || map || operand_count > 1)) return NULL;
	if (map && (!origin || origin->context != map->source || context != map->destination)) return NULL;
	if (origin && !map && context != origin->context) return NULL;
	if (origin && !selection && operand_count) return NULL;
	if (selection && operand_count && operands[0] && operands[0]->context != context) return NULL;
	if (map_count && !maps) return NULL;
	if (map_count > (SIZE_MAX - sizeof(struct pg_occurrence)) / sizeof(*maps)) return NULL;
	if (operand_count > (SIZE_MAX - sizeof(struct pg_occurrence) - map_count * sizeof(*maps)) / sizeof(*operands)) return NULL;
	size_t size = sizeof(struct pg_occurrence) + operand_count * sizeof(*operands) + map_count * sizeof(*maps);
	if (induction) {
		if (origin || map || (induction->count && !induction->clauses)) return NULL;
		if (!induction->recursion || induction->recursion->kind != PG_BINDER) return NULL;
		if (!induction->argument || induction->argument->kind != PG_BINDER) return NULL;
		if (!induction->self || induction->self->kind != PG_BINDER) return NULL;
		if (size > SIZE_MAX - sizeof(*induction)) return NULL;
		size += sizeof(*induction);
		if (induction->count > (SIZE_MAX - size) / sizeof(*induction->clauses)) return NULL;
		size += induction->count * sizeof(*induction->clauses);
	}
	uint64_t hash = context_hash(context, NULL, core);
	hash = (hash ^ judgement) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)classifier) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)type) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)annotation) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)origin) * UINT64_C(1099511628211);
	hash = (hash ^ selection) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)map) * UINT64_C(1099511628211);
	hash = (hash ^ operand_count) * UINT64_C(1099511628211);
	hash = (hash ^ map_count) * UINT64_C(1099511628211);
	hash = (hash ^ pg_induction_allocation_hash(induction)) * UINT64_C(1099511628211);
	for (size_t i = 0; i < map_count; ++i) {
		if (!maps[i] || maps[i]->destination != context) return NULL;
		hash = (hash ^ (uintptr_t)maps[i]) * UINT64_C(1099511628211);
	}
	for (size_t i = 0; i < operand_count; ++i) {
		if (!operands[i]) return NULL;
		hash = (hash ^ (uintptr_t)operands[i]) * UINT64_C(1099511628211);
	}
	/* Admission and rule history are absent from the key. Result Core, type,
	 * classifier, annotation and lexical allocation remain exact equality
	 * checks below; this bucket also permits preconstruction owner lookup. */
	if (origin || operand_count || map_count) hash = pg_occurrence_native_hash(header, operands, maps);
	struct pg_occurrence *principal = NULL;
	for (struct pg_index_entry *candidate = pg_index_candidates(&typing->occurrences, hash); candidate; candidate = candidate->next) {
		if (candidate->hash != hash) continue;
		const struct pg_occurrence *found = (const struct pg_occurrence *)candidate;
		if (found->judgement != judgement) continue;
		if (found->context != context) continue;
		if (found->core != core) continue;
		if (found->classifier != classifier) continue;
		if (found->type != type) continue;
		if (found->annotation != annotation) continue;
		if (found->origin != origin || found->map != map) continue;
		if (found->selection != selection) continue;
		if (found->operand_count != operand_count) continue;
		if (found->map_count != map_count) continue;
		if (!pg_induction_allocation_equal(found->induction, induction)) continue;
		size_t i = 0;
		while (i < operand_count && found->operands[i] == operands[i]) ++i;
		if (i != operand_count) continue;
		for (i = 0; i < map_count && pg_occurrence_maps(found)[i] == maps[i]; ++i) {}
		if (i != map_count) continue;
		if (!found->scoped_variant) principal = (void *)found;
		if (header->scope ? found->scope == header->scope : !found->scoped_variant) return found;
	}
	if (header->scope && principal && !principal->scope && !principal->admission_owner) {
		/* Bind the first native formation before admission. Later raw lookups
		 * retain this address; different formations get existing-index variants. */
		principal->scope = header->scope;
		return principal;
	}
	struct pg_occurrence *result = pg_alloc(typing->graph, size);
	if (!result) return NULL;
	*result = *header;
	result->scoped_variant = principal != NULL;
	result->admission_owner = NULL;
	result->construction = 0;
	result->certificate = NULL;
	result->induction = NULL;
	for (size_t i = 0; i < operand_count; ++i) result->operands[i] = operands[i];
	if (map_count) memcpy(result->operands + operand_count, maps, map_count * sizeof(*maps));
	if (induction) {
		struct pg_induction_allocation *a = (void *)((char *)(result->operands + operand_count) + map_count * sizeof(*maps));
		const struct pg_context **clauses = (void *)(a + 1);
		*a = *induction;
		for (size_t i = 0; i < a->count; ++i) clauses[i] = induction->clauses[i];
		a->clauses = clauses;
		result->induction = a;
	}
	if (pg_index_insert(&typing->occurrences, &result->index, hash) != 0) return NULL;
	return result;
}

const struct pg_occurrence *pg_occurrence(struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const struct pg_context *context, const struct pg_term *core,
	const struct pg_term *classifier, const struct pg_term *annotation, size_t operand_count,
	const struct pg_occurrence *const *operands)
{
	return pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = judgement,
		.context = context, .core = core, .classifier = classifier, .annotation = annotation,
		.operand_count = operand_count}, operands, NULL);
}

const struct pg_occurrence *pg_occurrence_typed(struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const struct pg_term *core,
	const struct pg_occurrence *type, const struct pg_term *annotation,
	size_t operand_count, const struct pg_occurrence *const *operands)
{
	return type ? pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = judgement,
		.context = type->context, .core = core, .classifier = type->core, .type = type,
		.annotation = annotation, .operand_count = operand_count}, operands, NULL) : NULL;
}

const struct pg_occurrence *pg_occurrence_reclassified(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct pg_occurrence *type)
{
	if (!source || !type) return NULL;
	if (source->type == type) return source;
	return pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = source->judgement,
		.context = source->context, .core = source->core, .classifier = type->core,
		.origin = source, .type = type}, NULL, NULL);
}

const struct pg_context_map *const *pg_occurrence_maps(const struct pg_occurrence *subject)
{
	return (const struct pg_context_map *const *)(subject->operands + subject->operand_count);
}

const struct pg_occurrence *pg_occurrence_boundary(struct pg_typing *typing,
	const struct pg_occurrence *source, enum pg_evidence_judgement judgement,
	const struct pg_term *classifier)
{
	if (!source) return NULL;
	if (source->judgement == judgement && source->classifier == classifier) return source;
	/* Type/value round trips retain the original construction. A changed
	 * formation is not such a round trip. This performs no evidence admission. */
	const struct pg_occurrence *origin = source->origin;
	if (origin && !source->map && !source->selection && source->core == origin->core && source->type == origin->type)
		if (origin->judgement == judgement && origin->classifier == classifier) return origin;
	return pg_occurrence_derived(typing, source, judgement, source->core, classifier);
}

const struct pg_occurrence *pg_occurrence_mapped(struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const struct pg_term *core,
	const struct pg_term *classifier, const struct pg_term *annotation,
	const struct pg_occurrence *source, const struct pg_context_map *map)
{
	if (!source || !map || source->context != map->source) return NULL;
	return pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = judgement,
		.context = map->destination, .core = core, .classifier = classifier,
		.annotation = annotation, .origin = source, .map = map}, NULL, NULL);
}

const struct pg_occurrence *pg_occurrence_derived(struct pg_typing *typing,
	const struct pg_occurrence *source, enum pg_evidence_judgement judgement,
	const struct pg_term *core, const struct pg_term *classifier)
{
	return source ? pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = judgement,
		.context = source->context, .core = core, .classifier = classifier, .origin = source,
		.type = source->classifier == classifier ? source->type : NULL}, NULL, NULL) : NULL;
}

const struct pg_occurrence *pg_occurrence_selected(struct pg_typing *typing,
	const struct pg_occurrence *source, size_t index, const struct pg_occurrence *argument,
	enum pg_evidence_judgement judgement, const struct pg_term *core, const struct pg_term *classifier)
{
	if (!source || index == SIZE_MAX) return NULL;
	if (argument && argument->context != source->context) return NULL;
	return pg_occurrence_intern(typing, &(struct pg_occurrence){.judgement = judgement,
		.context = source->context, .core = core, .classifier = classifier,
		.origin = source, .selection = index + 1, .operand_count = argument != NULL,
		.type = source->classifier == classifier ? source->type : NULL}, argument ? &argument : NULL, NULL);
}

static const struct pg_object *const *map_binders(const struct pg_context_map *map)
{
	return (const struct pg_object *const *)(map->images + map->count);
}

static struct pg_binding_value map_binding(const void *owner, size_t i)
{
	const struct pg_context_map *map = owner;
	if (!map || i >= map->count) return (struct pg_binding_value){0};
	return (struct pg_binding_value){map_binders(map)[i], map->images[i]->core};
}

struct pg_binding_inputs pg_context_map_bindings(const struct pg_context_map *map)
{
	return (struct pg_binding_inputs){.owner = map, .at = map_binding};
}

const struct pg_occurrence *pg_context_map_lookup(const struct pg_context_map *map,
	const struct pg_object *binder, size_t *index)
{
	if (!map) return NULL;
	const struct pg_object *const *binders = map_binders(map);
	for (size_t i = 0; i < map->count; ++i) {
		if (binders[i] != binder) continue;
		if (index) *index = i;
		return map->images[i];
	}
	return NULL;
}

const struct pg_context_map *pg_context_map(struct pg_typing *typing,
	const struct pg_context *source, const struct pg_context *destination,
	size_t count, const struct pg_occurrence *const *images)
{
	if (count && !images) return NULL;
	size_t stride = sizeof(*images) + sizeof(struct pg_object *);
	if (count > (SIZE_MAX - sizeof(struct pg_context_map)) / stride) return NULL;
	uint64_t hash = (uintptr_t)source;
	hash = (hash ^ (uintptr_t)destination) * UINT64_C(1099511628211);
	for (size_t i = 0; i < count; ++i) {
		if (!images[i] || images[i]->context != destination || !images[i]->classifier) return NULL;
		hash = (hash ^ (uintptr_t)images[i]) * UINT64_C(1099511628211);
	}
	for (struct pg_index_entry *p = pg_index_candidates(&typing->context_maps, hash); p; p = p->next) {
		if (p->hash != hash) continue;
		const struct pg_context_map *map = (const struct pg_context_map *)p;
		if (map->scoped_variant) continue;
		if (map->source != source || map->destination != destination || map->count != count) continue;
		if (!count || !memcmp(map->images, images, count * sizeof(*images))) return map;
	}
	size_t length;
	if (pg_context_extension_size(source, NULL, &length) || length != count) return NULL;
	struct pg_context_map *map = pg_alloc(typing->graph, sizeof(*map) + count * stride);
	if (!map) return NULL;
	map->source = source;
	map->judgement = PG_JUDGEMENT_SUBSTITUTION;
	map->scoped_variant = 0;
	map->destination = destination;
	map->count = count;
	map->admission_owner = NULL;
	map->source_scope = map->destination_scope = NULL;
	const struct pg_occurrence **stored_images = (void *)(map + 1);
	map->images = stored_images;
	const struct pg_object **binders = (const struct pg_object **)(map->images + count);
	const struct pg_context *scope = source;
	for (size_t i = count; i; --i, scope = scope->parent) {
		stored_images[i - 1] = images[i - 1];
		binders[i - 1] = scope->binder;
	}
	return pg_index_insert(&typing->context_maps, &map->index, hash) ? NULL : map;
}

const struct pg_context_map *pg_context_map_scoped(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_scope *source,
	const struct pg_scope *destination)
{
	if (!pg_context_map_owned_by(map, typing) || !pg_scope_owned_by(source, typing) ||
		!pg_scope_owned_by(destination, typing) || source->context != map->source ||
		destination->context != map->destination) return NULL;
	if (!map->admission_owner && !map->source_scope && !map->destination_scope) {
		/* The first checked selection uses the raw-first allocation. Once
		 * admitted these facts are immutable, including later raw requests. */
		((struct pg_context_map *)map)->source_scope = source;
		((struct pg_context_map *)map)->destination_scope = destination;
		return map;
	}
	for (const struct pg_index_entry *p = pg_index_candidates(&typing->context_maps, map->index.hash); p; p = p->next) {
		const struct pg_context_map *candidate = (const void *)p;
		if (p->hash != map->index.hash || candidate->source != map->source ||
			candidate->destination != map->destination || candidate->count != map->count ||
			candidate->source_scope != source || candidate->destination_scope != destination) continue;
		if (!map->count || !memcmp(candidate->images, map->images, map->count * sizeof(*map->images))) return candidate;
	}
	struct pg_context_map *selected = pg_alloc(typing->graph, sizeof(*selected));
	if (!selected) return NULL;
	*selected = *map;
	selected->scoped_variant = 1;
	selected->admission_owner = NULL;
	selected->source_scope = source;
	selected->destination_scope = destination;
	return pg_index_insert(&typing->context_maps, &selected->index, map->index.hash) ? NULL : selected;
}

struct context_projection {
	struct pg_index_entry index;
	const struct pg_context_map *map;
};

static const struct pg_occurrence *context_variable(struct pg_typing *typing,
	const struct pg_context *destination, const struct pg_context *declaration)
{
	return pg_occurrence(typing, declaration->judgement, destination,
		pg_reference(typing->graph, declaration->binder), declaration->declared_type, NULL, 0, NULL);
}

const struct pg_context_map *pg_context_map_projection(struct pg_typing *typing,
	const struct pg_context *source, const struct pg_context *destination)
{
	uint64_t hash = (uintptr_t)source * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)destination) * UINT64_C(1099511628211);
	for (struct pg_index_entry *p = pg_index_candidates(&typing->context_projections, hash); p; p = p->next) {
		if (p->hash != hash) continue;
		const struct pg_context_map *map = ((const struct context_projection *)p)->map;
		if (map->source == source && map->destination == destination) return map;
	}
	size_t count;
	if (pg_context_extension_size(destination, source, &count)) return NULL;
	if (pg_context_extension_size(source, NULL, &count)) return NULL;
	if (count > SIZE_MAX / sizeof(const struct pg_occurrence *)) return NULL;
	const struct pg_occurrence **images = malloc(count * sizeof(*images));
	if (count && !images) return NULL;
	const struct pg_context *scope = source;
	for (size_t i = count; i; --i, scope = scope->parent)
		images[i - 1] = context_variable(typing, destination, scope);
	const struct pg_context_map *map = pg_context_map(typing, source, destination, count, images);
	free(images);
	if (!map) return NULL;
	struct context_projection *entry = pg_alloc(typing->graph, sizeof(*entry));
	if (!entry) return NULL;
	entry->map = map;
	return pg_index_insert(&typing->context_projections, &entry->index, hash) ? NULL : map;
}

/* Extend the same structural map for pairing and lifting. Only a changed
 * destination projects the prefix; this does not certify any image. */
const struct pg_context_map *pg_context_map_extend(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_context *source,
	const struct pg_context *destination, size_t count,
	const struct pg_occurrence *const *suffix)
{
	if (!map || (count && !suffix)) return NULL;
	size_t length;
	if (pg_context_extension_size(source, map->source, &length) || length != count) return NULL;
	if (pg_context_extension_size(destination, map->destination, &length)) return NULL;
	if (!count && destination == map->destination) return map;
	if (count > SIZE_MAX / sizeof(const struct pg_occurrence *) - map->count) return NULL;
	size_t total = map->count + count;
	const struct pg_occurrence **images = malloc(total * sizeof(*images));
	if (total && !images) return NULL;
	for (size_t i = 0; i < map->count; ++i)
		images[i] = destination == map->destination ? map->images[i]
			: pg_occurrence_weaken(typing, destination, map->images[i]);
	for (size_t i = 0; i < count; ++i) images[map->count + i] = suffix[i];
	const struct pg_context_map *result = pg_context_map(typing, source, destination, total, images);
	free(images);
	return result;
}

struct pg_context_lift {
	struct pg_index_entry index;
	struct pg_typing *typing;
	const struct pg_context_map *map, *result, *indices_map;
	const struct pg_context *extension;
	const struct pg_object *binder, *requested;
	const struct pg_context **indices;
	const struct pg_term *universe;
	size_t count, next;
	struct pg_context_lift *child;
	struct pg_substitution *substitution;
	struct pg_typing_wait *waiting;
	enum pg_substitution_status status;
	uint64_t steps;
};

/* NULL requests one shared fresh allocation after a collision. A default
 * noncolliding binder uses the same key as an explicit request for that name. */
static struct pg_context_lift *context_lift_request(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_context *extension,
	const struct pg_object *binder)
{
	if (!map || !extension || extension->parent != map->source) return NULL;
	if (binder && binder->kind != PG_BINDER) return NULL;
	if (!binder && !pg_context_lookup(map->destination, extension->binder)) binder = extension->binder;
	uint64_t hash = (uintptr_t)map * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)extension) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)binder) * UINT64_C(1099511628211);
	for (struct pg_index_entry *p = pg_index_candidates(&typing->context_lifts, hash); p; p = p->next) {
		struct pg_context_lift *work = (void *)p;
		if (p->hash == hash && work->map == map && work->extension == extension && work->requested == binder) return work;
	}
	/* Immutable inputs: establish freshness once, before publishing the work. */
	if (binder && pg_context_lookup(map->destination, binder)) return NULL;
	struct pg_context_lift *work = pg_alloc(typing->graph, sizeof(*work));
	if (!work) return NULL;
	work->typing = typing;
	work->map = map;
	work->extension = extension;
	work->requested = binder;
	work->binder = binder ? binder : pg_binder(typing->graph);
	if (!work->binder) return NULL;
	work->indices_map = map;
	work->universe = extension->declared_type;
	if (extension->judgement == PG_JUDGEMENT_TYPE_FAMILY) {
		if (!extension->indices || pg_context_extension_size(extension->indices, extension->parent, &work->count)) return NULL;
		if (work->count > SIZE_MAX / sizeof(*work->indices)) return NULL;
		work->indices = pg_alloc(typing->graph, work->count * sizeof(*work->indices));
		if (!work->indices) return NULL;
		const struct pg_context *index = extension->indices;
		for (size_t i = work->count; i; --i, index = index->parent) work->indices[i - 1] = index;
		for (size_t i = 0; i < work->count; ++i) {
			const struct pg_term *domain, *body;
			const struct pg_object *bound;
			if (!pg_pi_view(work->universe, &domain, &bound, &body)) return NULL;
			if (domain != work->indices[i]->declared_type || bound != work->indices[i]->binder) return NULL;
			work->universe = body;
		}
	}
	return pg_index_insert(&typing->context_lifts, &work->index, hash) ? NULL : work;
}

struct pg_context_lift *pg_context_lift_request(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_context *extension,
	const struct pg_object *binder)
{
	return binder ? context_lift_request(typing, map, extension, binder) : NULL;
}

static enum pg_substitution_status context_lift_step(struct pg_context_lift *work)
{
	struct pg_typing *typing = work->typing;
	if (work->child) {
		if (work->child->status != PG_SUBSTITUTION_DONE) return work->child->status;
		work->indices_map = work->child->result;
		work->child = NULL;
		++work->next;
	}
	if (work->next < work->count) {
		const struct pg_context *index = work->indices[work->next];
		work->child = context_lift_request(typing, work->indices_map, index, NULL);
		return work->child ? PG_SUBSTITUTION_PENDING : PG_SUBSTITUTION_ERROR;
	}
	if (!work->substitution) work->substitution = pg_substitution_request(&typing->substitutions,
		work->universe, work->indices_map->count, pg_context_map_bindings(work->indices_map));
	enum pg_substitution_status status = pg_substitution_advance(work->substitution, 1);
	if (status != PG_SUBSTITUTION_DONE) return status;
	const struct pg_term *type = pg_substitution_result(work->substitution);
	const struct pg_context *indices = work->count ? work->indices_map->destination : NULL;
	if (indices) type = pg_context_signature(typing->graph, work->map->destination, indices, type);
	const struct pg_context *destination = pg_context_intern(typing, &(struct pg_context){
		.parent = work->map->destination, .binder = work->binder, .declared_type = type,
		.judgement = work->extension->judgement, .indices = indices});
	if (!destination) return PG_SUBSTITUTION_ERROR;
	const struct pg_occurrence *image = pg_occurrence(typing, work->extension->judgement, destination,
		pg_reference(typing->graph, work->binder), type, NULL, 0, NULL);
	work->result = pg_context_map_extend(typing, work->map, work->extension, destination, 1, &image);
	return work->result ? PG_SUBSTITUTION_DONE : PG_SUBSTITUTION_ERROR;
}

enum pg_substitution_status pg_context_lift_advance(struct pg_context_lift *work, uint64_t budget)
{
	if (!work) return PG_SUBSTITUTION_ERROR;
	while (work->status == PG_SUBSTITUTION_PENDING && budget--) {
		struct pg_context_lift *current = work->waiting ? work->waiting->work : work;
		++work->steps;
		if (current->status == PG_SUBSTITUTION_PENDING) {
			if (current != work) ++current->steps;
			current->status = context_lift_step(current);
		}
		if (current->status != PG_SUBSTITUTION_PENDING) {
			pg_typing_wait_clear(work->typing, &current->waiting);
			pg_typing_wait_pop(work->typing, &work->waiting);
		} else if (current->child && current->child->status == PG_SUBSTITUTION_PENDING) {
			if (pg_typing_wait_push(work->typing, &work->waiting, current->child))
				work->status = PG_SUBSTITUTION_ERROR;
		}
	}
	if (work->status != PG_SUBSTITUTION_PENDING) pg_typing_wait_clear(work->typing, &work->waiting);
	return work->status;
}

const struct pg_context_map *pg_context_lift_result(const struct pg_context_lift *work)
{
	return work && work->status == PG_SUBSTITUTION_DONE ? work->result : NULL;
}

const struct pg_context_map *pg_context_lift_indices(const struct pg_context_lift *work)
{
	return pg_context_lift_result(work) && work->count ? work->indices_map : NULL;
}

uint64_t pg_context_lift_steps(const struct pg_context_lift *work)
{
	return work ? work->steps : 0;
}

const struct pg_context_map *pg_context_map_lift(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_context *extension,
	const struct pg_object *binder)
{
	struct pg_context_lift *work = pg_context_lift_request(typing, map, extension, binder);
	while (pg_context_lift_advance(work, 1024) == PG_SUBSTITUTION_PENDING) {}
	return pg_context_lift_result(work);
}

static const struct pg_occurrence *action_result(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_occurrence *source,
	const struct pg_term *core, const struct pg_term *classifier, const struct pg_term *annotation)
{
	const struct pg_occurrence *image = source->core->kind == PG_REFERENCE
		? pg_context_map_lookup(map, source->core->as.reference, NULL) : NULL;
	if (image) {
		if (image->core != core) return NULL;
		if (image->judgement == source->judgement && image->classifier == classifier) return image;
		/* Keep the checked substitution's recipe when its classifier has
		 * different binder pointers. A bare boundary loses that premise. */
		return pg_occurrence_mapped(typing, source->judgement, core, classifier,
			annotation, source, map);
	}
	int identity = map->source == map->destination;
	for (size_t i = 0; identity && i < map->count; ++i) {
		struct pg_binding_value binding = map_binding(map, i);
		identity = binding.value->kind == PG_REFERENCE && binding.value->as.reference == binding.binder;
	}
	return identity ? source : pg_occurrence_mapped(typing,
		source->judgement, core, classifier, annotation, source, map);
}

const struct pg_occurrence *pg_occurrence_projection(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_occurrence *source)
{
	size_t count;
	if (!map || !source || source->context != map->source) return NULL;
	if (pg_context_extension_size(map->destination, map->source, &count)) return NULL;
	for (size_t i = 0; i < map->count; ++i) {
		struct pg_binding_value binding = map_binding(map, i);
		if (binding.value->kind != PG_REFERENCE) return NULL;
		if (binding.value->as.reference != binding.binder) return NULL;
	}
	return action_result(typing, map, source, source->core, source->classifier, source->annotation);
}

const struct pg_occurrence *pg_occurrence_weaken(struct pg_typing *typing,
	const struct pg_context *destination, const struct pg_occurrence *source)
{
	size_t count;
	if (!source || pg_context_extension_size(destination, source->context, &count)) return NULL;
	if (source->scope) {
		if (!count) return source;
		struct pg_occurrence header = *source;
		header.context = destination;
		return pg_occurrence_intern(typing, &header, NULL, NULL);
	}
	if (!source->scope && source->core->kind == PG_REFERENCE && source->core->as.reference->kind == PG_BINDER) {
		const struct pg_context *declaration = NULL;
		/* Match the map's oldest-first image selection even for raw contexts
		 * not yet checked for duplicate binder declarations. */
		for (const struct pg_context *scope = source->context; scope; scope = scope->parent)
			if (scope->binder == source->core->as.reference) declaration = scope;
		if (declaration && declaration->judgement == source->judgement && declaration->declared_type == source->classifier)
			return context_variable(typing, destination, declaration);
	}
	return pg_occurrence_projection(typing,
		pg_context_map_projection(typing, source->context, destination), source);
}

const struct pg_occurrence *pg_occurrence_unproject(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct pg_context *destination)
{
	size_t count;
	if (!source || pg_context_extension_size(source->context, destination, &count)) return NULL;
	if (source->context == destination) return source;
	if (source->scope) {
		struct pg_occurrence header = *source;
		header.context = destination;
		return pg_occurrence_intern(typing, &header, NULL, NULL);
	}
	if (source->core->kind == PG_REFERENCE && source->core->as.reference->kind == PG_BINDER) {
		const struct pg_context *declaration = pg_context_lookup(destination, source->core->as.reference);
		if (declaration && declaration->judgement == source->judgement && declaration->declared_type == source->classifier)
			return pg_occurrence(typing, source->judgement, destination, source->core, source->classifier, NULL, 0, NULL);
	}
	while (source->context != destination) {
		if (!source->map) return NULL;
		/* Only cancel an exact weakening. A converted boundary or a map that
		 * changes images must retain its justification and typed dependencies. */
		if (pg_occurrence_projection(typing, source->map, source->origin) != source) return NULL;
		source = source->origin;
		if (source->context == destination) return source;
		if (!pg_context_extension_size(destination, source->context, &count))
			return pg_occurrence_projection(typing,
				pg_context_map_projection(typing, source->context, destination), source);
	}
	return source;
}

static struct pg_occurrence_action *occurrence_action_find(const struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_occurrence *source, uint64_t *hash_out)
{
	uint64_t hash = (UINT64_C(1469598103934665603) ^ (uintptr_t)map) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)source) * UINT64_C(1099511628211);
	*hash_out = hash;
	if (!typing || !typing->occurrence_actions.capacity) return NULL;
	for (struct pg_index_entry *p = pg_index_candidates(&typing->occurrence_actions, hash); p; p = p->next) {
		struct pg_occurrence_action *work = (struct pg_occurrence_action *)p;
		if (p->hash == hash && work->map == map && work->source == source) return work;
	}
	return NULL;
}

const struct pg_occurrence *pg_occurrence_action_cached(const struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_occurrence *source)
{
	uint64_t hash;
	return pg_occurrence_action_result(occurrence_action_find(typing, map, source, &hash));
}

struct pg_occurrence_action *pg_occurrence_action_request(struct pg_typing *typing,
	const struct pg_context_map *map, const struct pg_occurrence *source)
{
	if (!map || !source || source->context != map->source || !source->classifier) return NULL;
	uint64_t hash;
	struct pg_occurrence_action *existing = occurrence_action_find(typing, map, source, &hash);
	if (existing) return existing;
	struct pg_occurrence_action *work = pg_alloc(typing->graph, sizeof(*work));
	if (!work) return NULL;
	work->typing = typing;
	work->map = map;
	work->source = source;
	return pg_index_insert(&typing->occurrence_actions, &work->index, hash) ? NULL : work;
}

struct pg_occurrence_action *pg_occurrence_instantiate_request(struct pg_typing *typing,
	const struct pg_occurrence *body, const struct pg_occurrence *argument)
{
	if (!body || !argument || !body->context) return NULL;
	if (body->context->parent != argument->context) return NULL;
	const struct pg_context_map *prefix = pg_context_map_projection(typing,
		argument->context, argument->context);
	return pg_occurrence_action_request(typing,
		pg_context_map_extend(typing, prefix, body->context, argument->context, 1, &argument), body);
}

static enum pg_substitution_status occurrence_action_step(struct pg_occurrence_action *work)
{
	const struct pg_occurrence *source = work->source;
	const struct pg_context_map *map = work->map;
	if (!work->next && !work->substitution) {
		work->result = pg_occurrence_projection(work->typing, map, source);
		if (work->result) return PG_SUBSTITUTION_DONE;
	}
	if (work->next < 3) {
		const struct pg_term *inputs[] = {source->core, source->classifier, source->annotation};
		if (!inputs[work->next]) { ++work->next; return PG_SUBSTITUTION_PENDING; }
		/* An explicitly reused checkpoint can retain a completed Core result in
		 * this same output slot. Consuming it remains one ordinary action step. */
		if (work->outputs[work->next]) { ++work->next; return PG_SUBSTITUTION_PENDING; }
		if (!work->substitution) {
			work->substitution = pg_substitution_request(&work->typing->substitutions,
				inputs[work->next], map->count, pg_context_map_bindings(map));
			return work->substitution ? PG_SUBSTITUTION_PENDING : PG_SUBSTITUTION_ERROR;
		}
		enum pg_substitution_status status = pg_substitution_advance(work->substitution, 1);
		if (status != PG_SUBSTITUTION_DONE) return status;
		work->outputs[work->next++] = pg_substitution_result(work->substitution);
		work->substitution = NULL;
		return PG_SUBSTITUTION_PENDING;
	}
	work->result = action_result(work->typing, map, source,
		work->outputs[0], work->outputs[1], work->outputs[2]);
	return work->result ? PG_SUBSTITUTION_DONE : PG_SUBSTITUTION_ERROR;
}

enum pg_substitution_status pg_occurrence_action_advance(struct pg_occurrence_action *work,
	uint64_t budget)
{
	if (!work) return PG_SUBSTITUTION_ERROR;
	if (budget && !work->typing) return PG_SUBSTITUTION_ERROR;
	while (work->status == PG_SUBSTITUTION_PENDING && budget) {
		--budget;
		++work->steps;
		work->status = occurrence_action_step(work);
	}
	return work->status;
}

const struct pg_occurrence *pg_occurrence_action_result(const struct pg_occurrence_action *work)
{
	return work && work->status == PG_SUBSTITUTION_DONE ? work->result : NULL;
}

uint64_t pg_occurrence_action_steps(const struct pg_occurrence_action *work)
{
	return work ? work->steps : 0;
}

static struct pg_occurrence_input *input_find(struct pg_typing *typing,
	const struct pg_occurrence *source, size_t index, const struct pg_context_map *map,
	const struct pg_occurrence *child, uint64_t *hash_out)
{
	uint64_t hash = ((uintptr_t)source ^ index) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)map) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)child) * UINT64_C(1099511628211);
	*hash_out = hash;
	for (struct pg_index_entry *p = pg_index_candidates(&typing->occurrence_inputs, hash); p; p = p->next) {
		struct pg_occurrence_input *work = (void *)p;
		if (p->hash == hash && work->source == source && work->index == index && work->outer == map && work->child == child) return work;
	}
	return NULL;
}

static struct pg_occurrence_input *input_request(struct pg_typing *typing,
	const struct pg_occurrence *source, size_t index, const struct pg_context_map *map,
	const struct pg_occurrence *child)
{
	if (!source || !source->classifier) return NULL;
	if (map && map->source != source->context) return NULL;
	uint64_t hash;
	struct pg_occurrence_input *existing = input_find(typing, source, index, map, child, &hash);
	if (existing) return existing;
	struct pg_occurrence_input *work = pg_alloc(typing->graph, sizeof(*work));
	if (!work) return NULL;
	work->typing = typing;
	work->source = source;
	work->current = child ? NULL : source;
	work->child = work->result = child;
	work->index = index;
	work->outer = map;
	if (child) {
		const struct pg_occurrence_input *resume = input_request(typing, source, index, map, NULL);
		if (!resume || resume->status != PG_INPUT_UNAVAILABLE || !resume->current) return NULL;
		work->maps = resume->maps;
	} else if (map) {
		work->maps = pg_alloc(typing->graph, sizeof(*work->maps));
		if (!work->maps) return NULL;
		*work->maps = (struct input_map){map, source->core, NULL};
	}
	return pg_index_insert(&typing->occurrence_inputs, &work->entry, hash) ? NULL : work;
}

struct pg_occurrence_input *pg_occurrence_type_pending_import(struct pg_typing *typing,
	const struct pg_occurrence_input *input)
{
	if (!typing || !input || input->typing || input->index != SIZE_MAX
		|| input->status != PG_INPUT_PENDING || input->outer || input->child
		|| !pg_occurrence_owned_by(input->source, typing)) return NULL;
	uint64_t hash;
	if (input_find(typing, input->source, SIZE_MAX, NULL, NULL, &hash)) return NULL;
	struct pg_occurrence_input *work = pg_alloc(typing->graph, sizeof(*work));
	if (!work) return NULL;
	*work = *input;
	work->entry = (struct pg_index_entry){0};
	return pg_index_insert(&typing->occurrence_inputs, &work->entry, hash) ? NULL : work;
}

struct pg_occurrence_input *pg_occurrence_input_request(struct pg_typing *typing,
	const struct pg_occurrence *source, size_t index)
{
	return index == SIZE_MAX ? NULL : input_request(typing, source, index, NULL, NULL);
}

struct pg_occurrence_input *pg_occurrence_input_mapped_request(struct pg_typing *typing,
	const struct pg_occurrence *source, size_t index, const struct pg_context_map *map)
{
	return map && index != SIZE_MAX ? input_request(typing, source, index, map, NULL) : NULL;
}

const struct pg_occurrence *pg_occurrence_input_blocked_source(const struct pg_occurrence_input *work)
{
	return work && work->status == PG_INPUT_UNAVAILABLE && work->index != SIZE_MAX ? work->current : NULL;
}

struct pg_occurrence_input *pg_occurrence_input_resume_request(struct pg_typing *typing,
	const struct pg_occurrence_input *work, const struct pg_occurrence *child)
{
	if (!work || work->typing != typing || !pg_occurrence_input_blocked_source(work) || !child || !child->classifier) return NULL;
	return input_request(typing, work->source, work->index, work->outer, child);
}

struct pg_occurrence_input *pg_occurrence_type_request(struct pg_typing *typing,
	const struct pg_occurrence *source)
{
	/* No operand array can have this index; the same scoped edge machinery
	 * handles the classifier without another work graph or source of truth. */
	return input_request(typing, source, SIZE_MAX, NULL, NULL);
}

/* The semantic owner exposes the same lexical binding carried by Core.
 * This is a scope view, not another executable binder representation. */
const struct pg_object *pg_occurrence_input_binder(const struct pg_term *core, size_t index,
	const struct pg_term **body)
{
	if (!core || !body) return NULL;
	if (core->kind == PG_LAMBDA && index == 0) {
		*body = core->as.lambda.body;
		return core->as.lambda.binder;
	}
	const struct pg_term *domain;
	const struct pg_object *binder;
	return index == 1 && pg_pi_view(core, &domain, &binder, body) ? binder : NULL;
}

const struct pg_occurrence *pg_occurrence_scoped_input(const struct pg_occurrence *source,
	size_t index)
{
	while (source && source->origin && !source->map && !source->selection && source->core == source->origin->core)
		source = source->origin;
	if (!source || source->origin || index >= source->operand_count) return NULL;
	const struct pg_occurrence *input = source->operands[index];
	const struct pg_context *scope = input->context;
	if (!scope || scope->parent != source->context) return NULL;
	const struct pg_term *body;
	const struct pg_object *binder = pg_occurrence_input_binder(source->core, index, &body);
	return binder && scope->binder == binder && input->core == body ? input : NULL;
}

/* These declarations are inputs in their own context, not terms in the
 * elimination's destination. Its explicit parameter maps carry the action. */
static int retained_input(const struct pg_occurrence *source, size_t index)
{
	/* Family Identity retains its generic family; elimination retains the
	 * nominal formation. Constructor fields and type-case branches are current
	 * children and must receive the enclosing map instead of discarding it. */
	if (source->map_count == 2 && source->judgement != PG_JUDGEMENT_VALUE) return index == 0;
	return source->map_count == 1 && source->judgement == PG_JUDGEMENT_COMPUTATION &&
		source->operand_count >= 3 && index == source->operand_count - 1;
}

static int motive_input(const struct pg_occurrence *source, size_t index)
{
	if (source->judgement != PG_JUDGEMENT_COMPUTATION || source->map_count != 1) return 0;
	if (source->operand_count < 3 || index != source->operand_count - 2) return 0;
	size_t count;
	return !pg_context_extension_size(source->operands[index]->context, source->context, &count);
}

/* Pi and logical Lambda retain declaration inputs in the family's local
 * scopes. They undergo the same lifted action as other scoped inputs. */
static int signature_input(const struct pg_occurrence *source, size_t index)
{
	size_t body_index;
	if (source->judgement == PG_JUDGEMENT_COMPUTATION_TYPE) body_index = 1;
	else if (source->judgement == PG_JUDGEMENT_TYPE_FAMILY) body_index = 0;
	else return 0;
	if (index == body_index) return 0;
	const struct pg_occurrence *body = pg_occurrence_scoped_input(source, body_index);
	if (!body || body->context->judgement != PG_JUDGEMENT_TYPE_FAMILY) return 0;
	size_t count;
	return !pg_context_extension_size(source->operands[index]->context, source->context, &count);
}

static enum pg_occurrence_input_status occurrence_input_step(struct pg_occurrence_input *work)
{
	struct pg_typing *typing = work->typing;
	if (work->current) {
		const struct pg_occurrence *current = work->current;
		if (work->index == SIZE_MAX && current->type) {
			work->result = current->type;
			work->current = NULL;
			return PG_INPUT_PENDING;
		}
		if (current->selection && work->index != SIZE_MAX) {
			if (!work->selected) work->selected = input_request(typing, current->origin, current->selection - 1, NULL, NULL);
			if (!work->selected) return PG_INPUT_ERROR;
			enum pg_occurrence_input_status status = work->selected->status;
			if (status != PG_INPUT_READY) return status;
			const struct pg_occurrence *child = pg_occurrence_input_result(work->selected);
			if (current->operand_count) {
				if (!work->action) work->action = pg_occurrence_instantiate_request(typing, child, current->operands[0]);
				enum pg_substitution_status action = pg_occurrence_action_advance(work->action, 1);
				if (action == PG_SUBSTITUTION_ERROR) return PG_INPUT_ERROR;
				if (action == PG_SUBSTITUTION_PENDING) return PG_INPUT_PENDING;
				child = pg_occurrence_action_result(work->action);
			} else child = pg_occurrence_unproject(typing, child, current->context);
			if (!child) return PG_INPUT_UNAVAILABLE;
			work->current = child;
			work->selected = NULL;
			work->action = NULL;
			return PG_INPUT_PENDING;
		}
		if (current->map) {
			const struct pg_term *origin = current->origin->core;
			if (work->index != SIZE_MAX && origin->kind == PG_REFERENCE && origin->as.reference->kind == PG_BINDER) {
				const struct pg_occurrence *image = pg_context_map_lookup(current->map,
					origin->as.reference, NULL);
				if (image) {
					work->current = image;
					return PG_INPUT_PENDING;
				}
			}
			struct input_map *frame = pg_alloc(typing->graph, sizeof(*frame));
			if (!frame) return PG_INPUT_ERROR;
			*frame = (struct input_map){current->map, current->core, work->maps};
			work->maps = frame;
			work->current = current->origin;
		} else {
			if (work->index == SIZE_MAX) {
				if (!current->origin || current->classifier != current->origin->classifier) return PG_INPUT_UNAVAILABLE;
				work->current = current->origin;
				return PG_INPUT_PENDING;
			}
			if (current->origin) {
				if (current->core != current->origin->core) return PG_INPUT_UNAVAILABLE;
				work->current = current->origin;
				return PG_INPUT_PENDING;
			}
			if (work->index >= current->operand_count) return PG_INPUT_UNAVAILABLE;
			work->result = current->operands[work->index];
			if (retained_input(current, work->index)) work->maps = NULL;
			else if (work->result->context != current->context && !motive_input(current, work->index) &&
				!signature_input(current, work->index) &&
				!pg_occurrence_scoped_input(current, work->index)) return PG_INPUT_UNAVAILABLE;
			work->current = NULL;
		}
		return PG_INPUT_PENDING;
	}
	if (!work->maps) return PG_INPUT_READY;
	const struct pg_context_map *map = work->maps->map;
	if (!work->effective) {
		for (const struct pg_context *scope = work->result->context; scope != map->source; scope = scope->parent) {
			if (!scope) return PG_INPUT_UNAVAILABLE;
			struct input_scope *frame = pg_alloc(typing->graph, sizeof(*frame));
			if (!frame) return PG_INPUT_ERROR;
			*frame = (struct input_scope){scope, work->scopes};
			work->scopes = frame;
		}
		work->effective = map;
	}
	if (work->scopes) {
		const struct pg_context *scope = work->scopes->context;
		if (!work->lift) {
			const struct pg_term *body;
			const struct pg_object *binder = pg_occurrence_input_binder(work->maps->core, work->index, &body);
			map = work->effective;
			if (binder && pg_context_lookup(map->destination, binder)) binder = NULL;
			work->lift = context_lift_request(typing, map, scope, binder);
		}
		enum pg_substitution_status status = pg_context_lift_advance(work->lift, 1);
		if (status == PG_SUBSTITUTION_ERROR) return PG_INPUT_ERROR;
		if (status == PG_SUBSTITUTION_PENDING) return PG_INPUT_PENDING;
		work->effective = pg_context_lift_result(work->lift);
		if (!work->effective) return PG_INPUT_ERROR;
		work->scopes = work->scopes->next;
		work->lift = NULL;
		return PG_INPUT_PENDING;
	}
	if (!work->action)
		work->action = pg_occurrence_action_request(typing, work->effective, work->result);
	enum pg_substitution_status status = pg_occurrence_action_advance(work->action, 1);
	if (status == PG_SUBSTITUTION_ERROR) return PG_INPUT_ERROR;
	if (status == PG_SUBSTITUTION_DONE) {
		work->result = pg_occurrence_action_result(work->action);
		work->maps = work->maps->next;
		work->action = NULL;
		work->effective = NULL;
	}
	return PG_INPUT_PENDING;
}

enum pg_occurrence_input_status pg_occurrence_input_advance(struct pg_occurrence_input *work,
	uint64_t budget)
{
	if (!work) return PG_INPUT_ERROR;
	if (budget && !work->typing) return PG_INPUT_ERROR;
	while (work->status == PG_INPUT_PENDING && budget--) {
		struct pg_occurrence_input *current = work->waiting ? work->waiting->work : work;
		++work->steps;
		if (current->status == PG_INPUT_PENDING) {
			if (current != work) ++current->steps;
			current->status = occurrence_input_step(current);
		}
		/* Shared dependencies can also finish through another caller. Resume
		 * their parent without recursive advancement or restarting the query. */
		if (current->status != PG_INPUT_PENDING) {
			pg_typing_wait_clear(work->typing, &current->waiting);
			pg_typing_wait_pop(work->typing, &work->waiting);
		} else if (current->selected && current->selected->status == PG_INPUT_PENDING) {
			if (pg_typing_wait_push(work->typing, &work->waiting, current->selected))
				work->status = PG_INPUT_ERROR;
		}
	}
	if (work->status != PG_INPUT_PENDING) pg_typing_wait_clear(work->typing, &work->waiting);
	return work->status;
}

const struct pg_occurrence *pg_occurrence_input_result(const struct pg_occurrence_input *work)
{
	return work && work->status == PG_INPUT_READY ? work->result : NULL;
}

struct pg_occurrence_input *pg_occurrence_type_resume(struct pg_typing *typing,
	const struct pg_occurrence *source, struct pg_occurrence_input *saved)
{
	if (!typing || !saved || saved->source != source || saved->typing || saved->index != SIZE_MAX
		|| saved->status != PG_INPUT_PENDING || saved->outer || saved->child
		|| saved->waiting || saved->selected || saved->scopes || saved->lift
		|| !pg_evidence_owned_by((const void *)saved->source, typing)) return NULL;
	uint64_t input_hash;
	if (input_find(typing, source, SIZE_MAX, NULL, NULL, &input_hash) != saved) return NULL;
	if (saved->current && !pg_occurrence_owned_by(saved->current, typing)) return NULL;
	if (saved->result && !pg_occurrence_owned_by(saved->result, typing)) return NULL;
	if (saved->current && saved->result) return NULL;
	const struct pg_occurrence *cursor = saved->source;
	while (cursor && cursor != saved->current && !cursor->type) cursor = cursor->origin;
	if (saved->current && cursor != saved->current) return NULL;
	for (const struct input_map *frame = saved->maps; frame; frame = frame->next) {
		if (!pg_context_map_owned_by(frame->map, typing)) return NULL;
		cursor = saved->source;
		while (cursor && (cursor->map != frame->map || cursor->core != frame->core)) cursor = cursor->origin;
		if (!cursor) return NULL;
	}
	if (saved->effective && (!saved->maps || saved->effective != saved->maps->map)) return NULL;
	struct pg_occurrence_action *action = NULL;
	if (saved->action) {
		const struct pg_occurrence_action *old = saved->action;
		if (saved->current || !saved->result || !saved->effective || old->typing
			|| old->source != saved->result || old->map != saved->effective
			|| old->result || old->substitution || old->next > 3 || old->status != PG_SUBSTITUTION_PENDING) return NULL;
		for (size_t i = old->next + 1; i < 3; ++i) if (old->outputs[i]) return NULL;
		uint64_t hash;
		action = occurrence_action_find(typing, old->map, old->source, &hash);
		if (action && (action->steps || action->next || action->substitution || action->result
			|| action->status != PG_SUBSTITUTION_PENDING)) return NULL;
	}
	if (saved->action) {
		struct pg_occurrence_action *old = saved->action;
		if (!action && pg_index_prepare_insert(&typing->occurrence_actions)) return NULL;
		if (!action) {
			uint64_t hash;
			occurrence_action_find(typing, old->map, old->source, &hash);
			if (pg_index_insert(&typing->occurrence_actions, &old->index, hash)) return NULL;
			action = old;
		} else {
			struct pg_index_entry index = action->index;
			*action = *old;
			action->index = index;
		}
		action->typing = typing;
	}
	saved->typing = typing; saved->action = action;
	return saved;
}

uint64_t pg_occurrence_input_steps(const struct pg_occurrence_input *work)
{
	return work ? work->steps : 0;
}

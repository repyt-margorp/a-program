# Native telescope frontier r5

This extends frozen native Source closure r4. Schema key discovery is separated
from its actual pre-member telescope edge. The native telescope keeps its existing
lexical scope/tail cursor and borrows canonical binding owners. No cursor array,
new index, owner, replay/checker or Oracle-level graph is added. Source I/O carries
the current lexical scope in its existing scope table/prepared ordinal. The cold
checkpoint needs one native telescope root, with no redundant body export root.

Loading retains descriptive lexical progress without accepting a Context or
typed fact and without Solve. Explicit authentic attachment validates that same
canonical cursor; normal attachment still refuses. Existing binding/context and
annotation checking proceeds through ordinary charged Solve. Discovery can be
reused because its canonical syntax/binding ancestry is checked without creating
another binding or admitting facts. Copied/foreign/wrong-child/raw/returned-frame
Scope and duplicate controls reject without count/ready/steps/admission mutation.

Four destroyed-producer cold cuts pass O2/SAN, with inert resave/result bytes and
exact useful30/29/28/27 of ordinary30. Loaded admissions remain1 (empty Context).
The earlier actual application Source cuts2/3/4 retain their charged validation,
same total B/cap R, byte/result and lifetime controls. New schema-edge controls
distinguish canonical telescope identity from copied and wrong-scope requests.
Original sign-compare build2 and partial-schedule control134 remain preserved.

Exact candidate has full unskipped serial O2 acceptance0 and seven affected SAN
gates0. Both imported ordinary Sorted workloads are DONE; exact steps are in the
verification summary. Both actual strict public recipes remain FAIL1 on the same
original three classes; all40 TSV/all52 images equal r4. These are local results,
not general public continuation, current-producer joint acceptance or time/peak
evidence. New transport stores essential progress; no memory/speed gain is claimed.

Allocated names/members, nominal telescope allocations, completed telescope,
constructor/qualified/Match and started WHNF endpoints still require their actual
owners/frontiers. Source ancestry checking uses the existing index; its traversal
cost and typed-owner overhead need later exclusive joint Performance attribution.
Frame/spine escaped-pointer contracts and reusable results remain mandatory.

Full snapshots are authoritative, applied.diff review-only. The durable manifest
lists actual publication files; raw logs/earlier sources stay externally pinned.
Merge owns exact task/current publication. Frozen r1-r4 and later trial6 are
excluded. No accepted, eval/readback or shared-Git changes; Goal remains active.

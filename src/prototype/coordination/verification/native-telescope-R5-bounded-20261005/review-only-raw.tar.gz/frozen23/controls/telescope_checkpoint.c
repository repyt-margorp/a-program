#define main composed_control_main
#include "application_composed_checkpoint.c"
#undef main

/* Exercise discovery independently of annotation checking. These ordinary
 * canonical factories also supply the lexical inputs of the eventual body. */
static struct pg_program *telescope_start(struct pg_synthesis_job **body,
	struct pg_synthesis_job **bindings, struct pg_synthesis_job **domains)
{
	const char *text = "v := \\x : @ => \\y : @ => \\z : @ => x;";
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *module = pg_parser_program(&program->parser);
	assert(module && !program->parser.error && module->item_count == 1);
	const struct pg_syntax *syntax = module->items[0].expression;
	program->root = pg_synthesis_telescope(&program->synthesis, program->scope, syntax);
	assert(program->root);
	const struct pg_source_scope *scope = program->scope;
	for (size_t i = 0; i < 3; ++i) {
		bindings[i] = pg_synthesis_binding(&program->synthesis, scope, syntax);
		assert(bindings[i] && pg_synthesis_binding_domain(&program->synthesis, bindings[i], &domains[i]) == 1);
		scope = pg_synthesis_binding_scope(bindings[i]); syntax = syntax->right;
	}
	*body = pg_synthesis_request(&program->synthesis, scope, syntax);
	assert(*body);
	return program;
}

static void select_ready(struct pg_program *program, size_t ready_count, struct pg_synthesis_job **ready)
{
	struct pg_synthesis *s = &program->synthesis;
	size_t count = s->jobs.count, next = 0;
	struct pg_synthesis_job **jobs = calloc(count, sizeof(*jobs));
	size_t *ordinals = calloc(ready_count, sizeof(*ordinals));
	assert(jobs && ordinals);
	for (size_t i = 0; i < s->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = s->jobs.buckets[i]; entry; entry = entry->next) jobs[next++] = (void *)entry;
	assert(next == count);
	for (size_t i = 0; i < ready_count; ++i) {
		size_t slot = 0;
		while (slot < count && jobs[slot] != ready[i]) ++slot;
		assert(slot < count); ordinals[i] = slot;
	}
	const struct pg_artifact_schedule *schedule = pg_artifact_schedule_ready(&program->graph, count, ready_count, ordinals);
	assert(schedule && !pg_artifact_schedule_attach(s, schedule, count, jobs));
	free(jobs); free(ordinals);
}

static void only(struct pg_program *program, struct pg_synthesis_job *job)
{
	select_ready(program, 1, &job);
}

static size_t all(struct pg_program *program, struct pg_synthesis_job *body,
	struct pg_synthesis_job **bindings, struct pg_synthesis_job **domains,
	struct pg_synthesis_job ***output)
{
	size_t count = program->synthesis.jobs.count;
	struct pg_synthesis_job **jobs = calloc(count, sizeof(*jobs));
	assert(jobs && count == 11);
	jobs[0] = program->root; jobs[1] = body;
	for (size_t i = 0; i < 3; ++i) {
		jobs[2 + 3 * i] = bindings[i]; jobs[3 + 3 * i] = domains[i];
		jobs[4 + 3 * i] = (void *)domains[i]->inputs[1];
		assert(pg_synthesis_plain_derivation(jobs[4 + 3 * i]));
	}
	*output = jobs;
	return count;
}

static int write_telescope(FILE *file, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	const struct checkpoint *checkpoint = opaque;
	return pg_artifact_source_write_with(file, checkpoint->source, codec, objects);
}

static int read_telescope(FILE *file, struct pg_typing *typing, size_t limit, size_t names,
	const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	struct checkpoint *checkpoint = opaque;
	checkpoint->source = pg_artifact_source_read_with(file, typing, limit, names, codec, objects);
	return !checkpoint->source;
}

static void continuation(struct pg_program *program, struct pg_synthesis_job **bindings,
	struct pg_synthesis_job **domains)
{
	/* The same explicit ordinary ready order is used on both sides. It checks
 * all retained annotations/Contexts rather than marking discovery DONE. */
	struct pg_synthesis_job *ready[] = {(void *)domains[0]->inputs[1], domains[0], bindings[0],
		(void *)domains[1]->inputs[1], domains[1], bindings[1], (void *)domains[2]->inputs[1], domains[2], bindings[2], program->root};
	select_ready(program, 10, ready);
}

static void telescope_check(uint64_t cut)
{
	struct pg_synthesis_job *body, *bindings[3], *domains[3];
	struct pg_program *program = telescope_start(&body, bindings, domains);
	only(program, program->root);
	advance(&program->synthesis, 3);
	continuation(program, bindings, domains);
	uint64_t total = finish(program);
	FILE *expected = tmpfile();
	struct pg_synthesis_input result = {.checked = pg_synthesis_result(program->root)};
	assert(expected && result.checked && !pg_sources_write(expected, &program->synthesis, 1, &result));
	pg_program_destroy(program);
	program = telescope_start(&body, bindings, domains);
	only(program, program->root);
	advance(&program->synthesis, cut);
	int started;
	struct pg_synthesis_job *binding;
	assert(pg_synthesis_telescope_frontier(&program->synthesis, program->root, &started, &binding) == 1
		&& started == (cut != 0) && binding == (cut ? bindings[cut - 1] : NULL));
	struct pg_synthesis_job **mapping;
	size_t count = all(program, body, bindings, domains, &mapping);
	struct pg_synthesis_job *owners[] = {program->root, bindings[0], domains[0], bindings[1], domains[1], bindings[2], domains[2], body};
	struct checkpoint saved = {0};
	saved.source = pg_artifact_source_capture(&program->graph, &program->synthesis, count, mapping, 8, owners);
	assert(saved.source);
	FILE *file = tmpfile();
	struct pg_synthesis_input inputs[] = {{.pending = pg_synthesis_pending(program->root)}, {.pending = pg_synthesis_pending(body)}};
	assert(file && !pg_sources_write_with(file, &program->synthesis, 1, inputs, 0, write_telescope, &saved));
	free(mapping);
	pg_program_destroy(program);
	rewind(file);
	struct checkpoint loaded = {0};
	size_t source_count;
	struct pg_synthesis_job *const *sources;
	program = pg_sources_read_with(file, 100000, &source_count, &sources, read_telescope, &loaded);
	assert(program && source_count == 1 && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	program->root = sources[0];
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(pg_synthesis_telescope_input(&program->synthesis, program->root, &scope, &syntax) == 1);
	for (size_t i = 0; i < 3; ++i) {
		bindings[i] = pg_synthesis_binding(&program->synthesis, scope, syntax);
		assert(bindings[i] && pg_synthesis_binding_domain(&program->synthesis, bindings[i], &domains[i]) == 1);
		scope = pg_synthesis_binding_scope(bindings[i]); syntax = syntax->right;
	}
	body = pg_synthesis_request(&program->synthesis, scope, syntax);
	assert(body);
	count = all(program, body, bindings, domains, &mapping);
	assert(pg_synthesis_telescope_frontier(&program->synthesis, program->root, &started, &binding) == 1
		&& started == (cut != 0) && binding == (cut ? bindings[cut - 1] : NULL));
	inputs[0].pending = pg_synthesis_pending(program->root); inputs[1].pending = pg_synthesis_pending(body);
	FILE *copy = tmpfile();
	assert(copy && !pg_sources_write_with(copy, &program->synthesis, 1, inputs, 0, write_telescope, &loaded));
	equal(file, copy);
	assert(!fclose(copy) && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	assert(pg_artifact_source_attach(&program->synthesis, loaded.source, count, mapping));
	assert(!program->synthesis.steps && native_admissions(&program->typing) == 1);
	assert(!pg_artifact_source_attach_with_frontiers(&program->synthesis, loaded.source, count, mapping));
	free(mapping);
	assert(pg_synthesis_telescope_frontier(&program->synthesis, program->root, &started, &binding) == 1
		&& started == (cut != 0) && binding == (cut ? bindings[cut - 1] : NULL));
	pg_synthesis_advance(&program->synthesis, 0);
	assert(!program->synthesis.steps && native_admissions(&program->typing) == 1);
	only(program, program->root);
	advance(&program->synthesis, 3 - cut);
	continuation(program, bindings, domains);
	assert(finish(program) == total - cut);
	result.checked = pg_synthesis_result(program->root);
	copy = tmpfile();
	assert(copy && !pg_sources_write(copy, &program->synthesis, 1, &result));
	equal(expected, copy);
	assert(!fclose(file) && !fclose(copy) && !fclose(expected));
	pg_program_destroy(program);
	printf("cold telescope cut=%" PRIu64 " useful=%" PRIu64 " total=%" PRIu64 " validation=0\n", cut, total - cut, total);
}

__attribute__((noinline)) static struct pg_synthesis_job *escaped_telescope(struct pg_synthesis *s,
	const struct pg_source_scope *scope, const struct pg_syntax *syntax)
{
	struct pg_source_scope raw = *scope;
	return pg_synthesis_telescope(s, &raw, syntax);
}

static void telescope_negative(void)
{
	struct pg_synthesis_job *body, *bindings[3], *domains[3], *foreign_body, *foreign_bindings[3], *foreign_domains[3];
	struct pg_program *program = telescope_start(&body, bindings, domains);
	struct pg_program *foreign = telescope_start(&foreign_body, foreign_bindings, foreign_domains);
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(pg_synthesis_telescope_input(s, program->root, &scope, &syntax) == 1);
	struct pg_source_scope raw = *scope;
	struct pg_synthesis_job *raw_job = pg_synthesis_telescope(s, &raw, syntax);
	struct pg_synthesis_job *escaped = escaped_telescope(s, scope, syntax);
	struct pg_synthesis_job *wrong = pg_synthesis_binding(s, scope, syntax->right);
	assert(raw_job && escaped && wrong);
	size_t count = s->jobs.count, admissions = native_admissions(&program->typing);
	struct pg_synthesis_job *ready = s->ready, copy = *program->root, *binding;
	int started;
	assert(pg_synthesis_telescope_frontier(s, &copy, &started, &binding) == -1);
	assert(pg_synthesis_telescope_resume(s, &copy, 1, bindings[0]));
	copy = *bindings[0];
	assert(pg_synthesis_telescope_resume(s, program->root, 1, &copy));
	assert(pg_synthesis_telescope_resume(s, program->root, 1, foreign_bindings[0]));
	assert(pg_synthesis_telescope_resume(s, program->root, 1, wrong));
	assert(pg_synthesis_telescope_resume(s, program->root, 0, bindings[0]));
	assert(pg_synthesis_telescope_input(s, raw_job, &scope, &syntax) == -1);
	assert(pg_synthesis_telescope_input(s, escaped, &scope, &syntax) == -1);
	assert(pg_synthesis_telescope_resume(s, raw_job, 1, bindings[0]));
	assert(pg_synthesis_telescope_resume(s, escaped, 1, bindings[0]));
	assert(s->jobs.count == count && s->ready == ready && !s->steps && native_admissions(&program->typing) == admissions);
	assert(!pg_synthesis_telescope_resume(s, program->root, 1, bindings[2]));
	assert(pg_synthesis_telescope_resume(s, program->root, 1, bindings[2]));
	assert(s->jobs.count == count && s->ready == ready && !s->steps && native_admissions(&program->typing) == admissions);
	pg_program_destroy(foreign); pg_program_destroy(program);
	puts("telescope: copied/foreign/wrong child, raw/escaped Scope and duplicate reject without mutation");
}

static void schema_edges(void)
{
	struct pg_program *program = start();
	advance(&program->synthesis, 3);
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope, *inner;
	const struct pg_syntax *syntax, *declaration_syntax;
	assert(!pg_synthesis_source_input(s, program->root, &scope, &syntax));
	struct pg_synthesis_job *declaration = pg_synthesis_request(s, scope, syntax->right), *schema;
	assert(pg_synthesis_declaration_frontier(s, declaration, &schema) == 1 && schema);
	assert(pg_synthesis_schema_seed_input(s, schema, &inner, &declaration_syntax) == 1);
	struct pg_synthesis_job *telescope = pg_synthesis_telescope(s, inner, declaration_syntax->left);
	struct pg_synthesis_job *wrong = pg_synthesis_telescope(s, scope, declaration_syntax->left);
	assert(telescope && wrong);
	size_t count = s->jobs.count, admissions = native_admissions(&program->typing);
	uint64_t steps = s->steps;
	struct pg_synthesis_job *ready = s->ready, copy = *schema, *left = NULL;
	assert(pg_synthesis_schema_frontier(s, &copy, &left) == -1);
	assert(pg_synthesis_schema_resume(s, &copy, telescope));
	copy = *telescope;
	assert(pg_synthesis_schema_resume(s, schema, &copy));
	assert(pg_synthesis_schema_resume(s, schema, wrong));
	assert(s->jobs.count == count && s->ready == ready && s->steps == steps
		&& native_admissions(&program->typing) == admissions);
	assert(!pg_synthesis_schema_resume(s, schema, telescope));
	assert(pg_synthesis_schema_frontier(s, schema, &left) == 1 && left == telescope);
	assert(!pg_synthesis_schema_seed_input(s, schema, &inner, &declaration_syntax));
	assert(pg_synthesis_schema_resume(s, schema, telescope));
	assert(s->jobs.count == count && s->ready == ready && s->steps == steps
		&& native_admissions(&program->typing) == admissions);
	pg_program_destroy(program);
	puts("schema: existing telescope key reconnects; copied/wrong-scope/duplicate owners reject without mutation");
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	schema_edges();
	telescope_negative();
	for (uint64_t cut = 0; cut <= 3; ++cut) telescope_check(cut);
	return 0;
}

#include "program.h"
#include "typed_query.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
	assert(argc == 2);
	FILE *file = fopen(argv[1], "rb");
	assert(file && !fseek(file, 0, SEEK_END));
	long length = ftell(file);
	assert(length >= 0 && !fseek(file, 0, SEEK_SET));
	char *text = malloc((size_t)length + 1);
	assert(text && fread(text, 1, (size_t)length, file) == (size_t)length);
	assert(!fclose(file));
	struct pg_program *program = pg_program_create(text, (size_t)length, PG_DEFINITION_EXPLICIT_THUNK);
	free(text);
	assert(program && program->root && !program->parser.error);
	int found = 0;
	while (program->synthesis.ready && program->synthesis.steps < 100000) {
		pg_synthesis_advance(&program->synthesis, 1);
		for (size_t i = 0; i < program->typing.typed_queries.capacity && !found; ++i) {
			for (struct pg_index_entry *entry = program->typing.typed_queries.buckets[i]; entry; entry = entry->next) {
				struct pg_typed_query *query = (void *)entry;
				const struct pg_occurrence *source = pg_classifier_source(query);
				if (!source || query->status || !query->steps) continue;
				assert(pg_typed_query_owned_by(query, &program->typing));
				printf("pending-classifier solve=%" PRIu64 " query=%" PRIu64
					" kind=%d type=%d origin=%d map=%d dependency=%d waiting=%d\n",
					program->synthesis.steps, query->steps, source->core->kind,
					source->type != NULL, source->origin != NULL, source->map != NULL,
					query->dependency != NULL, query->waiting != NULL);
				found = 1;
				break;
			}
		}
		if (found) break;
	}
	printf("frontier-found=%d solve=%" PRIu64 " status=%d\n", found,
		program->synthesis.steps, pg_synthesis_status(program->root));
	pg_program_destroy(program);
	return found ? 0 : 1;
}

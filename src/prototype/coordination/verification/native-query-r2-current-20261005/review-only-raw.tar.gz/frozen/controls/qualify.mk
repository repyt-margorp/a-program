include $(OVERLAY)/controls/frontier.mk

$(BUILD)/source_checkpoint: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(SOURCE_FRONTIER_IO) $(ROOT)artifact/schedule.c $(ROOT)artifact/derivation.c $(ROOT)artifact/source.c $(OVERLAY)/checkpoint_tests/source_checkpoint_test.c
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(SOURCE_FRONTIER_IO) $(ROOT)artifact/schedule.c $(ROOT)artifact/derivation.c $(ROOT)artifact/source.c $(OVERLAY)/checkpoint_tests/source_checkpoint_test.c -Wl,--wrap=pg_synthesis_advance -o $@

$(BUILD)/normalization_checkpoint: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)artifact/schedule.c $(OVERLAY)/checkpoint_tests/normalization_checkpoint_test.c
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)artifact/schedule.c $(OVERLAY)/checkpoint_tests/normalization_checkpoint_test.c -Wl,--wrap=pg_synthesis_advance -Wl,--wrap=pg_whnf_advance -o $@

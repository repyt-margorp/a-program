include $(OVERLAY)/controls/frontier.mk

$(BUILD)/typed_query_progress: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CONTROL) -o $@

$(BUILD)/typed_query_checkpoint: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)typing_io.c $(ROOT)artifact/source.c $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)typing_io.c $(ROOT)artifact/source.c $(CONTROL) -o $@

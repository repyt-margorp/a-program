#include "program.h"
#include "source_io.h"
#include "typed_query.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

static int write_extra(FILE *file, const struct pg_graph_codec *codec, void *objects, void *owner)
{
	(void)file; (void)codec; (void)objects; (void)owner;
	return 0;
}

static int read_extra(FILE *file, struct pg_typing *typing, size_t limit, size_t names,
	const struct pg_graph_codec *codec, void *objects, void *owner)
{
	(void)file; (void)typing; (void)limit; (void)names;
	(void)codec; (void)objects; (void)owner;
	return 0;
}

int main(int argc, char **argv)
{
	assert(argc == 3);
	FILE *input = fopen(argv[1], "rb");
	assert(input && !fseek(input, 0, SEEK_END));
	long length = ftell(input);
	assert(length >= 0 && !fseek(input, 0, SEEK_SET));
	char *text = malloc((size_t)length + 1);
	assert(text && fread(text, 1, (size_t)length, input) == (size_t)length && !fclose(input));
	struct pg_program *program = pg_program_create(text, (size_t)length, PG_DEFINITION_EXPLICIT_THUNK);
	free(text);
	assert(program && program->root && !program->parser.error);
	int found = 0;
	while (!found && program->synthesis.ready && program->synthesis.steps < 100000) {
		pg_synthesis_advance(&program->synthesis, 1);
		for (size_t i = 0; i < program->typing.typed_queries.capacity && !found; ++i)
			for (struct pg_index_entry *entry = program->typing.typed_queries.buckets[i]; entry; entry = entry->next) {
				struct pg_typed_query *query = (void *)entry;
				if (pg_classifier_source(query) && !query->status && query->steps) { found = 1; break; }
			}
	}
	assert(found);
	uint64_t steps = program->synthesis.steps;
	FILE *files[2];
	for (size_t i = 0; i < 2; ++i) {
		char path[4096];
		int n = snprintf(path, sizeof(path), "%s/source-%zu.a", argv[2], i);
		assert(n > 0 && (size_t)n < sizeof(path));
		files[i] = fopen(path, "w+b");
		struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
		assert(files[i] && !pg_sources_write_with(files[i], &program->synthesis, 1, &root, 0, write_extra, NULL));
		assert(!fflush(files[i]) && !fseek(files[i], 0, SEEK_SET));
		pg_program_destroy(program);
		if (!i) {
			size_t count;
			struct pg_synthesis_job *const *roots;
			program = pg_sources_read_with(files[0], 100000, &count, &roots, read_extra, NULL);
			assert(program && count == 1 && !program->synthesis.steps);
		}
	}
	assert(!fseek(files[0], 0, SEEK_SET) && !fseek(files[1], 0, SEEK_SET));
	int a, b, equal = 1;
	do { a = fgetc(files[0]); b = fgetc(files[1]); if (a != b) equal = 0; } while (a != EOF || b != EOF);
	assert(!ferror(files[0]) && !ferror(files[1]) && !fclose(files[0]) && !fclose(files[1]));
	printf("pending-classifier Source inert bytes=%s solve=%" PRIu64 "\n", equal ? "equal" : "different", steps);
	return !equal;
}

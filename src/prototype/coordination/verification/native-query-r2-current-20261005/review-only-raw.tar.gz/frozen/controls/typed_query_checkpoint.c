#include "program.h"
#include "source_io.h"
#include "typing_io.h"
#include "typing_internal.h"
#include "typed_query.h"
#include "wire.h"
#include "scope.h"
#include "artifact/file.h"
#include "artifact/source.h"
#include "derivation_io.h"
#include "synthesis_source.h"
#include "../tests/native_admissions.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct checkpoint {
	const struct pg_occurrence_input *written;
	struct pg_occurrence_input *loaded;
	const struct pg_scope *const *scopes;
	uint64_t steps;
	const struct pg_artifact_source *source;
};

static int write_extra(FILE *file, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	const struct checkpoint *checkpoint = opaque;
	if (pg_wire_write_u64(file, checkpoint->source != NULL)) return -1;
	if (checkpoint->source) return pg_artifact_source_write_with(file, checkpoint->source, codec, objects);
	return pg_wire_write_u64(file, checkpoint->steps)
		|| pg_occurrence_type_pending_write(file, checkpoint->written ? checkpoint->written : checkpoint->loaded,
			checkpoint->scopes, codec, objects);
}

static int read_extra(FILE *file, struct pg_typing *typing, size_t limit, size_t names,
	const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	struct checkpoint *checkpoint = opaque;
	uint64_t source;
	if (pg_wire_read_u64(file, &source) || source > 1) return -1;
	if (source) {
		checkpoint->source = pg_artifact_source_read_with(file, typing, limit, names, codec, objects);
		checkpoint->loaded = (void *)pg_artifact_source_query_frontier(checkpoint->source,
			0, &checkpoint->scopes, &checkpoint->steps);
		return !checkpoint->source || !checkpoint->loaded;
	}
	return pg_wire_read_u64(file, &checkpoint->steps)
		|| pg_occurrence_type_pending_read(file, typing, limit, names, codec, objects,
			&checkpoint->scopes, &checkpoint->loaded);
}

static void same_bytes(FILE *a, FILE *b)
{
	assert(!fflush(a) && !fflush(b) && !fseek(a, 0, SEEK_SET) && !fseek(b, 0, SEEK_SET));
	int x, y;
	do { x = fgetc(a); y = fgetc(b); assert(x == y); } while (x != EOF);
	assert(!ferror(a) && !ferror(b));
}

static struct pg_program *start(const char *path)
{
	FILE *file = fopen(path, "rb");
	assert(file && !fseek(file, 0, SEEK_END));
	long length = ftell(file);
	assert(length >= 0 && !fseek(file, 0, SEEK_SET));
	char *text = malloc((size_t)length + 1);
	assert(text && fread(text, 1, (size_t)length, file) == (size_t)length && !fclose(file));
	struct pg_program *program = pg_program_create(text, (size_t)length, PG_DEFINITION_EXPLICIT_THUNK);
	free(text);
	assert(program && program->root && !program->parser.error);
	return program;
}

static struct pg_program *mapped(struct pg_typed_query **query)
{
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	struct pg_typing *typing = &program->typing;
	const struct pg_evidence *empty = pg_prove_empty_context(typing);
	const struct pg_evidence *universe = pg_prove_universe(typing, empty, 1);
	const struct pg_object *binder = pg_binder(&program->graph);
	const struct pg_evidence *context = pg_prove_context_extension(typing, empty, binder, universe);
	const struct pg_evidence *value = pg_prove_variable(typing, context, binder);
	const struct pg_evidence *body = pg_prove_return(typing, value);
	const struct pg_evidence *image = pg_prove_type_value(typing, pg_prove_universe(typing, empty, 0));
	const struct pg_evidence *map = pg_prove_substitution(typing, context, empty, 1, &image);
	const struct pg_evidence *source = pg_prove_reindex(typing, map, body);
	assert(empty && context && body && map && source && !pg_evidence_subject(source)->type);
	*query = pg_classifier_request(typing, empty, source);
	assert(*query && !pg_typed_query_advance(*query, 1) && pg_classifier_pending_input(*query));
	return program;
}

static void source_owners(struct pg_program *program, struct pg_typed_query *query,
	struct pg_synthesis_job **owners)
{
	const struct pg_evidence *source = (const void *)pg_classifier_source(query);
	struct pg_derivation_input header;
	assert(!pg_derivation_input_header(source, &header) && header.count == 2);
	struct pg_synthesis_input inputs[] = {{.checked = pg_evidence_premise(source, 0)},
		{.checked = pg_evidence_premise(source, 1)}};
	struct pg_synthesis_job *body = pg_synthesis_rule_inputs(&program->synthesis, &header, inputs, NULL, NULL);
	struct pg_derivation_input context_input = {.rule = PG_CONTEXT_EMPTY};
	struct pg_synthesis_job *context = pg_synthesis_rule_inputs(&program->synthesis, &context_input, NULL, NULL, NULL);
	const struct pg_evidence *empty = pg_prove_empty_context(&program->typing);
	owners[0] = pg_pending_job(pg_synthesis_classifier_in(&program->synthesis,
		(struct pg_synthesis_input){.checked = empty},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)}));
	owners[1] = pg_pending_job(pg_synthesis_classifier_in(&program->synthesis,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(context)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)}));
	assert(owners[0] && owners[1] && owners[0] != owners[1]);
	while (owners[0]->status == PG_SYNTHESIS_PENDING || owners[1]->status == PG_SYNTHESIS_PENDING)
		pg_synthesis_advance(&program->synthesis, 1);
	for (size_t i = 0; i < 2; ++i) {
		struct pg_typed_query *selected;
		assert(owners[i]->status == PG_SYNTHESIS_DONE
			&& pg_synthesis_classifier_formation_frontier(&program->synthesis, owners[i], &selected) == 1
			&& selected == query && query->steps == 1);
	}
}

int main(int argc, char **argv)
{
	assert(argc == 3);
	int owner_mode = !strcmp(argv[1], "--mapped-owner");
	struct pg_typed_query *query = NULL;
	struct pg_program *program = !strcmp(argv[1], "--mapped") || owner_mode ? mapped(&query) : start(argv[1]);
	struct pg_synthesis_job *owners[2];
	if (owner_mode) source_owners(program, query, owners);
	while (!query && program->synthesis.ready && program->synthesis.steps < 100000) {
		pg_synthesis_advance(&program->synthesis, 1);
		for (size_t i = 0; i < program->typing.typed_queries.capacity && !query; ++i) {
			for (struct pg_index_entry *entry = program->typing.typed_queries.buckets[i]; entry; entry = entry->next) {
				struct pg_typed_query *candidate = (void *)entry;
				if (pg_classifier_pending_input(candidate) && !candidate->status && candidate->steps) {
					query = candidate;
					break;
				}
			}
		}
	}
	assert(query);
	FILE *files[256];
	size_t count = 0;
	size_t pending_substitutions = 0, completed_substitutions = 0;
	while (!query->status) {
		assert(count < sizeof(files) / sizeof(*files));
		struct checkpoint saved = {.written = pg_classifier_pending_input(query), .steps = query->steps};
		assert(saved.written);
		if (owner_mode) {
			saved.source = pg_artifact_source_capture(&program->graph, &program->synthesis, 2, owners, 2, owners);
			FILE *legacy = tmpfile();
			assert(saved.source && legacy && pg_artifact_source_write(legacy, saved.source) && !fclose(legacy));
		}
		if (saved.written->action && saved.written->action->substitution) {
			pending_substitutions += pg_substitution_status(saved.written->action->substitution) == PG_SUBSTITUTION_PENDING;
			completed_substitutions += pg_substitution_status(saved.written->action->substitution) == PG_SUBSTITUTION_DONE;
		}
		uint64_t before = program->synthesis.steps;
		char path[4096];
		int length = snprintf(path, sizeof(path), "%s/cut-%zu.a", argv[2], count + 1);
		assert(length > 0 && (size_t)length < sizeof(path));
		files[count] = fopen(path, "w+b");
		struct pg_synthesis_input roots[] = {program->root
			? (struct pg_synthesis_input){.pending = pg_synthesis_pending(program->root)}
			: (struct pg_synthesis_input){.checked = (const void *)saved.written->source},
			{.checked = (const void *)saved.written->source}};
		assert(files[count] && !pg_sources_write_with(files[count], &program->synthesis,
			2, roots, 0, write_extra, &saved));
		assert(program->synthesis.steps == before && query->steps == saved.steps);
		++count;
		assert(pg_typed_query_advance(query, 1) >= 0);
	}
	uint64_t total = query->steps, level;
	assert(query->status == 1 && pg_universe_level(pg_evidence_classifier(query->result), &level));
	enum pg_evidence_judgement judgement = pg_evidence_judgement(query->result);
	pg_program_destroy(program);
	for (size_t i = 0; i < count; ++i) {
		assert(!fseek(files[i], 0, SEEK_SET));
		struct checkpoint cold = {0};
		size_t cold_count;
		struct pg_synthesis_job *const *cold_sources;
		program = pg_sources_read_with(files[i], 100000, &cold_count, &cold_sources, read_extra, &cold);
		assert(program && cold_count == 2 && cold.loaded && !cold.loaded->typing
			&& !program->synthesis.steps && native_admissions(&program->typing) == 1);
		struct pg_occurrence_input duplicate = *cold.loaded;
		size_t inputs = program->typing.occurrence_inputs.count;
		assert(!pg_occurrence_type_pending_import(&program->typing, &duplicate)
			&& program->typing.occurrence_inputs.count == inputs
			&& pg_occurrence_type_request(&program->typing, cold.loaded->source) == cold.loaded
			&& !cold.loaded->typing && !program->synthesis.steps);
		/* Loading and abandoning a native frontier require no executor cleanup
		 * wrapper and never admit its checking facts. */
		pg_program_destroy(program);
		assert(!fseek(files[i], 0, SEEK_SET));
		struct checkpoint loaded = {0};
		size_t source_count;
		struct pg_synthesis_job *const *sources;
		program = pg_sources_read_with(files[i], 100000, &source_count, &sources, read_extra, &loaded);
		assert(program && source_count == 2 && loaded.loaded && !program->synthesis.steps);
		assert(native_admissions(&program->typing) == 1 && !loaded.loaded->typing);
		uint64_t cut = loaded.steps, input_steps = loaded.loaded->steps;
		assert(pg_occurrence_input_advance(loaded.loaded, 0) == PG_INPUT_PENDING);
		assert(pg_occurrence_input_advance(loaded.loaded, 1) == PG_INPUT_ERROR);
		assert(loaded.loaded->steps == input_steps && !program->synthesis.steps
			&& native_admissions(&program->typing) == 1);
		assert(!pg_occurrence_type_resume(&program->typing, loaded.loaded->source, loaded.loaded));
		assert(pg_occurrence_type_request(&program->typing, loaded.loaded->source) == loaded.loaded);
		if (owner_mode) {
			const struct pg_scope *const *shared_scopes;
			uint64_t shared_steps;
			assert(pg_artifact_source_query_frontier(loaded.source, 1, &shared_scopes, &shared_steps)
				== loaded.loaded && shared_scopes == loaded.scopes && shared_steps == loaded.steps);
			const struct pg_evidence *empty = pg_prove_empty_context(&program->typing);
			struct pg_derivation_input context_input = {.rule = PG_CONTEXT_EMPTY};
			struct pg_synthesis_job *context = pg_synthesis_rule_inputs(&program->synthesis, &context_input, NULL, NULL, NULL);
			owners[0] = pg_pending_job(pg_synthesis_classifier_in(&program->synthesis,
				(struct pg_synthesis_input){.checked = empty},
				(struct pg_synthesis_input){.pending = pg_synthesis_pending(sources[1])}));
			owners[1] = pg_pending_job(pg_synthesis_classifier_in(&program->synthesis,
				(struct pg_synthesis_input){.pending = pg_synthesis_pending(context)},
				(struct pg_synthesis_input){.pending = pg_synthesis_pending(sources[1])}));
			assert(owners[0] && owners[1] && !pg_artifact_source_prepare(&program->synthesis,
				loaded.source, 2, owners));
		}
		uint64_t budget = 512 + total, cap = 512, spent = UINT64_MAX;
		assert(pg_artifact_revalidate(program, sources[1], 0, cap, &spent) == PG_SYNTHESIS_PENDING
			&& !spent && !program->synthesis.steps && native_admissions(&program->typing) == 1);
		assert(pg_artifact_revalidate(program, sources[1], budget, 0, &spent) == PG_SYNTHESIS_PENDING
			&& !spent && !program->synthesis.steps && native_admissions(&program->typing) == 1);
		if (loaded.loaded->action) {
			uint64_t action_steps = loaded.loaded->action->steps;
			assert(pg_occurrence_action_advance(loaded.loaded->action, 0) == PG_SUBSTITUTION_PENDING);
			assert(pg_occurrence_action_advance(loaded.loaded->action, 1) == PG_SUBSTITUTION_ERROR
				&& loaded.loaded->action->steps == action_steps);
		}
		char path[4096];
		int length = snprintf(path, sizeof(path), "%s/cut-%zu-inert.a", argv[2], i + 1);
		assert(length > 0 && (size_t)length < sizeof(path));
		FILE *resave = fopen(path, "w+b");
		struct pg_synthesis_input roots[] = {{.pending = pg_synthesis_pending(sources[0])},
			{.pending = pg_synthesis_pending(sources[1])}};
		assert(resave && !pg_sources_write_with(resave, &program->synthesis, 2, roots, 0, write_extra, &loaded));
		same_bytes(files[i], resave);
		assert(!fclose(resave));
		/* This control explicitly selects authentic continuation reuse. Source
		 * and its formation are checked through the ordinary Kernel first. This
		 * owner test does not claim public B/R validation accounting. */
		while (pg_synthesis_status(sources[1]) == PG_SYNTHESIS_PENDING) {
			assert(budget && cap);
			enum pg_synthesis_status status = pg_artifact_revalidate(program, sources[1], budget, 1, &spent);
			assert(spent == 1 && status <= PG_SYNTHESIS_DONE);
			budget -= spent; cap -= spent;
		}
		if (owner_mode)
			while (owners[0]->status == PG_SYNTHESIS_PENDING || owners[1]->status == PG_SYNTHESIS_PENDING) {
				assert(budget && cap);
				uint64_t before = program->synthesis.steps;
				pg_synthesis_advance(&program->synthesis, 1);
				assert(program->synthesis.steps == before + 1);
				--budget; --cap;
			}
		uint64_t validation = program->synthesis.steps;
		assert(validation <= 512 && budget == 512 + total - validation && cap == 512 - validation);
		const struct pg_evidence *source = pg_synthesis_result(sources[1]);
		if (!source) {
			for (const struct pg_scope *scope = loaded.scopes[0]; scope; scope = scope->parent) {
				const struct pg_occurrence *type = scope->type;
				fprintf(stderr, "scope type judgement=%d core=%d refkind=%d origin=%d samecore=%d operands=%zu classifier=%d indices=%d\n",
					type->judgement, type->core->kind,
					type->core->kind == PG_REFERENCE ? (int)type->core->as.reference->kind : -1,
					type->origin != NULL, type->origin && type->origin->core == type->core,
					type->operand_count, type->classifier != NULL, scope->indices != NULL);
			}
			fprintf(stderr, "source scope checked=%d context=%p\n",
				pg_prove_scope(&program->typing, loaded.scopes[0]) != NULL,
				(void *)loaded.loaded->source->context);
			for (const struct pg_occurrence *node = loaded.loaded->source; node; node = node->origin)
				fprintf(stderr, "typed input judgement=%d core=%d construction=%u scope=%p type=%p operands=%zu selection=%zu map=%p from=%p to=%p\n",
					node->judgement, node->core->kind, node->construction, (void *)node->scope,
					(void *)node->type, node->operand_count, node->selection, (void *)node->map,
					(void *)(node->map ? node->map->source_scope : NULL),
					(void *)(node->map ? node->map->destination_scope : NULL));
		}
		assert(source && pg_evidence_subject(source) == loaded.loaded->source);
		const struct pg_evidence *context = pg_prove_scope(&program->typing, loaded.scopes[0]);
		query = pg_classifier_request(&program->typing, context, source);
		assert(query && !query->status && !query->steps);
		struct pg_typed_query copied_query = *query;
		assert(pg_classifier_resume(&copied_query, loaded.loaded, cut));
		const struct pg_occurrence *original = loaded.loaded->source;
		struct pg_occurrence copied_source = *original;
		loaded.loaded->source = &copied_source;
		assert(pg_classifier_resume(query, loaded.loaded, cut));
		loaded.loaded->source = original;
		struct pg_occurrence_input copied_input = *loaded.loaded;
		assert(!pg_occurrence_type_resume(&program->typing, original, &copied_input));
		if (owner_mode) assert(pg_artifact_source_attach(&program->synthesis, loaded.source, 2, owners));
		int resumed = owner_mode
			? pg_artifact_source_attach_with_frontiers(&program->synthesis, loaded.source, 2, owners)
			: pg_classifier_resume(query, loaded.loaded, cut);
		if (resumed) {
			fprintf(stderr, "resume failed cut=%" PRIu64 " current=%d result=%d action=%d action-next=%zu action-steps=%" PRIu64 " substitution=%d\n",
				cut, loaded.loaded->current != NULL, loaded.loaded->result != NULL,
				loaded.loaded->action != NULL, loaded.loaded->action ? loaded.loaded->action->next : 0,
				loaded.loaded->action ? loaded.loaded->action->steps : 0,
				loaded.loaded->action && loaded.loaded->action->substitution);
			for (size_t bucket = 0; bucket < program->typing.occurrence_inputs.capacity; ++bucket)
				for (struct pg_index_entry *entry = program->typing.occurrence_inputs.buckets[bucket]; entry; entry = entry->next) {
					struct pg_occurrence_input *input = (void *)entry;
					if (input->source == loaded.loaded->source && input->index == SIZE_MAX)
						fprintf(stderr, "existing type input steps=%" PRIu64 " status=%d\n", input->steps, input->status);
				}
			for (size_t bucket = 0; bucket < program->typing.occurrence_actions.capacity; ++bucket)
				for (struct pg_index_entry *entry = program->typing.occurrence_actions.buckets[bucket]; entry; entry = entry->next) {
					struct pg_occurrence_action *action = (void *)entry;
					if (loaded.loaded->action && action->source == loaded.loaded->action->source
						&& action->map == loaded.loaded->action->map)
						fprintf(stderr, "existing action steps=%" PRIu64 " status=%d next=%zu\n", action->steps, action->status, action->next);
				}
		}
		assert(!resumed);
		assert(pg_classifier_pending_input(query) == loaded.loaded);
		assert(!query->status && query->steps == cut && program->synthesis.steps == validation);
		assert(pg_typed_query_advance(query, 0) == 0 && query->steps == cut);
		assert(total > cut && total - cut <= budget && pg_typed_query_advance(query, total - cut) == 1);
		budget -= total - cut;
		assert(query->steps == total && pg_evidence_judgement(query->result) == judgement);
		uint64_t restored_level;
		assert(pg_universe_level(pg_evidence_classifier(query->result), &restored_level)
			&& restored_level == level && pg_alpha_equal(pg_evidence_subject(query->result)->core,
				loaded.loaded->source->classifier) == 1);
		printf("typed-frontier cut=%" PRIu64 " useful=%" PRIu64 " total=%" PRIu64 " validation=%" PRIu64 " inert-bytes=equal\n",
			cut, total - cut, total, validation);
		assert(!fflush(stdout));
		pg_program_destroy(program);
		assert(!fclose(files[i]));
	}
	if (!strcmp(argv[1], "--mapped") || owner_mode) assert(completed_substitutions);
	printf("destroyed-owner typed classifier cuts=%zu pending-substitutions=%zu completed-substitutions=%zu\n",
		count, pending_substitutions, completed_substitutions);
	return 0;
}

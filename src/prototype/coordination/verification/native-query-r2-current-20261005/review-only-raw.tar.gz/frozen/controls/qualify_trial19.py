import csv
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


base = Path(__file__).resolve().parent
workspace = base.parents[3]
overlay = base / "history/trial19-inputs"
output = base / "trial19-final-qualification"
build = base / "build-trial19-affected-san"
parent = base.parent / "job_evidence_native_frontier"
output.mkdir()
(output / "temporary").mkdir()
records = []
environment = dict(os.environ, TMPDIR=str(output / "temporary"),
    ASAN_OPTIONS="detect_leaks=1:abort_on_error=1",
    UBSAN_OPTIONS="halt_on_error=1", IMAGE_AUDIT_STRICT_BYTES="1")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + "\n")


def verify():
    lines = (base / "trial19-inputs.sha256").read_text().splitlines()
    assert len(lines) == 671
    for line in lines:
        expected, relative = line.split("  ", 1)
        assert digest(overlay / relative) == expected, relative
    return {"count": len(lines), "manifest_sha256": digest(base / "trial19-inputs.sha256")}


def run(label, argv, required=None, binary=None):
    log = output / (label + ".log")
    with log.open("wb") as stream:
        result = subprocess.run([str(arg) for arg in argv], cwd=overlay,
            env=environment, stdout=stream, stderr=subprocess.STDOUT)
    record = {"label": label, "argv": [str(arg) for arg in argv],
        "returncode": result.returncode, "log_sha256": digest(log)}
    if binary is not None:
        record["binary_sha256"] = digest(binary)
    records.append(record)
    write("records.json", records)
    print(json.dumps(record), flush=True)
    if required is not None:
        assert result.returncode == required, record
    return result.returncode


write("inputs-before.json", verify())
strict_script = workspace / "src/prototype/image_audit/partition_fuel.sh"
sorted_inputs = parent / "sorted-result-controls/inputs"
parent_binary = parent / "build-trial8-o2/pointer-check"
candidate_binary = base / "build-trial19-broad-o2/pointer-check"
write("request.json", {"runtime_manifest_sha256": digest(base / "trial19-code.sha256"),
    "input_manifest_sha256": digest(base / "trial19-inputs.sha256"),
    "strict_script_sha256": digest(strict_script),
    "sorted_manifest_sha256": digest(sorted_inputs / "manifest.sha256"),
    "parent_binary_sha256": digest(parent_binary),
    "candidate_binary_sha256": digest(candidate_binary),
    "strict_gate": "Actual exit and original failure rows retained; no expected-pass waiver",
    "parent": "Immutable native-frontier r1 runtime126", "candidate": "Query trial19 runtime129"})
try:
    targets = ["core_test", "synthesis_test", "source_io_test", "typed_structure_test",
        "occurrence_io_test", "source_checkpoint", "normalization_checkpoint"]
    run("affected-san-build", ["make", "-f", overlay / "controls/qualify.mk",
        "OVERLAY=" + str(overlay), "BUILD=" + str(build),
        "CFLAGS=-std=c11 -Wall -Wextra -Werror -O1 -g -fsanitize=address,undefined -fno-omit-frame-pointer -fno-pie -no-pie",
        "-j1", *[build / target for target in targets]], 0)
    for target in targets:
        binary = build / target
        argv = [binary]
        if target in ("source_io_test", "typed_structure_test", "occurrence_io_test"):
            argv = ["bash", overlay / "tests" / (target.removesuffix("_test") + ".sh"), binary]
        run(target + "-san", argv, 0, binary)
    sorted_records = []
    for label, binary in (("r1", parent_binary), ("query", candidate_binary)):
        run(label + "-sorted", [binary, "--steps", "8000000", "--imports",
            sorted_inputs / "quick-local-provider.p", "--save", output / (label + "-sorted.a"),
            sorted_inputs / "quick-local-result.p"], 0, binary)
        matches = re.findall(r"^done steps=(\d+)$", (output / (label + "-sorted.log")).read_text(), re.M)
        assert len(matches) == 1
        sorted_records.append({"variant": label, "status": "DONE", "steps": int(matches[0])})
        run(label + "-strict-public", ["bash", strict_script, binary,
            overlay / "examples/09_list_induction.p", output / (label + "-public"), "ordinary"], binary=binary)
    write("ordinary-sorted.json", sorted_records)
    first = output / "r1-public"
    second = output / "query-public"
    assert (first / "partitions.tsv").read_bytes() == (second / "partitions.tsv").read_bytes()
    rows = list(csv.DictReader((second / "partitions.tsv").open(), delimiter="\t"))
    assert len(rows) == 40
    failed = [row for row in rows if any(row[field] != "yes" for field in
        ("size_equal", "byte_equal", "status_equal", "fuel_equal"))]
    assert [(row["partition"], row["path"]) for row in failed] == [
        ("1000:1000", "reload"), ("1600:1600", "reload"), ("1915:0", "reload")]
    images = sorted(first.glob("*.a"))
    assert len(images) == 52
    comparisons = [{"image": image.name, "equal": image.read_bytes() == (second / image.name).read_bytes(),
        "r1_sha256": digest(image), "query_sha256": digest(second / image.name)} for image in images]
    write("public-image-comparison.json", comparisons)
    assert all(item["equal"] for item in comparisons)
    assert [record["returncode"] for record in records if record["label"].endswith("strict-public")] == [1, 1]
    write("summary.json", {"affected_san": "all seven gates exit0", "ordinary_sorted": sorted_records,
        "strict_public": "Both actual gates FAIL exit1; original three failure rows remain unwaived",
        "failed_rows": failed, "all40_tsv_rows_equal": True, "all52_images_equal": True,
        "all671_inputs_exact_after": verify(), "all_launched_children_reaped": True,
        "current_producer_joint": "not run", "time_or_peak_memory": "not measured"})
finally:
    write("inputs-after.json", verify())
    write("records.json", records)

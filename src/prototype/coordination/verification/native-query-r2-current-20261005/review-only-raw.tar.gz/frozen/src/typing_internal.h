#ifndef __TYPING_INTERNAL_H__
#define __TYPING_INTERNAL_H__

#include "typing.h"

/* Existing owner-private progress. The transport borrows these exact cursors;
 * they are neither checked facts nor an additional semantic graph. */
struct pg_occurrence_action {
	struct pg_index_entry index;
	struct pg_typing *typing;
	const struct pg_context_map *map;
	const struct pg_occurrence *source, *result;
	struct pg_substitution *substitution;
	const struct pg_term *outputs[3];
	size_t next;
	uint64_t steps;
	enum pg_substitution_status status;
};

struct input_map {
	const struct pg_context_map *map;
	const struct pg_term *core;
	struct input_map *next;
};

struct input_scope {
	const struct pg_context *context;
	struct input_scope *next;
};

struct pg_occurrence_input {
	struct pg_index_entry entry;
	struct pg_typing *typing;
	const struct pg_occurrence *source, *current, *result, *child;
	const struct pg_context_map *outer;
	size_t index;
	struct input_map *maps;
	struct pg_occurrence_action *action;
	struct pg_context_lift *lift;
	struct pg_occurrence_input *selected;
	struct pg_typing_wait *waiting;
	struct input_scope *scopes;
	const struct pg_context_map *effective;
	uint64_t steps;
	enum pg_occurrence_input_status status;
};

/* Import one inert native owner into the existing input index. The codec's
 * temporary header is copied once; its graph-owned frames stay on this owner.
 * An existing key rejects instead of overwriting reusable work. */
struct pg_occurrence_input *pg_occurrence_type_pending_import(struct pg_typing *,
	const struct pg_occurrence_input *);

#endif

#ifndef A_PROGRAM_ARTIFACT_SOURCE_H
#define A_PROGRAM_ARTIFACT_SOURCE_H

#include "program.h"
#include <stdio.h>

struct pg_artifact_source;
struct pg_graph_codec;

/* Source-owned cursors/edges in an enclosing shared job mapping. The enclosing
 * image transports syntax/scopes and reconstructs request identities first.
 * Supported owners: definitions, module traversal, literal/@ expressions,
 * plain identifiers, Source Lambda/Body and binding domain edges, classifier
 * discovery with an undispatched, completed or transported native type query,
 * domain discovery without a started return adapter. Domain completion is discovery only: its normalization
 * may still be pending. Ordinary charged validation recreates its selected edge;
 * that status never admits the normalization result. Every child state still needs
 * its own owner transport; a Lambda edge alone is not a complete checkpoint.
 * Other source continuations reject, never silently recompute.
 * Partial query records borrow their actual native cursor until write_with;
 * other records borrow no live pointers after capture. No source results, proof flags
 * authorizing acceptance, or independent scheduler are stored here. */
const struct pg_artifact_source *pg_artifact_source_capture(struct pg_graph *,
	const struct pg_synthesis *, size_t job_count, struct pg_synthesis_job *const *jobs,
	size_t owner_count, struct pg_synthesis_job *const *owners);
int pg_artifact_source_write(FILE *, const struct pg_artifact_source *);
const struct pg_artifact_source *pg_artifact_source_read(FILE *, struct pg_graph *, size_t limit);
/* The enclosing shared codec transports partial query owners. Legacy metadata
 * calls reject them; loading stays inert, with no checked status or policy. */
int pg_artifact_source_write_with(FILE *, const struct pg_artifact_source *,
	const struct pg_graph_codec *, void *);
const struct pg_artifact_source *pg_artifact_source_read_with(FILE *, struct pg_typing *,
	size_t limit, size_t name_limit, const struct pg_graph_codec *, void *);
/* Descriptive native query frontier in a mapped Source slot. NULL includes a
 * completed/undispatched query. Returned scopes and steps authorize no result. */
const struct pg_occurrence_input *pg_artifact_source_query_frontier(
	const struct pg_artifact_source *, size_t slot, const struct pg_scope *const **scopes,
	uint64_t *steps);
/* Unpublished import only. Lexical name registration is restored by source I/O,
 * not duplicated here. Uses the normal factories to reconnect body/rule edges,
 * but never accepts a result.
 * Failure requires discarding the unpublished Program. After this, recheck the
 * saved completed targets through ordinary Solve and attach pending cursors.
 * Identifier edges attach after their definition producers are checked; the
 * ordinary scope lookup must select the exact saved producer or binder rule.
 * Lambda edges must match the ordinary factory using the restored lexical input.
 * The enclosing image supplies provenance and finally restores ONE schedule. */
int pg_artifact_source_prepare(struct pg_synthesis *, const struct pg_artifact_source *,
	size_t job_count, struct pg_synthesis_job *const *jobs);
size_t pg_artifact_source_validation(const struct pg_artifact_source *, size_t *slots);
/* Completed query claims only. Their existing typed owners must be checked by
 * ordinary Solve before attach. Partial native queries instead reconnect only
 * through explicitly selected continuation reuse after their source is checked. */
size_t pg_artifact_source_query_validation(const struct pg_artifact_source *, size_t *slots);
int pg_artifact_source_attach(struct pg_synthesis *, const struct pg_artifact_source *,
	size_t job_count, struct pg_synthesis_job *const *jobs);
/* Explicit selected reuse for transported partial queries. Ordinary checked
 * Source inputs and discovery owners must already exist. No Solve occurs here;
 * the enclosing importer charges revalidation against its one total budget
 * and supplies authentic retained computation provenance. Strict/default
 * attachment never selects this policy automatically. */
int pg_artifact_source_attach_with_frontiers(struct pg_synthesis *, const struct pg_artifact_source *,
	size_t job_count, struct pg_synthesis_job *const *jobs);

#endif

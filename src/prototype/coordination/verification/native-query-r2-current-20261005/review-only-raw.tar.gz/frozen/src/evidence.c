#include "evidence.h"
#include "evidence_structure.h"
#include "typed_query.h"
#include "computation.h"
#include "eval.h"
#include "identity.h"
#include "iadt.h"
#include "host.h"
#include "dag.h"
#include "scope.h"
#include <stdlib.h>
#include <string.h>

/* The opaque input API borrows the native Occurrence, Scope or map directly.
 * These owners already begin with their interner entry and judgement. There is
 * no Evidence allocation, proof index, receipt header or alternative chain. */
_Static_assert(offsetof(struct pg_occurrence, judgement) == sizeof(struct pg_index_entry),
	"native occurrence judgement");
_Static_assert(offsetof(struct pg_scope, judgement) == sizeof(struct pg_index_entry),
	"native scope judgement");
_Static_assert(offsetof(struct pg_context_map, judgement) == sizeof(struct pg_index_entry),
	"native map judgement");

static const void *evidence_certificate(const struct pg_evidence *input)
{
	if (!input) return NULL;
	enum pg_evidence_judgement judgement = pg_evidence_judgement(input);
	if (judgement == PG_JUDGEMENT_CONTEXT) return pg_evidence_scope(input);
	if (judgement == PG_JUDGEMENT_SUBSTITUTION) return NULL;
	return ((const struct pg_occurrence *)(const void *)input)->certificate;
}

static int elimination_rule(enum pg_evidence_rule rule)
{
	return rule == PG_MATCH_ELIM || rule == PG_INDUCTION_ELIM;
}

static const struct pg_evidence *formed_classifier(struct pg_typing *typing,
	const struct pg_evidence *term);
static int context_proof(const struct pg_typing *, const struct pg_evidence *);
static const struct pg_evidence *pi_codomain(struct pg_typing *typing,
	const struct pg_evidence *pi, const struct pg_evidence *argument,
	const struct pg_occurrence *retained);

static const struct pg_evidence *conclusion_receipt(const struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const void *key)
{
	const struct pg_evidence *result = NULL;
	if (judgement == PG_JUDGEMENT_CONTEXT) {
		const struct pg_scope *scope = key ? ((const struct pg_context *)key)->checked_scope
			: typing ? typing->empty_scope : NULL;
		if (scope && scope->admission_owner) result = (const void *)scope;
	} else if (judgement == PG_JUDGEMENT_SUBSTITUTION) {
		const struct pg_context_map *map = key;
		if (map && map->admission_owner) result = key;
	} else {
		const struct pg_occurrence *subject = key;
		if (subject && subject->admission_owner) result = key;
	}
	return result;
}

static const struct pg_evidence *conclusion_first(const struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const void *key)
{
	const struct pg_evidence *result = conclusion_receipt(typing, judgement, key);
	return pg_evidence_owned_by(result, typing) ? result : NULL;
}

const struct pg_evidence *pg_evidence_for_subject(const struct pg_typing *typing,
	const struct pg_occurrence *subject, const struct pg_evidence *after)
{
	/* Alternative proof-history identity is retired. The accepted object is
	 * this exact typed construction, not a second selected receipt. */
	if (!subject || after) return NULL;
	return conclusion_first(typing, subject->judgement, subject);
}

const struct pg_evidence *pg_evidence_for_context(const struct pg_typing *typing,
	const struct pg_context *context)
{
	const struct pg_evidence *result = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, context);
	return result && pg_evidence_context(result) == context ? result : NULL;
}

static const struct pg_evidence *elimination_premise(const struct pg_occurrence *subject,
	const void *certificate, size_t ordinal)
{
	if (!subject || subject->operand_count < 3 || subject->map_count != 1) return NULL;
	size_t count = subject->operand_count - 3;
	const struct pg_occurrence *input;
	if (ordinal == 0) input = subject->operands[count + 1];
	else if (ordinal == 1) input = subject->operands[count + 2];
	else if (ordinal == 2)
		return conclusion_receipt(NULL, PG_JUDGEMENT_SUBSTITUTION, pg_occurrence_maps(subject)[0]);
	else if (ordinal == 3) input = subject->operands[0];
	else if (ordinal == 4)
		return certificate;
	else if (ordinal < count + 5) input = subject->operands[ordinal - 4];
	else if (ordinal == count + 5) input = subject->type;
	else return NULL;
	return input ? conclusion_receipt(NULL, input->judgement, input) : NULL;
}

struct pg_operation_declaration {
	struct pg_object_entry base;
	const struct pg_object *label;
	const struct pg_evidence *payload_type, *response_type;
};

static const struct pg_operation_declaration *handler_operation(
	const struct pg_handler_signature *, size_t);

static size_t borrowed_premise_count(enum pg_evidence_rule rule,
	const void *conclusion, const void *certificate)
{
	const struct pg_occurrence *subject = conclusion;
	switch (rule) {
	case PG_VARIABLE:
		return subject->scope && subject->scope->context != subject->context ? 2 : 1;
	case PG_UNIVERSE_FORM: case PG_HOST_TYPE_FORM:
	case PG_HOST_VALUE_INTRO: case PG_HOST_FUNCTION_INTRO: return 1;
	case PG_TERMINATION_FORM: case PG_TERMINATION_INTRO: case PG_FAMILY_ACTION: return 2;
	case PG_TYPE_CASE: case PG_FAMILY_IDENTITY_FORM: return subject->operand_count + 2;
	case PG_CONTEXT_SUBSTITUTION: return ((const struct pg_context_map *)conclusion)->count + 2;
	case PG_REINDEX:
		return subject && subject->map && subject->origin ? 2 : 0;
	case PG_CONTEXT_PROJECTION:
		return subject && subject->map && subject->origin ? 2 : 0;
	case PG_RETURN_VALUE: case PG_THUNK_COMPUTATION:
		/* A same-Core boundary retains the child, not the inverted producer. */
		if (!subject || !subject->origin) return 0;
		return subject->origin->core != subject->core ? 1 : 0;
	case PG_PURE_NORMALIZATION:
		return subject && subject->origin ? 1 : 0;
	case PG_TYPE_CONVERSION: case PG_EFFECT_SUBSUMPTION:
		return subject && subject->origin && subject->type ? 2 : 0;
	case PG_INDUCTIVE_FORM:
		return pg_data_constructor_count(certificate) +
			(pg_evidence_rule(pg_data_schema_parameters(certificate)) == PG_CONTEXT_FAMILY_EXTEND ? 2 : 1);
	case PG_CONSTRUCTOR_INTRO: case PG_REQUEST_INTRO: return 4;
	case PG_FOLD_ELIM: return 2;
	case PG_MATCH_ELIM: case PG_INDUCTION_ELIM: return subject->operand_count + 3;
	case PG_HANDLER_ELIM: return 3 + 3 * (subject->operand_count - 2);
	default: return 0;
	}
}

/* Borrow stable checked inputs retained by the native owner. */
static const struct pg_evidence *borrowed_premise(enum pg_evidence_rule rule,
	const void *conclusion, const void *certificate, size_t ordinal)
{
	const struct pg_occurrence *subject = conclusion;
	const struct pg_occurrence *input = NULL;
	switch (rule) {
	case PG_VARIABLE:
		if (subject->scope && (ordinal || subject->scope->context == subject->context))
			return (const void *)subject->scope;
		return conclusion_receipt(NULL, PG_JUDGEMENT_CONTEXT, subject->context);
	case PG_UNIVERSE_FORM: case PG_HOST_TYPE_FORM:
		return conclusion_receipt(NULL, PG_JUDGEMENT_CONTEXT, subject->context);
	case PG_HOST_VALUE_INTRO: case PG_HOST_FUNCTION_INTRO:
		input = subject->type;
		break;
	case PG_TERMINATION_FORM:
		input = subject->operands[ordinal];
		break;
	case PG_TERMINATION_INTRO: case PG_FAMILY_ACTION:
		input = ordinal ? subject->operands[0] : subject->type;
		break;
	case PG_TYPE_CASE:
		if (!ordinal) return certificate;
		if (ordinal == 1) return (const void *)pg_occurrence_maps(subject)[0];
		input = subject->operands[ordinal - 2];
		break;
	case PG_FAMILY_IDENTITY_FORM:
		if (!ordinal) input = subject->operands[0];
		else if (ordinal < 3) return conclusion_receipt(NULL, PG_JUDGEMENT_SUBSTITUTION,
			pg_occurrence_maps(subject)[ordinal - 1]);
		else input = subject->operands[ordinal - 2];
		break;
	case PG_CONTEXT_SUBSTITUTION: {
		const struct pg_context_map *map = conclusion;
		if (ordinal < 2) return (const void *)(ordinal ? map->destination_scope : map->source_scope);
		input = map->images[ordinal - 2];
		break;
	}
	case PG_REINDEX:
		if (!ordinal) return conclusion_receipt(NULL, PG_JUDGEMENT_SUBSTITUTION, subject->map);
		if (ordinal == 1) input = subject->origin;
		break;
	case PG_CONTEXT_PROJECTION:
		if (!ordinal) return conclusion_receipt(NULL, PG_JUDGEMENT_CONTEXT, subject->context);
		if (ordinal == 1) input = subject->origin;
		break;
	case PG_PURE_NORMALIZATION: case PG_RETURN_VALUE: case PG_THUNK_COMPUTATION:
	case PG_TYPE_CONVERSION: case PG_EFFECT_SUBSUMPTION:
		input = ordinal ? subject->type : subject->origin;
		break;
	case PG_INDUCTIVE_FORM: {
		const struct pg_data_schema *schema = certificate;
		const struct pg_evidence *parameters = pg_data_schema_parameters(schema);
		size_t prefix = pg_evidence_rule(parameters) == PG_CONTEXT_FAMILY_EXTEND ? 2 : 1;
		if (!ordinal) return parameters;
		if (ordinal < prefix) return pg_data_schema_indices(schema);
		return pg_data_schema_result(schema,
			pg_data_constructor(pg_data_schema_layout(schema), ordinal - prefix));
	}
	case PG_MATCH_ELIM: case PG_INDUCTION_ELIM:
		return elimination_premise(subject, certificate, ordinal);
	case PG_CONSTRUCTOR_INTRO:
		if (!ordinal) input = subject->type;
		else if (ordinal == 1) return certificate;
		else return (const void *)pg_occurrence_maps(subject)[ordinal - 2];
		break;
	case PG_HANDLER_ELIM:
		if (ordinal < 2) input = subject->operands[ordinal];
		else if (ordinal == 2) input = subject->type;
		else if ((ordinal - 3) % 3 == 2) input = subject->operands[(ordinal - 3) / 3 + 2];
		else {
			const struct pg_operation_declaration *operation = handler_operation(certificate, (ordinal - 3) / 3);
			return (ordinal - 3) % 3 ? operation->response_type : operation->payload_type;
		}
		break;
	case PG_REQUEST_INTRO:
		if (ordinal < 2) {
			const struct pg_operation_declaration *operation = certificate;
			return ordinal ? operation->response_type : operation->payload_type;
		}
		/* The remaining inputs are the typed payload and continuation. */
		ordinal -= 2;
		/* fall through */
	case PG_FOLD_ELIM:
		if (ordinal < subject->operand_count) input = subject->operands[ordinal];
		break;
	default: break;
	}
	return input ? conclusion_receipt(NULL, input->judgement, input) : NULL;
}

static const struct pg_object_class operation_label_class = {"operation-label"};
static const struct pg_object_class operation_declaration_class = {"operation-declaration"};
struct operation_label {
	struct pg_object object;
	const struct pg_term *payload, *response;
};
static const struct pg_object_class handler_signature_class = {"handler-signature"};
struct pg_handler_signature {
	struct pg_object_entry base;
	size_t count;
	const struct pg_operation_declaration *const *operations;
	const struct pg_object *labels[];
};

static const struct pg_operation_declaration *handler_operation(
	const struct pg_handler_signature *signature, size_t ordinal)
{
	return signature && ordinal < signature->count ? signature->operations[ordinal] : NULL;
}

static const struct pg_handler_signature *handler_signature(struct pg_graph *graph,
	size_t count, const struct pg_object *const *labels, const struct pg_handler_clause *clauses)
{
	if (!graph || !count || !labels) return NULL;
	if (count > (SIZE_MAX - sizeof(struct pg_handler_signature)) / (sizeof(*labels) + sizeof(void *))) return NULL;
	if (!graph->objects.capacity && pg_index_init(&graph->objects)) return NULL;
	uint64_t hash = UINT64_C(1469598103934665603) ^ count;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_term *payload, *response;
		if (!pg_operation_label_types(labels[i], &payload, &response)) return NULL;
		hash = (hash ^ (uintptr_t)labels[i]) * UINT64_C(1099511628211);
		hash = (hash ^ (uintptr_t)(clauses ? clauses[i].operation : NULL)) * UINT64_C(1099511628211);
	}
	for (struct pg_index_entry *p = pg_index_candidates(&graph->objects, hash); p; p = p->next) {
		const struct pg_object_entry *base = (const struct pg_object_entry *)p;
		if (base->object.owner != &handler_signature_class) continue;
		const struct pg_handler_signature *signature = (const void *)base;
		if (signature->count != count || memcmp(signature->labels, labels, count * sizeof(*labels))) continue;
		size_t i = 0;
		while (i < count && signature->operations[i] == (clauses ? clauses[i].operation : NULL)) ++i;
		if (i == count) return signature;
	}
	struct pg_handler_signature *signature = pg_alloc(graph, sizeof(*signature) + count * (sizeof(*labels) + sizeof(void *)));
	if (!signature) return NULL;
	signature->base.object = (struct pg_object){PG_SEMANTIC_OBJECT, &handler_signature_class};
	signature->count = count;
	signature->operations = (const void *)(signature->labels + count);
	const struct pg_operation_declaration **operations = (void *)signature->operations;
	for (size_t i = 0; i < count; ++i) operations[i] = clauses ? clauses[i].operation : NULL;
	memcpy(signature->labels, labels, count * sizeof(*labels));
	return pg_index_insert(&graph->objects, &signature->base.index, hash) ? NULL : signature;
}

const struct pg_handler_signature *pg_handler_signature(struct pg_graph *graph,
	size_t count, const struct pg_object *const *labels)
{
	return handler_signature(graph, count, labels, NULL);
}

size_t pg_handler_signature_count(const struct pg_handler_signature *signature)
{
	return signature ? signature->count : 0;
}

const struct pg_object *pg_handler_signature_label(
	const struct pg_handler_signature *signature, size_t index)
{
	return signature && index < signature->count ? signature->labels[index] : NULL;
}

const struct pg_handler_signature *pg_evidence_handler_signature(const struct pg_evidence *evidence)
{
	return evidence && pg_evidence_rule(evidence) == PG_HANDLER_ELIM ? evidence_certificate(evidence) : NULL;
}

const struct pg_term *pg_handler_signature_reference(struct pg_graph *graph, const struct pg_handler_signature *signature)
{
	return signature ? pg_reference(graph, &signature->base.object) : NULL;
}

const struct pg_handler_signature *pg_handler_signature_view(const struct pg_term *term)
{
	if (!term || term->kind != PG_REFERENCE || term->as.reference->owner != &handler_signature_class) return NULL;
	return (const void *)((const char *)term->as.reference - offsetof(struct pg_object_entry, object));
}

static int derived_output(enum pg_evidence_rule rule)
{
	switch (rule) {
	case PG_REINDEX: case PG_CONTEXT_PROJECTION:
	case PG_FOLD_ELIM: case PG_EFFECT_SUBSUMPTION: case PG_REQUEST_INTRO:
	case PG_FAMILY_IDENTITY_FORM: case PG_FAMILY_ACTION:
	case PG_INDUCTIVE_FORM: case PG_CONSTRUCTOR_INTRO: case PG_MATCH_ELIM: case PG_INDUCTION_ELIM: case PG_TYPE_CASE:
		return 1;
	default: return 0;
	}
}

static const void *certificate_key(enum pg_evidence_rule rule, const void *certificate)
{
	/* Schema wrappers attest premises; they do not introduce another family. */
	return rule == PG_INDUCTIVE_FORM ? pg_data_schema_declaration(certificate) : certificate;
}

const struct pg_evidence *pg_evidence_input(struct pg_evidence_inputs inputs, size_t i)
{
	if (i > SIZE_MAX - inputs.first) return NULL;
	i += inputs.first;
	if (inputs.at) return inputs.at(inputs.owner, i);
	return inputs.owner ? ((const struct pg_evidence *const *)inputs.owner)[i] : NULL;
}

struct receipt_segments {
	size_t prefix_count, count;
	const struct pg_evidence *const *prefix, *const *suffix;
	struct pg_evidence_inputs arguments;
};

static const struct pg_evidence *segmented_receipt(const void *owner, size_t i)
{
	const struct receipt_segments *inputs = owner;
	if (i < inputs->prefix_count) return inputs->prefix[i];
	i -= inputs->prefix_count;
	return i < inputs->count ? pg_evidence_input(inputs->arguments, i) : inputs->suffix[i - inputs->count];
}

static const struct pg_evidence *find_record_inputs(const struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, struct pg_evidence_inputs inputs,
	const void *certificate, uint64_t *hash_out)
{
	*hash_out = 0;
	if (!typing) return NULL;
	if (rule == PG_CONTEXT_SUBSTITUTION) {
		if (count < 2) return NULL;
		const struct pg_evidence *source = pg_evidence_input(inputs, 0);
		const struct pg_evidence *destination = pg_evidence_input(inputs, 1);
		if (!context_proof(typing, source) || !context_proof(typing, destination)) return NULL;
		const struct pg_context *from = pg_evidence_context(source), *to = pg_evidence_context(destination);
		uint64_t hash = ((uintptr_t)from ^ (uintptr_t)to) * UINT64_C(1099511628211);
		for (size_t i = 2; i < count; ++i) {
			const struct pg_evidence *image = pg_evidence_input(inputs, i);
			if (!pg_evidence_owned_by(image, typing) || !pg_evidence_subject(image)) return NULL;
			hash = (hash ^ (uintptr_t)pg_evidence_subject(image)) * UINT64_C(1099511628211);
		}
		for (const struct pg_index_entry *p = pg_index_candidates(&typing->context_maps, hash); p; p = p->next) {
			const struct pg_context_map *map = (const void *)p;
			if (p->hash != hash || map->source != from || map->destination != to || map->count != count - 2) continue;
			if (map->source_scope != (const void *)source || map->destination_scope != (const void *)destination) continue;
			if (!pg_evidence_owned_by((const void *)map, typing)) continue;
			size_t i = 0;
			while (i < map->count && map->images[i] == pg_evidence_subject(pg_evidence_input(inputs, i + 2))) ++i;
			if (i == map->count) return (const void *)map;
		}
		return NULL;
	}
	if (rule == PG_CONTEXT_EMPTY || rule == PG_CONTEXT_EXTEND || rule == PG_CONTEXT_FAMILY_EXTEND)
		return pg_evidence_for_scope(typing, certificate);
	if (subject && !derived_output(rule)) return pg_evidence_for_subject(typing, subject, NULL);
	/* Search only the native input bucket, before rules allocate fresh lexical
	 * fields. No retained proof-key, second interner or full-graph scan exists.
	 * Purely structural map/scope factories use their own canonical lookup. */
	struct pg_occurrence key = {.context = context};
	const struct pg_context_map *maps[2] = {NULL, NULL};
	switch (rule) {
	case PG_CONSTRUCTOR_INTRO: {
		const struct pg_context_map *parameters = pg_evidence_context_map(pg_evidence_input(inputs, 2));
		const struct pg_context_map *instance = pg_evidence_context_map(pg_evidence_input(inputs, 3));
		if (!parameters || !instance || instance->count <= parameters->count) return NULL;
		key.operand_count = instance->count - parameters->count - 1;
		key.map_count = 2;
		maps[0] = parameters;
		maps[1] = instance;
		break;
	}
	case PG_MATCH_ELIM: case PG_INDUCTION_ELIM:
		if (count < 6) return NULL;
		key.operand_count = count - 3;
		key.map_count = 1;
		maps[0] = pg_evidence_context_map(pg_evidence_input(inputs, 2));
		break;
	case PG_TYPE_CASE:
		if (count < 3) return NULL;
		key.operand_count = count - 2;
		key.map_count = 1;
		maps[0] = pg_evidence_context_map(pg_evidence_input(inputs, 1));
		break;
	case PG_FAMILY_IDENTITY_FORM:
		if (count < 5) return NULL;
		key.operand_count = count - 2;
		key.map_count = 2;
		maps[0] = pg_evidence_context_map(pg_evidence_input(inputs, 1));
		maps[1] = pg_evidence_context_map(pg_evidence_input(inputs, 2));
		break;
	case PG_FAMILY_ACTION: case PG_FOLD_ELIM: case PG_REQUEST_INTRO:
		key.operand_count = 2;
		break;
	case PG_EFFECT_SUBSUMPTION:
		key.origin = pg_evidence_subject(pg_evidence_input(inputs, 0));
		break;
	case PG_REINDEX:
		key.map = pg_evidence_context_map(pg_evidence_input(inputs, 0));
		key.origin = pg_evidence_subject(pg_evidence_input(inputs, 1));
		break;
	default: return NULL;
	}
	for (size_t i = 0; i < key.map_count; ++i) if (!maps[i]) return NULL;
	if (key.operand_count > SIZE_MAX / sizeof(const struct pg_occurrence *)) return NULL;
	const struct pg_occurrence *small[8], **operands = small;
	if (key.operand_count > 8) operands = malloc(key.operand_count * sizeof(*operands));
	if (!operands) return NULL;
	for (size_t i = 0; i < key.operand_count; ++i) {
		size_t ordinal = i;
		if (rule == PG_CONSTRUCTOR_INTRO) {
			operands[i] = maps[1]->images[maps[1]->count - key.operand_count + i];
			continue;
		}
		if (elimination_rule(rule))
			ordinal = !i ? 3 : i + 2 < key.operand_count ? i + 4 : i + 2 == key.operand_count ? 0 : 1;
		else if (rule == PG_TYPE_CASE) ordinal = i + 2;
		else if (rule == PG_FAMILY_IDENTITY_FORM) ordinal = i ? i + 2 : 0;
		else if (rule == PG_FAMILY_ACTION) ordinal = 1 - i;
		else if (rule == PG_REQUEST_INTRO) ordinal = i + 2;
		operands[i] = pg_evidence_subject(pg_evidence_input(inputs, ordinal));
	}
	uint64_t hash = pg_occurrence_native_hash(&key, operands, maps);
	const struct pg_evidence *result = NULL;
	for (const struct pg_index_entry *entry = pg_index_candidates(&typing->occurrences, hash); entry; entry = entry->next) {
		if (entry->hash != hash) continue;
		const struct pg_occurrence *candidate = (const void *)entry;
		const struct pg_evidence *proof = (const void *)candidate;
		if (candidate->admission_owner != typing->owner_key || pg_evidence_rule(proof) != rule || candidate->context != context) continue;
		if (rule == PG_CONSTRUCTOR_INTRO && pg_evidence_constructor(proof) != certificate) continue;
		if (rule == PG_INDUCTION_ELIM && subject &&
			!pg_induction_allocation_equal(candidate->induction, subject->induction)) continue;
		if (rule != PG_CONSTRUCTOR_INTRO && rule != PG_TYPE_CASE && !elimination_rule(rule) &&
			certificate_key(rule, evidence_certificate(proof)) != certificate_key(rule, certificate)) continue;
		if (pg_evidence_premise_count(proof) != count) continue;
		size_t i = 0;
		while (i < count && pg_evidence_premise(proof, i) == pg_evidence_input(inputs, i)) ++i;
		if (i == count) { result = proof; break; }
	}
	if (operands != small) free(operands);
	return result;
}

static const struct pg_evidence *find_record(const struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, const struct pg_evidence *const *premises,
	const void *certificate, uint64_t *hash_out)
{
	return find_record_inputs(typing, rule, context, subject, count,
		(struct pg_evidence_inputs){.owner = premises}, certificate, hash_out);
}

const struct pg_evidence *pg_evidence_for_scope(const struct pg_typing *typing,
	const struct pg_scope *scope)
{
	if (!typing) return NULL;
	if (!scope) scope = typing->empty_scope;
	const struct pg_evidence *result = (const void *)scope;
	return pg_evidence_owned_by(result, typing) ? result : NULL;
}

static const struct pg_evidence *accept_record_inputs(struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, struct pg_evidence_inputs inputs,
	const void *certificate, const struct pg_context_map *map)
{
	if (!typing || !typing->owner_key || (subject && subject->context != context)) return NULL;
	for (size_t i = 0; i < count; ++i)
		if (!pg_evidence_owned_by(pg_evidence_input(inputs, i), typing)) return NULL;
	if (map) {
		if (!pg_context_map_owned_by(map, typing)) return NULL;
		for (size_t i = 0; i < map->count; ++i)
			if (!pg_evidence_owned_by((const void *)map->images[i], typing)) return NULL;
		if (count < 2) return NULL;
		map = pg_context_map_scoped(typing, map, (const void *)pg_evidence_input(inputs, 0),
			(const void *)pg_evidence_input(inputs, 1));
		if (!map) return NULL;
		if (map->admission_owner && map->admission_owner != typing->owner_key) return NULL;
		((struct pg_context_map *)map)->admission_owner = typing->owner_key;
		return (const void *)map;
	}
	if (!subject) {
		const struct pg_scope *scope = certificate;
		if (rule == PG_CONTEXT_EMPTY) scope = pg_scope_intern(typing, NULL, NULL, NULL, NULL);
		if (!scope || scope->context != context || !pg_scope_owned_by(scope, typing)) return NULL;
		if (scope->admission_owner && scope->admission_owner != typing->owner_key) return NULL;
		((struct pg_scope *)scope)->admission_owner = typing->owner_key;
		if (context && !context->checked_scope) ((struct pg_context *)context)->checked_scope = scope;
		if (!context) {
			typing->empty_scope = scope;
			((struct pg_typing_owner *)typing->owner_key)->empty_scope = scope;
		}
		return (const void *)scope;
	}
	if (!pg_occurrence_owned_by(subject, typing)) return NULL;
	if (subject->admission_owner) {
		if (subject->admission_owner != typing->owner_key) return NULL;
		/* A completed NF fact must not be forgotten when the same endpoint
		 * was admitted earlier as WHNF. Intermediate endpoints stay distinct. */
		if (rule == PG_PURE_NORMALIZATION && subject->construction == PG_PURE_NORMALIZATION &&
			pg_reduction_kind(certificate) == PG_REDUCTION_NF)
			((struct pg_occurrence *)subject)->certificate = certificate;
		return (const void *)subject;
	}
	if (rule == PG_CONSTRUCTOR_INTRO || rule == PG_TYPE_CASE)
		certificate = pg_evidence_input(inputs, rule == PG_CONSTRUCTOR_INTRO ? 1 : 0);
	else if (elimination_rule(rule)) certificate = pg_evidence_input(inputs, 4);
	else if (rule == PG_RETURN_VALUE || rule == PG_THUNK_COMPUTATION)
		certificate = count ? pg_evidence_input(inputs, 0) : NULL;
	struct pg_occurrence *accepted = (void *)subject;
	accepted->construction = rule;
	accepted->certificate = certificate;
	accepted->admission_owner = typing->owner_key;
	return (const void *)subject;
}

static const struct pg_evidence *accept_record(struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, const struct pg_evidence *const *premises,
	const void *certificate, const struct pg_context_map *map)
{
	return accept_record_inputs(typing, rule, context, subject, count,
		(struct pg_evidence_inputs){.owner = premises}, certificate, map);
}

static const struct pg_evidence *accept_with_conversion(struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, const struct pg_evidence *const *premises,
	const struct pg_conversion_certificate *conversion)
{
	return accept_record(typing, rule, context, subject, count, premises, conversion, NULL);
}

static const struct pg_evidence *accept(struct pg_typing *typing, enum pg_evidence_rule rule,
	const struct pg_context *context, const struct pg_occurrence *subject, size_t count, const struct pg_evidence *const *premises)
{
	return accept_with_conversion(typing, rule, context, subject, count, premises, NULL);
}

/* An inversion either exposes an existing typed child or retains its source
 * as a selection/boundary recipe. Do not attach an inverse history to a child. */
static const struct pg_evidence *accept_selection(struct pg_typing *typing,
	enum pg_evidence_rule rule, const struct pg_evidence *source,
	const struct pg_occurrence *subject)
{
	if (!subject) return NULL;
	const struct pg_evidence *checked = pg_evidence_for_subject(typing, subject, NULL);
	if (checked) return checked;
	if (subject->origin != pg_evidence_subject(source)) return pg_prove_structural_subject(typing, subject);
	return accept(typing, rule, subject->context, subject, 0, NULL);
}

static int context_proof(const struct pg_typing *typing, const struct pg_evidence *proof)
{
	if (!pg_evidence_owned_by(proof, typing)) return 0;
	return pg_evidence_judgement(proof) == PG_JUDGEMENT_CONTEXT;
}

/* Only an exact structural lifting can supply an unchecked destination scope.
 * Remove the final variable image and cancel the prefix images' weakenings. */
static const struct pg_context_map *map_lift_prefix(struct pg_typing *typing,
	const struct pg_context_map *map)
{
	if (!map->source || !map->destination || !map->count) return NULL;
	const struct pg_occurrence *variable = map->images[map->count - 1];
	if (variable->core != pg_reference(typing->graph, map->destination->binder)) return NULL;
	if (variable->classifier != map->destination->declared_type) return NULL;
	if (map->count > SIZE_MAX / sizeof(const struct pg_occurrence *)) return NULL;
	const struct pg_occurrence **images = malloc((map->count - 1) * sizeof(*images));
	if (map->count > 1 && !images) return NULL;
	for (size_t i = 0; i + 1 < map->count; ++i) {
		images[i] = pg_occurrence_unproject(typing, map->images[i], map->destination->parent);
		if (!images[i]) { free(images); return NULL; }
	}
	const struct pg_context_map *prefix = pg_context_map(typing,
		map->source->parent, map->destination->parent, map->count - 1, images);
	free(images);
	return prefix;
}

static const struct pg_evidence *lift_destination(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *prefix, struct pg_context_lift *work)
{
	const struct pg_context_map *map = pg_context_lift_result(work);
	if (!map) return NULL;
	const struct pg_evidence *checked = pg_check_scope_action(typing, prefix,
		pg_evidence_scope(source), map->destination);
	return checked ? pg_evidence_premise(checked, 1) : NULL;
}

static int map_dependency(void *owner, const void *key, size_t index, const void **child)
{
	(void)index;
	struct pg_typing *typing = owner;
	const struct pg_context_map *map = key;
	if (conclusion_first(typing, PG_JUDGEMENT_SUBSTITUTION, map)) return 0;
	const struct pg_evidence *source = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, map->source);
	const struct pg_evidence *destination = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, map->destination);
	if (!source) return -1;
	const struct pg_context_map *prefix_map = map_lift_prefix(typing, map);
	const struct pg_evidence *prefix = prefix_map
		? conclusion_first(typing, PG_JUDGEMENT_SUBSTITUTION, prefix_map) : NULL;
	/* Known endpoints need no reconstructed lift. Keep an accepted prefix's
	 * premises for pairing; otherwise check the described images individually. */
	if (!destination && prefix_map) {
		struct pg_context_lift *work = pg_context_lift_request(typing, prefix_map, map->source, map->destination->binder);
		while (pg_context_lift_advance(work, 1024) == PG_SUBSTITUTION_PENDING) {}
		if (pg_context_lift_result(work) != map) return -1;
		if (!prefix) { *child = prefix_map; return 1; }
		destination = lift_destination(typing, source, prefix, work);
		if (!destination) return -1;
	}
	if (destination && prefix) {
		const struct pg_evidence *image = pg_prove_variable(typing, destination, map->destination->binder);
		const struct pg_evidence *accepted = pg_prove_substitution_extension(typing, source, destination, prefix, 1, (struct pg_evidence_inputs){.owner = &image});
		if (pg_evidence_context_map(accepted) == map) return 0;
	}
	if (!destination || map->count > SIZE_MAX / sizeof(const struct pg_evidence *)) return -1;
	const struct pg_evidence **images = malloc(map->count * sizeof(*images));
	if (map->count && !images) return -1;
	for (size_t i = 0; i < map->count; ++i) images[i] = pg_prove_structural_subject(typing, map->images[i]);
	const struct pg_evidence *accepted = pg_prove_substitution(typing, source, destination, map->count, images);
	free(images);
	return pg_evidence_context_map(accepted) == map ? 0 : -1;
}

const struct pg_evidence *pg_structure_input(struct pg_typing *typing,
	const struct pg_occurrence *input, const struct pg_occurrence **child)
{
	const struct pg_evidence *proof = pg_evidence_for_subject(typing, input, NULL);
	if (!proof) *child = input;
	return proof;
}

static int structural_dependency(void *owner, const void *key, size_t index, const void **child)
{
	struct pg_typing *typing = owner;
	const struct pg_occurrence *subject = key;
	if (pg_evidence_for_subject(typing, subject, NULL)) return 0;
	const struct pg_evidence *proof = NULL;
	if (subject->map) {
		const struct pg_evidence *origin = pg_evidence_for_subject(typing, subject->origin, NULL);
		if (!origin && !index) { *child = subject->origin; return 1; }
		/* The origin may establish the source scope of this map. Certify it
		 * before asking the ordinary map rule to check its lifted destination
		 * and images, rather than requiring those scopes during collection. */
		proof = pg_prove_reindex(typing, pg_prove_context_map(typing, subject->map),
			origin);
	} else {
		const struct pg_occurrence *input = NULL;
		const struct pg_evidence *declaration = subject->scope ? pg_prove_scope(typing, subject->scope) : NULL;
		if (subject->scope && !declaration) return -1;
		const struct pg_evidence *context = subject->scope && subject->scope->context == subject->context
			? declaration : subject->context
			? conclusion_first(typing, PG_JUDGEMENT_CONTEXT, subject->context)
			: pg_prove_empty_context(typing);
		if (!context) return -1;
		uint64_t level;
		if (subject->selection) {
			proof = pg_function_selection(typing, subject, &input);
			if (!proof && !input) proof = pg_cbpv_selection(typing, subject, &input);
		} else if (subject->origin) {
			if (subject->core != subject->origin->core) return -1;
			const struct pg_evidence *source = pg_structure_input(typing, subject->origin, &input);
			if (source && subject->judgement == PG_JUDGEMENT_VALUE)
				proof = pg_prove_type_value(typing, source);
			else if (source && subject->judgement == PG_JUDGEMENT_VALUE_TYPE)
				proof = pg_prove_value_type(typing, source);
		} else if (!subject->operand_count && subject->core->kind == PG_REFERENCE && subject->core->as.reference->kind == PG_BINDER) {
			proof = subject->scope ? pg_check_variable(typing, context, subject->core->as.reference, declaration)
				: pg_prove_variable(typing, context, subject->core->as.reference);
		} else if (!subject->operand_count && pg_universe_level(subject->core, &level)) {
			proof = pg_prove_universe(typing, context, level);
		} else {
			proof = pg_identity_structure(typing, subject, &input);
			if (!proof && !input) proof = pg_cbpv_structure(typing, subject, &input);
			if (!proof && !input) proof = pg_function_structure(typing, context, subject, &input);
		}
		if (input) { *child = input; return 1; }
	}
	return proof && pg_evidence_subject(proof) == subject ? 0 : -1;
}

/* Each callback checks its rule once dependencies finish. There is no second
 * interpretation pass over the collected graph, nor acceptance from shape. */
static const struct pg_evidence *prove_structural(struct pg_typing *typing,
	enum pg_evidence_judgement judgement, const void *key,
	int (*dependency)(void *, const void *, size_t, const void **))
{
	if (!typing || !key) return NULL;
	const struct pg_evidence *result = conclusion_first(typing, judgement, key);
	if (result) return result;
	/* A ready rule needs no traversal workspace. The same callback performs
	 * its checks; allocate a DAG only for an outstanding prerequisite. */
	const void *child;
	int status = dependency(typing, key, 0, &child);
	if (status <= 0) return status ? NULL : conclusion_first(typing, judgement, key);
	struct pg_dag dag = {0};
	if (pg_dag_init(&dag, dependency, typing)) return NULL;
	if (!pg_dag_add(&dag, key)) result = conclusion_first(typing, judgement, key);
	pg_dag_destroy(&dag);
	return result;
}

const struct pg_evidence *pg_prove_context_map(struct pg_typing *typing,
	const struct pg_context_map *map)
{
	return prove_structural(typing, PG_JUDGEMENT_SUBSTITUTION, map, map_dependency);
}

/* Typed structure selects the construction; ordinary rules certify its maps.
 * No search by erased Core or interpretation of a receipt's history occurs. */
const struct pg_evidence *pg_prove_structural_subject(struct pg_typing *typing,
	const struct pg_occurrence *subject)
{
	return subject ? prove_structural(typing, subject->judgement, subject, structural_dependency) : NULL;
}

const struct pg_data_schema *pg_evidence_inductive_schema(const struct pg_evidence *evidence)
{
	return evidence && pg_evidence_rule(evidence) == PG_INDUCTIVE_FORM ? evidence_certificate(evidence) : NULL;
}

const struct pg_object *pg_evidence_constructor(const struct pg_evidence *evidence)
{
	if (!evidence || pg_evidence_rule(evidence) != PG_CONSTRUCTOR_INTRO) return NULL;
	const struct pg_term *head = pg_evidence_subject(evidence)->core;
	while (head->kind == PG_APPLICATION) head = head->as.application.function;
	return head->kind == PG_REFERENCE ? head->as.reference : NULL;
}

const struct pg_induction_allocation *pg_evidence_induction_allocation(const struct pg_evidence *evidence)
{
	return evidence && pg_evidence_rule(evidence) == PG_INDUCTION_ELIM ? pg_evidence_subject(evidence)->induction : NULL;
}

static const struct pg_evidence *schema_receipt(const void *owner, size_t i)
{
	return borrowed_premise(PG_INDUCTIVE_FORM, NULL, owner, i);
}

const struct pg_evidence *pg_prove_inductive_type(struct pg_typing *typing,
	const struct pg_data_schema *schema)
{
	const struct pg_evidence *self = pg_data_schema_parameters(schema);
	if (!context_proof(typing, self)) return NULL;
	int indexed = pg_evidence_rule(self) == PG_CONTEXT_FAMILY_EXTEND;
	if (!indexed && pg_evidence_rule(self) != PG_CONTEXT_EXTEND) return NULL;
	const struct pg_evidence *indices = pg_data_schema_indices(schema);
	if (!context_proof(typing, indices)) return NULL;
	uint64_t level, bound;
	const struct pg_term *universe = pg_evidence_scope(self)->type->core;
	if (!pg_universe_level(universe, &level)) return NULL;
	if (indexed) {
		const struct pg_term *signature = pg_context_signature(typing->graph,
			pg_evidence_context(self), pg_evidence_context(indices), universe);
		if (!signature || pg_alpha_equal(signature, pg_evidence_context(self)->declared_type) != 1) return NULL;
	} else if (pg_evidence_context(indices) != pg_evidence_context(self)) return NULL;
	const struct pg_evidence *parent = pg_context_parent_input(typing, self);
	size_t count = pg_data_constructor_count(schema), parameters;
	size_t prefix = indexed ? 2 : 1;
	if (count > SIZE_MAX / sizeof(void *) - prefix) return NULL;
	if (pg_context_extension_size(pg_evidence_context(parent), NULL, &parameters)) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	const struct pg_evidence_inputs inputs = {.owner = schema, .at = schema_receipt};
	uint64_t hash;
	enum pg_evidence_judgement kind = indexed ? PG_JUDGEMENT_TYPE_FAMILY : PG_JUDGEMENT_VALUE_TYPE;
	result = find_record_inputs(typing, PG_INDUCTIVE_FORM,
		pg_evidence_context(parent), NULL, count + prefix, inputs, schema, &hash);
	if (result) goto done;
	if (pg_data_schema_positive(schema, pg_evidence_context(self)->binder) != 1) goto done;
	if (pg_data_schema_field_level(schema, &bound) || bound > level) goto done;
	if (parameters > SIZE_MAX / sizeof(const struct pg_object *)) goto done;
	const struct pg_object **binders = pg_alloc(&temporary, parameters * sizeof(*binders));
	if (parameters && !binders) goto done;
	const struct pg_context *context = pg_evidence_context(parent);
	for (size_t i = parameters; i; --i, context = context->parent) binders[i - 1] = context->binder;
	const struct pg_term *core = pg_reference(typing->graph, pg_data_family_object(schema));
	for (size_t i = 0; i < parameters; ++i)
		core = pg_application(typing->graph, core, pg_reference(typing->graph, binders[i]));
	if (!core || !universe) goto done;
	const struct pg_occurrence *subject = pg_occurrence(typing, kind, pg_evidence_context(parent), core, pg_evidence_context(self)->declared_type, NULL, 0, NULL);
	if (!subject) goto done;
	result = accept_record_inputs(typing, PG_INDUCTIVE_FORM,
		pg_evidence_context(parent), subject, count + prefix, inputs, schema, NULL);
done:
	pg_graph_destroy(&temporary);
	return result;
}

/* A scope action is either a total substitution or a Pi component whose
 * independent inputs must be recovered in its smaller context. */
struct scope_frame {
	const struct pg_context_map *map;
	const struct pg_occurrence *restriction;
	const struct scope_frame *next;
};

static struct scope_frame *scope_frame(struct pg_graph *storage,
	const struct pg_context_map *map, const struct pg_occurrence *restriction,
	const struct scope_frame *next)
{
	if (!!map == !!restriction) return NULL;
	struct scope_frame *frame = pg_alloc(storage, sizeof(*frame));
	if (frame) *frame = (struct scope_frame){map, restriction, next};
	return frame;
}

struct constructor_structure {
	const struct pg_evidence *formation, *parameters;
	const struct pg_object *constructor;
	size_t count;
	const struct pg_occurrence *subject;
};

/* Inspect the current typed head, without evaluating or following provenance.
 * Declaration identity and arity are checked before exposing any field. */
static int constructor_view(struct pg_typing *typing, const struct pg_evidence *value,
	struct constructor_structure *view)
{
	if (!pg_evidence_owned_by(value, typing) || pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return 0;
	const struct pg_term *head = pg_evidence_subject(value)->core;
	size_t count = 0, position, arity;
	for (; head->kind == PG_APPLICATION; head = head->as.application.function) ++count;
	const struct pg_data_layout *layout;
	if (head->kind != PG_REFERENCE || !pg_data_constructor_view(head->as.reference, &layout, &position, &arity)) return 0;
	if (count != arity) return -1;
	struct pg_inductive_instance instance;
	if (!pg_inductive_instance(typing, formed_classifier(typing, value), &instance)) return -1;
	if (layout != pg_data_schema_layout(instance.schema)) return -1;
	*view = (struct constructor_structure){.formation = instance.formation,
		.parameters = instance.parameters, .constructor = head->as.reference,
		.count = count, .subject = pg_evidence_subject(value)};
	return 1;
}

static int structural_input(struct pg_typing *typing, const struct pg_occurrence *source,
	size_t index, const struct pg_occurrence **result);

static const struct pg_reduction_certificate *subject_normalization(struct pg_typing *typing,
	const struct pg_occurrence *subject)
{
	if (!subject->origin || subject->map || subject->selection) return NULL;
	/* A boundary conversion does not replace the original reduction receipt. */
	const struct pg_occurrence *normalized = pg_occurrence_derived(typing, subject->origin,
		subject->origin->judgement, subject->core, subject->origin->classifier);
	const struct pg_evidence *proof = pg_evidence_for_subject(typing, normalized, NULL);
	return proof ? pg_evidence_normalization(proof) : NULL;
}

static const struct pg_evidence *image_boundary(struct pg_typing *typing,
	const struct pg_evidence *result, const struct pg_occurrence *expected)
{
	if (!result) return NULL;
	if (pg_evidence_judgement(result) != expected->judgement) {
		if (expected->judgement == PG_JUDGEMENT_VALUE_TYPE) result = pg_prove_value_type(typing, result);
		else if (expected->judgement == PG_JUDGEMENT_VALUE) result = pg_prove_type_value(typing, result);
	}
	if (!result || pg_evidence_judgement(result) != expected->judgement) return NULL;
	if (pg_alpha_equal(pg_evidence_subject(result)->core, expected->core) != 1) return NULL;
	if (pg_alpha_equal(pg_evidence_classifier(result), expected->classifier) != 1) return NULL;
	return result;
}

const struct pg_evidence *pg_prove_substitution_rebase(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *map)
{
	struct pg_typed_query *work = pg_substitution_rebase_request(typing, context, map);
	while (!pg_typed_query_advance(work, UINT64_MAX)) {}
	return pg_typed_query_result(work);
}

static const struct pg_evidence *variable_frame(struct pg_typing *typing,
	const struct pg_evidence *variable, const struct scope_frame **frames)
{
	if (!*frames) return NULL;
	const struct scope_frame *frame = *frames;
	*frames = (*frames)->next;
	const struct pg_object *binder = pg_evidence_subject(variable)->core->as.reference;
	if (frame->map) {
		const struct pg_occurrence *image = pg_context_map_lookup(frame->map, binder, NULL);
		return pg_prove_structural_subject(typing, image);
	}
	return pg_prove_variable(typing,
		conclusion_first(typing, PG_JUDGEMENT_CONTEXT, frame->restriction->context), binder);
}

static const struct pg_occurrence *returned_computation(const struct pg_occurrence *subject)
{
	if (subject->judgement != PG_JUDGEMENT_VALUE) return NULL;
	if (subject->origin)
		return subject->origin->judgement == PG_JUDGEMENT_COMPUTATION ? subject->origin : NULL;
	if (subject->operand_count != 1 || subject->core->kind != PG_APPLICATION) return NULL;
	const struct pg_term *head = subject->core->as.application.function;
	if (head->kind != PG_REFERENCE || head->as.reference != &pg_total_result_operation) return NULL;
	const struct pg_occurrence *input = subject->operands[0];
	return input->judgement == PG_JUDGEMENT_COMPUTATION &&
		input->core == subject->core->as.application.argument ? input : NULL;
}

enum typed_query_resume { TYPED_RESUME_NONE, TYPED_RESUME_BODY, TYPED_RESUME_INPUT, TYPED_RESUME_PHASE,
	TYPED_RESUME_SELECTION, TYPED_RESUME_SELECTED_INPUT, TYPED_RESUME_SCOPE_IMAGE, TYPED_RESUME_COMPOSITION };

struct typed_elimination {
	const struct pg_evidence *branch;
	const struct pg_evidence **arguments;
	size_t count, next;
};

struct typed_field_input {
	const struct pg_occurrence *original;
	const struct pg_reduction_certificate *reduction;
};

struct typed_field {
	const struct pg_evidence *map;
	const struct pg_evidence **declarations;
	struct typed_field_input *inputs;
	size_t prefix, next;
};

struct typed_rebase {
	const struct pg_evidence *source, *substitution;
	struct constructor_structure constructor;
	const struct pg_reduction_certificate *reduction;
	const struct pg_evidence **outputs;
	size_t parameters, count, next;
};

struct typed_inductive {
	const struct scope_frame *frames;
	struct inductive_argument *arguments;
	const struct pg_evidence *instance, *prefix;
	const struct pg_evidence **values;
	size_t count, next;
	struct pg_inductive_instance result;
};

struct scope_sequence {
	const struct scope_frame *first;
	struct scope_frame *last;
};

struct selection_pending {
	const struct pg_evidence *argument;
	struct scope_sequence frames;
	size_t index;
	struct selection_pending *next;
};

struct typed_selection {
	struct scope_sequence frames, lifted;
	struct selection_pending *pending;
	const struct pg_evidence *argument, *extended, *body;
	const struct pg_occurrence *child;
	const struct pg_object *binder;
	const struct scope_frame *cursor;
	struct pg_typed_query *lift;
	struct pg_occurrence_action *action;
	size_t index;
};

struct typed_association {
	const struct pg_evidence *outer, *inner, *source, *first, *last;
	const struct pg_term *inner_target;
	const struct pg_object *binder;
	unsigned next;
};

struct typed_fold {
	const struct pg_evidence *outer, *handler, *carrier, *head, *payload, *resume, *origin;
	const struct pg_evidence **inputs, **waiting;
	size_t count, next;
};

struct typed_body_query {
	const struct pg_occurrence *current;
	const struct pg_evidence *argument, *environment, *value;
	enum typed_query_resume resume;
	struct pg_occurrence_action *action;
	struct typed_association *association;
	struct typed_fold *fold;
	size_t forces;
};

struct typed_input_query {
	const struct pg_occurrence *current;
	const struct pg_evidence *argument, *value;
	enum typed_query_resume resume;
	struct pg_occurrence_input *input;
	struct pg_typed_query *lift;
	struct pg_occurrence_action *action;
	struct typed_field *field;
	struct typed_selection *selection;
	const struct pg_reduction_certificate *reduction;
	const struct pg_reduction_certificate *input_reduction;
};

struct typed_elimination_query {
	struct typed_elimination *elimination;
};

struct typed_origin_query {
	const struct pg_evidence *environment;
	enum typed_query_resume resume;
};

struct typed_classifier_query {
	struct pg_occurrence_input *input;
};

struct typed_rebase_query {
	const struct pg_occurrence *current;
	const struct pg_evidence *argument, *environment;
	enum typed_query_resume resume;
	struct typed_rebase *rebase;
};

struct typed_inductive_query {
	const struct pg_occurrence *current;
	const struct pg_evidence *value, *environment;
	struct typed_inductive *inductive;
};

struct typed_selection_query {
	const struct pg_occurrence *current;
	struct typed_selection *selection;
};

static const struct pg_occurrence *typed_source(const struct pg_typed_query *work)
{
	return work->inputs[0];
}

static const struct pg_evidence *typed_map(const struct pg_typed_query *work)
{
	return work->inputs[0];
}

/* Borrow immutable scope frames; only this query's cursor/value advances.
 * Restriction is ordinary shared query work, not a nested unbounded solve. */
static int scope_image_step(struct pg_typed_query *work,
	const struct pg_evidence **value, const struct scope_frame **frames)
{
	if (work->dependency) {
		*value = pg_typed_query_result(work->dependency);
		work->dependency = NULL;
		*frames = (*frames)->next;
		return *value ? 0 : -1;
	}
	if (!*frames) return 1;
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct scope_frame *frame = *frames;
	if (frame->map) {
		*value = pg_prove_reindex(typing, pg_prove_context_map(typing, frame->map), *value);
		*frames = frame->next;
		return *value ? 0 : -1;
	}
	work->dependency = pg_rebase_request(typing,
		conclusion_first(typing, PG_JUDGEMENT_CONTEXT, frame->restriction->context), *value);
	return work->dependency ? 0 : -1;
}

static int typed_body_match(struct pg_typed_query *work);
static int typed_input_step(struct pg_typed_query *work);
static int typed_elimination_step(struct pg_typed_query *work);
static int typed_classifier_step(struct pg_typed_query *work);
static int typed_inductive_step(struct pg_typed_query *work);
static int typed_selection_step(struct pg_typed_query *work);
static const struct pg_evidence *unary_term_content(struct pg_typing *typing,
	const struct pg_evidence *proof, const struct pg_occurrence *child);

static int typed_phase_step(struct pg_typed_query *work);
static int typed_rebase_step(struct pg_typed_query *work);
static int typed_origin_step(struct pg_typed_query *work);
static int typed_body_step(struct pg_typed_query *work);

static int typed_input_advance(struct pg_typed_query *work)
{
	int status = typed_input_step(work);
	if (status == 1 && !work->result && !work->ordinal)
		work->result = unary_term_content(pg_typed_query_typing(work),
			pg_prove_structural_subject(pg_typed_query_typing(work), typed_source(work)), NULL);
	return status;
}

static const struct pg_typed_query_class TYPED_BODY[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_body_query), .input_count = 2, .advance = typed_body_step}};
static const struct pg_typed_query_class TYPED_INPUT[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_input_query), .input_count = 2, .advance = typed_input_advance}};
static const struct pg_typed_query_class TYPED_HEAD[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_body_query), .input_count = 2, .advance = typed_body_step}};
static const struct pg_typed_query_class TYPED_ELIMINATION[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_elimination_query), .input_count = 2, .advance = typed_elimination_step}};
static const struct pg_typed_query_class TYPED_ORIGIN[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_origin_query), .input_count = 2, .advance = typed_origin_step}};
static const struct pg_typed_query_class TYPED_CLASSIFIER[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_classifier_query), .input_count = 2, .advance = typed_classifier_step}};
static const struct pg_typed_query_class TYPED_REBASE[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_rebase_query), .input_count = 2, .advance = typed_rebase_step}};
static const struct pg_typed_query_class TYPED_MAP_REBASE[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_rebase_query), .input_count = 2, .advance = typed_rebase_step}};
static const struct pg_typed_query_class TYPED_INDUCTIVE[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_inductive_query), .input_count = 2, .advance = typed_inductive_step}};
static const struct pg_typed_query_class TYPED_SELECTION[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.size = sizeof(struct typed_selection_query), .input_count = 2, .advance = typed_selection_step}};
static const struct pg_typed_query_class TYPED_PHASE[1] = {{
	.pending = {&pg_typed_query_pending_ops},
	.input_count = 2, .advance = typed_phase_step}};

static struct pg_typed_query *typed_body_request(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct pg_evidence *argument,
	const struct pg_typed_query_class *kind, const struct pg_term *target)
{
	const void *key = argument ? (const void *)pg_evidence_subject(argument) : (const void *)target;
	const void *inputs[] = {source, key};
	int created;
	struct pg_typed_query *work = pg_typed_query_request(typing, kind, 0, inputs, &created);
	if (created) {
		struct typed_body_query *local = pg_typed_query_state(work);
		local->current = source;
		local->argument = argument;
	}
	return work;
}

struct pg_typed_query *pg_application_body_request(struct pg_typing *typing,
	const struct pg_evidence *function, const struct pg_evidence *argument)
{
	if (!pg_evidence_owned_by(function, typing)) return NULL;
	if (pg_evidence_judgement(function) != PG_JUDGEMENT_COMPUTATION && pg_evidence_judgement(function) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (!pg_evidence_owned_by(argument, typing)) return NULL;
	if (pg_evidence_judgement(argument) != PG_JUDGEMENT_VALUE && pg_evidence_judgement(argument) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (pg_evidence_context(function) != pg_evidence_context(argument)) return NULL;
	return typed_body_request(typing, pg_evidence_subject(function), argument, TYPED_BODY, NULL);
}

struct pg_typed_query *pg_return_body_request(struct pg_typing *typing,
	const struct pg_evidence *computation)
{
	if (!pg_evidence_owned_by(computation, typing) || pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	return typed_body_request(typing, pg_evidence_subject(computation), NULL, TYPED_BODY, NULL);
}

struct pg_typed_query *pg_elimination_body_request(struct pg_typing *typing,
	const struct pg_evidence *elimination)
{
	if (!pg_evidence_owned_by(elimination, typing)) return NULL;
	if (pg_evidence_rule(elimination) != PG_MATCH_ELIM && pg_evidence_rule(elimination) != PG_INDUCTION_ELIM) return NULL;
	const void *inputs[] = {pg_evidence_subject(elimination), NULL};
	return pg_typed_query_request(typing, TYPED_ELIMINATION, 0, inputs, NULL);
}

static struct pg_typed_query *typed_head_request(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_reduction_certificate *receipt)
{
	if (!pg_evidence_owned_by(source, typing) || !pg_evidence_subject(source)) return NULL;
	if (receipt) {
		if (pg_reduction_policy(receipt) != &pg_pure_policy) return NULL;
		if (pg_alpha_equal(pg_evidence_subject(source)->core, pg_reduction_source(receipt)) != 1) return NULL;
	}
	/* Without a receipt the caller requests constructor exposure, not a
	 * prediction of the evaluator's normal form. */
	return typed_body_request(typing, pg_evidence_subject(source), NULL, TYPED_HEAD, receipt ? pg_reduction_target(receipt) : NULL);
}

/* Reuse the accepted source and its finite reduction chain. Different input
 * queries share these intermediate conclusions; this is not another AST. */
static struct pg_typed_query *typed_phase_request(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct pg_reduction_phase *phase)
{
	const void *inputs[] = {source, phase};
	return pg_typed_query_request(typing, TYPED_PHASE, 0, inputs, NULL);
}

static int typed_phase_step(struct pg_typed_query *work)
{
	const struct pg_reduction_phase *phase = work->inputs[1];
	const struct pg_evidence *source;
	if (phase->previous) {
		if (!work->dependency) {
			work->dependency = typed_phase_request(pg_typed_query_typing(work), typed_source(work), phase->previous);
			return work->dependency ? 0 : -1;
		}
		if (!work->dependency->status) return 0;
		source = pg_typed_query_result(work->dependency);
	} else source = pg_prove_structural_subject(pg_typed_query_typing(work), typed_source(work));
	const struct pg_reduction_certificate *receipt = phase->children[0]
		? pg_reduction_prefix(pg_typed_query_typing(work)->graph, phase->head, phase->children[0], phase->children[1]) : phase->head;
	work->result = pg_prove_normalization(pg_typed_query_typing(work), source, receipt);
	return work->result ? 1 : -1;
}

struct pg_typed_query *pg_typed_input_request(struct pg_typing *typing,
	const struct pg_evidence *source, size_t index)
{
	if (!pg_evidence_owned_by(source, typing) || !pg_evidence_subject(source) || index == SIZE_MAX) return NULL;
	const void *inputs[] = {pg_evidence_subject(source), NULL};
	int created;
	struct pg_typed_query *work = pg_typed_query_request(typing, TYPED_INPUT, index, inputs, &created);
	if (created) {
		struct typed_input_query *local = pg_typed_query_state(work);
		local->current = inputs[0];
	}
	return work;
}

struct pg_typed_query *pg_construction_origin_request(struct pg_typing *typing,
	const struct pg_evidence *source)
{
	if (!pg_evidence_owned_by(source, typing) || !pg_evidence_subject(source)) return NULL;
	const void *inputs[] = {pg_evidence_subject(source), NULL};
	return pg_typed_query_request(typing, TYPED_ORIGIN, 0, inputs, NULL);
}

static struct pg_typed_query *typed_rebase_request(struct pg_typing *typing,
	const struct pg_evidence *context, const void *source, const struct pg_typed_query_class *kind)
{
	const void *inputs[] = {source, kind == TYPED_MAP_REBASE ? (const void *)context : (const void *)pg_evidence_context(context)};
	int created;
	struct pg_typed_query *work = pg_typed_query_request(typing, kind, 0, inputs, &created);
	if (created) {
		struct typed_rebase_query *local = pg_typed_query_state(work);
		local->current = kind == TYPED_MAP_REBASE ? NULL : source;
		local->argument = context;
	}
	return work;
}

struct pg_typed_query *pg_rebase_request(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *source)
{
	if (!context_proof(typing, context) || !pg_evidence_owned_by(source, typing) || !pg_evidence_subject(source)) return NULL;
	return typed_rebase_request(typing, context, pg_evidence_subject(source), TYPED_REBASE);
}

struct pg_typed_query *pg_substitution_rebase_request(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *map)
{
	if (!context_proof(typing, context) || !pg_evidence_owned_by(map, typing)) return NULL;
	if (pg_evidence_rule(map) != PG_CONTEXT_SUBSTITUTION) return NULL;
	return typed_rebase_request(typing, context, map, TYPED_MAP_REBASE);
}

static int typed_environment_request(struct pg_typed_query *work,
	enum typed_query_resume *resume, const struct pg_evidence *first, const struct pg_evidence *second)
{
	work->dependency = pg_substitution_compose_request(pg_typed_query_typing(work), first, second);
	*resume = TYPED_RESUME_COMPOSITION;
	return work->dependency ? 0 : -1;
}

static int typed_environment_resume(struct pg_typed_query *work,
	enum typed_query_resume *resume, const struct pg_evidence **environment)
{
	*environment = pg_typed_query_result(work->dependency);
	work->dependency = NULL;
	*resume = TYPED_RESUME_NONE;
	return *environment ? 0 : -1;
}

static int typed_rebase_step(struct pg_typed_query *work)
{
	struct typed_rebase_query *local = pg_typed_query_state(work);
	if (local->resume == TYPED_RESUME_COMPOSITION) return typed_environment_resume(work, &local->resume, &local->environment);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_evidence *context = local->argument;
	int map_query = pg_typed_query_role(work) == TYPED_MAP_REBASE;
	/* No relocation: retain this map's exact image and Context derivations. */
	if (map_query && context == pg_evidence_premise(typed_map(work), 1)) {
		work->result = typed_map(work);
		return 1;
	}
	if (map_query && !local->rebase) {
		local->rebase = pg_alloc(typing->graph, sizeof(*local->rebase));
		if (!local->rebase) return -1;
		local->rebase->substitution = typed_map(work);
		local->rebase->count = pg_evidence_context_map(typed_map(work))->count;
	}
	if (local->resume == TYPED_RESUME_BODY) {
		const struct pg_evidence *computation = pg_typed_query_result(work->dependency);
		work->result = image_boundary(typing,
			unary_term_content(typing, computation, NULL), typed_source(work));
		return work->result ? 1 : -1;
	}
	if (!local->rebase) {
		const struct pg_occurrence *subject = local->current;
		if (typed_source(work)->core->kind == PG_REFERENCE && typed_source(work)->core->as.reference->kind == PG_BINDER)
			work->result = image_boundary(typing, pg_prove_variable(typing, context, typed_source(work)->core->as.reference), typed_source(work));
		if (!work->result) work->result = image_boundary(typing, pg_prove_projection(typing, context,
			pg_prove_structural_subject(typing, subject)), typed_source(work));
		if (work->result) return 1;
		if (subject->origin && !subject->selection) {
			if (subject->map) {
				const struct pg_evidence *inner = pg_prove_context_map(typing, subject->map);
				local->current = subject->origin;
				if (local->environment) return typed_environment_request(work, &local->resume, inner, local->environment);
				local->environment = inner;
				return inner ? 0 : -1;
			}
			if (subject->core == subject->origin->core && subject->classifier == subject->origin->classifier) {
				local->current = subject->origin;
				return 0;
			}
			if (subject->origin->judgement == PG_JUDGEMENT_COMPUTATION && subject->judgement != PG_JUDGEMENT_COMPUTATION) {
				/* Transport the checked computation before inverting RETURN.
				 * Extracting its value first can revisit this same derived node. */
				const struct pg_evidence *computation = pg_prove_structural_subject(typing, subject->origin);
				if (local->environment) computation = pg_prove_reindex(typing, local->environment, computation);
				work->dependency = pg_rebase_request(typing, context, computation);
				local->resume = TYPED_RESUME_BODY;
				return work->dependency ? 0 : -1;
			}
		}
		if (local->environment && subject->core->kind == PG_REFERENCE && subject->core->as.reference->kind == PG_BINDER) {
			const struct pg_evidence *value = pg_substitution_image(typing, local->environment, subject->core->as.reference);
			local->current = value ? pg_evidence_subject(value) : NULL;
			local->environment = NULL;
			return local->current ? 0 : -1;
		}
		struct typed_rebase *state = pg_alloc(typing->graph, sizeof(*state));
		if (!state) return -1;
		state->source = pg_prove_structural_subject(typing, subject);
		if (!state->source) return -1;
		int constructor = subject->origin ? 0 : constructor_view(typing, state->source, &state->constructor);
		if (constructor < 0) return -1;
		if (constructor) {
			if (state->constructor.count != subject->operand_count) return -1;
			state->parameters = pg_evidence_context_map(state->constructor.parameters)->count;
			if (subject->operand_count > SIZE_MAX - state->parameters) return -1;
			state->count = state->parameters + subject->operand_count;
		} else if (!subject->origin && subject->operand_count == 2 && subject->core->kind == PG_APPLICATION &&
			subject->operands[0]->judgement == PG_JUDGEMENT_TYPE_FAMILY &&
			subject->operands[0]->core == subject->core->as.application.function &&
			subject->operands[1]->core == subject->core->as.application.argument) state->count = 2;
		else if (local->environment) {
			state->substitution = local->environment;
			state->count = pg_evidence_context_map(state->substitution)->count;
			local->environment = NULL;
		} else if (subject->origin && !subject->selection) {
			state->reduction = subject_normalization(typing, subject);
			if (!state->reduction) return -1;
			state->count = 1;
		} else return -1;
		local->rebase = state;
	}
	struct typed_rebase *state = local->rebase;
	if (!state->outputs && state->count) {
		if (state->count > SIZE_MAX / sizeof(*state->outputs)) return -1;
		state->outputs = pg_alloc(typing->graph, state->count * sizeof(*state->outputs));
		if (!state->outputs) return -1;
	}
	if (work->dependency) {
		const struct pg_evidence *result = pg_typed_query_result(work->dependency);
		if (!result) return -1;
		state->outputs[state->next++] = result;
		work->dependency = NULL;
	}
	if (state->next < state->count) {
		if (map_query) {
			work->dependency = pg_rebase_request(typing, context,
				pg_substitution_image_at(typing, state->substitution, state->next));
			return work->dependency ? 0 : -1;
		}
		const struct pg_occurrence *input;
		if (state->constructor.constructor && state->next < state->parameters)
			input = pg_evidence_context_map(state->constructor.parameters)->images[state->next];
		else if (state->substitution) input = pg_evidence_context_map(state->substitution)->images[state->next];
		else input = state->reduction ? local->current->origin : local->current->operands[state->next - state->parameters];
		const struct pg_evidence *value = pg_prove_structural_subject(typing, input);
		if (local->environment) value = pg_prove_reindex(typing, local->environment, value);
		work->dependency = pg_rebase_request(typing, context, value);
		return work->dependency ? 0 : -1;
	}
	if (state->constructor.constructor) {
		const struct pg_evidence *map = pg_prove_substitution(typing, pg_evidence_premise(state->constructor.parameters, 0),
			context, state->parameters, state->outputs);
		work->result = pg_prove_constructor(typing, state->constructor.formation,
			state->constructor.constructor, map, state->count - state->parameters,
			state->count > state->parameters ? state->outputs + state->parameters : NULL);
	} else if (state->substitution) {
		const struct pg_evidence *map = pg_prove_substitution(typing, pg_evidence_premise(state->substitution, 0),
			context, state->count, state->outputs);
		work->result = map_query ? map : pg_prove_reindex(typing, map, state->source);
	} else if (state->reduction) work->result = pg_prove_normalization(typing, state->outputs[0], state->reduction);
	else work->result = pg_prove_family_application(typing, state->outputs[0], state->outputs[1]);
	if (!map_query) work->result = image_boundary(typing, work->result, typed_source(work));
	return work->result ? 1 : -1;
}

static int typed_origin_step(struct pg_typed_query *work)
{
	struct typed_origin_query *local = pg_typed_query_state(work);
	if (local->resume == TYPED_RESUME_COMPOSITION)
		return typed_environment_resume(work, &local->resume, &local->environment) ? -1 : 1;
	const struct pg_occurrence *subject = typed_source(work);
	if (subject->origin && !subject->selection && (subject->map || subject->judgement == subject->origin->judgement)) {
		if (!work->dependency) {
			work->dependency = pg_construction_origin_request(pg_typed_query_typing(work),
				pg_prove_structural_subject(pg_typed_query_typing(work), subject->origin));
			return work->dependency ? 0 : -1;
		}
		if (!work->dependency->status) return 0;
		work->result = pg_typed_query_result(work->dependency);
		if (!work->result) return -1;
		local->environment = pg_construction_origin_environment(work->dependency);
		if (subject->map) {
			const struct pg_evidence *step = pg_prove_context_map(pg_typed_query_typing(work), subject->map);
			if (local->environment) return typed_environment_request(work, &local->resume, local->environment, step);
			local->environment = step;
			if (!step) return -1;
		}
		return 1;
	}
	work->result = pg_prove_structural_subject(pg_typed_query_typing(work), subject);
	return work->result ? 1 : -1;
}

const struct pg_evidence *pg_construction_origin_environment(const struct pg_typed_query *work)
{
	if (!work || pg_typed_query_role(work) != TYPED_ORIGIN || work->status != 1) return NULL;
	struct typed_origin_query *local = pg_typed_query_state(work);
	return local->environment;
}

static int typed_body_enter(struct pg_typed_query *work, const struct pg_occurrence *current,
	const struct pg_evidence *argument)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	const struct pg_evidence *source = pg_prove_structural_subject(pg_typed_query_typing(work), current);
	/* A captured callee may itself be the image of a binder. Apply the same
	 * pending scope to both operands before asking shared application work. */
	if (local->environment) {
		source = pg_prove_reindex(pg_typed_query_typing(work), local->environment, source);
		if (argument) {
			argument = pg_prove_reindex(pg_typed_query_typing(work), local->environment, argument);
			if (!argument) return -1;
		}
		local->environment = NULL;
	}
	work->dependency = argument ? pg_application_body_request(pg_typed_query_typing(work), source, argument)
		: pg_return_body_request(pg_typed_query_typing(work), source);
	local->resume = TYPED_RESUME_BODY;
	return work->dependency ? 0 : -1;
}

static int exposed_head(const struct pg_occurrence *subject)
{
	const struct pg_term *core = subject->core, *payload, *resume;
	const struct pg_object *label;
	if (subject->judgement == PG_JUDGEMENT_COMPUTATION &&
		core->kind == PG_APPLICATION && core->as.application.function->kind == PG_REFERENCE &&
		core->as.application.function->as.reference == &pg_return_operation) return 1;
	/* A normalized request still needs its typed construction, not merely
	 * its printed head, to retain the operation's accepted declaration. */
	if (subject->judgement == PG_JUDGEMENT_COMPUTATION && !subject->origin &&
		pg_computation_request_view(core, &label, &payload, &resume)) return 1;
	if (subject->judgement != PG_JUDGEMENT_VALUE) return 0;
	const struct pg_term *head = subject->core;
	while (head->kind == PG_APPLICATION) head = head->as.application.function;
	const struct pg_data_layout *layout;
	size_t position, arity;
	return head->kind == PG_REFERENCE && pg_data_constructor_view(head->as.reference, &layout, &position, &arity);
}

static const struct pg_term *fold_source(const struct pg_term *core)
{
	if (!core || core->kind != PG_APPLICATION) return NULL;
	const struct pg_term *head = core->as.application.function;
	if (head->kind != PG_APPLICATION || head->as.application.function->kind != PG_REFERENCE) return NULL;
	return head->as.application.function->as.reference == &pg_fold_operation ? head->as.application.argument : NULL;
}

/* Read the evaluator's association shape to demand the inner head first.
 * The shape guides work only; ordinary rules establish every typed result. */
static int typed_association_start(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	if (pg_typed_query_role(work) != TYPED_HEAD || !work->inputs[1] || local->forces) return 0;
	if (!fold_source(fold_source(local->current->core))) return 0;
	const struct pg_term *target = work->inputs[1], *source = fold_source(target);
	if (!source) return 0;
	const struct pg_term *lambda = target->as.application.argument;
	if (lambda->kind != PG_LAMBDA) return 0;
	const struct pg_term *call = fold_source(lambda->as.lambda.body);
	if (!call || call->kind != PG_APPLICATION) return 0;
	const struct pg_term *argument = call->as.application.argument;
	if (argument->kind != PG_REFERENCE || argument->as.reference != lambda->as.lambda.binder) return 0;
	struct typed_association *state = pg_alloc(pg_typed_query_typing(work)->graph, sizeof(*state));
	if (!state) return -1;
	*state = (struct typed_association){0};
	state->outer = pg_prove_structural_subject(pg_typed_query_typing(work), local->current);
	if (local->environment) state->outer = pg_prove_reindex(pg_typed_query_typing(work), local->environment, state->outer);
	state->inner_target = pg_computation_fold(pg_typed_query_typing(work)->graph, source, call->as.application.function, 0, NULL);
	state->binder = lambda->as.lambda.binder;
	if (!state->outer || !state->inner_target) return -1;
	local->association = state;
	local->environment = NULL;
	return 1;
}

static int typed_association_step(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	struct typed_association *state = local->association;
	const struct pg_evidence **outputs[] = {&state->inner, &state->inner, &state->source, &state->first, &state->last};
	if (state->next < 5) {
		if (!work->dependency) {
			switch (state->next) {
			case 0: work->dependency = pg_typed_input_request(typing, state->outer, 0); break;
			case 1: work->dependency = typed_body_request(typing, pg_evidence_subject(state->inner), NULL,
				TYPED_HEAD, state->inner_target); break;
			case 2: work->dependency = pg_typed_input_request(typing, state->inner, 0); break;
			case 3: work->dependency = pg_typed_input_request(typing, state->inner, 1); break;
			case 4: work->dependency = pg_typed_input_request(typing, state->outer, 1); break;
			}
			return work->dependency ? 0 : -1;
		}
		if (!work->dependency->status) return 0;
		const struct pg_evidence *input = pg_typed_query_result(work->dependency);
		if (!input) return -1;
		*outputs[state->next++] = input;
		work->dependency = NULL;
		return 0;
	}
	const struct pg_evidence *context = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, pg_evidence_context(state->outer));
	const struct pg_evidence *domain = pg_prove_return_content(typing, pg_prove_classifier(typing, context, state->source));
	const struct pg_evidence *extended = pg_prove_context_extension(typing, context, state->binder, domain);
	const struct pg_evidence *call = pg_prove_application(typing, pg_prove_projection(typing, extended, state->first),
		pg_prove_variable(typing, extended, state->binder));
	const struct pg_evidence *body = pg_prove_fold(typing, call, pg_prove_projection(typing, extended, state->last));
	const struct pg_evidence *pi = pg_prove_pi(typing, extended, pg_prove_classifier(typing, extended, body));
	const struct pg_evidence *result = pg_prove_fold(typing, state->source, pg_prove_lambda(typing, pi, body));
	if (!result) return -1;
	local->current = pg_evidence_subject(result);
	local->association = NULL;
	return 0;
}

static int typed_fold_start(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	const struct pg_occurrence *source = local->current;
	const struct pg_term *head = source->core;
	size_t supplied = source->operand_count, count = 0;
	if (supplied < 2) return 0;
	if (supplied == 2 && !fold_source(head)) return 0;
	for (size_t i = 0; i < supplied; ++i) {
		if (head->kind != PG_APPLICATION) return 0;
		head = head->as.application.function;
	}
	if (head->kind != PG_REFERENCE) return 0;
	const struct pg_clause_position *positions;
	if (head->as.reference != &pg_fold_operation &&
		!pg_computation_handler_view(head->as.reference, &count, &positions)) return 0;
	if (count > SIZE_MAX - 2 || supplied != count + 2) return -1;
	if (supplied > SIZE_MAX / sizeof(const struct pg_evidence *)) return -1;
	struct typed_fold *state = pg_alloc(pg_typed_query_typing(work)->graph, sizeof(*state));
	if (!state) return -1;
	*state = (struct typed_fold){.count = count};
	state->inputs = pg_alloc(pg_typed_query_typing(work)->graph, supplied * sizeof(*state->inputs));
	if (!state->inputs) return -1;
	/* Signature formation is logical evidence. Program operands come from
	 * the typed structure; no traversal of premise wrappers recovers them. */
	if (count) {
		for (state->handler = pg_evidence_for_subject(pg_typed_query_typing(work), source, NULL);
			state->handler && pg_evidence_rule(state->handler) != PG_HANDLER_ELIM;
			state->handler = pg_evidence_for_subject(pg_typed_query_typing(work), source, state->handler)) {}
		if (!state->handler) return -1;
	}
	state->outer = pg_prove_structural_subject(pg_typed_query_typing(work), source);
	if (local->environment) state->outer = pg_prove_reindex(pg_typed_query_typing(work), local->environment, state->outer);
	if (!state->outer) return -1;
	if (count) {
		state->carrier = formed_classifier(pg_typed_query_typing(work), state->outer);
		if (!state->carrier) return -1;
	}
	local->environment = NULL;
	local->fold = state;
	return 1;
}

struct fold_rebuild_inputs {
	struct pg_typing *typing;
	const struct typed_fold *state;
	const struct pg_evidence *context;
};

static struct pg_handler_clause fold_rebuild_clause(const void *owner, size_t i)
{
	const struct fold_rebuild_inputs *inputs = owner;
	const struct typed_fold *state = inputs->state;
	return (struct pg_handler_clause){pg_operation_declaration_at(inputs->typing,
		pg_handler_signature_label(evidence_certificate(state->handler), i),
		pg_evidence_premise(state->handler, 3 + 3 * i), pg_evidence_premise(state->handler, 4 + 3 * i)),
		pg_prove_projection(inputs->typing, inputs->context, state->inputs[i + 2])};
}

static const struct pg_evidence *typed_fold_rebuild(struct pg_typing *typing,
	const struct typed_fold *state, const struct pg_evidence *context, const struct pg_evidence *input)
{
	const struct pg_evidence *returned = pg_prove_projection(typing, context, state->inputs[1]);
	if (!state->count) return pg_prove_fold(typing, input, returned);
	const struct fold_rebuild_inputs inputs = {typing, state, context};
	return pg_prove_handler_inputs(typing, input, returned,
		pg_prove_projection(typing, context, state->carrier),
		state->count, &inputs, fold_rebuild_clause);
}

static int typed_fold_wait(struct pg_typed_query *work,
	const struct pg_evidence **slot, struct pg_typed_query *dependency)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	local->fold->waiting = slot;
	work->dependency = dependency;
	return dependency ? 0 : -1;
}

static int typed_fold_step(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	struct typed_fold *state = local->fold;
	if (state->waiting) {
		if (!work->dependency->status) return 0;
		*state->waiting = pg_typed_query_result(work->dependency);
		if (!*state->waiting) return -1;
		state->waiting = NULL;
		work->dependency = NULL;
		return 0;
	}
	if (state->next < state->count + 2) {
		size_t i = state->next++;
		return typed_fold_wait(work, &state->inputs[i], pg_typed_input_request(typing, state->outer, i));
	}
	if (!state->head)
		return typed_fold_wait(work, &state->head, typed_head_request(typing, state->inputs[0], NULL));
	const struct pg_term *head = pg_evidence_subject(state->head)->core;
	const struct pg_evidence *result;
	if (head->kind == PG_APPLICATION && head->as.application.function == pg_reference(typing->graph, &pg_return_operation)) {
		if (!state->payload)
			return typed_fold_wait(work, &state->payload, pg_return_body_request(typing, state->inputs[0]));
		result = pg_prove_application(typing, state->inputs[1], state->payload);
	} else {
		const struct pg_term *payload, *resume;
		const struct pg_object *label;
		if (!pg_computation_request_view(head, &label, &payload, &resume)) return -1;
		if (!state->payload)
			return typed_fold_wait(work, &state->payload, pg_typed_input_request(typing, state->head, 0));
		if (!state->resume)
			return typed_fold_wait(work, &state->resume, pg_typed_input_request(typing, state->head, 1));
		if (!state->origin)
			return typed_fold_wait(work, &state->origin, pg_construction_origin_request(typing, state->head));
		const struct pg_operation_declaration *operation = pg_evidence_request_declaration(state->origin);
		if (!operation || pg_operation_label(operation) != label) return -1;
		const struct pg_evidence *context = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, pg_evidence_context(state->outer));
		const struct pg_object *binder = pg_binder(typing->graph);
		const struct pg_evidence *scope = pg_prove_context_extension(typing, context, binder,
			pg_prove_projection(typing, context, pg_operation_response_type(operation)));
		const struct pg_evidence *call = pg_prove_application(typing, pg_prove_projection(typing, scope, state->resume),
			pg_prove_variable(typing, scope, binder));
		const struct pg_evidence *body = typed_fold_rebuild(typing, state, scope, call);
		const struct pg_evidence *pi = pg_prove_pi(typing, scope, formed_classifier(typing, body));
		const struct pg_evidence *continuation = pg_prove_lambda(typing, pi, body);
		size_t i = 0;
		while (i < state->count && pg_handler_signature_label(evidence_certificate(state->handler), i) != label) ++i;
		result = i == state->count ? pg_prove_request(typing, operation, state->payload, continuation)
			: pg_prove_application(typing, pg_prove_application(typing, state->inputs[i + 2], state->payload),
				pg_prove_thunk(typing, continuation));
	}
	if (!result) return -1;
	local->current = pg_evidence_subject(result);
	local->fold = NULL;
	return 0;
}

static int typed_return_step(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	if (!work->dependency) {
		work->dependency = typed_head_request(pg_typed_query_typing(work),
			pg_prove_structural_subject(pg_typed_query_typing(work), typed_source(work)), NULL);
		return work->dependency ? 0 : -1;
	}
	if (!work->dependency->status) return 0;
	const struct pg_evidence *result = pg_typed_query_result(work->dependency);
	if (!result) return -1;
	if (local->resume == TYPED_RESUME_INPUT) {
		work->result = result;
		return 1;
	}
	const struct pg_term *core = pg_evidence_subject(result)->core;
	if (core->kind != PG_APPLICATION || core->as.application.function !=
		pg_reference(pg_typed_query_typing(work)->graph, &pg_return_operation)) return -1;
	work->dependency = pg_typed_input_request(pg_typed_query_typing(work), result, 0);
	local->resume = TYPED_RESUME_INPUT;
	return work->dependency ? 0 : -1;
}

static int typed_body_step(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	if (local->resume == TYPED_RESUME_COMPOSITION) return typed_environment_resume(work, &local->resume, &local->environment);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_occurrence *current = local->current;
	if (pg_typed_query_role(work) == TYPED_BODY && !local->argument) return typed_return_step(work);
	if (local->association) return typed_association_step(work);
	if (local->fold) return typed_fold_step(work);
	if (local->resume == TYPED_RESUME_BODY) {
		if (!work->dependency->status) return 0;
		const struct pg_evidence *result = pg_typed_query_result(work->dependency);
		if (!result) return -1;
		local->current = pg_evidence_subject(result);
		work->dependency = NULL;
		local->resume = TYPED_RESUME_NONE;
		return 0;
	}
	if (local->value) {
		work->result = local->environment ? pg_prove_reindex(typing, local->environment, local->value) : local->value;
		return work->result ? 1 : -1;
	}
	/* A checked result is usable structure, even when its origin is a
	 * computation whose construction cannot be exposed by this query. */
	const struct pg_term *core = current->core;
	/* The retained reduction specifies the head. Constructor guesses cannot
	 * replace that boundary, especially while a context action is pending. */
	if (pg_typed_query_role(work) == TYPED_HEAD && !local->forces &&
		(work->inputs[1] || local->action || exposed_head(current))) {
		const struct pg_occurrence *image = current;
		if (local->environment) {
			if (!local->action) local->action = pg_occurrence_action_request(typing,
				pg_evidence_context_map(local->environment), current);
			enum pg_substitution_status status = pg_occurrence_action_advance(local->action, 1);
			if (status == PG_SUBSTITUTION_PENDING) return 0;
			if (status == PG_SUBSTITUTION_ERROR) return -1;
			image = pg_occurrence_action_result(local->action);
			local->action = NULL;
		}
		if (image->context == typed_source(work)->context &&
			(!work->inputs[1] || pg_alpha_equal(image->core, work->inputs[1]) == 1)) {
			local->value = pg_prove_structural_subject(typing, current);
			if (local->environment) local->value = pg_prove_reindex(typing, local->environment, local->value);
			local->environment = NULL;
			return local->value ? 0 : -1;
		}
	}
	const struct pg_occurrence *returned = returned_computation(current);
	if (returned) return typed_body_enter(work, returned, NULL);
	/* Child normalization can reveal right unit. Select the current typed
	 * input before following provenance, including under a context action. */
	if (core->kind == PG_APPLICATION && core->as.application.function->kind == PG_APPLICATION) {
		const struct pg_term *head = core->as.application.function;
		if (head->as.application.function == pg_reference(typing->graph, &pg_fold_operation) &&
			pg_computation_eta(typing->graph, core) == head->as.application.argument) {
			work->dependency = pg_typed_input_request(typing, pg_prove_structural_subject(typing, current), 0);
			local->resume = TYPED_RESUME_BODY;
			return work->dependency ? 0 : -1;
		}
	}
	int association = typed_association_start(work);
	if (association) return association < 0 ? -1 : 0;
	if (current->origin) {
		if (current->selection) return -1;
		if (current->map) {
			const struct pg_evidence *step = pg_prove_context_map(typing, current->map);
			local->current = current->origin;
			if (local->environment) return typed_environment_request(work, &local->resume, step, local->environment);
			local->environment = step;
			return step ? 0 : -1;
		} else if (current->judgement != current->origin->judgement) {
			if (current->judgement != PG_JUDGEMENT_COMPUTATION || current->origin->judgement != PG_JUDGEMENT_VALUE) return -1;
			++local->forces;
		}
		local->current = current->origin;
		return 0;
	}
	if (current->map_count == 1)
		return typed_body_match(work);
	int fold = typed_fold_start(work);
	if (fold) return fold < 0 ? -1 : 0;
	if (core->kind == PG_LAMBDA) {
		if (!local->argument || local->forces) return -1;
		const struct pg_occurrence *body = pg_occurrence_scoped_input(current, 0);
		if (!body) return -1;
		const struct pg_evidence *extended = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, body->context);
		if (!extended) return -1;
		const struct pg_evidence *parent = pg_context_parent_input(typing, extended);
		const struct pg_evidence *map = local->environment ? local->environment
			: pg_prove_substitution_projection(typing, parent, parent);
		map = pg_prove_substitution_pair(typing, map, extended, local->argument);
		work->result = pg_prove_reindex(typing, map, pg_prove_structural_subject(typing, body));
		return work->result ? 1 : -1;
	}
	if (core->kind == PG_APPLICATION) {
		const struct pg_term *head = core->as.application.function;
		if (head->kind == PG_REFERENCE &&
			(head->as.reference == &pg_force_operation || head->as.reference == &pg_thunk_operation)) {
			if (current->operand_count != 1 || current->operands[0]->core != core->as.application.argument) return -1;
			if (head->as.reference == &pg_force_operation) ++local->forces;
			else if (local->forces) --local->forces;
			else return -1;
			local->current = current->operands[0];
			return 0;
		}
		if (current->operand_count != 2 || current->operands[1]->core != core->as.application.argument) return -1;
		if (current->operands[0]->core != head) return -1;
		const struct pg_evidence *right = pg_prove_structural_subject(typing, current->operands[1]);
		if (!right) return -1;
		return typed_body_enter(work, current->operands[0], right);
	}
	if (core->kind != PG_REFERENCE || core->as.reference->kind != PG_BINDER || !local->environment) return -1;
	const struct pg_evidence *image = pg_substitution_image(typing, local->environment, core->as.reference);
	if (!image) return -1;
	local->current = pg_evidence_subject(image);
	local->environment = NULL;
	return local->current ? 0 : -1;
}

const struct pg_evidence *pg_prove_application_body(struct pg_typing *typing,
	const struct pg_evidence *function, const struct pg_evidence *argument)
{
	struct pg_typed_query *work = pg_application_body_request(typing, function, argument);
	while (!pg_typed_query_advance(work, UINT64_MAX)) {}
	return pg_typed_query_result(work);
}

/* Select the retained formation before transporting its required parameters.
 * Rebuilding the whole Pi context would demand images for unused binders
 * already removed by constant-codomain projection. Each wrapper/selection or
 * lifted frame is one shared query transition, not a caller-owned traversal. */
static struct pg_typed_query *selection_request(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct scope_frame *outer)
{
	if (!source || !source->classifier) return NULL;
	const void *inputs[] = {source, outer};
	int created;
	struct pg_typed_query *work = pg_typed_query_request(typing, TYPED_SELECTION, 0, inputs, &created);
	if (created) {
		struct typed_selection_query *local = pg_typed_query_state(work);
		local->current = source;
	}
	return work;
}

/* Only link a query's private prefix. Published tails are immutable and can
 * be borrowed by another query without copying or scanning their frames. */
static void scope_append(struct scope_sequence *prefix, struct scope_sequence suffix)
{
	if (!suffix.first) return;
	if (prefix->last) prefix->last->next = suffix.first;
	else prefix->first = suffix.first;
	prefix->last = suffix.last;
}

/* Transport an open input's scope before its body. An explicit argument
 * closes the lifted binder; without one the input remains an open body. */
static int selection_lift_step(struct pg_typing *typing, struct typed_selection *state)
{
	const struct scope_frame *frame = state->cursor;
	const struct pg_evidence *map = NULL, *restricted = NULL;
	const struct pg_evidence *extended = state->extended;
	if (!frame && state->argument) {
		const struct pg_evidence *parent = pg_context_parent_input(typing, extended);
		map = pg_prove_substitution_projection(typing, parent, parent);
		map = pg_prove_substitution_pair(typing, map, extended, state->argument);
	} else if (frame) {
		const struct pg_context *destination = frame->map ? frame->map->destination : frame->restriction->context;
		if (frame->map) {
			if (!state->lift) {
				const struct pg_object *binder = !frame->next && state->binder ? state->binder
					: pg_evidence_context(extended)->binder;
				if (pg_context_lookup(destination, binder)) binder = pg_binder(typing->graph);
				state->lift = pg_substitution_lift_request(typing,
					pg_prove_context_map(typing, frame->map), extended, binder);
			}
			int status = pg_typed_query_advance(state->lift, 1);
			if (status <= 0) return status;
			map = pg_typed_query_result(state->lift);
			if (!map) return -1;
		} else {
			const struct pg_object *binder = !frame->next && state->binder ? state->binder
				: pg_evidence_context(extended)->binder;
			if (pg_context_lookup(destination, binder)) binder = pg_binder(typing->graph);
			const struct pg_evidence *step = pg_prove_structural_subject(typing, frame->restriction);
			const struct pg_evidence *context = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, destination);
			state->extended = pg_prove_context_extension(typing, context, binder, pg_prove_pi_domain(typing, step));
			if (!state->extended) return -1;
			restricted = pg_prove_pi_codomain(typing, pg_prove_projection(typing, state->extended, step),
				pg_prove_variable(typing, state->extended, binder));
		}
	}
	if (frame || state->argument) {
		if (map && state->body) {
			if (!state->action) state->action = pg_occurrence_action_request(typing,
				pg_evidence_context_map(map), pg_evidence_subject(state->body));
			switch (pg_occurrence_action_advance(state->action, 1)) {
			case PG_SUBSTITUTION_PENDING: return 0;
			case PG_SUBSTITUTION_ERROR: return -1;
			case PG_SUBSTITUTION_DONE: break;
			}
		}
		struct scope_frame *lifted = scope_frame(typing->graph, pg_evidence_context_map(map), restricted ? pg_evidence_subject(restricted) : NULL, NULL);
		if (!lifted) return -1;
		scope_append(&state->lifted, (struct scope_sequence){lifted, lifted});
		/* An open codomain is exactly the checked component described by
		 * the restriction. No independent strengthening of its body is needed. */
		if (state->body) {
			state->body = map ? pg_prove_reindex(typing, map, state->body) : restricted;
			if (!state->body) return -1;
		}
	}
	if (frame && map) state->extended = pg_evidence_premise(map, 1);
	state->lift = NULL;
	state->action = NULL;
	if (frame) { state->cursor = frame->next; return 0; }
	state->extended = NULL;
	state->frames = state->lifted;
	state->lifted = (struct scope_sequence){0};
	return 1;
}

static int typed_selection_step(struct pg_typed_query *work)
{
	struct typed_selection_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	if (!local->selection) {
		local->selection = pg_alloc(typing->graph, sizeof(*local->selection));
		if (!local->selection) return -1;
		local->selection->index = SIZE_MAX;
	}
	struct typed_selection *state = local->selection;
	const struct pg_occurrence *current = local->current;
	if (state->extended) {
		int status = selection_lift_step(typing, state);
		if (status <= 0) return status;
	}
	if (state->child) {
		local->current = state->child;
		state->child = NULL;
		scope_append(&state->frames, state->pending->frames);
		state->argument = state->pending->argument;
		state->index = state->pending->index;
		state->pending = state->pending->next;
		/* Do not chase the computation producing this selected type. */
		if (state->index != SIZE_MAX) return 0;
	} else if (current->map) {
		struct scope_frame *frame = scope_frame(typing->graph, current->map, NULL, state->frames.first);
		if (!frame) return -1;
		state->frames.first = frame;
		if (!state->frames.last) state->frames.last = frame;
		local->current = current->origin;
		return 0;
	} else if (current->selection) {
		struct selection_pending *next = pg_alloc(typing->graph, sizeof(*next));
		if (!next) return -1;
		*next = (struct selection_pending){state->argument, state->frames, state->index, state->pending};
		state->pending = next;
		state->frames = (struct scope_sequence){0};
		state->argument = current->operand_count ? pg_prove_structural_subject(typing, current->operands[0]) : NULL;
		if (current->operand_count && !state->argument) return -1;
		state->index = current->selection - 1;
		local->current = current->origin;
		return 0;
	} else if (current->origin && current->core == current->origin->core) {
		local->current = current->origin;
		return 0;
	} else if (state->index != SIZE_MAX) {
		const struct pg_occurrence *child;
		if (current->origin) {
			/* A changed head needs its checked current inputs. Following the
			 * old construction would silently select a pre-normalized child. */
			if (!work->dependency) work->dependency = pg_typed_input_request(typing,
				pg_prove_structural_subject(typing, current), state->index);
			if (!work->dependency) return -1;
			if (!work->dependency->status) return 0;
			const struct pg_evidence *input = pg_typed_query_result(work->dependency);
			if (!input) return -1;
			child = pg_evidence_subject(input);
			work->dependency = NULL;
		} else {
			if (state->index >= current->operand_count) return -1;
			child = current->operands[state->index];
		}
		if (child->context != current->context) {
			const struct pg_term *body;
			const struct pg_object *binder = pg_occurrence_input_binder(current->core, state->index, &body);
			if (!binder || !child->context || child->context->parent != current->context ||
				child->context->binder != binder || child->core != body) return -1;
			if (state->argument) {
				state->extended = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, child->context);
				if (!state->extended) return -1;
				state->cursor = state->frames.first;
			} else {
				const struct pg_evidence *constant = pg_prove_pi_constant_codomain(typing, pg_prove_structural_subject(typing, current));
				struct scope_frame *frame = scope_frame(typing->graph, NULL, pg_evidence_subject(constant), state->frames.first);
				if (!frame) return -1;
				state->frames.first = frame;
				if (!state->frames.last) state->frames.last = frame;
			}
		} else if (state->argument) return -1;
		state->child = child;
		return 0;
	}
	/* The supplied suffix is borrowed only after this query stops mutating
	 * its own prefix. No consumer may append to the published sequence. */
	if (state->frames.last) state->frames.last->next = work->inputs[1];
	else state->frames.first = work->inputs[1];
	work->result = pg_prove_structural_subject(typing, local->current);
	return work->result ? 1 : -1;
}

struct inductive_argument {
	const struct pg_evidence *value;
	const struct scope_frame *frames;
	struct inductive_argument *next;
};

struct pg_typed_query *pg_inductive_request(struct pg_typing *typing,
	const struct pg_evidence *type)
{
	if (!pg_evidence_owned_by(type, typing)) return NULL;
	if (pg_evidence_judgement(type) != PG_JUDGEMENT_VALUE_TYPE && pg_evidence_judgement(type) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	const void *inputs[] = {pg_evidence_subject(type), NULL};
	int created;
	struct pg_typed_query *work = pg_typed_query_request(typing, TYPED_INDUCTIVE, 0, inputs, &created);
	if (created) {
		struct typed_inductive_query *local = pg_typed_query_state(work);
		local->current = inputs[0];
	}
	return work;
}

/* The nominal owner fixes the formation context and classifier. Look up that
 * exact typed declaration, not any judgement sharing the erased Core. */
static const struct pg_evidence *nominal_formation(struct pg_typing *typing,
	const struct pg_occurrence *subject)
{
	if (subject->operand_count) return NULL;
	const struct pg_term *head = subject->core;
	while (head->kind == PG_APPLICATION) head = head->as.application.function;
	if (head->kind != PG_REFERENCE) return NULL;
	const struct pg_data_declaration *declaration = pg_data_declaration_view(head->as.reference);
	if (!declaration) return NULL;
	const struct pg_context *self = pg_data_declaration_parameters(declaration);
	if (!self || self->parent != subject->context) return NULL;
	enum pg_evidence_judgement judgement = self->judgement == PG_JUDGEMENT_TYPE_FAMILY
		? PG_JUDGEMENT_TYPE_FAMILY : PG_JUDGEMENT_VALUE_TYPE;
	const struct pg_occurrence *formed = pg_occurrence(typing, judgement, self->parent,
		subject->core, self->declared_type, NULL, 0, NULL);
	const struct pg_evidence *proof = pg_evidence_for_subject(typing, formed, NULL);
	return proof && pg_evidence_rule(proof) == PG_INDUCTIVE_FORM &&
		pg_data_schema_declaration(evidence_certificate(proof)) == declaration ? proof : NULL;
}

static int typed_inductive_step(struct pg_typed_query *work)
{
	struct typed_inductive_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	if (!local->inductive) local->inductive = pg_alloc(typing->graph, sizeof(*local->inductive));
	struct typed_inductive *state = local->inductive;
	if (!state) return -1;
	const struct pg_occurrence *subject = local->current;
	const struct pg_evidence *formation = local->value;
	if (formation) goto instantiate;
	formation = pg_prove_structural_subject(typing, subject);
	if (!formation) return -1;
	/* Scope traversal belongs to selection work even when there is no
	 * selected component. Nominal resolution only consumes its scoped head. */
	if (subject->map || subject->selection || (subject->origin && subject->core == subject->origin->core)) {
		if (!work->dependency) work->dependency = selection_request(typing, subject, state->frames);
		if (!work->dependency) return -1;
		if (!work->dependency->status) return 0;
		formation = pg_typed_query_result(work->dependency);
		if (!formation) return -1;
		const struct typed_selection_query *selected = pg_typed_query_state(work->dependency);
		state->frames = selected->selection->frames.first;
		work->dependency = NULL;
		goto advanced;
	}
	if (subject->origin) {
		formation = pg_prove_structural_subject(typing, subject->origin);
		if (subject->origin->judgement == PG_JUDGEMENT_COMPUTATION && subject->judgement != PG_JUDGEMENT_COMPUTATION) {
			if (!work->dependency) work->dependency = pg_return_body_request(typing, formation);
			if (work->dependency && !work->dependency->status) return 0;
			formation = pg_typed_query_result(work->dependency);
			work->dependency = NULL;
		}
		goto advanced;
	}
	const struct pg_term *core = subject->core;
	if (core->kind == PG_REFERENCE && core->as.reference->kind == PG_BINDER) {
		formation = variable_frame(typing, formation, &state->frames);
		goto advanced;
	}
	formation = nominal_formation(typing, subject);
	if (!formation) {
		if (core->kind != PG_APPLICATION || subject->operand_count != 2) return -1;
		const struct pg_term *head = core->as.application.function;
		const struct pg_evidence *left = pg_prove_structural_subject(typing, subject->operands[0]);
		if (!left) return -1;
		if (subject->operands[1]->core != core->as.application.argument) return -1;
		const struct pg_evidence *right = pg_prove_structural_subject(typing, subject->operands[1]);
		if (!right) return -1;
		if (subject->operands[0]->core != head) return -1;
		if (!work->dependency) work->dependency = pg_application_body_request(typing, left, right);
		if (work->dependency && !work->dependency->status) return 0;
		formation = pg_typed_query_result(work->dependency);
		work->dependency = NULL;
		if (!formation && pg_evidence_judgement(left) == PG_JUDGEMENT_TYPE_FAMILY) {
			struct inductive_argument *argument = pg_alloc(typing->graph, sizeof(*argument));
			if (!argument) return -1;
			*argument = (struct inductive_argument){right, state->frames, state->arguments};
			state->arguments = argument;
			formation = left;
		}
		goto advanced;
	}
	local->current = pg_evidence_subject(formation);
	/* The nominal declaration is fixed; remaining steps transport its Context. */
	local->value = formation;
instantiate:
	if (!local->environment) {
		const struct pg_evidence *context = pg_context_parent_input(typing, pg_evidence_premise(formation, 0));
		local->environment = pg_prove_substitution_projection(typing, context, context);
		return local->environment ? 0 : -1;
	}
	if (state->frames) {
		const struct scope_frame *frame = state->frames;
		if (frame->map) local->environment = pg_prove_substitution_compose(typing,
			local->environment, pg_prove_context_map(typing, frame->map));
		else {
			if (!work->dependency) work->dependency = pg_substitution_rebase_request(typing,
				conclusion_first(typing, PG_JUDGEMENT_CONTEXT, frame->restriction->context), local->environment);
			if (work->dependency && !work->dependency->status) return 0;
			local->environment = pg_typed_query_result(work->dependency);
			work->dependency = NULL;
		}
		state->frames = state->frames->next;
		return local->environment ? 0 : -1;
	}
	if (!state->instance) {
		if (pg_evidence_context(local->environment) != typed_source(work)->context) return -1;
		state->instance = pg_prove_reindex(typing, local->environment, formation);
		if (!state->instance) return -1;
		if (state->arguments) {
			if (pg_evidence_judgement(state->instance) != PG_JUDGEMENT_TYPE_FAMILY) return -1;
			state->prefix = pg_prove_substitution_pair(typing, local->environment, pg_evidence_premise(formation, 0), state->instance);
			if (!state->prefix) return -1;
			for (struct inductive_argument *a = state->arguments; a; a = a->next) ++state->count;
			if (state->count > SIZE_MAX / sizeof(*state->values)) return -1;
			state->values = pg_alloc(typing->graph, state->count * sizeof(*state->values));
			if (!state->values) return -1;
		}
	}
	if (state->arguments) {
		/* Index arguments cross precisely their own outer wrappers, not
		 * the parameter substitutions inside the callee. Retain each prefix. */
		struct inductive_argument *a = state->arguments;
		int status = scope_image_step(work, &a->value, &a->frames);
		if (status <= 0) return status;
		state->values[state->next++] = a->value;
		state->instance = pg_prove_family_application(typing, state->instance, a->value);
		if (!state->instance) return -1;
		state->arguments = a->next;
		return 0;
	}
	const struct pg_evidence *instance = state->instance, *indices = NULL;
	if (state->count) {
		const struct pg_data_signature *signature = pg_data_signature(typing, pg_evidence_premise(formation, 0),
			pg_data_schema_indices(evidence_certificate(formation)));
		indices = pg_data_signature_instance(typing, signature, state->prefix, state->count, state->values);
		if (!indices || pg_evidence_judgement(instance) != PG_JUDGEMENT_VALUE_TYPE) return -1;
	}
	if (!instance || pg_alpha_equal(pg_evidence_subject(instance)->core, typed_source(work)->core) != 1) return -1;
	state->result = (struct pg_inductive_instance){evidence_certificate(formation), formation, local->environment, indices};
	work->result = instance;
	return 1;
advanced:
	if (!formation) return -1;
	local->current = pg_evidence_subject(formation);
	return 0;
}

const struct pg_inductive_instance *pg_inductive_query_result(const struct pg_typed_query *work)
{
	if (!work || pg_typed_query_role(work) != TYPED_INDUCTIVE || work->status != 1) return NULL;
	struct typed_inductive_query *local = pg_typed_query_state(work);
	return &local->inductive->result;
}

int pg_inductive_instance(struct pg_typing *typing, const struct pg_evidence *type,
	struct pg_inductive_instance *output)
{
	if (!output) return 0;
	struct pg_typed_query *work = pg_inductive_request(typing, type);
	while (!pg_typed_query_advance(work, 1024)) {}
	const struct pg_inductive_instance *result = pg_inductive_query_result(work);
	if (result) *output = *result;
	return result != NULL;
}

static const struct pg_evidence *data_family(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(pg_evidence_premise(parameters, 0)) != pg_evidence_context(formation)) return NULL;
	return pg_prove_reindex(typing, parameters, formation);
}

static const struct pg_evidence *constructor_instance(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_object *constructor,
	const struct pg_evidence *parameters, const struct pg_evidence *instance,
	const struct pg_evidence *family)
{
	if (!family || !pg_evidence_owned_by(instance, typing) || pg_evidence_rule(instance) != PG_CONTEXT_SUBSTITUTION) return NULL;
	const struct pg_data_schema *schema = evidence_certificate(formation);
	const struct pg_evidence *fields = pg_data_schema_fields(schema, constructor);
	if (!fields) return NULL;
	const struct pg_context_map *map = pg_evidence_context_map(instance);
	const struct pg_context_map *parameter_map = pg_evidence_context_map(parameters);
	if (map->source != pg_evidence_context(fields) || map->destination != parameter_map->destination) return NULL;
	size_t prefix = parameter_map->count;
	if (map->count <= prefix) return NULL;
	/* A well-typed schema instance may still choose another Self or another
	 * parameter prefix. Check these equations before using its field evidence. */
	for (size_t i = 0; i < prefix; ++i)
		if (pg_alpha_equal(map->images[i]->core, parameter_map->images[i]->core) != 1) return NULL;
	if (pg_alpha_equal(map->images[prefix]->core, pg_evidence_subject(family)->core) != 1) return NULL;
	size_t count = map->count - prefix - 1;
	if (pg_evidence_judgement(formation) == PG_JUDGEMENT_TYPE_FAMILY) {
		const struct pg_evidence *result_map = pg_data_result(typing, schema, constructor, instance);
		if (!result_map) return NULL;
		for (size_t i = prefix + 1;
			i < pg_evidence_context_map(result_map)->count; ++i) {
			family = pg_prove_family_application(typing, family,
				pg_substitution_image_at(typing, result_map, i));
			if (!family) return NULL;
		}
		if (pg_evidence_judgement(family) != PG_JUDGEMENT_VALUE_TYPE) return NULL;
	}
	const struct pg_evidence *premises[] = {family, formation, parameters, instance};
	uint64_t hash;
	const struct pg_evidence *existing = find_record(typing, PG_CONSTRUCTOR_INTRO, pg_evidence_context(instance), NULL, 4, premises, constructor, &hash);
	if (existing) return existing;
	/* The checked instance already retains the exact field suffix. */
	const struct pg_occurrence *const *operands = map->images + map->count - count;
	const struct pg_term *core = pg_reference(typing->graph, constructor);
	for (size_t i = 0; i < count; ++i)
		core = pg_application(typing->graph, core, operands[i]->core);
	if (!core) return NULL;
	const struct pg_context_map *maps[] = {parameter_map, map};
	const struct pg_occurrence *subject = pg_occurrence_intern(typing, &(struct pg_occurrence){
		.judgement = PG_JUDGEMENT_VALUE, .context = pg_evidence_context(instance),
		.core = core, .classifier = pg_evidence_subject(family)->core, .type = pg_evidence_subject(family),
		.operand_count = count, .map_count = 2}, operands, maps);
	if (!subject) return NULL;
	return accept_record(typing, PG_CONSTRUCTOR_INTRO,
		pg_evidence_context(instance), subject, 4, premises, constructor, NULL);
}

const struct pg_evidence *pg_prove_constructor_instance(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_object *constructor,
	const struct pg_evidence *parameters, const struct pg_evidence *instance)
{
	return constructor_instance(typing, formation, constructor, parameters, instance,
		data_family(typing, formation, parameters));
}

const struct pg_evidence *pg_prove_constructor(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_object *constructor,
	const struct pg_evidence *parameters, size_t count,
	const struct pg_evidence *const *fields)
{
	const struct pg_evidence *family = data_family(typing, formation, parameters);
	if (!family) return NULL;
	const struct pg_evidence *self = pg_evidence_judgement(formation) == PG_JUDGEMENT_TYPE_FAMILY
		? family : pg_prove_type_value(typing, family);
	const struct pg_evidence *extended = pg_prove_substitution_extend(typing, parameters,
		pg_evidence_premise(formation, 0), 1, &self);
	const struct pg_evidence *instance = pg_data_instance(typing, evidence_certificate(formation), constructor, extended, count, fields);
	return constructor_instance(typing, formation, constructor, parameters, instance, family);
}

static const struct pg_evidence *lift_scope(struct pg_typing *typing,
	const struct pg_evidence *map, const struct pg_evidence *fields,
	const struct pg_context *allocation, int retained)
{
	if (!pg_evidence_owned_by(map, typing) || pg_evidence_rule(map) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (!context_proof(typing, fields)) return NULL;
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(fields), pg_evidence_context(pg_evidence_premise(map, 0)), &count)) return NULL;
	if (retained) {
		const struct pg_context *saved_prefix = allocation;
		for (size_t i = 0; i < count; ++i) {
			if (!saved_prefix) return NULL;
			saved_prefix = saved_prefix->parent;
		}
		if (!pg_context_same_allocation_shape(saved_prefix, pg_evidence_context(pg_evidence_premise(map, 1)))) return NULL;
	}
	if (count > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	const struct pg_evidence **extensions = pg_alloc(&temporary, count * sizeof(*extensions));
	const struct pg_object **binders = retained ? pg_alloc(&temporary, count * sizeof(*binders)) : NULL;
	if (count && (!extensions || (retained && !binders))) goto done;
	for (size_t i = count; i; --i, fields = pg_context_parent_input(typing, fields)) {
		extensions[i - 1] = fields;
		if (retained) { binders[i - 1] = allocation->binder; allocation = allocation->parent; }
	}
	for (size_t i = 0; i < count; ++i) {
		map = pg_prove_substitution_lift(typing, map, extensions[i],
			retained ? binders[i] : pg_binder(typing->graph));
		if (!map) goto done;
	}
	result = map;
done:
	pg_graph_destroy(&temporary);
	return result;
}

static const struct pg_evidence *prove_data_scope(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *fields, const struct pg_evidence *parameters,
	const struct pg_context *allocation, int retained)
{
	const struct pg_evidence *family = data_family(typing, formation, parameters);
	if (!family) return NULL;
	const struct pg_evidence *self = pg_evidence_judgement(formation) == PG_JUDGEMENT_TYPE_FAMILY
		? family : pg_prove_type_value(typing, family);
	if (!self) return NULL;
	const struct pg_evidence *map = pg_prove_substitution_extend(typing, parameters, pg_evidence_premise(formation, 0), 1, &self);
	return lift_scope(typing, map, fields, allocation, retained);
}

const struct pg_evidence *pg_prove_constructor_scope(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	return prove_data_scope(typing, formation,
		pg_data_schema_fields(evidence_certificate(formation), constructor), parameters, NULL, 0);
}

const struct pg_evidence *pg_prove_constructor_scope_at(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters,
	const struct pg_context *allocation)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	return prove_data_scope(typing, formation,
		pg_data_schema_fields(evidence_certificate(formation), constructor), parameters, allocation, 1);
}

static const struct pg_evidence *family_in_scope(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_evidence *map)
{
	if (!map) return NULL;
	const struct pg_evidence *family = pg_substitution_image(typing, map, pg_evidence_context(pg_evidence_premise(formation, 0))->binder);
	for (size_t i = pg_evidence_context_map(parameters)->count + 1;
		i < pg_evidence_context_map(map)->count; ++i) {
		family = pg_prove_family_application(typing, family,
			pg_substitution_image_at(typing, map, i));
		if (!family) return NULL;
	}
	return pg_prove_value_type(typing, family);
}

static const struct pg_evidence *inductive_motive_context(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_object *binder, const struct pg_context *indices, int retained)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	const struct pg_evidence *map = prove_data_scope(typing, formation,
		pg_data_schema_indices(evidence_certificate(formation)), parameters, indices, retained);
	if (!map) return NULL;
	return pg_prove_context_extension(typing, pg_evidence_premise(map, 1), binder,
		family_in_scope(typing, formation, parameters, map));
}

const struct pg_evidence *pg_prove_inductive_motive_context(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_object *binder)
{
	return inductive_motive_context(typing, formation, parameters, binder, NULL, 0);
}

const struct pg_evidence *pg_prove_inductive_motive_context_at(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_context *allocation)
{
	return allocation ? inductive_motive_context(typing, formation, parameters,
		allocation->binder, allocation->parent, 1) : NULL;
}

const struct pg_evidence *pg_prove_inductive_family_function(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	if (pg_evidence_judgement(formation) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	const struct pg_evidence *map = prove_data_scope(typing, formation,
		pg_data_schema_indices(evidence_certificate(formation)), parameters, NULL, 0);
	if (!map) return NULL;
	const struct pg_evidence *body = pg_prove_return_contract(typing, PG_TOTALITY_TOTAL,
		pg_prove_type_value(typing, family_in_scope(typing, formation, parameters, map)));
	return pg_prove_abstract(typing, pg_evidence_premise(parameters, 1), pg_evidence_premise(map, 1), body);
}

static const struct pg_evidence *constructor_in_scope(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_object *constructor,
	const struct pg_evidence *parameters, const struct pg_evidence *map)
{
	size_t prefix = pg_evidence_context_map(parameters)->count;
	size_t total = pg_evidence_context_map(map)->count;
	if (total <= prefix) return NULL;
	const struct pg_evidence *arguments = pg_prove_substitution_compose(typing,
		pg_prove_substitution_projection(typing, pg_evidence_premise(parameters, 0), pg_evidence_premise(map, 0)), map);
	return pg_prove_constructor_instance(typing, formation, constructor, arguments, map);
}

const struct pg_evidence *pg_prove_constructor_function(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters)
{
	const struct pg_evidence *map = pg_prove_constructor_scope(typing, formation, constructor, parameters);
	if (!map) return NULL;
	const struct pg_evidence *body = constructor_in_scope(typing, formation, constructor, parameters, map);
	body = pg_prove_return_contract(typing, PG_TOTALITY_TOTAL, body);
	if (!body) return NULL;
	return pg_prove_abstract(typing, pg_evidence_premise(parameters, 1), pg_evidence_premise(map, 1), body);
}

/* Check Gamma, indices, z : Family(parameters, indices), not a fixed fiber.
 * The ordinary family application rule checks each dependent index domain. */
int pg_inductive_motive_context_valid(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_evidence *motive_context)
{
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return 0;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return 0;
	if (pg_evidence_context(pg_evidence_premise(parameters, 0)) != pg_evidence_context(formation)) return 0;
	if (!context_proof(typing, motive_context) || pg_evidence_rule(motive_context) != PG_CONTEXT_EXTEND) return 0;
	const struct pg_data_schema *schema = evidence_certificate(formation);
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(pg_data_schema_indices(schema)),
		pg_evidence_context(pg_evidence_premise(formation, 0)), &count)) return 0;
	const struct pg_evidence *indices = pg_context_parent_input(typing, motive_context), *prefix = indices;
	struct pg_graph temporary = {0};
	int valid = 0;
	if (count > SIZE_MAX / sizeof(const struct pg_object *)) return 0;
	const struct pg_object **binders = pg_alloc(&temporary, count * sizeof(*binders));
	if (count && !binders) goto done;
	for (size_t i = count; i; --i, prefix = pg_context_parent_input(typing, prefix)) {
		if (pg_evidence_rule(prefix) != PG_CONTEXT_EXTEND) goto done;
		binders[i - 1] = pg_evidence_context(prefix)->binder;
	}
	if (pg_evidence_context(prefix) != pg_evidence_context(parameters)) goto done;
	const struct pg_evidence *family = pg_prove_projection(typing, indices,
		pg_prove_reindex(typing, parameters, formation));
	for (size_t i = 0; family && i < count; ++i)
		family = pg_prove_family_application(typing, family, pg_prove_variable(typing, indices, binders[i]));
	valid = family && pg_alpha_equal(pg_evidence_subject(family)->core, pg_evidence_context(motive_context)->declared_type) == 1;
done:
	pg_graph_destroy(&temporary);
	return valid;
}

/* Pull back along (Gamma projection, actual indices, value). Constructor
 * membership retains its result map; variables retain their fiber formation.
 * This is checked substitution, not a search for an expected result type. */
const struct pg_evidence *pg_prove_inductive_motive_substitution(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *source,
	const struct pg_evidence *destination, const struct pg_evidence *value)
{
	if (!pg_inductive_motive_context_valid(typing, formation, parameters, source)) return NULL;
	const struct pg_evidence *prefix = pg_prove_substitution_projection(typing, pg_evidence_premise(parameters, 1), destination);
	if (pg_evidence_judgement(formation) == PG_JUDGEMENT_TYPE_FAMILY) {
		const struct pg_evidence *type = pg_prove_classifier(typing, destination, value);
		struct pg_inductive_instance instance;
		if (!pg_inductive_instance(typing, type, &instance)) return NULL;
		if (instance.formation != formation || !instance.indices) return NULL;
		size_t offset = pg_evidence_context_map(instance.parameters)->count + 1;
		size_t total = pg_evidence_context_map(instance.indices)->count;
		if (total < offset) return NULL;
		size_t count = total - offset;
		struct pg_graph temporary = {0};
		const struct pg_evidence *const *images = pg_substitution_images(typing, instance.indices, &temporary);
		prefix = images ? pg_prove_substitution_extend(typing, prefix, pg_context_parent_input(typing, source),
			count, images + offset) : NULL;
		pg_graph_destroy(&temporary);
	}
	return pg_prove_substitution_pair(typing, prefix, source, value);
}

struct refinement_binding {
	struct pg_index_entry index;
	const struct pg_object *binder;
	const struct pg_evidence *image;
	int seen;
};

static struct refinement_binding *refinement_find(const struct pg_index *index,
	const struct pg_object *binder)
{
	for (struct pg_index_entry *entry = pg_index_candidates(index, (uintptr_t)binder); entry; entry = entry->next) {
		struct refinement_binding *binding = (struct refinement_binding *)entry;
		if (binding->binder == binder) return binding;
	}
	return NULL;
}

const struct pg_evidence *pg_prove_constructor_refinement(struct pg_typing *typing,
	const struct pg_evidence *context,
	const struct pg_evidence *scrutinee, const struct pg_object *constructor)
{
	if (!context_proof(typing, context) || !pg_evidence_owned_by(scrutinee, typing)) return NULL;
	if (pg_evidence_judgement(scrutinee) != PG_JUDGEMENT_VALUE || pg_evidence_context(scrutinee) != pg_evidence_context(context)) return NULL;
	struct pg_inductive_instance instance;
	if (!pg_inductive_instance(typing, pg_prove_classifier(typing, context, scrutinee), &instance)) return NULL;
	size_t first = pg_evidence_context_map(instance.parameters)->count + 1;
	size_t indices = instance.indices ? pg_evidence_context_map(instance.indices)->count - first : 0;
	if (indices >= SIZE_MAX / sizeof(struct refinement_binding)) return NULL;
	struct pg_graph temporary = {0};
	struct pg_index replacements;
	if (pg_index_init(&replacements)) return NULL;
	const struct pg_evidence *result = NULL;
	struct refinement_binding *bindings = pg_alloc(&temporary, (indices + 1) * sizeof(*bindings));
	if (!bindings) goto done;
	for (size_t i = 0; i <= indices; ++i) {
		const struct pg_term *term = i == indices ? pg_evidence_subject(scrutinee)->core
			: pg_evidence_context_map(instance.indices)->images[first + i]->core;
		if (term->kind != PG_REFERENCE || term->as.reference->kind != PG_BINDER) goto done;
		const struct pg_object *binder = term->as.reference;
		if (refinement_find(&replacements, binder)) goto done;
		bindings[i].binder = binder;
		if (pg_index_insert(&replacements, &bindings[i].index, (uintptr_t)binder)) goto done;
	}
	const struct pg_evidence *prefix = context;
	size_t remaining = indices + 1, count = 0;
	while (remaining) {
		if (!pg_evidence_context(prefix) || count == SIZE_MAX) goto done;
		struct refinement_binding *binding = refinement_find(&replacements, pg_evidence_context(prefix)->binder);
		if (binding && !binding->seen) { binding->seen = 1; --remaining; }
		++count;
		prefix = pg_context_parent_input(typing, prefix);
	}
	if (count > SIZE_MAX / sizeof(const struct pg_evidence *)) goto done;
	const struct pg_evidence **extensions = pg_alloc(&temporary, count * sizeof(*extensions));
	if (!extensions) goto done;
	const struct pg_evidence *extension = context;
	for (size_t i = count; i; --i, extension = pg_context_parent_input(typing, extension)) extensions[i - 1] = extension;
	const struct pg_evidence *parameters = pg_prove_substitution_rebase(typing, prefix, instance.parameters);
	const struct pg_evidence *fields = pg_prove_constructor_scope(typing, instance.formation, constructor, parameters);
	if (!fields) goto done;
	const struct pg_evidence *value = constructor_in_scope(typing, instance.formation, constructor, parameters, fields);
	const struct pg_evidence *fiber = pg_data_result(typing, instance.schema, constructor, fields);
	if (!value || !fiber || pg_evidence_context_map(fiber)->count != first + indices) goto done;
	for (size_t i = 0; i < indices; ++i)
		bindings[i].image = pg_substitution_image_at(typing, fiber, first + i);
	bindings[indices].image = value;
	const struct pg_evidence *map = pg_prove_substitution_projection(typing, prefix, pg_evidence_premise(fields, 1));
	for (size_t i = 0; map && i < count; ++i) {
		extension = extensions[i];
		struct refinement_binding *binding = refinement_find(&replacements, pg_evidence_context(extension)->binder);
		if (binding) map = pg_prove_substitution_pair(typing, map, extension,
			pg_prove_projection(typing, pg_evidence_premise(map, 1), binding->image));
		else map = pg_prove_substitution_lift(typing, map, extension, pg_binder(typing->graph));
	}
	result = map;
done:
	pg_index_destroy(&replacements);
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_inductive_motive_at(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters,
	const struct pg_evidence *source, const struct pg_evidence *motive,
	const struct pg_evidence *destination, const struct pg_evidence *value)
{
	if (!context_proof(typing, source)) return NULL;
	if (!pg_evidence_owned_by(motive, typing) || pg_evidence_judgement(motive) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(motive) != pg_evidence_context(source)) return NULL;
	const struct pg_evidence *map = pg_prove_inductive_motive_substitution(typing,
		formation, parameters, source, destination, value);
	return pg_prove_reindex(typing, map, motive);
}

static int unspecified_computation_result(const struct pg_term *type)
{
	const struct pg_term *domain, *body;
	const struct pg_object *binder;
	while (pg_pi_view(type, &domain, &binder, &body)) type = body;
	enum pg_totality totality;
	const struct pg_effect_row *effects;
	return pg_computation_type_view(type, &totality, &effects, &body) && totality == PG_TOTALITY_UNSPECIFIED;
}

const struct pg_evidence *pg_prove_inductive_hypothesis_type(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *motive_context,
	const struct pg_evidence *motive, const struct pg_evidence *context,
	const struct pg_evidence *field, const struct pg_term *allocation)
{
	if (!pg_evidence_owned_by(field, typing) || pg_evidence_judgement(field) != PG_JUDGEMENT_VALUE) return NULL;
	if (!context_proof(typing, context) || pg_evidence_context(field) != pg_evidence_context(context)) return NULL;
	const struct pg_term *type;
	if (!pg_thunk_type_view(pg_evidence_subject(field)->classifier, &type)) {
		const struct pg_evidence *at = pg_prove_inductive_motive_at(typing,
			formation, parameters, motive_context, motive, context, field);
		return pg_prove_thunk_type(typing, at);
	}
	if (allocation && !pg_thunk_type_view(allocation, &allocation)) return NULL;
	struct pg_call_telescope telescope;
	if (pg_prove_call_telescope(typing, context, pg_prove_force(typing, field), allocation, &telescope)) return NULL;
	const struct pg_evidence *scope = telescope.context, *call = telescope.call, *classifier = telescope.classifier;
	enum pg_totality field_totality;
	const struct pg_effect_row *effects;
	if (!classifier || !pg_computation_type_view(pg_evidence_subject(classifier)->core, &field_totality, &effects, &type)) return NULL;
	if (pg_effect_count(effects)) return NULL;
	const struct pg_evidence *at;
	if (field_totality == PG_TOTALITY_TOTAL) {
		const struct pg_evidence *result = pg_prove_total_pure_value(typing, call);
		at = pg_prove_inductive_motive_at(typing,
			formation, parameters, motive_context, motive, scope, result);
		goto abstract;
	}
	const struct pg_evidence *returned_type = pg_prove_return_content(typing, classifier);
	const struct pg_object *binder = pg_binder(typing->graph);
	const struct pg_evidence *returned = pg_prove_context_extension(typing, scope, binder, returned_type);
	at = pg_prove_inductive_motive_at(typing,
		formation, parameters, motive_context, motive, returned, pg_prove_variable(typing, returned, binder));
	if (!at) return NULL;
	/* Calling a recursive function field precedes recursion on its result.
	 * The IH cannot promise termination that this field does not provide. */
	enum pg_totality motive_totality;
	if (pg_computation_type_view(pg_evidence_subject(at)->core, &motive_totality, &effects, &type)) {
		at = pg_prove_computation_type(typing, field_totality, effects,
			pg_prove_return_content(typing, at));
	} else if (!unspecified_computation_result(pg_evidence_subject(at)->core)) return NULL;
	/* Fold the returned recursive value once. Its result classifier must not
	 * escape with that value's binder; indices may depend on the Pi arguments. */
	at = pg_prove_pi_constant_codomain(typing,
		pg_prove_pi(typing, returned, at));
abstract:
	while (at && pg_evidence_context(scope) != pg_evidence_context(context)) {
		at = pg_prove_pi(typing, scope, at);
		scope = pg_context_parent_input(typing, scope);
	}
	return pg_prove_thunk_type(typing, at);
}

static const struct pg_evidence *prove_induction_scope(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	const struct pg_context *allocation, int retained)
{
	if (!context_proof(typing, motive_context) || pg_evidence_rule(motive_context) != PG_CONTEXT_EXTEND) return NULL;
	if (!pg_evidence_owned_by(motive, typing) || pg_evidence_judgement(motive) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(motive) != pg_evidence_context(motive_context)) return NULL;
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (!pg_inductive_motive_context_valid(typing, formation, parameters, motive_context)) return NULL;
	const struct pg_evidence *fields = pg_data_schema_fields(evidence_certificate(formation), constructor);
	if (!fields) return NULL;
	const struct pg_object *self = pg_evidence_context(pg_evidence_premise(formation, 0))->binder;
	size_t prefix = pg_evidence_context_map(parameters)->count;
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(fields), pg_evidence_context(pg_evidence_premise(formation, 0)), &count)) return NULL;
	if (count > SIZE_MAX / sizeof(const struct pg_term *)) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	unsigned char *recursive_fields = pg_alloc(&temporary, count);
	if (count && !recursive_fields) goto done;
	size_t recursive_count = 0;
	for (size_t i = count; i; --i, fields = pg_context_parent_input(typing, fields)) {
		int recursive = pg_data_recursive_field(pg_evidence_context(fields)->declared_type, self);
		if (recursive < 0) goto done;
		recursive_fields[i - 1] = (unsigned char)recursive;
		recursive_count += (size_t)recursive;
	}
	const struct pg_context **ih_allocations = NULL;
	if (retained) {
		if (recursive_count > SIZE_MAX - count) goto done;
		const struct pg_context *saved_prefix = allocation;
		for (size_t i = 0; i < count + recursive_count; ++i) {
			if (!saved_prefix) goto done;
			saved_prefix = saved_prefix->parent;
		}
		if (!pg_context_same_allocation_shape(saved_prefix,
			pg_evidence_context(pg_evidence_premise(parameters, 1)))) goto done;
		ih_allocations = pg_alloc(&temporary, recursive_count * sizeof(*ih_allocations));
		if (recursive_count && !ih_allocations) goto done;
		for (size_t i = recursive_count; i; --i, allocation = allocation->parent)
			ih_allocations[i - 1] = allocation;
	}
	const struct pg_evidence *map = retained
		? pg_prove_constructor_scope_at(typing, formation, constructor, parameters, allocation)
		: pg_prove_constructor_scope(typing, formation, constructor, parameters);
	if (!map) goto done;
	const struct pg_evidence *context = pg_evidence_premise(map, 1);
	size_t next_ih = 0;
	for (size_t i = 0; i < count; ++i) {
		if (!recursive_fields[i]) continue;
		const struct pg_evidence *field = pg_prove_projection(typing, context,
			pg_substitution_image_at(typing, map, prefix + 1 + i));
		const struct pg_context *ih_allocation = retained ? ih_allocations[next_ih++] : NULL;
		const struct pg_evidence *ih = pg_prove_inductive_hypothesis_type(typing, formation, parameters,
			motive_context, motive, context, field, ih_allocation ? ih_allocation->declared_type : NULL);
		const struct pg_object *binder = ih_allocation ? ih_allocation->binder : pg_binder(typing->graph);
		context = pg_prove_context_extension(typing, context, binder, ih);
		if (!context) goto done;
	}
	result = pg_prove_substitution_extension(typing, pg_evidence_premise(map, 0), context, map, 0, (struct pg_evidence_inputs){.owner = NULL});
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_induction_scope(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive)
{
	return prove_induction_scope(typing, formation, constructor, parameters,
		motive_context, motive, NULL, 0);
}

const struct pg_evidence *pg_prove_induction_scope_at(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	const struct pg_context *allocation)
{
	return prove_induction_scope(typing, formation, constructor, parameters,
		motive_context, motive, allocation, 1);
}

static const struct pg_term *induction_field_core(struct pg_graph *graph,
	const struct pg_term *type, const struct pg_term *ih_type,
	const struct pg_term *field, const struct pg_object *recursion)
{
	const struct pg_term *call = pg_reference(graph, recursion);
	if (!pg_thunk_type_view(type, &type))
		return pg_application(graph, pg_reference(graph, &pg_thunk_operation),
			pg_application(graph, call, field));
	if (!pg_thunk_type_view(ih_type, &ih_type)) return NULL;
	struct argument { const struct pg_object *binder; struct argument *previous; };
	struct pg_graph temporary = {0};
	struct argument *arguments = NULL;
	const struct pg_term *body = pg_application(graph, pg_reference(graph, &pg_force_operation), field);
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	while (pg_pi_view(type, &domain, &binder, &codomain)) {
		type = codomain;
		if (!pg_pi_view(ih_type, &domain, &binder, &ih_type)) { body = NULL; goto done; }
		struct argument *argument = pg_alloc(&temporary, sizeof(*argument));
		if (!argument) { body = NULL; goto done; }
		*argument = (struct argument){binder, arguments};
		arguments = argument;
		body = pg_application(graph, body, pg_reference(graph, binder));
	}
	body = pg_computation_fold(graph, body, call, 0, NULL);
	for (; body && arguments; arguments = arguments->previous)
		body = pg_lambda(graph, arguments->binder, body);
	body = pg_application(graph, pg_reference(graph, &pg_thunk_operation), body);
done:
	pg_graph_destroy(&temporary);
	return body;
}

static const struct pg_term *induction_branch_core(struct pg_typing *typing,
	const struct pg_evidence *formation, const struct pg_evidence *parameters,
	const struct pg_evidence *map, const struct pg_evidence *branch,
	const struct pg_object *recursion)
{
	size_t offset = pg_evidence_context_map(parameters)->count + 1;
	size_t count = pg_evidence_context_map(map)->count - offset;
	struct pg_graph temporary = {0};
	const struct pg_term **types = pg_alloc(&temporary, count * sizeof(*types));
	const struct pg_term **ih_types = pg_alloc(&temporary, count * sizeof(*ih_types));
	const struct pg_term *result = NULL;
	if (count && (!types || !ih_types)) goto done;
	const struct pg_evidence *fields = pg_evidence_premise(map, 0);
	for (size_t i = count; i; --i, fields = pg_context_parent_input(typing, fields))
		types[i - 1] = pg_evidence_context(fields)->declared_type;
	const struct pg_object *self = pg_evidence_context(pg_evidence_premise(formation, 0))->binder;
	const struct pg_context *ih_context = pg_evidence_context(pg_evidence_premise(map, 1));
	for (size_t i = count; i; --i) {
		int recursive = pg_data_recursive_field(types[i - 1], self);
		if (recursive < 0) goto done;
		if (!recursive) continue;
		if (!ih_context->parent) goto done;
		ih_types[i - 1] = ih_context->declared_type;
		ih_context = ih_context->parent;
	}
	const struct pg_term *body = pg_evidence_subject(branch)->core;
	for (size_t i = 0; i < count; ++i)
		body = pg_application(typing->graph, body, pg_evidence_context_map(map)->images[offset + i]->core);
	for (size_t i = 0; i < count; ++i) {
		if (!ih_types[i]) continue;
		const struct pg_term *call = induction_field_core(typing->graph, types[i], ih_types[i],
			pg_evidence_context_map(map)->images[offset + i]->core, recursion);
		if (!call) goto done;
		body = pg_application(typing->graph, body, call);
	}
	for (size_t i = count; i; --i) {
		const struct pg_term *field = pg_evidence_context_map(map)->images[offset + i - 1]->core;
		if (field->kind != PG_REFERENCE || field->as.reference->kind != PG_BINDER) goto done;
		body = pg_lambda(typing->graph, field->as.reference, body);
	}
	result = body;
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_match_branch_type(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_object *constructor, const struct pg_evidence *parameters,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	const struct pg_evidence *fields)
{
	if (!typing) return NULL;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (!pg_evidence_owned_by(fields, typing) || pg_evidence_rule(fields) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context_map(fields)->count <= pg_evidence_context_map(parameters)->count) return NULL;
	const struct pg_evidence *context = pg_evidence_premise(fields, 1);
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(context), pg_evidence_context(parameters), &count)) return NULL;
	const struct pg_evidence *value = constructor_in_scope(typing, formation, constructor, parameters, fields);
	const struct pg_evidence *expected = pg_prove_inductive_motive_at(typing,
		formation, parameters, motive_context, motive, context, value);
	for (size_t i = 0; expected && i < count; ++i, context = pg_context_parent_input(typing, context))
		expected = pg_prove_pi(typing, context, expected);
	return expected;
}

struct induction_request {
	struct pg_index_entry index;
	const struct pg_evidence *result;
};

/* Omitting lexical allocation is a construction request, not an equivalence
 * of all conclusions with the same premises. Explicit allocations must still
 * be checked independently and retain their exact Core/typed structure. */
static struct induction_request *induction_request(struct pg_typing *typing,
	size_t count, struct pg_evidence_inputs inputs)
{
	if (!typing->induction_requests.capacity && pg_index_init(&typing->induction_requests)) return NULL;
	uint64_t hash = count;
	for (size_t i = 0; i < count; ++i) hash = (hash ^ (uintptr_t)pg_evidence_input(inputs, i)) * UINT64_C(1099511628211);
	for (struct pg_index_entry *p = pg_index_candidates(&typing->induction_requests, hash); p; p = p->next) {
		if (p->hash != hash) continue;
		struct induction_request *request = (void *)p;
		const struct pg_evidence *result = request->result;
		if (pg_evidence_premise_count(result) != count) continue;
		size_t i = 0;
		while (i < count && pg_evidence_premise(result, i) == pg_evidence_input(inputs, i)) ++i;
		if (i == count) return request;
	}
	struct induction_request *request = pg_alloc(typing->graph, sizeof(*request));
	if (request) request->index.hash = hash;
	return request;
}

static const struct pg_evidence *prove_data_elimination(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *scrutinee,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	size_t count, struct pg_evidence_inputs branches, enum pg_evidence_rule rule,
	const struct pg_induction_allocation *allocation)
{
	if (allocation) {
		if (rule != PG_INDUCTION_ELIM || allocation->count != count || (count && !allocation->clauses)) return NULL;
		if (!allocation->recursion || allocation->recursion->kind != PG_BINDER) return NULL;
		if (!allocation->argument || allocation->argument->kind != PG_BINDER) return NULL;
		if (!allocation->self || allocation->self->kind != PG_BINDER) return NULL;
		if (allocation->recursion == allocation->argument || allocation->recursion == allocation->self ||
			allocation->argument == allocation->self) return NULL;
	}
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(pg_evidence_premise(parameters, 0)) != pg_evidence_context(formation)) return NULL;
	const struct pg_evidence *destination = pg_evidence_premise(parameters, 1);
	if (allocation) {
		const struct pg_object *binders[] = {allocation->recursion, allocation->argument, allocation->self};
		for (size_t i = 0; i < 3; ++i) {
			if (pg_context_lookup(pg_evidence_context(destination), binders[i])) return NULL;
			for (size_t j = 0; j < count; ++j)
				if (pg_context_lookup(allocation->clauses[j], binders[i])) return NULL;
		}
	}
	if (!pg_evidence_owned_by(scrutinee, typing) || pg_evidence_judgement(scrutinee) != PG_JUDGEMENT_VALUE) return NULL;
	if (pg_evidence_context(scrutinee) != pg_evidence_context(destination)) return NULL;
	if (!context_proof(typing, motive_context) || pg_evidence_rule(motive_context) != PG_CONTEXT_EXTEND) return NULL;
	if (!pg_inductive_motive_context_valid(typing, formation, parameters, motive_context)) return NULL;
	if (!pg_evidence_owned_by(motive, typing) || pg_evidence_judgement(motive) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(motive) != pg_evidence_context(motive_context)) return NULL;
	const struct pg_data_schema *schema = evidence_certificate(formation);
	if (count != pg_data_constructor_count(schema)) return NULL;
	if (count > SIZE_MAX / sizeof(void *) - 6) return NULL;
	if (count > SIZE_MAX / sizeof(struct pg_match_clause)) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	/* Lookup precedes fresh field contexts. Reusing a rule never rebuilds them. */
	const struct pg_evidence *prefix[] = {motive, formation, parameters, scrutinee, motive_context};
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *branch = pg_evidence_input(branches, i);
		if (!pg_evidence_owned_by(branch, typing)) goto done;
		if (pg_evidence_judgement(branch) != PG_JUDGEMENT_COMPUTATION) goto done;
		if (pg_evidence_context(branch) != pg_evidence_context(destination)) goto done;
	}
	const struct pg_evidence *output = pg_prove_inductive_motive_at(typing, formation, parameters,
		motive_context, motive, destination, scrutinee);
	if (!output) goto done;
	const struct receipt_segments segments = {5, count, prefix, &output, branches};
	const struct pg_evidence_inputs inputs = {.owner = &segments, .at = segmented_receipt};
	struct induction_request *request = NULL;
	if (rule == PG_INDUCTION_ELIM) {
		if (!allocation) {
			request = induction_request(typing, count + 6, inputs);
			if (!request) goto done;
			result = request->result;
		} else {
			uint64_t hash;
			struct pg_occurrence selector = {.induction = allocation};
			result = find_record_inputs(typing, rule, pg_evidence_context(destination),
				&selector, count + 6, inputs, NULL, &hash);
		}
	} else {
		uint64_t hash;
		result = find_record_inputs(typing, rule,
			pg_evidence_context(destination), NULL, count + 6, inputs, NULL, &hash);
	}
	if (result) goto done;
	const struct pg_data_layout *layout = pg_data_schema_layout(schema);
	struct pg_match_clause *clauses = pg_alloc(&temporary, count * sizeof(*clauses));
	const struct pg_occurrence **operands = pg_alloc(&temporary, (count + 3) * sizeof(*operands));
	if ((count && !clauses) || !operands) goto done;
	operands[0] = pg_evidence_subject(scrutinee);
	operands[count + 1] = pg_evidence_subject(motive);
	operands[count + 2] = pg_evidence_subject(formation);
	struct pg_induction_allocation *saved = NULL;
	const struct pg_context **contexts = NULL;
	if (rule == PG_INDUCTION_ELIM) {
		saved = pg_alloc(&temporary, sizeof(*saved));
		contexts = pg_alloc(&temporary, count * sizeof(*contexts));
		if (!saved || (count && !contexts)) goto done;
		*saved = (struct pg_induction_allocation){
			.recursion = allocation ? allocation->recursion : pg_binder(typing->graph),
			.argument = allocation ? allocation->argument : pg_binder(typing->graph),
			.self = allocation ? allocation->self : pg_binder(typing->graph),
			.count = count, .clauses = contexts};
		if (!saved->recursion || !saved->argument || !saved->self) goto done;
	}
	const struct pg_object *recursion = saved ? saved->recursion : NULL;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *branch = pg_evidence_input(branches, i);
		const struct pg_object *constructor = pg_data_constructor(layout, i);
		const struct pg_evidence *map = allocation
			? pg_prove_induction_scope_at(typing, formation, constructor, parameters,
				motive_context, motive, allocation->clauses[i])
			: rule == PG_INDUCTION_ELIM
			? pg_prove_induction_scope(typing,
		formation, constructor, parameters, motive_context, motive)
			: pg_prove_constructor_scope(typing, formation, constructor, parameters);
		if (!map) goto done;
		const struct pg_evidence *context = pg_evidence_premise(map, 1);
		if (contexts) contexts[i] = allocation ? allocation->clauses[i] : pg_evidence_context(context);
		const struct pg_evidence *expected = pg_prove_match_branch_type(typing,
			formation, constructor, parameters, motive_context, motive, map);
		if (!expected || pg_alpha_equal(pg_evidence_subject(expected)->core, pg_evidence_subject(branch)->classifier) != 1) goto done;
		clauses[i] = (struct pg_match_clause){constructor, pg_evidence_subject(branch)->core};
		if (recursion) clauses[i].branch = induction_branch_core(typing, formation, parameters, map, branch, recursion);
		if (!clauses[i].branch) goto done;
		operands[i + 1] = pg_evidence_subject(branch);
	}
	const struct pg_term *core = recursion
		? pg_data_recursive_match(typing->graph, layout, recursion,
			saved->argument, saved->self, pg_evidence_subject(scrutinee)->core, count, clauses)
		: pg_data_match(typing->graph, layout, pg_evidence_subject(scrutinee)->core, count, clauses);
	if (!core) goto done;
	const struct pg_context_map *parameter_map = pg_evidence_context_map(parameters);
	const struct pg_occurrence *subject = pg_occurrence_intern(typing, &(struct pg_occurrence){
		.judgement = PG_JUDGEMENT_COMPUTATION, .context = pg_evidence_context(destination),
		.core = core, .classifier = pg_evidence_subject(output)->core, .type = pg_evidence_subject(output),
		.operand_count = count + 3, .map_count = 1, .induction = saved}, operands, &parameter_map);
	if (!subject) goto done;
	result = accept_record_inputs(typing, rule,
		pg_evidence_context(destination), subject, count + 6, inputs, NULL, NULL);
	if (result && request) {
		request->result = result;
		if (pg_index_insert(&typing->induction_requests, &request->index, request->index.hash)) result = NULL;
	}
done:
	pg_graph_destroy(&temporary);
	return result;
}

/* The checked rule identifies the eliminator theorem. Its program inputs and
 * lexical scopes come from the conclusion, not the premise array layout. */
int pg_elimination_view(const struct pg_typing *typing,
	const struct pg_evidence *proof, struct pg_elimination_inputs *view)
{
	if (!view || !pg_evidence_owned_by(proof, typing)) return -1;
	if (pg_evidence_rule(proof) != PG_MATCH_ELIM && pg_evidence_rule(proof) != PG_INDUCTION_ELIM) return -1;
	const struct pg_occurrence *subject = pg_evidence_subject(proof);
	if (subject->operand_count < 3 || subject->map_count != 1) return -1;
	size_t count = subject->operand_count - 3;
	*view = (struct pg_elimination_inputs){.subject = subject, .count = count,
		.formation = pg_evidence_for_subject(typing, subject->operands[count + 2], NULL),
		.parameters = conclusion_first(typing, PG_JUDGEMENT_SUBSTITUTION, pg_occurrence_maps(subject)[0]),
		.motive = pg_evidence_for_subject(typing, subject->operands[count + 1], NULL),
		.motive_context = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, subject->operands[count + 1]->context),
		.scrutinee = pg_evidence_for_subject(typing, subject->operands[0], NULL)};
	if (!view->formation || pg_evidence_rule(view->formation) != PG_INDUCTIVE_FORM) return -1;
	return view->parameters && view->motive && view->motive_context && view->scrutinee ? 0 : -1;
}

const struct pg_evidence *pg_prove_construction_origin(struct pg_typing *typing,
	const struct pg_evidence *proof,
	const struct pg_evidence **environment)
{
	if (!typing || !environment) return NULL;
	struct pg_typed_query *work = pg_construction_origin_request(typing, proof);
	while (!pg_typed_query_advance(work, 1024)) {}
	const struct pg_evidence *result = pg_typed_query_result(work);
	if (result) *environment = pg_construction_origin_environment(work);
	return result;
}

static const struct pg_evidence *elimination_instance(struct pg_typing *typing,
	const struct pg_evidence *substitution,
	const struct pg_evidence *elimination, const struct pg_evidence *scrutinee)
{
	struct pg_elimination_inputs view;
	if (pg_elimination_view(typing, elimination, &view)) return NULL;
	if (!pg_evidence_owned_by(substitution, typing) || pg_evidence_rule(substitution) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(pg_evidence_premise(substitution, 0)) != pg_evidence_context(elimination)) return NULL;
	struct pg_occurrence_input *query = pg_occurrence_input_mapped_request(typing,
		view.subject, view.count + 1, pg_evidence_context_map(substitution));
	while (pg_occurrence_input_advance(query, 1024) == PG_INPUT_PENDING) {}
	const struct pg_occurrence *input = pg_occurrence_input_result(query);
	const struct pg_evidence *motive = input ? pg_prove_structural_subject(typing, input) : NULL;
	if (!motive) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	size_t count = view.count;
	const struct pg_evidence **branches = pg_alloc(&temporary, count * sizeof(*branches));
	if (count && !branches) goto done;
	for (size_t i = 0; i < count; ++i) {
		branches[i] = pg_prove_reindex(typing, substitution,
			pg_prove_structural_subject(typing, view.subject->operands[i + 1]));
		if (!branches[i]) goto done;
	}
	result = prove_data_elimination(typing, view.formation,
		pg_prove_substitution_compose(typing, view.parameters, substitution),
		scrutinee ? scrutinee : pg_prove_reindex(typing, substitution, view.scrutinee),
		conclusion_first(typing, PG_JUDGEMENT_CONTEXT, input->context), motive,
		count, (struct pg_evidence_inputs){.owner = branches}, pg_evidence_rule(elimination), NULL);
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_elimination_reindex(struct pg_typing *typing,
	const struct pg_evidence *substitution,
	const struct pg_evidence *elimination)
{
	return elimination_instance(typing, substitution, elimination, NULL);
}

static const struct pg_evidence *constructor_head(struct pg_typing *typing,
	const struct pg_evidence *value, struct constructor_structure *view,
	struct pg_typed_query **dependency)
{
	if (!pg_evidence_owned_by(value, typing) || pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return NULL;
	const struct pg_context *context = pg_evidence_context(value);
	struct pg_typed_query *head_query = typed_head_request(typing, value, NULL);
	if (!head_query) return NULL;
	if (dependency) {
		*dependency = head_query;
		if (!head_query->status) return NULL;
		*dependency = NULL;
	} else while (!pg_typed_query_advance(head_query, 1024)) {}
	value = pg_typed_query_result(head_query);
	if (!value || pg_evidence_context(value) != context) return NULL;
	return constructor_view(typing, value, view) == 1 ? value : NULL;
}

static const struct pg_evidence *constructor_input(struct pg_typing *typing,
	const struct constructor_structure *view, size_t index)
{
	const struct pg_occurrence *input;
	return structural_input(typing, view->subject, index, &input)
		? pg_prove_structural_subject(typing, input) : NULL;
}

const struct pg_evidence *pg_prove_constructor_field(struct pg_typing *typing,
	const struct pg_evidence *value, const struct pg_object *field)
{
	struct constructor_structure view;
	value = constructor_head(typing, value, &view, NULL);
	if (!value) return NULL;
	const struct pg_occurrence *subject = pg_evidence_subject(value);
	const struct pg_context *scope = pg_evidence_context(pg_data_schema_fields(evidence_certificate(view.formation), view.constructor));
	const struct pg_term *spine = subject->core;
	for (size_t i = view.count; i; --i, scope = scope->parent, spine = spine->as.application.function) {
		if (scope->binder != field) continue;
		const struct pg_occurrence *input;
		if (!structural_input(typing, subject, i - 1, &input) || !input) return NULL;
		if (input->context != subject->context || pg_alpha_equal(input->core, spine->as.application.argument) != 1) return NULL;
		return pg_prove_structural_subject(typing, input);
	}
	return NULL;
}

static const struct pg_evidence *elimination_branch(struct pg_typing *typing,
	const struct pg_elimination_inputs *view,
	struct constructor_structure *value,
	struct pg_typed_query **dependency)
{
	if (!constructor_head(typing, view->scrutinee, value, dependency)) return NULL;
	if (pg_evidence_subject(value->formation) != pg_evidence_subject(view->formation)) return NULL;
	const struct pg_data_schema *schema = evidence_certificate(view->formation);
	size_t position;
	if (!pg_data_constructor_position(pg_data_schema_layout(schema), value->constructor, &position)) return NULL;
	if (position >= view->count) return NULL;
	return pg_prove_structural_subject(typing, view->subject->operands[position + 1]);
}

static int typed_body_match(struct pg_typed_query *work)
{
	struct typed_body_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_evidence *source = pg_prove_structural_subject(typing, local->current);
	if (local->environment)
		source = pg_prove_elimination_reindex(typing, local->environment, source);
	local->environment = NULL;
	work->dependency = pg_elimination_body_request(typing, source);
	local->resume = TYPED_RESUME_BODY;
	return work->dependency ? 0 : -1;
}

static const struct pg_evidence *elimination_branch_input(const void *owner, size_t i)
{
	const struct pg_occurrence *subject = owner;
	const struct pg_occurrence *input = subject->operands[i + 1];
	return conclusion_receipt(NULL, input->judgement, input);
}

static const struct pg_evidence *induction_field_body(struct pg_typing *typing,
	const struct pg_evidence *elimination,
	const struct pg_elimination_inputs *view, const struct pg_evidence *field)
{
	const struct pg_term *type;
	if (!pg_thunk_type_view(pg_evidence_subject(field)->classifier, &type)) {
		return pg_prove_induction_at(typing, view->formation, view->parameters,
			field, view->motive_context, view->motive, view->count,
			(struct pg_evidence_inputs){.owner = view->subject, .at = elimination_branch_input},
			pg_evidence_induction_allocation(elimination));
	}
	const struct pg_evidence *context = pg_evidence_premise(view->parameters, 1);
	struct pg_call_telescope telescope;
	if (pg_prove_call_telescope(typing, context, pg_prove_force(typing, field), NULL, &telescope)) return NULL;
	const struct pg_evidence *scope = telescope.context, *call = telescope.call, *classifier = telescope.classifier;
	const struct pg_evidence *returned = pg_prove_context_extension(typing, scope,
		pg_binder(typing->graph), pg_prove_return_content(typing, classifier));
	if (!returned) return NULL;
	const struct pg_evidence *map = pg_prove_substitution_projection(typing, context, returned);
	const struct pg_evidence *value = pg_prove_variable(typing, returned, pg_evidence_context(returned)->binder);
	if (!value) return NULL;
	const struct pg_evidence *child = elimination_instance(typing, map, elimination,
		value);
	/* Demand the field result before recursion, exactly as induction_field_core.
	 * Fold rejects a result classifier escaping with the returned-value binder. */
	const struct pg_evidence *continuation = pg_prove_abstract(typing, scope, returned, child);
	const struct pg_evidence *body = pg_prove_fold(typing, call, continuation);
	return pg_prove_abstract(typing, context, scope, body);
}

static int typed_elimination_prepare(struct pg_typed_query *work)
{
	struct typed_elimination_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_evidence *elimination = pg_prove_structural_subject(typing, typed_source(work));
	struct pg_elimination_inputs view;
	if (pg_elimination_view(typing, elimination, &view)) return -1;
	struct constructor_structure value;
	const struct pg_evidence *branch = elimination_branch(typing, &view, &value, &work->dependency);
	if (!branch) return work->dependency ? 0 : -1;
	const struct pg_data_schema *schema = evidence_certificate(view.formation);
	size_t count = value.count;
	if (count > SIZE_MAX / 2 / sizeof(const struct pg_evidence *)) return -1;
	struct typed_elimination *state = pg_alloc(typing->graph, sizeof(*state));
	if (!state) return -1;
	*state = (struct typed_elimination){.branch = branch, .count = count};
	state->arguments = pg_alloc(typing->graph, 2 * count * sizeof(*state->arguments));
	if (count && !state->arguments) return -1;
	for (size_t i = 0; i < count; ++i) {
		state->arguments[i] = constructor_input(typing, &value, i);
		if (!state->arguments[i]) return -1;
	}
	if (pg_evidence_rule(elimination) == PG_INDUCTION_ELIM) {
		const struct pg_context *declaration = pg_evidence_context(pg_data_schema_fields(schema, value.constructor));
		const struct pg_object *self = pg_evidence_context(pg_evidence_premise(view.formation, 0))->binder;
		for (size_t i = count; i; --i, declaration = declaration->parent) {
			int kind = pg_data_recursive_field(declaration->declared_type, self);
			if (kind < 0) return -1;
			state->arguments[count + i - 1] = kind ? state->arguments[i - 1] : NULL;
		}
		state->count += count;
		for (size_t i = count; i < state->count; ++i) {
			if (!state->arguments[i]) continue;
			const struct pg_evidence *call = induction_field_body(typing, elimination, &view, state->arguments[i]);
			state->arguments[i] = pg_prove_thunk(typing, call);
			if (!state->arguments[i]) return -1;
		}
	}
	local->elimination = state;
	return 0;
}

static int typed_elimination_step(struct pg_typed_query *work)
{
	struct typed_elimination_query *local = pg_typed_query_state(work);
	if (!local->elimination) return typed_elimination_prepare(work);
	struct typed_elimination *state = local->elimination;
	if (work->dependency) {
		if (!work->dependency->status) return 0;
		state->branch = pg_typed_query_result(work->dependency);
		work->dependency = NULL;
		if (!state->branch) return -1;
	}
	if (state->next == state->count) {
		work->result = state->branch;
		return 1;
	}
	const struct pg_evidence *argument = state->arguments[state->next++];
	if (!argument) return 0;
	work->dependency = pg_application_body_request(pg_typed_query_typing(work), state->branch, argument);
	return work->dependency ? 0 : -1;
}

const struct pg_evidence *pg_prove_elimination_body(struct pg_typing *typing,
	const struct pg_evidence *elimination)
{
	if (!typing) return NULL;
	struct pg_typed_query *work = pg_elimination_body_request(typing, elimination);
	while (!pg_typed_query_advance(work, 1024)) {}
	return pg_typed_query_result(work);
}

static int factor_binding(struct pg_graph *temporary, struct pg_index *index,
	const struct pg_term *pattern, const struct pg_evidence *image)
{
	if (!image) return -1;
	if (pattern->kind != PG_REFERENCE || pattern->as.reference->kind != PG_BINDER) return 0;
	struct refinement_binding *binding = refinement_find(index, pattern->as.reference);
	if (binding) return pg_alpha_equal(pg_evidence_subject(binding->image)->core, pg_evidence_subject(image)->core) == 1 ? 0 : -1;
	binding = pg_alloc(temporary, sizeof(*binding));
	if (!binding) return -1;
	binding->binder = pattern->as.reference; binding->image = image;
	return pg_index_insert(index, &binding->index, (uintptr_t)binding->binder);
}

const struct pg_evidence *pg_prove_refinement_factor(struct pg_typing *typing,
	const struct pg_evidence *refinement, const struct pg_evidence *instance,
	const struct pg_object *scrutinee)
{
	if (!pg_evidence_owned_by(refinement, typing) || pg_evidence_rule(refinement) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (!pg_evidence_owned_by(instance, typing) || pg_evidence_rule(instance) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(pg_evidence_premise(refinement, 0)) != pg_evidence_context(pg_evidence_premise(instance, 0))) return NULL;
	struct pg_graph temporary = {0};
	struct pg_index bindings;
	if (pg_index_init(&bindings)) return NULL;
	const struct pg_evidence *result = NULL;
	struct constructor_structure pattern, value;
	if (!constructor_head(typing, pg_substitution_image(typing, refinement, scrutinee), &pattern, NULL) ||
		!constructor_head(typing, pg_substitution_image(typing, instance, scrutinee), &value, NULL)) goto done;
	if (pattern.constructor != value.constructor || pattern.formation != value.formation || pattern.count != value.count) goto done;
	if (pg_evidence_context_map(refinement)->count != pg_evidence_context_map(instance)->count) goto done;
	for (size_t i = 0; i < pg_evidence_context_map(refinement)->count; ++i)
		if (factor_binding(&temporary, &bindings, pg_evidence_context_map(refinement)->images[i]->core,
			pg_substitution_image_at(typing, instance, i))) goto done;
	for (size_t i = 0; i < pattern.count; ++i) {
		const struct pg_evidence *field = constructor_input(typing, &pattern, i);
		const struct pg_evidence *image = constructor_input(typing, &value, i);
		if (!field || !image) goto done;
		if (factor_binding(&temporary, &bindings, pg_evidence_subject(field)->core, image)) goto done;
	}
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(refinement), NULL, &count)) goto done;
	if (count > SIZE_MAX / sizeof(const struct pg_evidence *)) goto done;
	const struct pg_evidence **images = pg_alloc(&temporary, count * sizeof(*images));
	if (count && !images) goto done;
	const struct pg_context *scope = pg_evidence_context(refinement);
	for (size_t i = count; i; --i, scope = scope->parent) {
		struct refinement_binding *binding = refinement_find(&bindings, scope->binder);
		if (!binding) goto done;
		images[i - 1] = binding->image;
	}
	const struct pg_evidence *map = pg_prove_substitution(typing, pg_evidence_premise(refinement, 1), pg_evidence_premise(instance, 1), count, images);
	const struct pg_evidence *composite = pg_prove_substitution_compose(typing, refinement, map);
	if (!composite || pg_evidence_context_map(composite)->count != pg_evidence_context_map(instance)->count) goto done;
	for (size_t i = 0; i < pg_evidence_context_map(composite)->count; ++i)
		if (pg_alpha_equal(pg_evidence_context_map(composite)->images[i]->core,
			pg_evidence_context_map(instance)->images[i]->core) != 1) goto done;
	result = map;
done:
	pg_index_destroy(&bindings);
	pg_graph_destroy(&temporary);
	return result;
}

/* A positional correspondence is only a candidate. The ordinary substitution
 * constructor checks every image against the preceding dependent telescope. */
const struct pg_evidence *pg_prove_telescope_correspondence(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *destination)
{
	if (!context_proof(typing, source) || !context_proof(typing, destination)) return NULL;
	size_t count, other;
	if (pg_context_extension_size(pg_evidence_context(source), NULL, &count) ||
		pg_context_extension_size(pg_evidence_context(destination), NULL, &other) || count != other) return NULL;
	if (count > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	const struct pg_evidence **images = malloc(count * sizeof(*images));
	if (count && !images) return NULL;
	const struct pg_context *scope = pg_evidence_context(destination);
	for (size_t i = count; i; --i, scope = scope->parent)
		images[i - 1] = pg_prove_variable(typing, destination, scope->binder);
	const struct pg_evidence *map = pg_prove_substitution(typing, source, destination, count, images);
	free(images);
	return map;
}

const struct pg_evidence *pg_prove_refined_match(struct pg_typing *typing,
	const struct pg_evidence *context,
	const struct pg_evidence *scrutinee, const struct pg_evidence *motive,
	size_t count, const struct pg_evidence *const *refinements,
	const struct pg_evidence *const *branches)
{
	if (!context_proof(typing, context) || !pg_evidence_owned_by(motive, typing)) return NULL;
	if (pg_evidence_judgement(motive) != PG_JUDGEMENT_COMPUTATION_TYPE || pg_evidence_context(motive) != pg_evidence_context(context)) return NULL;
	if (!pg_evidence_owned_by(scrutinee, typing) || pg_evidence_context(scrutinee) != pg_evidence_context(context)) return NULL;
	if (count && (!refinements || !branches)) return NULL;
	struct pg_inductive_instance instance;
	if (!pg_inductive_instance(typing, pg_prove_classifier(typing, context, scrutinee), &instance)) return NULL;
	if (count != pg_data_constructor_count(instance.schema)) return NULL;
	const struct pg_evidence *mc = pg_prove_inductive_motive_context(typing,
		instance.formation, instance.parameters, pg_binder(typing->graph));
	if (!mc) return NULL;
	if (!count) return pg_prove_match(typing, instance.formation, instance.parameters,
		scrutinee, mc, pg_prove_projection(typing, mc, motive), 0, (struct pg_evidence_inputs){.owner = NULL});
	if (count > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	struct pg_graph temporary = {0};
	struct pg_index replacements;
	if (pg_index_init(&replacements)) return NULL;
	const struct pg_evidence *result = NULL, *prefix = NULL;
	const struct pg_evidence **functions = pg_alloc(&temporary, count * sizeof(*functions));
	if (!functions) goto done;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *map = refinements[i], *body = branches[i];
		if (!pg_evidence_owned_by(map, typing) || pg_evidence_rule(map) != PG_CONTEXT_SUBSTITUTION) goto done;
		if (pg_evidence_context(pg_evidence_premise(map, 0)) != pg_evidence_context(context)) goto done;
		if (!pg_evidence_owned_by(body, typing) || pg_evidence_context(body) != pg_evidence_context(map)) goto done;
		const struct pg_evidence *expected = pg_prove_constructor_refinement(typing, context,
			scrutinee, pg_data_constructor(pg_data_schema_layout(instance.schema), i));
		if (!expected) goto done;
		if (!i) {
			size_t left, right;
			prefix = context;
			const struct pg_evidence *target = pg_evidence_premise(expected, 1);
			if (pg_context_extension_size(pg_evidence_context(prefix), NULL, &left) ||
				pg_context_extension_size(pg_evidence_context(target), NULL, &right)) goto done;
			while (left > right) { prefix = pg_context_parent_input(typing, prefix); --left; }
			while (right > left) { target = pg_context_parent_input(typing, target); --right; }
			while (pg_evidence_context(prefix) != pg_evidence_context(target)) {
				prefix = pg_context_parent_input(typing, prefix); target = pg_context_parent_input(typing, target);
			}
		}
		const struct pg_evidence *rename = pg_prove_telescope_correspondence(typing, pg_evidence_premise(expected, 1), pg_evidence_premise(map, 1));
		expected = pg_prove_substitution_compose(typing, expected, rename);
		if (!expected || pg_evidence_context_map(expected)->count != pg_evidence_context_map(map)->count) goto done;
		for (size_t j = 0; j < pg_evidence_context_map(map)->count; ++j)
			if (pg_alpha_equal(pg_evidence_context_map(expected)->images[j]->core,
				pg_evidence_context_map(map)->images[j]->core) != 1) goto done;
		const struct pg_evidence *lift = lift_scope(typing,
			pg_prove_substitution_projection(typing, prefix, context), pg_evidence_premise(map, 1), NULL, 0);
		if (!lift) goto done;
		functions[i] = pg_prove_abstract(typing, context, pg_evidence_premise(lift, 1),
			pg_prove_reindex(typing, lift, body));
		if (!functions[i]) goto done;
	}
	struct pg_inductive_instance generic;
	if (!pg_inductive_instance(typing, pg_context_declared_input(typing, mc), &generic)) goto done;
	size_t first = pg_evidence_context_map(instance.parameters)->count + 1;
	size_t indices = instance.indices ? pg_evidence_context_map(instance.indices)->count - first : 0;
	if (indices >= SIZE_MAX / sizeof(struct refinement_binding)) goto done;
	struct refinement_binding *bindings = pg_alloc(&temporary, (indices + 1) * sizeof(*bindings));
	if (!bindings) goto done;
	for (size_t i = 0; i <= indices; ++i) {
		const struct pg_term *term = i == indices ? pg_evidence_subject(scrutinee)->core
			: pg_evidence_context_map(instance.indices)->images[first + i]->core;
		if (term->kind != PG_REFERENCE || term->as.reference->kind != PG_BINDER) goto done;
		bindings[i].binder = term->as.reference;
		bindings[i].image = i == indices ? pg_prove_variable(typing, mc, pg_evidence_context(mc)->binder)
			: pg_prove_projection(typing, mc,
				pg_substitution_image_at(typing, generic.indices, first + i));
		if (!bindings[i].image || refinement_find(&replacements, bindings[i].binder)) goto done;
		if (pg_index_insert(&replacements, &bindings[i].index, (uintptr_t)bindings[i].binder)) goto done;
	}
	size_t suffix;
	if (pg_context_extension_size(pg_evidence_context(context), pg_evidence_context(prefix), &suffix)) goto done;
	if (suffix > SIZE_MAX / sizeof(const struct pg_evidence *)) goto done;
	const struct pg_evidence **extensions = pg_alloc(&temporary, suffix * sizeof(*extensions));
	if (suffix && !extensions) goto done;
	const struct pg_evidence *scope = context;
	for (size_t i = suffix; i; --i, scope = pg_context_parent_input(typing, scope)) extensions[i - 1] = scope;
	const struct pg_evidence *map = pg_prove_substitution_projection(typing, prefix, mc);
	for (size_t i = 0; map && i < suffix; ++i) {
		struct refinement_binding *binding = refinement_find(&replacements, pg_evidence_context(extensions[i])->binder);
		if (binding) map = pg_prove_substitution_pair(typing, map, extensions[i],
			pg_prove_projection(typing, pg_evidence_premise(map, 1), binding->image));
		else map = pg_prove_substitution_lift(typing, map, extensions[i], pg_binder(typing->graph));
	}
	if (!map) goto done;
	const struct pg_evidence *generalized = pg_prove_reindex(typing, map, motive);
	for (scope = pg_evidence_premise(map, 1); generalized && pg_evidence_context(scope) != pg_evidence_context(mc); scope = pg_context_parent_input(typing, scope))
		generalized = pg_prove_pi(typing, scope, generalized);
	result = pg_prove_match(typing, instance.formation, instance.parameters,
		scrutinee, mc, generalized, count, (struct pg_evidence_inputs){.owner = functions});
	for (size_t i = 0; result && i < suffix; ++i) {
		const struct pg_object *binder = pg_evidence_context(extensions[i])->binder;
		if (!refinement_find(&replacements, binder))
			result = pg_prove_application(typing, result, pg_prove_variable(typing, context, binder));
	}
done:
	pg_index_destroy(&replacements);
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_type_case(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *scrutinee,
	size_t count, struct pg_evidence_inputs branches)
{
	if (!typing) return NULL;
	if (!pg_evidence_owned_by(formation, typing) || pg_evidence_rule(formation) != PG_INDUCTIVE_FORM) return NULL;
	if (!pg_evidence_owned_by(parameters, typing) || pg_evidence_rule(parameters) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(pg_evidence_premise(parameters, 0)) != pg_evidence_context(formation)) return NULL;
	if (!pg_evidence_owned_by(scrutinee, typing) || pg_evidence_judgement(scrutinee) != PG_JUDGEMENT_VALUE) return NULL;
	if (pg_evidence_context(scrutinee) != pg_evidence_context(parameters)) return NULL;
	const struct pg_data_schema *schema = evidence_certificate(formation);
	if (!count || count != pg_data_constructor_count(schema)) return NULL;
	if (count > SIZE_MAX / sizeof(void *) - 3 || count > SIZE_MAX / sizeof(struct pg_match_clause)) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	const struct pg_evidence *header[] = {formation, parameters, scrutinee};
	const struct receipt_segments segments = {3, count, header, NULL, branches};
	const struct pg_evidence_inputs inputs = {.owner = &segments, .at = segmented_receipt};
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *branch = pg_evidence_input(branches, i);
		if (!pg_evidence_owned_by(branch, typing)) goto done;
		if (pg_evidence_context(branch) != pg_evidence_context(parameters)) goto done;
	}
	uint64_t hash;
	result = find_record_inputs(typing, PG_TYPE_CASE,
		pg_evidence_context(parameters), NULL, count + 3, inputs, NULL, &hash);
	if (result) goto done;
	const struct pg_evidence *type = pg_prove_classifier(typing, pg_evidence_premise(parameters, 1), scrutinee);
	struct pg_inductive_instance instance;
	if (!pg_inductive_instance(typing, type, &instance) || instance.formation != formation) goto done;
	if (pg_evidence_context_map(instance.parameters)->count != pg_evidence_context_map(parameters)->count) goto done;
	for (size_t i = 0; i < pg_evidence_context_map(parameters)->count; ++i)
		if (pg_alpha_equal(pg_evidence_context_map(instance.parameters)->images[i]->core,
			pg_evidence_context_map(parameters)->images[i]->core) != 1) goto done;
	const struct pg_evidence *self = pg_evidence_premise(formation, 0);
	const struct pg_evidence *prefix = prove_data_scope(typing, formation, self, parameters, NULL, 0);
	if (!prefix) goto done;
	const struct pg_context_map *map = pg_evidence_context_map(prefix);
	const struct pg_data_layout *layout = pg_data_schema_layout(schema);
	struct pg_match_clause *clauses = pg_alloc(&temporary, count * sizeof(*clauses));
	const struct pg_occurrence **operands = pg_alloc(&temporary, (count + 1) * sizeof(*operands));
	if (!clauses || !operands) goto done;
	operands[0] = pg_evidence_subject(scrutinee);
	uint64_t level = 0;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *branch = pg_evidence_input(branches, i);
		const struct pg_object *constructor = pg_data_constructor(layout, i);
		const struct pg_context *fields = pg_evidence_context(pg_data_schema_fields(schema, constructor));
		enum pg_evidence_judgement kind = fields == pg_evidence_context(self)
			? PG_JUDGEMENT_VALUE_TYPE : PG_JUDGEMENT_TYPE_FAMILY;
		if (pg_evidence_judgement(branch) != kind) goto done;
		const struct pg_term *signature = pg_evidence_classifier(branch), *domain, *body;
		const struct pg_object *binder;
		while (pg_pi_view(signature, &domain, &binder, &body)) signature = body;
		uint64_t bound;
		if (!pg_universe_level(signature, &bound)) goto done;
		/* Checking the closed telescope needs no fresh field variables or
		 * discarded applications of the already accepted branch. */
		signature = pg_context_signature(typing->graph, pg_evidence_context(self), fields, signature);
		signature = pg_substitution_compute(&typing->substitutions, signature, map->count, pg_context_map_bindings(map));
		if (!signature || pg_alpha_equal(signature, pg_evidence_classifier(branch)) != 1) goto done;
		if (bound > level) level = bound;
		clauses[i] = (struct pg_match_clause){constructor, pg_evidence_subject(branch)->core};
		operands[i + 1] = pg_evidence_subject(branch);
	}
	const struct pg_term *core = pg_data_match(typing->graph, layout, pg_evidence_subject(scrutinee)->core, count, clauses);
	const struct pg_term *universe = pg_universe(typing->graph, level);
	if (!core || !universe) goto done;
	const struct pg_context_map *parameter_map = pg_evidence_context_map(parameters);
	const struct pg_occurrence *subject = pg_occurrence_intern(typing, &(struct pg_occurrence){
		.judgement = PG_JUDGEMENT_VALUE_TYPE, .context = pg_evidence_context(parameters),
		.core = core, .classifier = universe, .operand_count = count + 1, .map_count = 1},
		operands, &parameter_map);
	if (!subject) goto done;
	result = accept_record_inputs(typing, PG_TYPE_CASE,
		pg_evidence_context(parameters), subject, count + 3, inputs, NULL, NULL);
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_match(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *scrutinee,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	size_t count, struct pg_evidence_inputs branches)
{
	return prove_data_elimination(typing, formation, parameters,
		scrutinee, motive_context, motive, count, branches, PG_MATCH_ELIM, NULL);
}

const struct pg_evidence *pg_prove_induction(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *scrutinee,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	size_t count, struct pg_evidence_inputs branches)
{
	return prove_data_elimination(typing, formation, parameters,
		scrutinee, motive_context, motive, count, branches, PG_INDUCTION_ELIM, NULL);
}

const struct pg_evidence *pg_prove_induction_at(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *parameters, const struct pg_evidence *scrutinee,
	const struct pg_evidence *motive_context, const struct pg_evidence *motive,
	size_t count, struct pg_evidence_inputs branches,
	const struct pg_induction_allocation *allocation)
{
	if (!allocation) return NULL;
	return prove_data_elimination(typing, formation, parameters,
		scrutinee, motive_context, motive, count, branches, PG_INDUCTION_ELIM, allocation);
}

const struct pg_evidence *pg_prove_empty_context(struct pg_typing *typing)
{
	return accept(typing, PG_CONTEXT_EMPTY, NULL, NULL, 0, NULL);
}

const struct pg_evidence *pg_prove_value_type(struct pg_typing *typing, const struct pg_evidence *value)
{
	if (!pg_evidence_owned_by(value, typing)) return NULL;
	if (pg_evidence_judgement(value) == PG_JUDGEMENT_VALUE_TYPE) return value;
	if (pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return NULL;
	uint64_t level;
	if (!pg_universe_level(pg_evidence_subject(value)->classifier, &level)) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_boundary(typing, pg_evidence_subject(value),
		PG_JUDGEMENT_VALUE_TYPE, pg_evidence_subject(value)->classifier);
	return accept_selection(typing, PG_TYPE_FROM_VALUE, value, subject);
}

const struct pg_evidence *pg_prove_type_value(struct pg_typing *typing, const struct pg_evidence *type)
{
	if (!pg_evidence_owned_by(type, typing)) return NULL;
	if (pg_evidence_judgement(type) != PG_JUDGEMENT_VALUE_TYPE) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_boundary(typing, pg_evidence_subject(type),
		PG_JUDGEMENT_VALUE, pg_evidence_subject(type)->classifier);
	return accept_selection(typing, PG_VALUE_FROM_TYPE, type, subject);
}

const struct pg_evidence *pg_prove_context_extension(struct pg_typing *typing,
	const struct pg_evidence *parent, const struct pg_object *binder,
	const struct pg_evidence *type)
{
	if (!context_proof(typing, parent)) return NULL;
	type = pg_prove_value_type(typing, type);
	if (!type) return NULL;
	if (!pg_evidence_subject(type) || pg_evidence_context(type) != pg_evidence_context(parent)) return NULL;
	uint64_t level;
	if (!pg_universe_level(pg_evidence_subject(type)->classifier, &level)) return NULL;
	if (pg_context_lookup(pg_evidence_context(parent), binder)) return NULL;
	const struct pg_context *context = pg_context_bind(typing, pg_evidence_context(parent), binder,
		pg_evidence_subject(type)->core, PG_JUDGEMENT_VALUE);
	if (!context) return NULL;
	const struct pg_scope *scope = pg_scope_intern(typing, context,
		pg_evidence_scope(parent), NULL, pg_evidence_subject(type));
	if (!scope) return NULL;
	return accept_record(typing, PG_CONTEXT_EXTEND, context, NULL, 0, NULL, scope, NULL);
}

const struct pg_evidence *pg_prove_universe(struct pg_typing *typing,
	const struct pg_evidence *context, uint64_t level)
{
	if (!context_proof(typing, context)) return NULL;
	if (level == UINT64_MAX) return NULL;
	const struct pg_term *term = pg_universe(typing->graph, level);
	const struct pg_term *sort = pg_universe(typing->graph, level + 1);
	if (!term || !sort) return NULL;
	const struct pg_occurrence *subject = pg_occurrence(typing, PG_JUDGEMENT_VALUE_TYPE, pg_evidence_context(context), term, sort, NULL, 0, NULL);
	if (!subject) return NULL;
	return accept(typing, PG_UNIVERSE_FORM, pg_evidence_context(context), subject, 1, &context);
}

const struct pg_evidence *pg_prove_host_type(struct pg_typing *typing,
	const struct pg_evidence *context,
	const struct pg_object *type)
{
	if (!context_proof(typing, context)) return NULL;
	if (!pg_host_type_name(type)) return NULL;
	const struct pg_term *core = pg_reference(typing->graph, type);
	const struct pg_term *universe = pg_universe(typing->graph, 0);
	if (!core || !universe) return NULL;
	const struct pg_occurrence *subject = pg_occurrence(typing, PG_JUDGEMENT_VALUE_TYPE, pg_evidence_context(context), core, universe, NULL, 0, NULL);
	if (!subject) return NULL;
	return accept(typing, PG_HOST_TYPE_FORM, pg_evidence_context(context), subject, 1, &context);
}

const struct pg_evidence *pg_prove_host_value(struct pg_typing *typing,
	const struct pg_evidence *type, const struct pg_object *value)
{
	if (!pg_evidence_owned_by(type, typing) || pg_evidence_judgement(type) != PG_JUDGEMENT_VALUE_TYPE) return NULL;
	const struct pg_object *descriptor;
	size_t count;
	const unsigned char *bytes;
	if (!pg_host_literal_view(value, &descriptor, &count, &bytes)) return NULL;
	if (pg_evidence_subject(type)->core->kind != PG_REFERENCE || pg_evidence_subject(type)->core->as.reference != descriptor) return NULL;
	const struct pg_term *core = pg_reference(typing->graph, value);
	if (!core) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_VALUE, core, pg_evidence_subject(type), NULL, 0, NULL);
	if (!subject) return NULL;
	return accept(typing, PG_HOST_VALUE_INTRO, pg_evidence_context(type), subject, 1, &type);
}

const struct pg_evidence *pg_prove_host_function(struct pg_typing *typing,
	const struct pg_evidence *type, const struct pg_object *function)
{
	if (!pg_evidence_owned_by(type, typing) || pg_evidence_judgement(type) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	const struct pg_object *host_domain, *host_result;
	size_t arity;
	if (!pg_host_function_view(function, &host_domain, &host_result, &arity)) return NULL;
	const struct pg_term *signature = pg_evidence_subject(type)->core;
	for (size_t i = 0; i < arity; ++i) {
		const struct pg_term *domain, *codomain;
		const struct pg_object *binder;
		if (!pg_pi_view(signature, &domain, &binder, &codomain)) return NULL;
		if (domain->kind != PG_REFERENCE || domain->as.reference != host_domain) return NULL;
		signature = codomain;
	}
	enum pg_totality totality;
	const struct pg_term *result;
	if (!pg_pure_computation_type_view(signature, &totality, &result) || totality != PG_TOTALITY_TOTAL) return NULL;
	if (result->kind != PG_REFERENCE || result->as.reference != host_result) return NULL;
	const struct pg_term *core = pg_reference(typing->graph, function);
	const struct pg_occurrence *subject = core ? pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, core, pg_evidence_subject(type), NULL, 0, NULL) : NULL;
	return subject ? accept(typing, PG_HOST_FUNCTION_INTRO,
		pg_evidence_context(type), subject, 1, &type) : NULL;
}

const struct pg_evidence *pg_prove_family_context_extension(struct pg_typing *typing,
	const struct pg_evidence *parent, const struct pg_object *binder,
	const struct pg_evidence *indices, const struct pg_evidence *universe)
{
	if (!context_proof(typing, parent) || !context_proof(typing, indices)) return NULL;
	if (!pg_evidence_owned_by(universe, typing)) return NULL;
	if (pg_evidence_judgement(universe) != PG_JUDGEMENT_VALUE_TYPE || pg_evidence_context(universe) != pg_evidence_context(indices)) return NULL;
	uint64_t level;
	if (!pg_universe_level(pg_evidence_subject(universe)->core, &level)) return NULL;
	size_t count;
	if (pg_context_extension_size(pg_evidence_context(indices), pg_evidence_context(parent), &count) || !count) return NULL;
	if (pg_context_lookup(pg_evidence_context(parent), binder)) return NULL;
	const struct pg_term *signature = pg_context_signature(typing->graph,
		pg_evidence_context(parent), pg_evidence_context(indices), pg_evidence_subject(universe)->core);
	if (!signature) return NULL;
	const struct pg_context *context = pg_context_intern(typing, &(struct pg_context){
		.parent = pg_evidence_context(parent), .binder = binder, .declared_type = signature,
		.judgement = PG_JUDGEMENT_TYPE_FAMILY, .indices = pg_evidence_context(indices)});
	if (!context) return NULL;
	const struct pg_scope *scope = pg_scope_intern(typing, context,
		pg_evidence_scope(parent), pg_evidence_scope(indices), pg_evidence_subject(universe));
	if (!scope) return NULL;
	return accept_record(typing, PG_CONTEXT_FAMILY_EXTEND,
		context, NULL, 0, NULL, scope, NULL);
}

const struct pg_evidence *pg_check_variable(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_object *binder,
	const struct pg_evidence *selected)
{
	if (!context_proof(typing, context)) return NULL;
	const struct pg_context *declaration = pg_context_lookup(pg_evidence_context(context), binder);
	if (!declaration) return NULL;
	const struct pg_scope *scope = NULL;
	if (selected) {
		if (!context_proof(typing, selected) || pg_evidence_context(selected) != declaration ||
			declaration->judgement != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
		scope = pg_evidence_scope(selected);
	} else if (declaration->judgement == PG_JUDGEMENT_TYPE_FAMILY) {
		scope = pg_evidence_scope(context);
		while (scope && scope->context != declaration) scope = scope->parent;
		if (!scope || !pg_evidence_for_scope(typing, scope)) return NULL;
	}
	const struct pg_term *term = pg_reference(typing->graph, binder);
	const struct pg_occurrence *subject = pg_occurrence_intern(typing, &(struct pg_occurrence){
		.judgement = declaration->judgement, .context = pg_evidence_context(context),
		.core = term, .classifier = declaration->declared_type,
		.scope = scope}, NULL, NULL);
	if (!subject) return NULL;
	const struct pg_evidence *premises[] = {context, scope ? pg_evidence_for_scope(typing, scope) : NULL};
	return accept(typing, PG_VARIABLE, pg_evidence_context(context),
		subject, scope && scope->context != subject->context ? 2 : 1, premises);
}

const struct pg_evidence *pg_prove_variable(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_object *binder)
{
	return pg_check_variable(typing, context, binder, NULL);
}

static const struct pg_evidence *family_application(struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_evidence *index,
	const struct pg_occurrence *retained)
{
	if (!pg_evidence_owned_by(family, typing) || !pg_evidence_owned_by(index, typing)) return NULL;
	if (pg_evidence_judgement(family) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (pg_evidence_judgement(index) != PG_JUDGEMENT_VALUE && pg_evidence_judgement(index) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (pg_evidence_context(family) != pg_evidence_context(index)) return NULL;
	const struct pg_term *domain, *body;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(family)->classifier, &domain, &binder, &body)) return NULL;
	if (pg_alpha_equal(domain, pg_evidence_subject(index)->classifier) != 1) return NULL;
	struct pg_binding_value binding = {binder, pg_evidence_subject(index)->core};
	const struct pg_term *classifier = pg_substitution_compute(&typing->substitutions, body, 1, (struct pg_binding_inputs){.owner = &binding});
	if (!classifier) return NULL;
	/* Loading must preserve an explicit bound-pointer allocation, just as
	 * ordinary APP does. Check the computed signature; never infer from it. */
	if (retained) {
		if (pg_alpha_equal(classifier, retained->classifier) != 1) return NULL;
		classifier = retained->classifier;
	}
	uint64_t level;
	enum pg_evidence_judgement kind = pg_universe_level(classifier, &level)
		? PG_JUDGEMENT_VALUE_TYPE : PG_JUDGEMENT_TYPE_FAMILY;
	const struct pg_term *core = pg_application(typing->graph, pg_evidence_subject(family)->core, pg_evidence_subject(index)->core);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(family), pg_evidence_subject(index)};
	const struct pg_occurrence *subject = pg_occurrence(typing, kind, pg_evidence_context(family), core, classifier, NULL, 2, operands);
	if (!subject) return NULL;
	if (retained && subject != retained) return NULL;
	return accept(typing, PG_TYPE_FAMILY_APP, pg_evidence_context(family), subject, 0, NULL);
}

const struct pg_evidence *pg_prove_family_application(struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_evidence *index)
{
	return family_application(typing, family, index, NULL);
}

const struct pg_evidence *pg_check_family_application(struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_evidence *index,
	const struct pg_occurrence *subject)
{
	return subject ? family_application(typing, family, index, subject) : NULL;
}

const struct pg_evidence *pg_prove_family_abstraction(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *body)
{
	if (!context_proof(typing, context)) return NULL;
	if (pg_evidence_rule(context) != PG_CONTEXT_EXTEND && pg_evidence_rule(context) != PG_CONTEXT_FAMILY_EXTEND) return NULL;
	if (!pg_evidence_owned_by(body, typing) || pg_evidence_context(body) != pg_evidence_context(context)) return NULL;
	if (pg_evidence_judgement(body) != PG_JUDGEMENT_VALUE_TYPE && pg_evidence_judgement(body) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	const struct pg_occurrence *subject = pg_function_binding(typing, context, pg_evidence_subject(body), PG_JUDGEMENT_TYPE_FAMILY);
	if (!subject) return NULL;
	return accept_record(typing, PG_TYPE_FAMILY_ABSTRACT,
		subject->context, subject, 0, NULL, pg_evidence_scope(context), NULL);
}

static const struct pg_evidence *unary_formation(struct pg_typing *typing,
	const struct pg_evidence *argument,
	enum pg_evidence_rule rule, enum pg_totality totality, const struct pg_effect_row *effects)
{
	if (!pg_evidence_owned_by(argument, typing)) return NULL;
	enum pg_evidence_judgement output;
	const struct pg_term *term;
	if (rule == PG_RETURN_TYPE_FORM) {
		argument = pg_prove_value_type(typing, argument);
		if (!argument) return NULL;
		output = PG_JUDGEMENT_COMPUTATION_TYPE;
		term = pg_computation_type(typing->graph, totality, effects, pg_evidence_subject(argument)->core);
	} else {
		if (pg_evidence_judgement(argument) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
		output = PG_JUDGEMENT_VALUE_TYPE;
		term = pg_thunk_type(typing->graph, pg_evidence_subject(argument)->core);
	}
	if (!term) return NULL;
	const struct pg_occurrence *subject = pg_occurrence(typing, output, pg_evidence_context(argument),
		term, pg_evidence_subject(argument)->classifier, NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(argument)});
	if (!subject) return NULL;
	return accept(typing, rule, pg_evidence_context(argument), subject, 0, NULL);
}

const struct pg_evidence *pg_prove_termination_type(struct pg_typing *typing,
	const struct pg_evidence *type,
	const struct pg_evidence *suspended)
{
	if (!typing) return NULL;
	if (!pg_evidence_owned_by(type, typing) || !pg_evidence_owned_by(suspended, typing)) return NULL;
	if (pg_evidence_judgement(type) != PG_JUDGEMENT_VALUE_TYPE || pg_evidence_judgement(suspended) != PG_JUDGEMENT_VALUE) return NULL;
	if (pg_evidence_context(type) != pg_evidence_context(suspended)) return NULL;
	const struct pg_term *computation;
	if (!pg_thunk_type_view(pg_evidence_subject(type)->core, &computation)) return NULL;
	if (pg_alpha_equal(pg_evidence_subject(type)->core, pg_evidence_subject(suspended)->classifier) != 1) return NULL;
	const struct pg_term *core = pg_termination_type(typing->graph, pg_evidence_subject(suspended)->core);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(type), pg_evidence_subject(suspended)};
	const struct pg_occurrence *subject = pg_occurrence(typing, PG_JUDGEMENT_VALUE_TYPE, pg_evidence_context(type), core, pg_evidence_subject(type)->classifier, NULL, 2, operands);
	const struct pg_evidence *premises[] = {type, suspended};
	return subject ? accept(typing, PG_TERMINATION_FORM,
		pg_evidence_context(type), subject, 2, premises) : NULL;
}

const struct pg_evidence *pg_prove_termination(struct pg_typing *typing,
	const struct pg_evidence *formation,
	const struct pg_evidence *suspended)
{
	if (!typing) return NULL;
	if (!pg_evidence_owned_by(formation, typing) || !pg_evidence_owned_by(suspended, typing)) return NULL;
	if (pg_evidence_judgement(formation) != PG_JUDGEMENT_VALUE_TYPE || pg_evidence_judgement(suspended) != PG_JUDGEMENT_VALUE) return NULL;
	if (pg_evidence_context(formation) != pg_evidence_context(suspended)) return NULL;
	const struct pg_term *expected, *computation, *value;
	const struct pg_effect_row *effects;
	enum pg_totality totality;
	if (!pg_termination_type_view(pg_evidence_subject(formation)->core, &expected)) return NULL;
	if (pg_alpha_equal(expected, pg_evidence_subject(suspended)->core) != 1) return NULL;
	if (!pg_thunk_type_view(pg_evidence_subject(suspended)->classifier, &computation)) return NULL;
	if (!pg_computation_type_view(computation, &totality, &effects, &value)) return NULL;
	if (totality != PG_TOTALITY_TOTAL) return NULL;
	const struct pg_term *core = pg_termination_witness(typing->graph, pg_evidence_subject(suspended)->core);
	if (!core) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_VALUE, core, pg_evidence_subject(formation), NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(suspended)});
	const struct pg_evidence *premises[] = {formation, suspended};
	return subject ? accept(typing, PG_TERMINATION_INTRO,
		pg_evidence_context(suspended), subject, 2, premises) : NULL;
}

const struct pg_evidence *pg_prove_return_type(struct pg_typing *typing,
	const struct pg_evidence *value_type)
{
	if (!typing) return NULL;
	return pg_prove_effect_type(typing, pg_effect_row(typing->graph, 0, NULL), value_type);
}

const struct pg_evidence *pg_prove_effect_type(struct pg_typing *typing,
	const struct pg_effect_row *effects,
	const struct pg_evidence *value_type)
{
	return pg_prove_computation_type(typing, PG_TOTALITY_UNSPECIFIED, effects, value_type);
}

const struct pg_evidence *pg_prove_computation_type(struct pg_typing *typing,
	enum pg_totality totality,
	const struct pg_effect_row *effects, const struct pg_evidence *value_type)
{
	if (!effects) return NULL;
	return unary_formation(typing, value_type, PG_RETURN_TYPE_FORM, totality, effects);
}

static int endpoint(const struct pg_typing *typing, const struct pg_evidence *term,
	enum pg_evidence_judgement judgement, const struct pg_context *context,
	const struct pg_term *type)
{
	if (!pg_evidence_owned_by(term, typing)) return 0;
	if (pg_evidence_judgement(term) != judgement) return 0;
	if (pg_evidence_context(term) != context) return 0;
	return pg_alpha_equal(pg_evidence_subject(term)->classifier, type) == 1;
}

const struct pg_evidence *pg_prove_identity_type(struct pg_typing *typing,
	const struct pg_evidence *type, const struct pg_evidence *left,
	const struct pg_evidence *right)
{
	if (!pg_evidence_owned_by(type, typing)) return NULL;
	enum pg_evidence_judgement elements;
	switch (pg_evidence_judgement(type)) {
	case PG_JUDGEMENT_VALUE_TYPE: elements = PG_JUDGEMENT_VALUE; break;
	case PG_JUDGEMENT_COMPUTATION_TYPE: elements = PG_JUDGEMENT_COMPUTATION; break;
	default: return NULL;
	}
	if (!endpoint(typing, left, elements, pg_evidence_context(type), pg_evidence_subject(type)->core)) return NULL;
	if (!endpoint(typing, right, elements, pg_evidence_context(type), pg_evidence_subject(type)->core)) return NULL;
	const struct pg_term *family = pg_identity_action(typing->graph, pg_evidence_subject(type)->core);
	const struct pg_term *core = pg_identity_instance(typing->graph, family,
		pg_evidence_subject(left)->core, pg_evidence_subject(right)->core);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(type), pg_evidence_subject(left), pg_evidence_subject(right)};
	const struct pg_occurrence *subject = pg_occurrence(typing, pg_evidence_judgement(type), pg_evidence_context(type), core, pg_evidence_subject(type)->classifier, NULL, 3, operands);
	if (!subject) return NULL;
	return accept(typing, PG_IDENTITY_FORM, pg_evidence_context(type),
		subject, 0, NULL);
}

static int universe_identity(const struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_term **left,
	const struct pg_term **right, uint64_t *level)
{
	if (!pg_evidence_owned_by(family, typing)) return 0;
	if (pg_evidence_judgement(family) != PG_JUDGEMENT_VALUE) return 0;
	const struct pg_term *universe;
	if (!pg_identity_view(pg_evidence_subject(family)->classifier, &universe, left, right)) return 0;
	return pg_universe_level(universe, level);
}

const struct pg_evidence *pg_prove_identity_endpoint_type(struct pg_typing *typing,
	const struct pg_evidence *family,
	enum pg_evidence_rule side)
{
	const struct pg_term *left, *right, *core;
	uint64_t level;
	if (!universe_identity(typing, family, &left, &right, &level)) return NULL;
	switch (side) {
	case PG_IDENTITY_LEFT_TYPE: core = left; break;
	case PG_IDENTITY_RIGHT_TYPE: core = right; break;
	default: return NULL;
	}
	const struct pg_term *sort = pg_universe(typing->graph, level);
	if (!sort) return NULL;
	const struct pg_occurrence *subject = pg_occurrence(typing, PG_JUDGEMENT_VALUE_TYPE, pg_evidence_context(family),
		core, sort, NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(family)});
	if (!subject) return NULL;
	return accept(typing, side, pg_evidence_context(family),
		subject, 0, NULL);
}

const struct pg_evidence *pg_prove_identity_instance(struct pg_typing *typing,
	const struct pg_evidence *family,
	const struct pg_evidence *left, const struct pg_evidence *right)
{
	const struct pg_term *left_type, *right_type;
	uint64_t level;
	if (!universe_identity(typing, family, &left_type, &right_type, &level)) return NULL;
	if (!endpoint(typing, left, PG_JUDGEMENT_VALUE, pg_evidence_context(family), left_type)) return NULL;
	if (!endpoint(typing, right, PG_JUDGEMENT_VALUE, pg_evidence_context(family), right_type)) return NULL;
	const struct pg_term *core = pg_identity_instance(typing->graph, pg_evidence_subject(family)->core,
		pg_evidence_subject(left)->core, pg_evidence_subject(right)->core);
	if (!core) return NULL;
	const struct pg_term *sort = pg_universe(typing->graph, level);
	if (!sort) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(family), pg_evidence_subject(left), pg_evidence_subject(right)};
	const struct pg_occurrence *subject = pg_occurrence(typing, PG_JUDGEMENT_VALUE_TYPE, pg_evidence_context(family), core, sort, NULL, 3, operands);
	if (!subject) return NULL;
	return accept(typing, PG_IDENTITY_INSTANCE, pg_evidence_context(family),
		subject, 0, NULL);
}

const struct pg_evidence *pg_prove_reflexivity(struct pg_typing *typing,
	const struct pg_evidence *type, const struct pg_evidence *term)
{
	const struct pg_evidence *identity = pg_prove_identity_type(typing, type, term, term);
	if (!identity) return NULL;
	const struct pg_term *core = pg_identity_action(typing->graph, pg_evidence_subject(term)->core);
	if (!core) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, pg_evidence_judgement(term), core, pg_evidence_subject(identity), NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(term)});
	if (!subject) return NULL;
	return accept(typing, PG_REFLEXIVITY, pg_evidence_context(term),
		subject, 0, NULL);
}

const struct pg_evidence *pg_prove_identity_transport(struct pg_typing *typing,
	const struct pg_evidence *family,
	const struct pg_evidence *value, enum pg_identity_direction direction)
{
	if ((unsigned)direction > PG_IDENTITY_LEFT) return NULL;
	const struct pg_term *left, *right;
	uint64_t level;
	if (!universe_identity(typing, family, &left, &right, &level)) return NULL;
	const struct pg_term *domain = direction == PG_IDENTITY_RIGHT ? left : right;
	if (!endpoint(typing, value, PG_JUDGEMENT_VALUE, pg_evidence_context(family), domain)) return NULL;
	const struct pg_evidence *target = pg_prove_identity_endpoint_type(typing, family,
		direction == PG_IDENTITY_RIGHT ? PG_IDENTITY_RIGHT_TYPE : PG_IDENTITY_LEFT_TYPE);
	if (!target) return NULL;
	const struct pg_term *core = pg_identity_transport(typing->graph, pg_evidence_subject(family)->core, pg_evidence_subject(value)->core, direction);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(family), pg_evidence_subject(value)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_VALUE, core, pg_evidence_subject(target), NULL, 2, operands);
	if (!subject) return NULL;
	return accept(typing, PG_IDENTITY_TRANSPORT, pg_evidence_context(family),
		subject, 0, NULL);
}

const struct pg_evidence *pg_prove_identity_lift(struct pg_typing *typing,
	const struct pg_evidence *family,
	const struct pg_evidence *value, enum pg_identity_direction direction)
{
	const struct pg_evidence *transport = pg_prove_identity_transport(typing, family, value, direction);
	if (!transport) return NULL;
	const struct pg_evidence *left = direction == PG_IDENTITY_RIGHT ? value : transport;
	const struct pg_evidence *right = direction == PG_IDENTITY_RIGHT ? transport : value;
	const struct pg_evidence *type = pg_prove_identity_instance(typing, family, left, right);
	if (!type) return NULL;
	const struct pg_term *core = pg_identity_lift(typing->graph, pg_evidence_subject(family)->core, pg_evidence_subject(value)->core, direction);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(family), pg_evidence_subject(value)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_VALUE, core, pg_evidence_subject(type), NULL, 2, operands);
	if (!subject) return NULL;
	return accept(typing, PG_IDENTITY_LIFT, pg_evidence_context(family),
		subject, 0, NULL);
}

const struct pg_evidence *pg_prove_thunk_type(struct pg_typing *typing,
	const struct pg_evidence *computation_type)
{
	return unary_formation(typing, computation_type, PG_THUNK_TYPE_FORM, PG_TOTALITY_UNSPECIFIED, NULL);
}

const struct pg_evidence *pg_prove_pi(struct pg_typing *typing,
	const struct pg_evidence *extended_context,
	const struct pg_evidence *codomain)
{
	if (!context_proof(typing, extended_context)) return NULL;
	const struct pg_context *scope = pg_evidence_context(extended_context);
	if (!scope) return NULL;
	if (!pg_evidence_owned_by(codomain, typing)) return NULL;
	if (pg_evidence_judgement(codomain) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(codomain) != scope) return NULL;
	const struct pg_occurrence *subject = pg_function_binding(typing, extended_context,
		pg_evidence_subject(codomain), PG_JUDGEMENT_COMPUTATION_TYPE);
	if (!subject) return NULL;
	return accept_record(typing, PG_PI_FORM,
		scope->parent, subject, 0, NULL, pg_evidence_scope(extended_context), NULL);
}

static const struct pg_evidence *unary_term(struct pg_typing *typing,
	const struct pg_evidence *argument, const struct pg_object *operation,
	const struct pg_evidence *type, enum pg_evidence_rule rule,
	enum pg_evidence_judgement judgement)
{
	if (!type) return NULL;
	const struct pg_term *term = pg_application(typing->graph,
		pg_reference(typing->graph, operation), pg_evidence_subject(argument)->core);
	if (!term) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, judgement,
		term, pg_evidence_subject(type), NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(argument)});
	if (!subject) return NULL;
	return accept(typing, rule, pg_evidence_context(argument), subject, 0, NULL);
}

const struct pg_evidence *pg_prove_return(struct pg_typing *typing,
	const struct pg_evidence *value)
{
	return pg_prove_return_contract(typing, PG_TOTALITY_UNSPECIFIED, value);
}

const struct pg_evidence *pg_prove_return_contract(struct pg_typing *typing,
	enum pg_totality totality,
	const struct pg_evidence *value)
{
	if (!pg_evidence_owned_by(value, typing)) return NULL;
	if (pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return NULL;
	const struct pg_evidence *type = pg_prove_computation_type(typing, totality,
		pg_effect_row(typing->graph, 0, NULL), formed_classifier(typing, value));
	if (!type) return NULL;
	return unary_term(typing, value, &pg_return_operation,
		type, PG_RETURN_INTRO, PG_JUDGEMENT_COMPUTATION);
}

const struct pg_evidence *pg_prove_thunk(struct pg_typing *typing,
	const struct pg_evidence *computation)
{
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	return unary_term(typing, computation, &pg_thunk_operation,
		pg_prove_thunk_type(typing, formed_classifier(typing, computation)), PG_THUNK_INTRO, PG_JUDGEMENT_VALUE);
}

const struct pg_evidence *pg_prove_force(struct pg_typing *typing, const struct pg_evidence *value)
{
	if (!pg_evidence_owned_by(value, typing)) return NULL;
	if (pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return NULL;
	const struct pg_term *classifier;
	if (!pg_thunk_type_view(pg_evidence_subject(value)->classifier, &classifier)) return NULL;
	return unary_term(typing, value, &pg_force_operation,
		pg_prove_thunk_content(typing, formed_classifier(typing, value)), PG_FORCE_ELIM, PG_JUDGEMENT_COMPUTATION);
}

const struct pg_evidence *pg_prove_lambda(struct pg_typing *typing,
	const struct pg_evidence *pi, const struct pg_evidence *body)
{
	if (!pg_evidence_owned_by(pi, typing)) return NULL;
	if (pg_evidence_judgement(pi) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (!pg_evidence_owned_by(body, typing)) return NULL;
	if (pg_evidence_judgement(body) != PG_JUDGEMENT_COMPUTATION) return NULL;
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(pi)->core, &domain, &binder, &codomain)) return NULL;
	const struct pg_occurrence *input = pg_occurrence_scoped_input(pg_evidence_subject(pi), 1);
	if (!input || input->context != pg_evidence_context(body)) return NULL;
	if (pg_alpha_equal(input->context->declared_type, domain) != 1) return NULL;
	if (pg_alpha_equal(pg_evidence_subject(body)->classifier, codomain) != 1) return NULL;
	const struct pg_term *term = pg_lambda(typing->graph, binder, pg_evidence_subject(body)->core);
	if (!term) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, term, pg_evidence_subject(pi), domain, 1, (const struct pg_occurrence *[]){pg_evidence_subject(body)});
	if (!subject) return NULL;
	return accept(typing, PG_LAMBDA_INTRO,
		pg_evidence_context(pi), subject, 0, NULL);
}

const struct pg_evidence *pg_prove_abstract(struct pg_typing *typing,
	const struct pg_evidence *prefix,
	const struct pg_evidence *context, const struct pg_evidence *body)
{
	if (!context_proof(typing, prefix) || !context_proof(typing, context)) return NULL;
	if (!pg_evidence_owned_by(body, typing) || pg_evidence_judgement(body) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_context(body) != pg_evidence_context(context)) return NULL;
	const struct pg_evidence *type = pg_prove_classifier(typing, context, body);
	if (!type) return NULL;
	while (pg_evidence_context(context) != pg_evidence_context(prefix)) {
		if (pg_evidence_rule(context) != PG_CONTEXT_EXTEND && pg_evidence_rule(context) != PG_CONTEXT_FAMILY_EXTEND) return NULL;
		type = pg_prove_pi(typing, context, type);
		body = pg_prove_lambda(typing, type, body);
		if (!body) return NULL;
		context = pg_context_parent_input(typing, context);
	}
	return body;
}

/* Align a scoped input with readback's binder using the same lifted context
 * action as ordinary substitution. Free bindings are never alpha-renamed. */
static int typed_input_align(struct pg_typed_query *work, const struct pg_evidence *input,
	const struct pg_term *head)
{
	struct typed_input_query *local = pg_typed_query_state(work);
	const struct pg_occurrence *child = pg_evidence_subject(input);
	const struct pg_term *body;
	const struct pg_object *binder = pg_occurrence_input_binder(head, work->ordinal, &body);
	if (!binder || !child->context || child->context->binder == binder) {
		local->argument = input;
		return 1;
	}
	if (child->context->parent != local->current->context) return -1;
	if (!local->lift) {
		const struct pg_evidence *scope = pg_evidence_for_context(pg_typed_query_typing(work), child->context);
		const struct pg_evidence *parent = pg_context_parent_input(pg_typed_query_typing(work), scope);
		const struct pg_evidence *identity = pg_prove_substitution_projection(pg_typed_query_typing(work), parent, parent);
		local->lift = pg_substitution_lift_request(pg_typed_query_typing(work), identity, scope, binder);
	}
	int checked = pg_typed_query_advance(local->lift, 1);
	if (checked <= 0) return checked;
	const struct pg_evidence *map = pg_typed_query_result(local->lift);
	if (!map) return -1;
	if (!local->action) local->action = pg_occurrence_action_request(pg_typed_query_typing(work),
		pg_evidence_context_map(map), child);
	enum pg_substitution_status status = pg_occurrence_action_advance(local->action, 1);
	if (status == PG_SUBSTITUTION_PENDING) return 0;
	if (status == PG_SUBSTITUTION_ERROR) return -1;
	local->argument = pg_prove_reindex(pg_typed_query_typing(work), map, input);
	return local->argument ? 1 : -1;
}

/* Reinstantiate a dependent field's declared type with the current preceding
 * fields. Their retained reductions justify conversion of the old instance;
 * checking the new substitution remains the ordinary dependent map rule. */
static struct pg_reduced_binding typed_field_binding(const void *owner, size_t i)
{
	const struct typed_field *field = owner;
	if (i < field->prefix)
		return (struct pg_reduced_binding){.binding = pg_binding_input(
			pg_context_map_bindings(pg_evidence_context_map(field->map)), i)};
	i -= field->prefix;
	return (struct pg_reduced_binding){
		.binding = {pg_evidence_context(field->declarations[i])->binder, field->inputs[i].original->core},
		.reduction = field->inputs[i].reduction};
}

static int typed_field_step(struct pg_typed_query *work)
{
	struct typed_input_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	if (!local->field) {
		if (!work->ordinal) return 1;
		struct constructor_structure view;
		int constructor = constructor_view(typing, pg_prove_structural_subject(typing, local->current), &view);
		if (constructor <= 0) return constructor ? -1 : 1;
		if (work->ordinal >= view.count) return -1;
		const struct pg_evidence *family = pg_prove_reindex(typing, view.parameters, view.formation);
		if (!family) return -1;
		const struct pg_evidence *self = pg_evidence_judgement(family) == PG_JUDGEMENT_TYPE_FAMILY
			? family : pg_prove_type_value(typing, family);
		const struct pg_evidence *map = pg_prove_substitution_pair(typing, view.parameters,
			pg_evidence_premise(view.formation, 0), self);
		if (!map) return -1;
		struct typed_field *field = pg_alloc(typing->graph, sizeof(*field));
		if (!field) return -1;
		*field = (struct typed_field){.map = map, .prefix = pg_evidence_context_map(map)->count};
		if (work->ordinal >= SIZE_MAX / sizeof(*field->declarations) ||
			work->ordinal > SIZE_MAX / sizeof(*field->inputs) ||
			field->prefix > SIZE_MAX - work->ordinal) return -1;
		field->declarations = pg_alloc(typing->graph, (work->ordinal + 1) * sizeof(*field->declarations));
		field->inputs = pg_alloc(typing->graph, work->ordinal * sizeof(*field->inputs));
		if (!field->declarations || !field->inputs) return -1;
		const struct pg_evidence *scope = pg_data_schema_fields(evidence_certificate(view.formation), view.constructor);
		for (size_t i = view.count; i; --i, scope = pg_context_parent_input(typing, scope))
			if (i <= work->ordinal + 1) field->declarations[i - 1] = scope;
		local->field = field;
		work->dependency = NULL;
	}
	struct typed_field *field = local->field;
	if (field->next < work->ordinal) {
		if (!work->dependency) {
			const struct pg_occurrence *blocked = pg_occurrence_input_blocked_source(local->input);
			work->dependency = pg_typed_input_request(typing, pg_prove_structural_subject(typing, blocked), field->next);
			return work->dependency ? 0 : -1;
		}
		if (!work->dependency->status) return 0;
		const struct pg_evidence *value = pg_typed_query_result(work->dependency);
		const struct pg_occurrence *original;
		if (!value || !structural_input(typing, local->current, field->next, &original) || !original) return -1;
		const struct pg_evidence *declaration = field->declarations[field->next];
		const struct typed_input_query *selected = pg_typed_query_state(work->dependency);
		field->inputs[field->next] = (struct typed_field_input){original, selected->input_reduction};
		field->map = pg_prove_substitution_pair(typing, field->map, declaration, value);
		if (!field->map) return -1;
		++field->next;
		work->dependency = NULL;
		return 0;
	}
	const struct pg_evidence *declared_type = pg_context_declared_input(typing, field->declarations[work->ordinal]);
	const struct pg_evidence *type = pg_prove_reindex(typing, field->map, declared_type);
	if (!type) return -1;
	const struct pg_term *left = pg_evidence_classifier(local->value), *right = pg_evidence_subject(type)->core;
	if (pg_alpha_equal(left, right) == 1) return 1;
	const struct pg_conversion_certificate *conversion = pg_conversion_substitution(&typing->substitutions,
		left, right, pg_evidence_subject(declared_type)->core, field->prefix + work->ordinal, field, typed_field_binding);
	local->value = pg_prove_conversion(typing, local->value, type, conversion);
	return local->value ? 1 : -1;
}

static int typed_input_step(struct pg_typed_query *work)
{
	struct typed_input_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_occurrence *source = typed_source(work);
	if (local->resume == TYPED_RESUME_SCOPE_IMAGE) {
		struct typed_selection *state = local->selection;
		int status = scope_image_step(work, &state->body, &state->cursor);
		if (status <= 0) return status < 0 ? 1 : 0;
		local->value = state->body;
		local->resume = TYPED_RESUME_NONE;
		return 0;
	}
	if (local->value) {
		int status = local->reduction ? typed_field_step(work) : 1;
		if (status <= 0) return status;
		local->input = pg_occurrence_input_resume_request(typing, local->input, pg_evidence_subject(local->value));
		local->value = NULL;
		work->dependency = NULL;
		return local->input ? 0 : -1;
	}
	if (!work->dependency) {
		if (!local->input) local->input = pg_occurrence_input_request(typing, source, work->ordinal);
		enum pg_occurrence_input_status status = pg_occurrence_input_advance(local->input, 1);
		if (status == PG_INPUT_PENDING) return 0;
		if (status == PG_INPUT_ERROR) return -1;
		work->result = pg_prove_structural_subject(typing, pg_occurrence_input_result(local->input));
		if (work->result) return 1;
		const struct pg_occurrence *blocked = pg_occurrence_input_blocked_source(local->input);
		if (!blocked) return 1;
		if (blocked->selection) {
			work->dependency = selection_request(typing, blocked, NULL);
			local->resume = TYPED_RESUME_SELECTION;
			return work->dependency ? 0 : -1;
		}
		local->reduction = subject_normalization(typing, blocked);
		if (!local->reduction) return 1;
		const struct pg_reduction_phase *phase = pg_reduction_head_congruence(local->reduction);
		const struct pg_evidence *origin = pg_prove_structural_subject(typing, blocked->origin);
		local->current = blocked->origin;
		const struct pg_reduction_phase *last = pg_reduction_phases(local->reduction);
		if (!phase && last && last->previous) {
			work->dependency = typed_phase_request(typing, blocked->origin, last->previous);
			local->reduction = last->head;
			local->resume = TYPED_RESUME_PHASE;
		} else if (phase && pg_reduction_source(phase->head) == pg_reduction_target(phase->head))
			work->dependency = pg_typed_input_request(typing, origin, work->ordinal);
		else {
			work->dependency = typed_head_request(typing, origin, phase ? phase->head : local->reduction);
			local->resume = TYPED_RESUME_INPUT;
		}
		return work->dependency ? 0 : -1;
	}
	if (!work->dependency->status) return 0;
	if (work->dependency->status < 0) {
		/* Checked exposure may be unavailable even for an accepted type.
		 * Inversion can still use its own rule; no child is fabricated. */
		switch (local->resume) {
		case TYPED_RESUME_INPUT: case TYPED_RESUME_SELECTION: case TYPED_RESUME_SELECTED_INPUT:
			return 1;
		default: return -1;
		}
	}
	const struct pg_evidence *input = work->dependency->result;
	if (!input) return 1;
	if (local->resume == TYPED_RESUME_SELECTION) {
		local->selection = pg_alloc(typing->graph, sizeof(*local->selection));
		if (!local->selection) return -1;
		const struct typed_selection_query *selected = pg_typed_query_state(work->dependency);
		local->selection->frames.first = selected->selection->frames.first;
		local->current = pg_evidence_subject(input);
		work->dependency = pg_typed_input_request(typing, input, work->ordinal);
		local->resume = TYPED_RESUME_SELECTED_INPUT;
		return work->dependency ? 0 : -1;
	}
	if (local->resume == TYPED_RESUME_SELECTED_INPUT) {
		struct typed_selection *state = local->selection;
		if (!state->child) {
			state->child = pg_evidence_subject(input);
			if (state->child->context != local->current->context) {
				if (pg_occurrence_scoped_input(local->current, work->ordinal) != state->child) return 1;
				const struct pg_occurrence *blocked = pg_occurrence_input_blocked_source(local->input);
				const struct pg_term *body;
				state->binder = pg_occurrence_input_binder(blocked->core, work->ordinal, &body);
				state->extended = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, state->child->context);
				if (!state->binder || !state->extended) return 1;
				state->cursor = state->frames.first;
				state->body = input;
			}
		}
		if (state->extended) {
			int status = selection_lift_step(typing, state);
			if (status <= 0) return status;
		}
		if (state->body) local->value = state->body;
		else {
			state->body = input;
			state->cursor = state->frames.first;
			work->dependency = NULL;
			local->resume = TYPED_RESUME_SCOPE_IMAGE;
		}
		return 0;
	}
	if (local->resume == TYPED_RESUME_PHASE) {
		local->current = pg_evidence_subject(input);
		work->dependency = typed_head_request(typing, input, local->reduction);
		local->resume = TYPED_RESUME_INPUT;
		return work->dependency ? 0 : -1;
	}
	if (local->resume == TYPED_RESUME_INPUT) {
		const struct pg_reduction_phase *phase = pg_reduction_head_congruence(local->reduction);
		const struct pg_occurrence *blocked = pg_occurrence_input_blocked_source(local->input);
		const struct pg_term *head = pg_reduction_target(phase ? phase->head : local->reduction);
		/* Scoped children are subsequently transported to readback's binders;
		 * alpha comparison here cannot change any free variable. */
		if (pg_alpha_equal(pg_evidence_subject(input)->core, head) != 1 ||
			pg_evidence_context(input) != blocked->context) return 1;
		local->current = pg_evidence_subject(input);
		work->dependency = pg_typed_input_request(typing, input, work->ordinal);
		local->resume = TYPED_RESUME_NONE;
		return work->dependency ? 0 : -1;
	}
	if (!local->argument) {
		const struct pg_reduction_phase *phase = pg_reduction_head_congruence(local->reduction);
		int status = typed_input_align(work, input, pg_reduction_target(phase ? phase->head : local->reduction));
		if (status <= 0) return status < 0 ? 1 : 0;
	}
	input = local->argument;
	/* Follow the semantic input boundary along the erased APP spine,
	 * one congruence phase per transition, not arbitrary descendants. */
	const struct pg_reduction_phase *phase = pg_reduction_head_congruence(local->reduction);
	if (!phase) {
		if (pg_alpha_equal(local->current->core, pg_reduction_target(local->reduction)) != 1) return 1;
		local->value = input;
		return 0;
	}
	if (pg_reduction_source(phase->head) != pg_reduction_target(phase->head) &&
		pg_alpha_equal(local->current->core, pg_reduction_target(phase->head)) != 1) return 1;
	const struct pg_term *core = pg_evidence_subject(input)->core;
	const struct pg_reduction_certificate *child = NULL;
	if (pg_alpha_equal(pg_reduction_source(phase->children[0]), core) == 1) child = phase->children[0];
	else if (phase->children[1] && pg_alpha_equal(pg_reduction_source(phase->children[1]), core) == 1) child = phase->children[1];
	else {
		const struct pg_term *head = pg_reduction_target(phase->head), *body;
		if (head->kind != PG_APPLICATION) return 1;
		const struct pg_object *binder = pg_occurrence_input_binder(head, work->ordinal, &body);
		/* Pi's semantic codomain is beneath its right-hand Lambda, not
		 * the erased APP's left spine. Its scope was aligned above. */
		local->reduction = binder ? phase->children[1] : phase->children[0];
		if (!local->reduction) return 1;
		return 0;
	}
	local->value = pg_prove_normalization(typing, input, child);
	if (!local->value) return 1;
	local->input_reduction = child;
	return 0;
}

static int structural_input(struct pg_typing *typing, const struct pg_occurrence *source,
	size_t index, const struct pg_occurrence **result)
{
	struct pg_typed_query *work = pg_typed_input_request(typing, pg_prove_structural_subject(typing, source), index);
	int status;
	do status = pg_typed_query_advance(work, 1024); while (!status);
	const struct pg_evidence *proof = pg_typed_query_result(work);
	*result = proof ? pg_evidence_subject(proof) : NULL;
	return status > 0;
}

/* Keep the parent when its selected Universe bound differs from the child's.
 * A boundary alone would lose the formation justifying that larger bound. */
static const struct pg_occurrence *content_subject(struct pg_typing *typing,
	const struct pg_occurrence *source, const struct pg_term *core,
	const struct pg_term *classifier, enum pg_evidence_judgement judgement)
{
	const struct pg_occurrence *child;
	if (!structural_input(typing, source, 0, &child)) return NULL;
	if (child && child->context == source->context && child->core == core &&
		child->judgement == judgement && child->classifier == classifier) return child;
	return pg_occurrence_selected(typing, source, 0, NULL, judgement, core, classifier);
}

/* Inversion uses an accepted judgement, never an untyped constructor spine. */
static const struct pg_evidence *unary_term_content(struct pg_typing *typing,
	const struct pg_evidence *proof, const struct pg_occurrence *child)
{
	if (!pg_evidence_owned_by(proof, typing)) return NULL;
	const struct pg_object *operation;
	const struct pg_term *classifier;
	enum pg_evidence_rule rule;
	enum pg_evidence_judgement judgement;
	if (pg_evidence_judgement(proof) == PG_JUDGEMENT_COMPUTATION) {
		const struct pg_effect_row *effects;
		enum pg_totality totality;
		if (!pg_computation_type_view(pg_evidence_classifier(proof), &totality, &effects, &classifier) || pg_effect_count(effects)) return NULL;
		operation = &pg_return_operation;
		rule = PG_RETURN_VALUE;
		judgement = PG_JUDGEMENT_VALUE;
	} else if (pg_evidence_judgement(proof) == PG_JUDGEMENT_VALUE) {
		if (!pg_thunk_type_view(pg_evidence_classifier(proof), &classifier)) return NULL;
		operation = &pg_thunk_operation;
		rule = PG_THUNK_COMPUTATION;
		judgement = PG_JUDGEMENT_COMPUTATION;
	} else return NULL;
	const struct pg_term *core = pg_evidence_subject(proof)->core;
	if (core->kind != PG_APPLICATION) return NULL;
	const struct pg_term *head = core->as.application.function;
	if (head->kind != PG_REFERENCE || head->as.reference != operation) return NULL;
	/* Inverting an accepted unary result does not require reconstructing
	 * the redex which produced it. Retain a checked structural child when
	 * available, but never query this result recursively to invent one. */
	const struct pg_occurrence *subject;
	if (child && child->context == pg_evidence_context(proof) &&
		child->core == core->as.application.argument && child->judgement == judgement)
		subject = pg_occurrence_boundary(typing, child, judgement, classifier);
	else subject = pg_occurrence_derived(typing, pg_evidence_subject(proof),
		judgement, core->as.application.argument, classifier);
	if (!subject) return NULL;
	if (!subject->type && !pg_evidence_for_subject(typing, subject, NULL)) {
		const struct pg_evidence *formation = formed_classifier(typing, proof);
		formation = operation == &pg_return_operation ? pg_prove_return_content(typing, formation)
			: pg_prove_thunk_content(typing, formation);
		if (!formation) return NULL;
		struct pg_occurrence header = *subject;
		header.type = pg_evidence_subject(formation);
		header.classifier = header.type->core;
		subject = pg_occurrence_intern(typing, &header, subject->operands, pg_occurrence_maps(subject));
		if (!subject) return NULL;
	}
	const struct pg_evidence *checked = pg_evidence_for_subject(typing, subject, NULL);
	if (checked) return checked;
	return accept(typing, rule, pg_evidence_context(proof), subject, 1, &proof);
}

const struct pg_evidence *pg_prove_return_value(struct pg_typing *typing,
	const struct pg_evidence *computation)
{
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	const struct pg_occurrence *child;
	if (!structural_input(typing, pg_evidence_subject(computation), 0, &child)) return NULL;
	return unary_term_content(typing, computation, child);
}

const struct pg_evidence *pg_prove_thunk_computation(struct pg_typing *typing,
	const struct pg_evidence *value)
{
	if (!pg_evidence_owned_by(value, typing)) return NULL;
	if (pg_evidence_judgement(value) != PG_JUDGEMENT_VALUE) return NULL;
	const struct pg_occurrence *child;
	if (!structural_input(typing, pg_evidence_subject(value), 0, &child)) return NULL;
	return unary_term_content(typing, value, child);
}

const struct pg_evidence *pg_prove_total_pure_value(struct pg_typing *typing,
	const struct pg_evidence *computation)
{
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	const struct pg_term *type;
	const struct pg_effect_row *effects;
	enum pg_totality totality;
	if (!pg_computation_type_view(pg_evidence_subject(computation)->classifier, &totality, &effects, &type)) return NULL;
	if (totality != PG_TOTALITY_TOTAL || pg_effect_count(effects)) return NULL;
	const struct pg_term *core = pg_application(typing->graph,
		pg_reference(typing->graph, &pg_total_result_operation), pg_evidence_subject(computation)->core);
	if (!core) return NULL;
	const struct pg_evidence *formation = pg_prove_return_content(typing, formed_classifier(typing, computation));
	if (!formation) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_VALUE, core, pg_evidence_subject(formation), NULL, 1, (const struct pg_occurrence *[]){pg_evidence_subject(computation)});
	if (!subject) return NULL;
	return accept(typing, PG_TOTAL_PURE_VALUE,
		pg_evidence_context(computation), subject, 0, NULL);
}

static const struct pg_evidence *application(struct pg_typing *typing,
	const struct pg_evidence *function, const struct pg_evidence *argument,
	const struct pg_occurrence *retained)
{
	if (!pg_evidence_owned_by(function, typing)) return NULL;
	if (!pg_evidence_owned_by(argument, typing)) return NULL;
	if (pg_evidence_judgement(function) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_judgement(argument) != PG_JUDGEMENT_VALUE && pg_evidence_judgement(argument) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (pg_evidence_context(function) != pg_evidence_context(argument)) return NULL;
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(function)->classifier, &domain, &binder, &codomain)) return NULL;
	if (pg_alpha_equal(domain, pg_evidence_subject(argument)->classifier) != 1) return NULL;
	const struct pg_evidence *type = pi_codomain(typing, formed_classifier(typing, function), argument,
		retained ? retained->type : NULL);
	const struct pg_term *term = pg_application(typing->graph, pg_evidence_subject(function)->core, pg_evidence_subject(argument)->core);
	if (!type || !term) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(function), pg_evidence_subject(argument)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, term, pg_evidence_subject(type), NULL, 2, operands);
	if (!subject) return NULL;
	if (retained && subject != retained) return NULL;
	return accept(typing, PG_APP_ELIM,
		pg_evidence_context(function), subject, 0, NULL);
}

const struct pg_evidence *pg_prove_application(struct pg_typing *typing,
	const struct pg_evidence *function, const struct pg_evidence *argument)
{
	return application(typing, function, argument, NULL);
}

const struct pg_evidence *pg_check_application(struct pg_typing *typing,
	const struct pg_evidence *function, const struct pg_evidence *argument,
	const struct pg_occurrence *subject)
{
	if (!subject || !subject->type) return NULL;
	return application(typing, function, argument, subject);
}

int pg_prove_call_telescope(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *computation,
	const struct pg_term *allocation, struct pg_call_telescope *output)
{
	if (!output || !pg_evidence_owned_by(computation, typing) ||
		pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return -1;
	struct pg_call_telescope view = {context, computation,
		pg_prove_classifier(typing, context, computation)};
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	while (view.classifier && pg_pi_view(pg_evidence_subject(view.classifier)->core, &domain, &binder, &codomain)) {
		if (allocation) {
			if (!pg_pi_view(allocation, &domain, &binder, &allocation)) return -1;
		} else binder = pg_binder(typing->graph);
		view.context = pg_prove_context_extension(typing, view.context, binder,
			pg_prove_pi_domain(typing, view.classifier));
		if (!view.context) return -1;
		view.call = pg_prove_application(typing, pg_prove_projection(typing, view.context, view.call),
			pg_prove_variable(typing, view.context, binder));
		view.classifier = pg_prove_classifier(typing, view.context, view.call);
	}
	if (!view.classifier) return -1;
	*output = view;
	return 0;
}

const struct pg_evidence *pg_prove_conversion(struct pg_typing *typing,
	const struct pg_evidence *term, const struct pg_evidence *target_type,
	const struct pg_conversion_certificate *certificate)
{
	if (!certificate) return NULL;
	if (!pg_evidence_owned_by(term, typing)) return NULL;
	if (!pg_evidence_owned_by(target_type, typing)) return NULL;
	if (pg_evidence_context(term) != pg_evidence_context(target_type)) return NULL;
	switch (pg_evidence_judgement(term)) {
	case PG_JUDGEMENT_VALUE:
		target_type = pg_prove_value_type(typing, target_type);
		if (!target_type) return NULL;
		break;
	case PG_JUDGEMENT_COMPUTATION:
		if (pg_evidence_judgement(target_type) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
		break;
	default:
		return NULL;
	}
	if (pg_conversion_left(certificate) != pg_evidence_subject(term)->classifier) return NULL;
	if (pg_conversion_right(certificate) != pg_evidence_subject(target_type)->core) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_reclassified(typing, pg_evidence_subject(term), pg_evidence_subject(target_type));
	if (!subject) return NULL;
	const struct pg_evidence *premises[] = {term, target_type};
	return accept_with_conversion(typing, PG_TYPE_CONVERSION,
		pg_evidence_context(term), subject, 2, premises, certificate);
}

const struct pg_conversion_certificate *pg_evidence_conversion(const struct pg_evidence *evidence)
{
	return pg_evidence_rule(evidence) == PG_TYPE_CONVERSION ? evidence_certificate(evidence) : NULL;
}

const struct pg_reduction_certificate *pg_evidence_normalization(const struct pg_evidence *evidence)
{
	return pg_evidence_rule(evidence) == PG_PURE_NORMALIZATION ? evidence_certificate(evidence) : NULL;
}

const struct pg_evidence *pg_prove_normalization(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_reduction_certificate *certificate)
{
	if (!pg_evidence_owned_by(source, typing) || !certificate) return NULL;
	if (!pg_evidence_subject(source)) return NULL;
	switch (pg_evidence_judgement(source)) {
	case PG_JUDGEMENT_VALUE: case PG_JUDGEMENT_COMPUTATION:
	case PG_JUDGEMENT_VALUE_TYPE: case PG_JUDGEMENT_COMPUTATION_TYPE:
	case PG_JUDGEMENT_TYPE_FAMILY: break;
	default: return NULL;
	}
	if (pg_reduction_policy(certificate) != &pg_pure_policy) return NULL;
	/* Context action and evaluator readback can independently freshen bound
	 * pointers. Alpha conversion preserves the typed source; it does not intern
	 * the two graphs together or change any free binding or classifier. */
	if (pg_alpha_equal(pg_reduction_source(certificate), pg_evidence_subject(source)->core) != 1) return NULL;
	const struct pg_term *target = pg_reduction_target(certificate);
	if (target == pg_evidence_subject(source)->core) return source;
	const struct pg_occurrence *subject = pg_occurrence_derived(typing, pg_evidence_subject(source),
		pg_evidence_judgement(source), target, pg_evidence_subject(source)->classifier);
	if (!subject) return NULL;
	return accept_record(typing, PG_PURE_NORMALIZATION,
		pg_evidence_context(source), subject, 1, &source, certificate, NULL);
}

const struct pg_evidence *pg_prove_normalization_input(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_reduction_certificate *certificate,
	size_t index)
{
	if (!pg_evidence_owned_by(source, typing) || !certificate) return NULL;
	const struct pg_occurrence *subject = pg_evidence_subject(source);
	if (!subject) return NULL;
	if (pg_reduction_policy(certificate) != &pg_pure_policy || pg_reduction_source(certificate) != subject->core) return NULL;
	const struct pg_evidence *normal = pg_prove_normalization(typing, source, certificate);
	struct pg_typed_query *work = pg_typed_input_request(typing, normal, index);
	while (!pg_typed_query_advance(work, 1024)) {}
	return pg_typed_query_result(work);
}

const struct pg_evidence *pg_prove_projection(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *proof)
{
	if (!context_proof(typing, context)) return NULL;
	if (!pg_evidence_owned_by(proof, typing)) return NULL;
	if (pg_evidence_judgement(proof) == PG_JUDGEMENT_CONTEXT) return NULL;
	if (pg_evidence_judgement(proof) == PG_JUDGEMENT_SUBSTITUTION) return NULL;
	if (pg_evidence_context(proof) == pg_evidence_context(context)) return proof;
	const struct pg_evidence *premises[] = {context, proof};
	uint64_t hash;
	const struct pg_evidence *found = find_record(typing, PG_CONTEXT_PROJECTION,
		pg_evidence_context(context), NULL, 2, premises, NULL, &hash);
	if (found) return found;
	const struct pg_occurrence *subject = pg_occurrence_weaken(typing,
		pg_evidence_context(context), pg_evidence_subject(proof));
	if (!subject) return NULL;
	/* Weakening a variable selects its existing native declaration use.
	 * Admit it by that rule instead of inventing a projection with no origin. */
	if (!subject->origin && !subject->map) {
		const struct pg_evidence *variable = subject->core->kind == PG_REFERENCE
			? pg_prove_variable(typing, context, subject->core->as.reference) : NULL;
		return pg_evidence_subject(variable) == subject ? variable : NULL;
	}
	return accept(typing, PG_CONTEXT_PROJECTION,
		pg_evidence_context(context), subject, 2, premises);
}

const struct pg_evidence *pg_prove_substitution_extension(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *destination,
	const struct pg_evidence *prefix,
	size_t count, struct pg_evidence_inputs images)
{
	if (!context_proof(typing, source)) return NULL;
	if (!context_proof(typing, destination)) return NULL;
	if (!pg_evidence_owned_by(prefix, typing) || pg_evidence_rule(prefix) != PG_CONTEXT_SUBSTITUTION) return NULL;
	if (!count && source == pg_evidence_premise(prefix, 0) && destination == pg_evidence_premise(prefix, 1)) return prefix;
	if (count > SIZE_MAX / sizeof(const struct pg_occurrence *) - 3) return NULL;
	const struct pg_evidence *header[] = {source, destination, prefix};
	const struct receipt_segments segments = {3, count, header, NULL, images};
	const struct pg_evidence_inputs inputs = {.owner = &segments, .at = segmented_receipt};
	const struct pg_evidence *result = NULL;
	const struct pg_occurrence **typed_images = NULL;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *image = pg_evidence_input(images, i);
		if (!pg_evidence_owned_by(image, typing)) goto done;
		if (pg_evidence_context(image) != pg_evidence_context(destination)) goto done;
	}
	uint64_t hash;
	result = find_record_inputs(typing, PG_CONTEXT_SUBSTITUTION,
		pg_evidence_context(destination), NULL, count + 3, inputs, prefix, &hash);
	if (result) goto done;
	if (count) {
		typed_images = malloc(count * sizeof(*typed_images));
		if (!typed_images) goto done;
		for (size_t i = 0; i < count; ++i) typed_images[i] = pg_evidence_subject(pg_evidence_input(images, i));
	}
	/* Structural construction is shared with lifting and scoped instantiation;
	 * only this layer checks the supplied receipts and dependent classifiers. */
	const struct pg_context_map *map = pg_context_map_extend(typing, pg_evidence_context_map(prefix),
		pg_evidence_context(source), pg_evidence_context(destination), count, typed_images);
	if (!map) goto done;
	size_t retained = map->count - count;
	struct pg_binding_inputs bindings = pg_context_map_bindings(map);
	/* Every image is available before checking; the declaration chain already
	 * supplies reverse telescope order without a second scope array. */
	const struct pg_context *scope = pg_evidence_context(source);
	for (size_t i = count; i; --i, scope = scope->parent) {
		const struct pg_evidence *image = pg_evidence_input(images, i - 1);
		if (pg_evidence_judgement(image) != scope->judgement) goto done;
		const struct pg_term *expected = pg_substitution_compute(&typing->substitutions,
			scope->declared_type, retained + i - 1, bindings);
		if (!expected) goto done;
		if (pg_alpha_equal(expected, pg_evidence_subject(image)->classifier) != 1) goto done;
	}
	/* The old prefix receipt justified these images indirectly. The native
	 * map exports the actual projected images, so admit those exact objects
	 * with the existing structural rule before publishing the map. */
	for (size_t i = 0; i < retained; ++i)
		if (!pg_prove_structural_subject(typing, map->images[i])) goto done;
	result = accept_record_inputs(typing, PG_CONTEXT_SUBSTITUTION,
		pg_evidence_context(destination), NULL, count + 3, inputs, prefix, map);
done:
	free(typed_images);
	return result;
}

const struct pg_context_map *pg_evidence_context_map(const struct pg_evidence *evidence)
{
	return evidence && pg_evidence_judgement(evidence) == PG_JUDGEMENT_SUBSTITUTION ? (const void *)evidence : NULL;
}

const struct pg_evidence *pg_substitution_image(struct pg_typing *typing,
	const struct pg_evidence *substitution, const struct pg_object *binder)
{
	if (!pg_evidence_owned_by(substitution, typing)) return NULL;
	if (pg_evidence_rule(substitution) != PG_CONTEXT_SUBSTITUTION) return NULL;
	const struct pg_context_map *map = pg_evidence_context_map(substitution);
	size_t index;
	return pg_context_map_lookup(map, binder, &index)
		? pg_substitution_image_at(typing, substitution, index) : NULL;
}

/* Images belong to the typed map, not its history of prefix extensions. */
static int substitution_image_range(struct pg_typing *typing,
	const struct pg_evidence *substitution, size_t first, size_t count,
	const struct pg_evidence **images)
{
	if (!pg_evidence_owned_by(substitution, typing) || pg_evidence_rule(substitution) != PG_CONTEXT_SUBSTITUTION) return -1;
	const struct pg_context_map *map = pg_evidence_context_map(substitution);
	if (first > map->count || count > map->count - first) return -1;
	for (size_t i = 0; i < count; ++i) {
		images[i] = pg_prove_structural_subject(typing, map->images[first + i]);
		if (!images[i]) return -1;
	}
	return 0;
}

const struct pg_evidence *pg_substitution_image_at(struct pg_typing *typing,
	const struct pg_evidence *substitution, size_t index)
{
	const struct pg_evidence *image;
	return substitution_image_range(typing, substitution, index, 1, &image) ? NULL : image;
}

const struct pg_evidence *const *pg_substitution_images(struct pg_typing *typing,
	const struct pg_evidence *substitution, struct pg_graph *scratch)
{
	if (!pg_evidence_owned_by(substitution, typing) || pg_evidence_rule(substitution) != PG_CONTEXT_SUBSTITUTION) return NULL;
	size_t count = pg_evidence_context_map(substitution)->count;
	if (!scratch || count > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	const struct pg_evidence **images = pg_alloc(scratch, count * sizeof(*images));
	return images && !substitution_image_range(typing, substitution, 0, count, images) ? images : NULL;
}

const struct pg_evidence *pg_prove_substitution(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *destination,
	size_t count, const struct pg_evidence *const *images)
{
	return pg_prove_substitution_inputs(typing, source, destination, count,
		(struct pg_evidence_inputs){.owner = images});
}

const struct pg_evidence *pg_prove_substitution_inputs(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *destination,
	size_t count, struct pg_evidence_inputs images)
{
	if (!context_proof(typing, source) || !context_proof(typing, destination) || count > SIZE_MAX - 2) return NULL;
	const struct pg_evidence *endpoints[] = {source, destination};
	const struct receipt_segments inputs = {.prefix_count = 2, .prefix = endpoints, .count = count, .arguments = images};
	uint64_t hash;
	const struct pg_evidence *known = find_record_inputs(typing, PG_CONTEXT_SUBSTITUTION,
		pg_evidence_context(destination), NULL, count + 2,
		(struct pg_evidence_inputs){.owner = &inputs, .at = segmented_receipt}, NULL, &hash);
	if (known) return known;
	/* A malformed full tuple must not create and admit an unrelated empty
	 * prefix before rejection. Known complete maps already returned above. */
	size_t length;
	if (pg_context_extension_size(pg_evidence_context(source), NULL, &length) || length != count) return NULL;
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *image = pg_evidence_input(images, i);
		if (!pg_evidence_owned_by(image, typing) || !pg_evidence_subject(image) ||
			pg_evidence_context(image) != pg_evidence_context(destination)) return NULL;
	}
	const struct pg_evidence *prefix = pg_prove_substitution_projection(typing,
		pg_prove_empty_context(typing), destination);
	return pg_prove_substitution_extension(typing, source, destination, prefix, count, images);
}

const struct pg_evidence *pg_prove_substitution_projection(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_evidence *destination)
{
	if (!context_proof(typing, source) || !context_proof(typing, destination)) return NULL;
	const struct pg_context_map *map = pg_context_map_projection(typing,
		pg_evidence_context(source), pg_evidence_context(destination));
	if (!map) return NULL;
	const struct pg_occurrence **images = NULL;
	const struct pg_context *declaration = map->source;
	for (size_t i = map->count; i; --i, declaration = declaration->parent) {
		const struct pg_evidence *variable = pg_prove_variable(typing, destination, declaration->binder);
		if (!variable) { free(images); return NULL; }
		if (!images && pg_evidence_subject(variable) != map->images[i - 1]) {
			images = malloc(map->count * sizeof(*images));
			if (!images) return NULL;
			memcpy(images, map->images, map->count * sizeof(*images));
		}
		if (images) images[i - 1] = pg_evidence_subject(variable);
	}
	if (images) {
		map = pg_context_map(typing, map->source, map->destination, map->count, images);
		free(images);
		if (!map) return NULL;
	}
	const struct pg_evidence *premises[] = {source, destination};
	uint64_t hash;
	const struct pg_evidence *found = find_record(typing, PG_CONTEXT_SUBSTITUTION,
		map->destination, NULL, 2, premises, NULL, &hash);
	return found ? found : accept_record(typing, PG_CONTEXT_SUBSTITUTION,
		map->destination, NULL, 2, premises, NULL, map);
}

static int reindex_inputs(const struct pg_typing *typing,
	const struct pg_evidence *substitution, const struct pg_evidence *proof)
{
	if (!pg_evidence_owned_by(substitution, typing)) return 0;
	if (pg_evidence_rule(substitution) != PG_CONTEXT_SUBSTITUTION) return 0;
	if (!pg_evidence_owned_by(proof, typing) || !pg_evidence_subject(proof)) return 0;
	return pg_evidence_context(proof) == pg_evidence_context(pg_evidence_premise(substitution, 0));
}

const struct pg_evidence *pg_reindex_receipt(const struct pg_typing *typing,
	const struct pg_evidence *substitution, const struct pg_evidence *proof)
{
	if (!reindex_inputs(typing, substitution, proof)) return NULL;
	const struct pg_occurrence *result = pg_occurrence_action_cached(typing,
		pg_evidence_context_map(substitution), pg_evidence_subject(proof));
	return pg_evidence_for_subject(typing, result, NULL);
}

const struct pg_evidence *pg_prove_reindex(struct pg_typing *typing,
	const struct pg_evidence *substitution, const struct pg_evidence *proof)
{
	if (!reindex_inputs(typing, substitution, proof)) return NULL;
	const struct pg_evidence *premises[] = {substitution, proof};
	const struct pg_evidence *result = pg_reindex_receipt(typing, substitution, proof);
	if (result) return result;
	struct pg_occurrence_action *action = pg_occurrence_action_request(typing,
		pg_evidence_context_map(substitution), pg_evidence_subject(proof));
	while (pg_occurrence_action_advance(action, UINT64_MAX) == PG_SUBSTITUTION_PENDING) {}
	const struct pg_occurrence *subject = pg_occurrence_action_result(action);
	return subject ? accept(typing, PG_REINDEX, subject->context, subject, 2, premises) : NULL;
}

static int substitution_proof(const struct pg_typing *typing, const struct pg_evidence *proof)
{
	if (!pg_evidence_owned_by(proof, typing)) return 0;
	return pg_evidence_rule(proof) == PG_CONTEXT_SUBSTITUTION;
}

/* Close the varied suffix before substituting the common prefix. One action
 * then consumes every boundary triple; this is not iterated reflexivity. */
static const struct pg_term *family_action_core(struct pg_typing *typing,
	const struct pg_term *abstraction, const struct pg_context *context, const struct pg_evidence *left,
	const struct pg_evidence *right, size_t common, size_t count,
	struct pg_evidence_inputs paths)
{
	for (size_t i = 0; i < count; ++i, context = context->parent)
		abstraction = pg_lambda(typing->graph, context->binder, abstraction);
	struct pg_binding_inputs bindings = pg_context_map_bindings(pg_evidence_context_map(left));
	abstraction = pg_substitution_compute(&typing->substitutions, abstraction, common, bindings);
	if (!abstraction) return NULL;
	const struct pg_term *result = pg_identity_action(typing->graph, abstraction);
	for (size_t i = 0; i < count; ++i) {
		result = pg_identity_instance(typing->graph, result,
			pg_evidence_context_map(left)->images[common + i]->core,
			pg_evidence_context_map(right)->images[common + i]->core);
		result = pg_application(typing->graph, result, pg_evidence_subject(pg_evidence_input(paths, i))->core);
	}
	return result;
}

const struct pg_evidence *pg_prove_family_identity_type(struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_evidence *left_substitution,
	const struct pg_evidence *right_substitution, size_t count,
	struct pg_evidence_inputs paths,
	const struct pg_evidence *left, const struct pg_evidence *right)
{
	if (!pg_evidence_owned_by(family, typing)) return NULL;
	enum pg_evidence_judgement elements;
	switch (pg_evidence_judgement(family)) {
	case PG_JUDGEMENT_VALUE_TYPE: elements = PG_JUDGEMENT_VALUE; break;
	case PG_JUDGEMENT_COMPUTATION_TYPE: elements = PG_JUDGEMENT_COMPUTATION; break;
	default: return NULL;
	}
	if (!substitution_proof(typing, left_substitution)) return NULL;
	if (!substitution_proof(typing, right_substitution)) return NULL;
	if (pg_evidence_context(pg_evidence_premise(left_substitution, 0)) != pg_evidence_context(family)) return NULL;
	if (pg_evidence_context(pg_evidence_premise(right_substitution, 0)) != pg_evidence_context(family)) return NULL;
	const struct pg_context *context = pg_evidence_context(left_substitution);
	if (pg_evidence_context(right_substitution) != context) return NULL;
	size_t arity = pg_evidence_context_map(left_substitution)->count;
	if (pg_evidence_context_map(right_substitution)->count != arity) return NULL;
	if (count > arity) return NULL;
	if (count > SIZE_MAX / sizeof(const void *) - 5) return NULL;
	size_t common = arity - count;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	const struct pg_evidence *prefix[] = {family, left_substitution, right_substitution};
	const struct pg_evidence *suffix[] = {left, right};
	const struct receipt_segments segments = {3, count, prefix, suffix, paths};
	const struct pg_evidence_inputs inputs = {.owner = &segments, .at = segmented_receipt};
	uint64_t hash;
	result = find_record_inputs(typing, PG_FAMILY_IDENTITY_FORM, context, NULL, count + 5, inputs, NULL, &hash);
	if (result) goto done;
	const struct pg_occurrence **operands = pg_alloc(&temporary, (count + 3) * sizeof(*operands));
	const struct pg_context **declarations = pg_alloc(&temporary, count * sizeof(*declarations));
	if (!operands || (count && !declarations)) goto done;
	for (size_t i = 0; i < common; ++i) {
		if (pg_alpha_equal(pg_evidence_context_map(left_substitution)->images[i]->core,
			pg_evidence_context_map(right_substitution)->images[i]->core) != 1) goto done;
	}
	const struct pg_context *declaration = pg_evidence_context(pg_evidence_premise(left_substitution, 0));
	for (size_t i = count; i; --i) {
		declarations[i - 1] = declaration;
		declaration = declaration->parent;
	}
	for (size_t i = 0; i < count; ++i) {
		const struct pg_term *acted = family_action_core(typing, declarations[i]->declared_type, declarations[i]->parent,
			left_substitution, right_substitution, common, i, paths);
		const struct pg_term *path_type = pg_identity_instance(typing->graph, acted,
			pg_evidence_context_map(left_substitution)->images[common + i]->core,
			pg_evidence_context_map(right_substitution)->images[common + i]->core);
		if (!endpoint(typing, pg_evidence_input(paths, i), PG_JUDGEMENT_VALUE, context, path_type)) goto done;
	}
	const struct pg_evidence *ltype = pg_prove_reindex(typing, left_substitution, family);
	const struct pg_evidence *rtype = pg_prove_reindex(typing, right_substitution, family);
	if (!ltype || !rtype) goto done;
	if (!endpoint(typing, left, elements, context, pg_evidence_subject(ltype)->core)) goto done;
	if (!endpoint(typing, right, elements, context, pg_evidence_subject(rtype)->core)) goto done;
	const struct pg_term *acted = family_action_core(typing, pg_evidence_subject(family)->core, pg_evidence_context(family),
		left_substitution, right_substitution, common, count, paths);
	const struct pg_term *core = pg_identity_instance(typing->graph, acted, pg_evidence_subject(left)->core, pg_evidence_subject(right)->core);
	if (!core) goto done;
	operands[0] = pg_evidence_subject(family);
	for (size_t i = 0; i < count; ++i) operands[i + 1] = pg_evidence_subject(pg_evidence_input(paths, i));
	operands[count + 1] = pg_evidence_subject(left);
	operands[count + 2] = pg_evidence_subject(right);
	const struct pg_context_map *maps[] = {pg_evidence_context_map(left_substitution), pg_evidence_context_map(right_substitution)};
	const struct pg_occurrence *subject = pg_occurrence_intern(typing, &(struct pg_occurrence){
		.judgement = pg_evidence_judgement(family), .context = context, .core = core,
		.classifier = pg_evidence_classifier(family), .operand_count = count + 3,
		.map_count = 2}, operands, maps);
	if (!subject) goto done;
	result = accept_record_inputs(typing, PG_FAMILY_IDENTITY_FORM, context,
		subject, count + 5, inputs, NULL, NULL);
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_family_action(struct pg_typing *typing,
	const struct pg_evidence *family, const struct pg_evidence *term,
	const struct pg_evidence *left_substitution,
	const struct pg_evidence *right_substitution, size_t count,
	const struct pg_evidence *const *paths)
{
	if (!pg_evidence_owned_by(family, typing)) return NULL;
	enum pg_evidence_judgement elements;
	switch (pg_evidence_judgement(family)) {
	case PG_JUDGEMENT_VALUE_TYPE: elements = PG_JUDGEMENT_VALUE; break;
	case PG_JUDGEMENT_COMPUTATION_TYPE: elements = PG_JUDGEMENT_COMPUTATION; break;
	default: return NULL;
	}
	if (!endpoint(typing, term, elements, pg_evidence_context(family), pg_evidence_subject(family)->core)) return NULL;
	const struct pg_evidence *left = pg_prove_reindex(typing, left_substitution, term);
	const struct pg_evidence *right = pg_prove_reindex(typing, right_substitution, term);
	const struct pg_evidence *identity = pg_prove_family_identity_type(typing,
		family, left_substitution, right_substitution, count, (struct pg_evidence_inputs){.owner = paths}, left, right);
	if (!identity) return NULL;
	const struct pg_evidence *premises[] = {identity, term};
	uint64_t hash;
	const struct pg_evidence *existing = find_record(typing, PG_FAMILY_ACTION, pg_evidence_context(identity), NULL, 2, premises, NULL, &hash);
	if (existing) return existing;
	const struct pg_term *core = family_action_core(typing, pg_evidence_subject(term)->core, pg_evidence_context(term),
		left_substitution, right_substitution, pg_evidence_context_map(left_substitution)->count - count, count, (struct pg_evidence_inputs){.owner = paths});
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(term), pg_evidence_subject(identity)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, elements,
		core, pg_evidence_subject(identity), NULL, 2, operands);
	if (!subject) return NULL;
	return accept(typing, PG_FAMILY_ACTION, pg_evidence_context(identity),
		subject, 2, premises);
}

const struct pg_evidence *pg_prove_substitution_extend(struct pg_typing *typing,
	const struct pg_evidence *prefix, const struct pg_evidence *source,
	size_t count, const struct pg_evidence *const *values)
{
	if (!pg_evidence_owned_by(prefix, typing) || pg_evidence_rule(prefix) != PG_CONTEXT_SUBSTITUTION) return NULL;
	return pg_prove_substitution_extension(typing, source, pg_evidence_premise(prefix, 1), prefix, count, (struct pg_evidence_inputs){.owner = values});
}

struct context_alpha_frame {
	const struct pg_scope *source;
	const struct pg_evidence *parent, *indices;
	const struct pg_context *target;
	struct context_alpha_frame *previous;
	unsigned stage;
};

const struct pg_evidence *pg_prove_context_alpha(struct pg_typing *typing,
	const struct pg_evidence *source, const struct pg_context *target)
{
	if (!context_proof(typing, source)) return NULL;
	struct pg_graph temporary = {0};
	struct context_alpha_frame root = {.source = pg_evidence_scope(source), .target = target};
	struct context_alpha_frame *frame = &root;
	const struct pg_evidence *result = NULL;
	while (frame) {
		const struct pg_scope *input = frame->source;
		const struct pg_context *from = input ? input->context : NULL, *to = frame->target;
		if (!frame->stage) {
			if (from == to) { result = pg_evidence_for_scope(typing, input); frame = frame->previous; continue; }
			if (!from || !to || from->binder != to->binder || from->judgement != to->judgement) goto fail;
			struct context_alpha_frame *parent = pg_alloc(&temporary, sizeof(*parent));
			if (!parent) goto fail;
			*parent = (struct context_alpha_frame){.source = input->parent,
				.target = to->parent, .previous = frame};
			frame->stage = 1;
			frame = parent;
			continue;
		}
		if (frame->stage == 1) {
			frame->parent = result;
			if (input->indices) {
				struct context_alpha_frame *indices = pg_alloc(&temporary, sizeof(*indices));
				if (!indices) goto fail;
				*indices = (struct context_alpha_frame){.source = input->indices,
					.target = to->indices, .previous = frame};
				frame->stage = 2;
				frame = indices;
				continue;
			}
		} else frame->indices = result;
		const struct pg_evidence *old_scope = pg_evidence_for_scope(typing, input->indices ? input->indices : input->parent);
		const struct pg_evidence *new_scope = frame->indices ? frame->indices : frame->parent;
		const struct pg_evidence *type = pg_prove_structural_subject(typing, input->type);
		if (pg_evidence_context(old_scope) != pg_evidence_context(new_scope))
			type = pg_prove_reindex(typing, pg_prove_telescope_correspondence(typing, old_scope, new_scope), type);
		if (!type) goto fail;
		if (frame->indices)
			result = pg_prove_family_context_extension(typing, frame->parent, to->binder, frame->indices, type);
		else {
			if (pg_evidence_subject(type)->core != to->declared_type)
				type = pg_prove_normalization(typing, type,
					pg_reduction_identity(typing->graph, &pg_pure_policy, to->declared_type));
			result = pg_prove_context_extension(typing, frame->parent, to->binder, type);
		}
		if (!result || pg_evidence_context(result) != to) goto fail;
		frame = frame->previous;
	}
	pg_graph_destroy(&temporary);
	return result;
fail:
	pg_graph_destroy(&temporary);
	return NULL;
}

const struct pg_evidence *pg_prove_substitution_pair(struct pg_typing *typing,
	const struct pg_evidence *substitution, const struct pg_evidence *source_extension,
	const struct pg_evidence *image)
{
	if (!substitution_proof(typing, substitution)) return NULL;
	return pg_prove_substitution_extension(typing, source_extension,
		pg_evidence_premise(substitution, 1), substitution, 1, (struct pg_evidence_inputs){.owner = &image});
}

struct pattern_variable {
	struct pg_index_entry index;
	const struct pg_object *image, *binder;
};

static const struct pattern_variable *pattern_variable(const struct pg_index *index,
	const struct pg_object *image)
{
	for (struct pg_index_entry *p = pg_index_candidates(index, (uintptr_t)image); p; p = p->next) {
		const struct pattern_variable *entry = (const void *)p;
		if (entry->image == image) return entry;
	}
	return NULL;
}

enum pattern_type_phase { PATTERN_TYPE_ENTER, PATTERN_TYPE_RETURN, PATTERN_TYPE_THUNK,
	PATTERN_TYPE_PI, PATTERN_TYPE_PI_DOMAIN, PATTERN_TYPE_ARGUMENTS, PATTERN_TYPE_PARAMETER };

struct pattern_type_frame {
	struct pattern_type_frame *parent;
	const struct pg_evidence *body, *context, *extension;
	const struct pg_effect_row *effects;
	enum pg_totality totality;
	struct pg_inductive_instance instance;
	const struct pg_evidence **images;
	size_t count, parameters, next;
	enum pattern_type_phase phase;
};

/* Invert whole constructor images through F/U, Pi results and nominal type
 * arguments. Rebuild with ordinary formation rules, never raw replacement in
 * a claimed type. The caller checks substitution back to the original body. */
static const struct pg_evidence *pattern_index_type(struct pg_typing *typing,
	const struct pg_evidence *prefix,
	const struct pg_evidence *pattern, const struct pg_evidence *inverse,
	const struct pg_evidence *body)
{
	if (!body) return NULL;
	struct pg_graph temporary = {0};
	const struct pg_evidence *result = NULL;
	struct pattern_type_frame root = {.body = body, .context = pg_evidence_premise(inverse, 1)};
	struct pattern_type_frame *frame = &root;
	while (frame) {
		const struct pg_evidence *child = NULL, *child_context = frame->context;
		if (frame->phase == PATTERN_TYPE_ENTER) {
			const struct pg_term *core = pg_evidence_subject(frame->body)->core, *content, *domain;
			const struct pg_object *binder;
			if (pg_computation_type_view(core, &frame->totality, &frame->effects, &content)) {
				frame->phase = PATTERN_TYPE_RETURN;
				child = pg_prove_return_content(typing, frame->body);
			} else if (pg_thunk_type_view(core, &content)) {
				frame->phase = PATTERN_TYPE_THUNK;
				child = pg_prove_thunk_content(typing, frame->body);
			} else if (pg_pi_view(core, &domain, &binder, &content)) {
				frame->phase = PATTERN_TYPE_PI_DOMAIN;
				child = pg_prove_pi_domain(typing, frame->body);
			} else if (pg_inductive_instance(typing, frame->body, &frame->instance)) {
				frame->phase = PATTERN_TYPE_ARGUMENTS;
				frame->parameters = pg_evidence_context_map(frame->instance.parameters)->count;
				const struct pg_evidence *map = frame->instance.indices
					? frame->instance.indices : frame->instance.parameters;
				frame->count = pg_evidence_context_map(map)->count;
				if (frame->count > SIZE_MAX / sizeof(*frame->images)) goto fail;
				frame->images = pg_alloc(&temporary, frame->count * sizeof(*frame->images));
				if (frame->count && !frame->images) goto fail;
				if (substitution_image_range(typing, map, 0, frame->count, frame->images)) goto fail;
				continue;
			} else {
				result = frame->body;
				frame = frame->parent;
				continue;
			}
			if (!child) goto fail;
		} else if (frame->phase == PATTERN_TYPE_PI_DOMAIN) {
			const struct pg_term *domain, *codomain;
			const struct pg_object *binder;
			if (!pg_pi_view(pg_evidence_subject(frame->body)->core, &domain, &binder, &codomain)) goto fail;
			frame->extension = pg_prove_context_extension(typing, frame->context, binder, result);
			child_context = frame->extension;
			if (!child_context) goto fail;
			/* Independent results need no argument substitution, including
			 * through earlier domains generalized to different index images. */
			const struct pg_evidence *constant = pg_prove_pi_constant_codomain(typing, frame->body);
			if (constant) {
				child = pg_prove_projection(typing, child_context, constant);
			} else if (pg_alpha_equal(domain, pg_evidence_subject(result)->core) == 1) {
				child = pg_prove_pi_codomain(typing,
					pg_prove_projection(typing, child_context, frame->body),
					pg_prove_variable(typing, child_context, binder));
			}
			if (!child) goto fail;
			frame->phase = PATTERN_TYPE_PI;
		} else if (frame->phase <= PATTERN_TYPE_PI) {
			if (frame->phase == PATTERN_TYPE_RETURN) result = pg_prove_computation_type(typing,
				frame->totality, frame->effects, result);
			else if (frame->phase == PATTERN_TYPE_THUNK) result = pg_prove_thunk_type(typing, result);
			else result = pg_prove_pi(typing, frame->extension, result);
			if (!result) goto fail;
			frame = frame->parent;
			continue;
		} else {
			if (frame->phase == PATTERN_TYPE_PARAMETER) {
				frame->images[frame->next - 1] = pg_prove_type_value(typing, result);
				if (!frame->images[frame->next - 1]) goto fail;
				frame->phase = PATTERN_TYPE_ARGUMENTS;
			}
			if (frame->next == frame->count) {
				const struct pg_evidence *parameters = pg_prove_substitution(typing,
					pg_evidence_premise(frame->instance.parameters, 0), frame->context,
					frame->parameters, frame->images);
				result = pg_prove_reindex(typing, parameters, frame->instance.formation);
				for (size_t i = frame->parameters + 1; result && i < frame->count; ++i)
					result = pg_prove_family_application(typing, result, frame->images[i]);
				if (!result) goto fail;
				frame = frame->parent;
				continue;
			}
			size_t i = frame->next++;
			if (i == frame->parameters) continue; /* Rebuild Self from the new parameters. */
			const struct pg_evidence *selected = NULL;
			const struct pg_evidence *extension = pg_evidence_premise(pattern, 0);
			for (size_t j = pg_evidence_context_map(pattern)->count;
				pg_evidence_context(extension) != pg_evidence_context(prefix);
				--j, extension = pg_context_parent_input(typing, extension)) {
				const struct pg_evidence *image = pg_substitution_image_at(typing, pattern, j - 1);
				if (pg_evidence_subject(image)->core->kind == PG_REFERENCE && pg_evidence_subject(image)->core->as.reference->kind == PG_BINDER) continue;
				image = pg_prove_reindex(typing, inverse, image);
				if (!image || pg_alpha_equal(pg_evidence_subject(image)->core, pg_evidence_subject(frame->images[i])->core) != 1) continue;
				if (selected) goto fail;
				selected = pg_prove_variable(typing, frame->context, pg_evidence_context(extension)->binder);
				if (!selected) goto fail;
			}
			if (selected) { frame->images[i] = selected; continue; }
			child = pg_prove_value_type(typing, frame->images[i]);
			if (!child) continue;
			frame->phase = PATTERN_TYPE_PARAMETER;
		}
		struct pattern_type_frame *next = pg_alloc(&temporary, sizeof(*next));
		if (!next) goto fail;
		*next = (struct pattern_type_frame){.parent = frame, .body = child, .context = child_context};
		frame = next;
	}
	pg_graph_destroy(&temporary);
	return result;
fail:
	pg_graph_destroy(&temporary);
	return NULL;
}

const struct pg_evidence *pg_prove_pattern_type(struct pg_typing *typing,
	const struct pg_evidence *prefix,
	const struct pg_evidence *pattern, const struct pg_evidence *body)
{
	if (!typing) return NULL;
	if (!context_proof(typing, prefix) || !substitution_proof(typing, pattern)) return NULL;
	if (!pg_evidence_owned_by(body, typing)) return NULL;
	if (pg_evidence_judgement(body) != PG_JUDGEMENT_COMPUTATION_TYPE || pg_evidence_context(body) != pg_evidence_context(pattern)) return NULL;
	const struct pg_evidence *source = pg_evidence_premise(pattern, 0), *destination = pg_evidence_premise(pattern, 1);
	size_t source_count, destination_count, common;
	if (pg_context_extension_size(pg_evidence_context(source), pg_evidence_context(prefix), &source_count)) return NULL;
	if (pg_context_extension_size(pg_evidence_context(destination), pg_evidence_context(prefix), &destination_count)) return NULL;
	if (pg_context_extension_size(pg_evidence_context(prefix), NULL, &common)) return NULL;
	if (source_count > SIZE_MAX / sizeof(struct pattern_variable)) return NULL;
	if (destination_count > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	struct pg_graph temporary = {0};
	struct pg_index variables = {0};
	const struct pg_evidence *result = NULL;
	struct pattern_variable *entries = pg_alloc(&temporary, source_count * sizeof(*entries));
	const struct pg_evidence **fields = pg_alloc(&temporary, destination_count * sizeof(*fields));
	if ((source_count && !entries) || (destination_count && !fields)) goto done;
	if (pg_index_init(&variables)) goto done;
	const struct pg_evidence *extension = source;
	for (size_t i = source_count; i; --i, extension = pg_context_parent_input(typing, extension)) {
		if (pg_evidence_rule(extension) != PG_CONTEXT_EXTEND) goto done;
		const struct pg_term *image = pg_evidence_context_map(pattern)->images[common + i - 1]->core;
		if (image->kind != PG_REFERENCE || image->as.reference->kind != PG_BINDER) continue;
		if (pattern_variable(&variables, image->as.reference)) goto done;
		entries[i - 1].image = image->as.reference;
		entries[i - 1].binder = pg_evidence_context(extension)->binder;
		if (pg_index_insert(&variables, &entries[i - 1].index, (uintptr_t)image->as.reference)) goto done;
	}
	for (size_t i = common; i; --i, extension = pg_context_parent_input(typing, extension)) {
		const struct pg_object *binder = pg_evidence_context(extension)->binder;
		if (pg_evidence_context_map(pattern)->images[i - 1]->core != pg_reference(typing->graph, binder)) goto done;
		if (pattern_variable(&variables, binder)) goto done;
	}
	extension = destination;
	for (size_t i = destination_count; i; --i, extension = pg_context_parent_input(typing, extension)) {
		if (pg_evidence_rule(extension) != PG_CONTEXT_EXTEND) goto done;
		fields[i - 1] = extension;
	}
	const struct pg_evidence *inverse = pg_prove_substitution_projection(typing, prefix, source);
	for (size_t i = 0; inverse && i < destination_count; ++i) {
		const struct pattern_variable *entry = pattern_variable(&variables, pg_evidence_context(fields[i])->binder);
		if (entry) {
			const struct pg_evidence *image = pg_prove_variable(typing, pg_evidence_premise(inverse, 1), entry->binder);
			const struct pg_evidence *domain = pg_prove_reindex(typing, inverse, pg_context_declared_input(typing, fields[i]));
			if (!image || !domain) goto done;
			if (pg_alpha_equal(pg_evidence_subject(image)->classifier, pg_evidence_subject(domain)->core) == 1) {
				inverse = pg_prove_substitution_pair(typing, inverse, fields[i], image);
				continue;
			}
		}
		/* A dependent field may still mention a constructed index. Retain
		 * it until the inferred type is checked independent of that field. */
		inverse = pg_prove_substitution_lift(typing, inverse, fields[i], pg_binder(typing->graph));
	}
	if (!inverse) goto done;
	result = pg_prove_reindex(typing, inverse, body);
	result = pattern_index_type(typing, prefix, pattern, inverse, result);
	/* Keep every intermediate substitution total and typed. Only then remove
	 * fresh nuisance fields, checking that the result does not depend on them. */
	for (extension = pg_evidence_premise(inverse, 1); result && pg_evidence_context(extension) != pg_evidence_context(source);
		extension = pg_context_parent_input(typing, extension))
		result = pg_prove_pi_constant_codomain(typing,
			pg_prove_pi(typing, extension, result));
	if (result) {
		const struct pg_evidence *instance = pg_prove_reindex(typing, pattern, result);
		if (!instance || pg_alpha_equal(pg_evidence_subject(instance)->core, pg_evidence_subject(body)->core) != 1) result = NULL;
	}
done:
	pg_index_destroy(&variables);
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_thunk_content(struct pg_typing *typing,
	const struct pg_evidence *thunk_type)
{
	thunk_type = pg_prove_value_type(typing, thunk_type);
	if (!thunk_type) return NULL;
	const struct pg_term *content;
	if (!pg_thunk_type_view(pg_evidence_subject(thunk_type)->core, &content)) return NULL;
	const struct pg_occurrence *subject = content_subject(typing, pg_evidence_subject(thunk_type),
		content, pg_evidence_subject(thunk_type)->classifier, PG_JUDGEMENT_COMPUTATION_TYPE);
	return accept_selection(typing, PG_THUNK_CONTENT, thunk_type, subject);
}

const struct pg_evidence *pg_prove_return_content(struct pg_typing *typing,
	const struct pg_evidence *return_type)
{
	if (!pg_evidence_owned_by(return_type, typing)) return NULL;
	if (pg_evidence_judgement(return_type) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	const struct pg_term *content;
	const struct pg_effect_row *effects;
	enum pg_totality totality;
	if (!pg_computation_type_view(pg_evidence_subject(return_type)->core, &totality, &effects, &content)) return NULL;
	const struct pg_occurrence *subject = content_subject(typing, pg_evidence_subject(return_type),
		content, pg_evidence_subject(return_type)->classifier, PG_JUDGEMENT_VALUE_TYPE);
	return accept_selection(typing, PG_RETURN_CONTENT, return_type, subject);
}

const struct pg_evidence *pg_prove_pi_constant_codomain(struct pg_typing *typing,
	const struct pg_evidence *pi)
{
	if (!pg_evidence_owned_by(pi, typing)) return NULL;
	if (pg_evidence_judgement(pi) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	const struct pg_term *codomain = pg_pi_constant_codomain(pg_evidence_subject(pi)->core);
	if (!codomain) return NULL;
	const struct pg_occurrence *subject;
	if (!structural_input(typing, pg_evidence_subject(pi), 1, &subject)) return NULL;
	subject = pg_occurrence_unproject(typing, subject, pg_evidence_context(pi));
	if (subject) {
		if (subject->judgement != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
		if (pg_alpha_equal(subject->core, codomain) != 1) return NULL;
		if (subject->classifier != pg_evidence_classifier(pi)) subject = NULL;
	}
	if (!subject) subject = pg_occurrence_selected(typing, pg_evidence_subject(pi), 1, NULL,
		PG_JUDGEMENT_COMPUTATION_TYPE, codomain, pg_evidence_classifier(pi));
	return accept_selection(typing, PG_PI_CONSTANT_CODOMAIN, pi, subject);
}

const struct pg_object *pg_operation_label_create(struct pg_graph *graph,
	const struct pg_term *payload, const struct pg_term *response)
{
	if (!graph || !payload || !response) return NULL;
	struct operation_label *label = pg_alloc(graph, sizeof(*label));
	if (!label) return NULL;
	*label = (struct operation_label){
		.object = {PG_SEMANTIC_OBJECT, &operation_label_class}, .payload = payload, .response = response};
	return &label->object;
}

int pg_operation_label_types(const struct pg_object *object,
	const struct pg_term **payload, const struct pg_term **response)
{
	if (pg_host_operation_types(object, payload, response)) return 1;
	if (!object || object->owner != &operation_label_class || object->kind != PG_SEMANTIC_OBJECT) return 0;
	if (!payload || !response) return 0;
	const struct operation_label *label = (const void *)object;
	*payload = label->payload;
	*response = label->response;
	return 1;
}

const struct pg_operation_declaration *pg_operation_declaration_at(struct pg_typing *typing,
	const struct pg_object *label, const struct pg_evidence *payload_type,
	const struct pg_evidence *response_type)
{
	const struct pg_term *payload, *response;
	if (!pg_operation_label_types(label, &payload, &response)) return NULL;
	payload_type = pg_prove_value_type(typing, payload_type);
	response_type = pg_prove_value_type(typing, response_type);
	if (!payload_type || !response_type) return NULL;
	if (pg_evidence_context(payload_type) || pg_evidence_context(response_type)) return NULL;
	if (pg_evidence_subject(payload_type)->core != payload || pg_evidence_subject(response_type)->core != response) return NULL;
	struct pg_index *index = &typing->graph->objects;
	if (!index->capacity && pg_index_init(index)) return NULL;
	uint64_t hash = ((uintptr_t)label ^ (uintptr_t)payload_type) * UINT64_C(1099511628211) ^ (uintptr_t)response_type;
	for (struct pg_index_entry *p = pg_index_candidates(index, hash); p; p = p->next) {
		const struct pg_operation_declaration *old = (const void *)p;
		if (old->base.object.owner != &operation_declaration_class) continue;
		if (old->label == label && old->payload_type == payload_type && old->response_type == response_type) return old;
	}
	struct pg_operation_declaration *declaration = pg_alloc(typing->graph, sizeof(*declaration));
	if (!declaration) return NULL;
	*declaration = (struct pg_operation_declaration){
		.base.object = {PG_SEMANTIC_OBJECT, &operation_declaration_class}, .label = label,
		.payload_type = payload_type, .response_type = response_type};
	return pg_index_insert(index, &declaration->base.index, hash) ? NULL : declaration;
}

const struct pg_operation_declaration *pg_operation_declaration(struct pg_typing *typing,
	const struct pg_evidence *payload_type, const struct pg_evidence *response_type)
{
	payload_type = pg_prove_value_type(typing, payload_type);
	response_type = pg_prove_value_type(typing, response_type);
	if (!payload_type || !response_type) return NULL;
	if (pg_evidence_context(payload_type) || pg_evidence_context(response_type)) return NULL;
	return pg_operation_declaration_at(typing, pg_operation_label_create(typing->graph,
		pg_evidence_subject(payload_type)->core, pg_evidence_subject(response_type)->core), payload_type, response_type);
}

const struct pg_evidence *pg_operation_payload_type(const struct pg_operation_declaration *declaration)
{
	return declaration ? declaration->payload_type : NULL;
}

const struct pg_evidence *pg_operation_response_type(const struct pg_operation_declaration *declaration)
{
	return declaration ? declaration->response_type : NULL;
}

const struct pg_object *pg_operation_label(const struct pg_operation_declaration *declaration)
{
	return declaration ? declaration->label : NULL;
}

const struct pg_operation_declaration *pg_evidence_request_declaration(const struct pg_evidence *evidence)
{
	return evidence && pg_evidence_rule(evidence) == PG_REQUEST_INTRO ? evidence_certificate(evidence) : NULL;
}

const struct pg_evidence *pg_prove_request(struct pg_typing *typing,
	const struct pg_operation_declaration *declaration,
	const struct pg_evidence *payload, const struct pg_evidence *continuation)
{
	if (!declaration) return NULL;
	if (!pg_evidence_owned_by(declaration->payload_type, typing)) return NULL;
	if (!pg_evidence_owned_by(declaration->response_type, typing)) return NULL;
	if (!pg_evidence_owned_by(payload, typing)) return NULL;
	if (!pg_evidence_owned_by(continuation, typing)) return NULL;
	if (pg_evidence_judgement(payload) != PG_JUDGEMENT_VALUE) return NULL;
	if (pg_evidence_judgement(continuation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_context(payload) != pg_evidence_context(continuation)) return NULL;
	const struct pg_evidence *premises[] = {declaration->payload_type, declaration->response_type, payload, continuation};
	uint64_t hash;
	const struct pg_evidence *existing = find_record(typing, PG_REQUEST_INTRO, pg_evidence_context(payload), NULL, 4, premises, declaration, &hash);
	if (existing) return existing;
	if (pg_alpha_equal(pg_evidence_subject(payload)->classifier, pg_evidence_subject(declaration->payload_type)->core) != 1) return NULL;
	const struct pg_term *domain, *codomain, *result_type;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(continuation)->classifier, &domain, &binder, &codomain)) return NULL;
	if (pg_alpha_equal(domain, pg_evidence_subject(declaration->response_type)->core) != 1) return NULL;
	const struct pg_effect_row *effects;
	enum pg_totality totality;
	if (!pg_computation_type_view(codomain, &totality, &effects, &result_type)) return NULL;
	const struct pg_object *label = pg_operation_label(declaration);
	const struct pg_effect_row *row = pg_effect_union(typing->graph, pg_effect_row(typing->graph, 1, &label), effects);
	const struct pg_evidence *type = pg_prove_pi_constant_codomain(typing, formed_classifier(typing, continuation));
	type = pg_prove_computation_type(typing, totality, row, pg_prove_return_content(typing, type));
	const struct pg_term *core = pg_computation_request(typing->graph, label, pg_evidence_subject(payload)->core, pg_evidence_subject(continuation)->core);
	if (!type || !core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(payload), pg_evidence_subject(continuation)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, core, pg_evidence_subject(type), NULL, 2, operands);
	if (!subject) return NULL;
	return accept_record(typing, PG_REQUEST_INTRO,
		pg_evidence_context(payload), subject, 4, premises, declaration, NULL);
}

const struct pg_evidence *pg_prove_operation_function(struct pg_typing *typing,
	const struct pg_operation_declaration *declaration)
{
	if (!declaration) return NULL;
	if (!pg_evidence_owned_by(declaration->payload_type, typing)) return NULL;
	if (!pg_evidence_owned_by(declaration->response_type, typing)) return NULL;
	const struct pg_evidence *empty = pg_prove_empty_context(typing);
	const struct pg_object *a = pg_binder(typing->graph), *b = pg_binder(typing->graph);
	const struct pg_evidence *scope = pg_prove_context_extension(typing, empty, a, declaration->payload_type);
	const struct pg_evidence *response_type = pg_prove_projection(typing, scope, declaration->response_type);
	const struct pg_evidence *response_scope = pg_prove_context_extension(typing, scope, b, response_type);
	const struct pg_evidence *returned = pg_prove_return_contract(typing, PG_TOTALITY_TOTAL,
		pg_prove_variable(typing, response_scope, b));
	const struct pg_evidence *response_pi = pg_prove_pi(typing, response_scope,
		pg_prove_classifier(typing, response_scope, returned));
	const struct pg_evidence *continuation = pg_prove_lambda(typing, response_pi, returned);
	const struct pg_evidence *body = pg_prove_request(typing, declaration,
		pg_prove_variable(typing, scope, a), continuation);
	const struct pg_evidence *pi = pg_prove_pi(typing, scope,
		pg_prove_classifier(typing, scope, body));
	return pg_prove_lambda(typing, pi, body);
}

const struct pg_evidence *pg_prove_handler_context(struct pg_typing *typing,
	const struct pg_operation_declaration *operation, const struct pg_evidence *context,
	const struct pg_evidence *carrier, const struct pg_object *payload, const struct pg_object *resume)
{
	if (!operation || !context_proof(typing, context)) return NULL;
	if (!pg_evidence_owned_by(operation->payload_type, typing)) return NULL;
	if (!pg_evidence_owned_by(operation->response_type, typing)) return NULL;
	if (!pg_evidence_owned_by(carrier, typing)) return NULL;
	if (pg_evidence_context(carrier) != pg_evidence_context(context)) return NULL;
	if (pg_evidence_judgement(carrier) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	const struct pg_effect_row *effects;
	const struct pg_term *result;
	enum pg_totality totality;
	if (!pg_computation_type_view(pg_evidence_subject(carrier)->core, &totality, &effects, &result)) return NULL;
	const struct pg_evidence *response_type = pg_prove_projection(typing, context, operation->response_type);
	const struct pg_evidence *response_scope = pg_prove_context_extension(typing, context,
		pg_binder(typing->graph), response_type);
	const struct pg_evidence *resume_type = pg_prove_thunk_type(typing,
		pg_prove_pi(typing, response_scope,
			pg_prove_projection(typing, response_scope, carrier)));
	const struct pg_evidence *payload_scope = pg_prove_context_extension(typing, context, payload,
		pg_prove_projection(typing, context, operation->payload_type));
	return pg_prove_context_extension(typing, payload_scope, resume,
		pg_prove_projection(typing, payload_scope, resume_type));
}

static int returning_within(const struct pg_term *actual, const struct pg_term *carrier)
{
	const struct pg_effect_row *effects, *allowed;
	const struct pg_term *value, *result;
	enum pg_totality actual_grade, carrier_grade;
	if (!pg_computation_type_view(actual, &actual_grade, &effects, &value)) return 0;
	if (!pg_computation_type_view(carrier, &carrier_grade, &allowed, &result)) return 0;
	if (actual_grade < carrier_grade) return 0;
	if (pg_effect_subset(effects, allowed) != 1) return 0;
	return pg_alpha_equal(value, result) == 1;
}

static int handler_clause_type(const struct pg_term *type,
	const struct pg_operation_declaration *operation, const struct pg_term *carrier)
{
	const struct pg_term *domain, *codomain, *resume;
	const struct pg_object *binder;
	if (!pg_pi_view(type, &domain, &binder, &codomain)) return 0;
	if (pg_alpha_equal(domain, pg_evidence_subject(operation->payload_type)->core) != 1) return 0;
	type = pg_pi_constant_codomain(type);
	if (!pg_pi_view(type, &domain, &binder, &codomain)) return 0;
	if (!returning_within(pg_pi_constant_codomain(type), carrier)) return 0;
	if (!pg_thunk_type_view(domain, &resume)) return 0;
	if (!pg_pi_view(resume, &domain, &binder, &codomain)) return 0;
	if (pg_alpha_equal(domain, pg_evidence_subject(operation->response_type)->core) != 1) return 0;
	return pg_alpha_equal(pg_pi_constant_codomain(resume), carrier) == 1;
}

struct handler_checked_inputs {
	const struct pg_evidence *prefix[3];
	const struct pg_handler_clause *clauses;
};

static struct pg_operation_clause handler_core_clause(const void *owner, size_t i)
{
	const struct handler_checked_inputs *inputs = owner;
	const struct pg_handler_clause *clause = &inputs->clauses[i];
	return (struct pg_operation_clause){pg_operation_label(clause->operation), pg_evidence_subject(clause->body)->core};
}

static const struct pg_evidence *handler_checked_premise(const void *owner, size_t i)
{
	const struct handler_checked_inputs *inputs = owner;
	if (i < 3) return inputs->prefix[i];
	const struct pg_handler_clause *clause = &inputs->clauses[(i - 3) / 3];
	switch ((i - 3) % 3) {
	case 0: return clause->operation->payload_type;
	case 1: return clause->operation->response_type;
	default: return clause->body;
	}
}

static struct pg_handler_clause handler_array_clause(const void *owner, size_t i)
{
	return ((const struct pg_handler_clause *)owner)[i];
}

const struct pg_evidence *pg_prove_handler(struct pg_typing *typing,
	const struct pg_evidence *computation, const struct pg_evidence *returned,
	const struct pg_evidence *carrier, size_t count, const struct pg_handler_clause *clauses)
{
	return pg_prove_handler_inputs(typing, computation, returned, carrier,
		count, clauses, clauses ? handler_array_clause : NULL);
}

const struct pg_evidence *pg_prove_handler_inputs(struct pg_typing *typing,
	const struct pg_evidence *computation, const struct pg_evidence *returned,
	const struct pg_evidence *carrier, size_t count, const void *owner,
	struct pg_handler_clause (*clause)(const void *, size_t))
{
	if (!count) return pg_prove_effect_subsumption(typing,
		pg_prove_fold(typing, computation, returned), carrier);
	if (!clause || count > (SIZE_MAX - 3) / 3) return NULL;
	size_t n = 3 + 3 * count;
	if (n > SIZE_MAX / sizeof(const struct pg_evidence *)) return NULL;
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (!pg_evidence_owned_by(returned, typing)) return NULL;
	if (!pg_evidence_owned_by(carrier, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_judgement(returned) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_judgement(carrier) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(computation) != pg_evidence_context(returned)) return NULL;
	if (pg_evidence_context(computation) != pg_evidence_context(carrier)) return NULL;
	const struct pg_effect_row *input_effects, *output_effects;
	const struct pg_term *input_type, *result_type, *domain, *codomain;
	const struct pg_object *binder;
	enum pg_totality input_grade, output_grade;
	if (!pg_computation_type_view(pg_evidence_subject(computation)->classifier, &input_grade, &input_effects, &input_type)) return NULL;
	if (!pg_computation_type_view(pg_evidence_subject(carrier)->core, &output_grade, &output_effects, &result_type)) return NULL;
	/* Handling cannot guarantee that an unknown prefix reaches RETURN or an
	 * operation. As in sequencing, a typed literal RETURN is already finite. */
	if (input_grade < output_grade && !pg_prove_return_value(typing, computation)) return NULL;
	if (!pg_pi_view(pg_evidence_subject(returned)->classifier, &domain, &binder, &codomain)) return NULL;
	if (pg_alpha_equal(domain, input_type) != 1) return NULL;
	if (!returning_within(pg_pi_constant_codomain(pg_evidence_subject(returned)->classifier), pg_evidence_subject(carrier)->core)) return NULL;
	struct pg_graph temporary = {0};
	struct pg_handler_clause *checked = pg_alloc(&temporary, count * sizeof(*checked));
	const struct pg_object **labels = pg_alloc(&temporary, count * sizeof(*labels));
	const struct pg_occurrence **operands = pg_alloc(&temporary, (count + 2) * sizeof(*operands));
	const struct pg_evidence *result = NULL;
	if (!checked || !labels || !operands) goto done;
	const struct handler_checked_inputs inputs = {{computation, returned, carrier}, checked};
	operands[0] = pg_evidence_subject(computation); operands[1] = pg_evidence_subject(returned);
	for (size_t i = 0; i < count; ++i) {
		struct pg_handler_clause input = clause(owner, i);
		const struct pg_operation_declaration *operation = input.operation;
		const struct pg_evidence *body = input.body;
		if (!operation || !pg_evidence_owned_by(body, typing)) goto done;
		if (!pg_evidence_owned_by(operation->payload_type, typing)) goto done;
		if (!pg_evidence_owned_by(operation->response_type, typing)) goto done;
		if (pg_evidence_judgement(body) != PG_JUDGEMENT_COMPUTATION || pg_evidence_context(body) != pg_evidence_context(computation)) goto done;
		if (!handler_clause_type(pg_evidence_subject(body)->classifier, operation, pg_evidence_subject(carrier)->core)) goto done;
		checked[i] = input;
		labels[i] = pg_operation_label(operation);
		operands[i + 2] = pg_evidence_subject(body);
	}
	const struct pg_effect_row *handled = pg_effect_row(typing->graph, count, labels);
	const struct pg_effect_row *forwarded = pg_effect_difference(typing->graph, input_effects, handled);
	if (pg_effect_subset(forwarded, output_effects) != 1) goto done;
	const struct pg_term *core = pg_computation_fold_inputs(typing->graph, pg_evidence_subject(computation)->core,
		pg_evidence_subject(returned)->core, count, &inputs, handler_core_clause);
	if (!core) goto done;
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, core, pg_evidence_subject(carrier), NULL, count + 2, operands);
	if (!subject) goto done;
	const struct pg_handler_signature *signature = handler_signature(typing->graph, count, labels, checked);
	if (!signature) goto done;
	result = accept_record_inputs(typing, PG_HANDLER_ELIM,
		pg_evidence_context(computation), subject, n,
		(struct pg_evidence_inputs){&inputs, handler_checked_premise, 0}, signature, NULL);
done:
	pg_graph_destroy(&temporary);
	return result;
}

const struct pg_evidence *pg_prove_effect_subsumption(struct pg_typing *typing,
	const struct pg_evidence *computation, const struct pg_evidence *target_type)
{
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (!pg_evidence_owned_by(target_type, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_judgement(target_type) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (pg_evidence_context(computation) != pg_evidence_context(target_type)) return NULL;
	const struct pg_evidence *premises[] = {computation, target_type};
	uint64_t hash;
	const struct pg_evidence *existing = find_record(typing, PG_EFFECT_SUBSUMPTION, pg_evidence_context(computation), NULL, 2, premises, NULL, &hash);
	if (existing) return existing;
	const struct pg_effect_row *source_row, *target_row;
	const struct pg_term *source_value, *target_value;
	enum pg_totality source_totality, target_totality;
	if (!pg_computation_type_view(pg_evidence_subject(computation)->classifier, &source_totality, &source_row, &source_value)) return NULL;
	if (!pg_computation_type_view(pg_evidence_subject(target_type)->core, &target_totality, &target_row, &target_value)) return NULL;
	if (source_totality < target_totality) return NULL;
	if (pg_effect_subset(source_row, target_row) != 1) return NULL;
	if (pg_alpha_equal(source_value, target_value) != 1) return NULL;
	const struct pg_occurrence *subject = pg_occurrence_reclassified(typing, pg_evidence_subject(computation),
		pg_evidence_subject(target_type));
	if (!subject) return NULL;
	return accept(typing, PG_EFFECT_SUBSUMPTION,
		pg_evidence_context(computation), subject, 2, premises);
}

const struct pg_evidence *pg_prove_fold(struct pg_typing *typing,
	const struct pg_evidence *computation, const struct pg_evidence *continuation)
{
	if (!pg_evidence_owned_by(computation, typing)) return NULL;
	if (!pg_evidence_owned_by(continuation, typing)) return NULL;
	if (pg_evidence_judgement(computation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_judgement(continuation) != PG_JUDGEMENT_COMPUTATION) return NULL;
	if (pg_evidence_context(computation) != pg_evidence_context(continuation)) return NULL;
	const struct pg_evidence *premises[] = {computation, continuation};
	uint64_t hash;
	const struct pg_evidence *existing = find_record(typing, PG_FOLD_ELIM, pg_evidence_context(computation), NULL, 2, premises, NULL, &hash);
	if (existing) return existing;
	const struct pg_term *value_type, *domain, *codomain;
	const struct pg_object *binder;
	const struct pg_effect_row *effects, *following;
	enum pg_totality first_totality, next_totality;
	if (!pg_computation_type_view(pg_evidence_subject(computation)->classifier, &first_totality, &effects, &value_type)) return NULL;
	if (!pg_pi_view(pg_evidence_subject(continuation)->classifier, &domain, &binder, &codomain)) return NULL;
	if (pg_alpha_equal(domain, value_type) != 1) return NULL;
	const struct pg_evidence *type = pg_prove_pi_constant_codomain(typing, formed_classifier(typing, continuation));
	if (!type) return NULL;
	const struct pg_term *result_type;
	if (pg_computation_type_view(codomain, &next_totality, &following, &result_type)) {
		enum pg_totality totality = first_totality < next_totality ? first_totality : next_totality;
		type = pg_prove_computation_type(typing, totality,
			pg_effect_union(typing->graph, effects, following), pg_prove_return_content(typing, type));
		if (!type) return NULL;
	} else {
		if (pg_effect_count(effects)) return NULL;
		/* A possibly divergent prefix cannot inherit a total latent result
		 * merely because the continuation immediately produces a Lambda. */
		/* Typed RETURN inversion also supplies a finite prefix without
		 * evaluating its value (which may itself be a suspended computation). */
		if (first_totality == PG_TOTALITY_UNSPECIFIED && !pg_prove_return_value(typing, computation)) {
			if (!unspecified_computation_result(codomain)) return NULL;
		}
	}
	const struct pg_term *core = pg_computation_fold(typing->graph,
		pg_evidence_subject(computation)->core, pg_evidence_subject(continuation)->core, 0, NULL);
	if (!core) return NULL;
	const struct pg_occurrence *operands[] = {pg_evidence_subject(computation), pg_evidence_subject(continuation)};
	const struct pg_occurrence *subject = pg_occurrence_typed(typing, PG_JUDGEMENT_COMPUTATION, core, pg_evidence_subject(type), NULL, 2, operands);
	if (!subject) return NULL;
	return accept(typing, PG_FOLD_ELIM,
		pg_evidence_context(computation), subject, 2, premises);
}

const struct pg_evidence *pg_prove_pi_domain(struct pg_typing *typing,
	const struct pg_evidence *pi)
{
	if (!pg_evidence_owned_by(pi, typing)) return NULL;
	if (pg_evidence_judgement(pi) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(pi)->core, &domain, &binder, &codomain)) return NULL;
	const struct pg_term *index, *fiber;
	const struct pg_object *parameter;
	if (pg_pi_view(domain, &index, &parameter, &fiber)) return NULL;
	const struct pg_occurrence *subject;
	if (!structural_input(typing, pg_evidence_subject(pi), 0, &subject)) return NULL;
	if (subject && subject->judgement == PG_JUDGEMENT_VALUE_TYPE && subject->context == pg_evidence_context(pi)) {
		uint64_t bound, level;
		if (!pg_universe_level(pg_evidence_classifier(pi), &bound)) return NULL;
		if (!pg_universe_level(subject->classifier, &level) || level > bound) return NULL;
		if (pg_alpha_equal(subject->core, domain) != 1) return NULL;
		return pg_evidence_for_subject(typing, subject, NULL);
	}
	subject = pg_occurrence_selected(typing, pg_evidence_subject(pi), 0, NULL,
		PG_JUDGEMENT_VALUE_TYPE, domain, pg_evidence_classifier(pi));
	return accept_selection(typing, PG_PI_DOMAIN, pi, subject);
}

static const struct pg_evidence *pi_codomain(struct pg_typing *typing,
	const struct pg_evidence *pi, const struct pg_evidence *argument,
	const struct pg_occurrence *retained)
{
	if (!pg_evidence_owned_by(pi, typing)) return NULL;
	if (pg_evidence_judgement(pi) != PG_JUDGEMENT_COMPUTATION_TYPE) return NULL;
	if (!pg_evidence_owned_by(argument, typing)) return NULL;
	if (pg_evidence_judgement(argument) != PG_JUDGEMENT_VALUE && pg_evidence_judgement(argument) != PG_JUDGEMENT_TYPE_FAMILY) return NULL;
	if (pg_evidence_context(pi) != pg_evidence_context(argument)) return NULL;
	const struct pg_term *domain, *codomain;
	const struct pg_object *binder;
	if (!pg_pi_view(pg_evidence_subject(pi)->core, &domain, &binder, &codomain)) return NULL;
	if (pg_alpha_equal(domain, pg_evidence_subject(argument)->classifier) != 1) return NULL;
	struct pg_binding_value binding = {binder, pg_evidence_subject(argument)->core};
	const struct pg_term *type = pg_substitution_compute(&typing->substitutions, codomain, 1, (struct pg_binding_inputs){.owner = &binding});
	if (retained) {
		if (pg_alpha_equal(type, retained->core) != 1) return NULL;
		type = retained->core;
	}
	const struct pg_occurrence *subject = pg_occurrence_selected(typing, pg_evidence_subject(pi), 1,
		pg_evidence_subject(argument), PG_JUDGEMENT_COMPUTATION_TYPE, type, pg_evidence_classifier(pi));
	if (!subject) return NULL;
	if (retained && subject != retained) return NULL;
	return accept_selection(typing, PG_PI_CODOMAIN, pi, subject);
}

const struct pg_evidence *pg_prove_pi_codomain(struct pg_typing *typing,
	const struct pg_evidence *pi, const struct pg_evidence *argument)
{
	return pi_codomain(typing, pi, argument, NULL);
}

const struct pg_evidence *pg_check_pi_codomain(struct pg_typing *typing,
	const struct pg_evidence *pi, const struct pg_evidence *argument,
	const struct pg_occurrence *subject)
{
	return subject ? pi_codomain(typing, pi, argument, subject) : NULL;
}

struct pg_typed_query *pg_classifier_request(struct pg_typing *typing,
	const struct pg_evidence *context, const struct pg_evidence *term)
{
	if (!context_proof(typing, context) || !pg_evidence_owned_by(term, typing)) return NULL;
	if (pg_evidence_context(context) != pg_evidence_context(term)) return NULL;
	if (pg_evidence_judgement(term) != PG_JUDGEMENT_VALUE &&
		pg_evidence_judgement(term) != PG_JUDGEMENT_COMPUTATION) return NULL;
	const void *inputs[] = {pg_evidence_subject(term), NULL};
	return pg_typed_query_request(typing, TYPED_CLASSIFIER, 0, inputs, NULL);
}

static int typed_classifier_step(struct pg_typed_query *work)
{
	struct typed_classifier_query *local = pg_typed_query_state(work);
	struct pg_typing *typing = pg_typed_query_typing(work);
	const struct pg_occurrence *subject = typed_source(work);
	uint64_t level;
	if (subject->type) work->result = pg_prove_structural_subject(typing, subject->type);
	else if (subject->judgement == PG_JUDGEMENT_VALUE &&
		pg_universe_level(subject->classifier, &level)) {
		work->result = pg_prove_universe(typing,
			conclusion_first(typing, PG_JUDGEMENT_CONTEXT, subject->context), level);
	} else if (subject->judgement == PG_JUDGEMENT_VALUE && subject->core->kind == PG_REFERENCE &&
		subject->core->as.reference->kind == PG_BINDER) {
		const struct pg_context *declaration = pg_context_lookup(subject->context, subject->core->as.reference);
		const struct pg_scope *scope = pg_evidence_scope(conclusion_first(typing, PG_JUDGEMENT_CONTEXT, declaration));
		if (scope && !scope->indices)
			work->result = pg_prove_projection(typing,
				conclusion_first(typing, PG_JUDGEMENT_CONTEXT, subject->context),
				pg_prove_structural_subject(typing, scope->type));
	} else {
		if (!local->input) local->input = pg_occurrence_type_request(typing, subject);
		enum pg_occurrence_input_status status = pg_occurrence_input_advance(local->input, 1);
		if (status == PG_INPUT_PENDING) return 0;
		work->result = pg_prove_structural_subject(typing, pg_occurrence_input_result(local->input));
	}
	if (!work->result) return -1;
	return pg_evidence_context(work->result) == subject->context &&
		pg_alpha_equal(pg_evidence_subject(work->result)->core, subject->classifier) == 1 ? 1 : -1;
}

const struct pg_occurrence *pg_classifier_source(const struct pg_typed_query *work)
{
	return work && pg_typed_query_role(work) == TYPED_CLASSIFIER ? typed_source(work) : NULL;
}

const struct pg_occurrence_input *pg_classifier_pending_input(const struct pg_typed_query *work)
{
	if (!work || pg_typed_query_role(work) != TYPED_CLASSIFIER || work->status
		|| !pg_typed_query_owned_by(work, pg_typed_query_typing(work))) return NULL;
	const struct typed_classifier_query *local = pg_typed_query_state(work);
	return local->input;
}

int pg_classifier_resume(struct pg_typed_query *work, struct pg_occurrence_input *input,
	uint64_t steps)
{
	if (!work || pg_typed_query_role(work) != TYPED_CLASSIFIER || work->status || work->steps
		|| work->dependency || work->waiting
		|| !pg_typed_query_owned_by(work, pg_typed_query_typing(work))) return -1;
	struct typed_classifier_query *local = pg_typed_query_state(work);
	if (local->input || !input || !steps || steps == UINT64_MAX
		|| steps > pg_occurrence_input_steps(input)) return -1;
	/* The native input owner independently verifies the exact admitted source
	 * and local cursor dependencies before installing any progress. */
	struct pg_occurrence_input *restored = pg_occurrence_type_resume(pg_typed_query_typing(work), typed_source(work), input);
	if (!restored) return -1;
	local->input = restored;
	work->steps = steps;
	return 0;
}

/* Universe successors are formed lazily in the typing store's graph. */
static const struct pg_evidence *formed_classifier(struct pg_typing *typing,
	const struct pg_evidence *term)
{
	if (!pg_evidence_owned_by(term, typing)) return NULL;
	const struct pg_evidence *context = conclusion_first(typing, PG_JUDGEMENT_CONTEXT, pg_evidence_context(term));
	return pg_prove_classifier(typing, context, term);
}

const struct pg_evidence *pg_prove_classifier(struct pg_typing *typing,
	const struct pg_evidence *context,
	const struct pg_evidence *term)
{
	struct pg_typed_query *work = pg_classifier_request(typing, context, term);
	while (!pg_typed_query_advance(work, 1024)) {}
	return pg_typed_query_result(work);
}

enum pg_evidence_rule pg_evidence_rule(const struct pg_evidence *evidence)
{
	if (pg_evidence_judgement(evidence) == PG_JUDGEMENT_CONTEXT) {
		const struct pg_scope *scope = (const void *)evidence;
		return !scope->context ? PG_CONTEXT_EMPTY : scope->indices ? PG_CONTEXT_FAMILY_EXTEND : PG_CONTEXT_EXTEND;
	}
	if (pg_evidence_judgement(evidence) == PG_JUDGEMENT_SUBSTITUTION) return PG_CONTEXT_SUBSTITUTION;
	return (enum pg_evidence_rule)((const struct pg_occurrence *)(const void *)evidence)->construction;
}

const struct pg_scope *pg_evidence_scope(const struct pg_evidence *evidence)
{
	if (!evidence || pg_evidence_judgement(evidence) != PG_JUDGEMENT_CONTEXT) return NULL;
	const struct pg_scope *scope = (const void *)evidence;
	return scope->context ? scope : NULL;
}

const struct pg_scope *pg_evidence_binding_scope(const struct pg_evidence *evidence)
{
	if (!evidence) return NULL;
	switch (pg_evidence_rule(evidence)) {
	case PG_PI_FORM: case PG_TYPE_FAMILY_ABSTRACT: return evidence_certificate(evidence);
	default: return NULL;
	}
}

enum pg_evidence_judgement pg_evidence_judgement(const struct pg_evidence *evidence)
{
	enum pg_evidence_judgement judgement = PG_JUDGEMENT_INPUT;
	if (evidence) memcpy(&judgement, (const char *)evidence + sizeof(struct pg_index_entry), sizeof(judgement));
	return judgement;
}

int pg_evidence_owned_by(const struct pg_evidence *evidence, const struct pg_typing *typing)
{
	if (!evidence || !typing || !typing->owner_key) return 0;
	enum pg_evidence_judgement judgement = pg_evidence_judgement(evidence);
	if (judgement == PG_JUDGEMENT_CONTEXT) {
		const struct pg_scope *scope = (const void *)evidence;
		return pg_scope_owned_by(scope, typing) && scope->admission_owner == typing->owner_key;
	}
	if (judgement == PG_JUDGEMENT_SUBSTITUTION) {
		const struct pg_context_map *map = (const void *)evidence;
		return pg_context_map_owned_by(map, typing) && map->admission_owner == typing->owner_key;
	}
	const struct pg_occurrence *subject = (const void *)evidence;
	return pg_occurrence_owned_by(subject, typing) && subject->admission_owner == typing->owner_key;
}

const struct pg_context *pg_evidence_context(const struct pg_evidence *evidence)
{
	if (!evidence) return NULL;
	enum pg_evidence_judgement judgement = pg_evidence_judgement(evidence);
	if (judgement == PG_JUDGEMENT_CONTEXT) return ((const struct pg_scope *)(const void *)evidence)->context;
	if (judgement == PG_JUDGEMENT_SUBSTITUTION) return ((const struct pg_context_map *)(const void *)evidence)->destination;
	return ((const struct pg_occurrence *)(const void *)evidence)->context;
}

const struct pg_occurrence *pg_evidence_subject(const struct pg_evidence *evidence)
{
	if (!evidence) return NULL;
	enum pg_evidence_judgement judgement = pg_evidence_judgement(evidence);
	return judgement == PG_JUDGEMENT_CONTEXT || judgement == PG_JUDGEMENT_SUBSTITUTION ? NULL : (const void *)evidence;
}

const struct pg_term *pg_evidence_classifier(const struct pg_evidence *evidence)
{
	const struct pg_occurrence *subject = pg_evidence_subject(evidence);
	return subject ? subject->classifier : NULL;
}

size_t pg_evidence_premise_count(const struct pg_evidence *evidence)
{
	if (!evidence) return 0;
	const struct pg_occurrence *subject = pg_evidence_subject(evidence);
	if (pg_evidence_judgement(evidence) == PG_JUDGEMENT_SUBSTITUTION)
		return ((const struct pg_context_map *)(const void *)evidence)->count + 2;
	enum pg_evidence_rule rule = pg_evidence_rule(evidence);
	if (rule == PG_RETURN_VALUE || rule == PG_THUNK_COMPUTATION) return 1;
	return borrowed_premise_count(rule, subject, evidence_certificate(evidence));
}

size_t pg_evidence_retained_premise_count(const struct pg_evidence *evidence)
{
	(void)evidence;
	return 0;
}

size_t pg_evidence_retained_premise_bytes(const struct pg_evidence *evidence)
{
	(void)evidence;
	return 0;
}

const struct pg_evidence *pg_evidence_premise(const struct pg_evidence *evidence, size_t index)
{
	if (index >= pg_evidence_premise_count(evidence)) return NULL;
	if (pg_evidence_judgement(evidence) == PG_JUDGEMENT_SUBSTITUTION) {
		const struct pg_context_map *map = (const void *)evidence;
		if (index < 2) return (const void *)(index ? map->destination_scope : map->source_scope);
		const struct pg_occurrence *input = map->images[index - 2];
		return (const void *)input;
	}
	enum pg_evidence_rule rule = pg_evidence_rule(evidence);
	if (rule == PG_RETURN_VALUE || rule == PG_THUNK_COMPUTATION) return evidence_certificate(evidence);
	const struct pg_occurrence *subject = pg_evidence_subject(evidence);
	if ((rule == PG_UNIVERSE_FORM || rule == PG_HOST_TYPE_FORM || rule == PG_VARIABLE) && !subject->context)
		return (const void *)((const struct pg_typing_owner *)subject->admission_owner)->empty_scope;
	return borrowed_premise(rule, pg_evidence_subject(evidence), evidence_certificate(evidence), index);
}

#include "typing_io.h"
#include "typing_internal.h"
#include "evidence.h"
#include "wire.h"
#include <string.h>

static const char magic[8] = "APGTYP2";

static int member(const struct pg_index *index, const struct pg_index_entry *entry)
{
	if (!index || !index->capacity) return 0;
	for (const struct pg_index_entry *candidate = pg_index_candidates(index, entry->hash);
		candidate; candidate = candidate->next)
		if (candidate == entry) return 1;
	return 0;
}

static const struct pg_occurrence *anchor(const struct pg_occurrence_input *work,
	const struct input_map *frame)
{
	for (const struct pg_occurrence *source = work->source; source; source = source->origin)
		if (source->map == frame->map && source->core == frame->core) return source;
	return NULL;
}

static int shape(const struct pg_occurrence_input *work)
{
	if (!work || work->index != SIZE_MAX || work->status != PG_INPUT_PENDING
		|| !work->source || work->outer || work->child || work->selected || work->waiting
		|| work->lift || work->scopes || (work->current && work->result)) return 0;
	if (work->typing && !member(&work->typing->occurrence_inputs, &work->entry)) return 0;
	if (work->effective && (!work->maps || work->effective != work->maps->map)) return 0;
	if (work->action) {
		const struct pg_occurrence_action *action = work->action;
		if (work->current || !work->result || !work->maps || !work->effective
			|| action->map != work->effective || action->source != work->result
			|| action->result || action->status != PG_SUBSTITUTION_PENDING || action->next > 3) return 0;
		if (action->typing && !member(&action->typing->occurrence_actions, &action->index)) return 0;
		for (size_t i = action->next + 1; i < 3; ++i) if (action->outputs[i]) return 0;
		if (action->substitution && (action->next >= 3 || action->outputs[action->next]
			|| pg_substitution_status(action->substitution) != PG_SUBSTITUTION_DONE)) return 0;
	}
	return 1;
}

int pg_occurrence_type_pending_write(FILE *file, const struct pg_occurrence_input *work,
	const struct pg_scope *const *scopes, const struct pg_graph_codec *codec, void *owner)
{
	if (!file || !shape(work)) return -1;
	size_t maps = 0;
	for (const struct input_map *frame = work->maps; frame; frame = frame->next) {
		if (!anchor(work, frame) || maps == SIZE_MAX) return -1;
		++maps;
	}
	if (maps > SIZE_MAX / sizeof(void *) - 4) return -1;
	struct pg_graph scratch = {0};
	int status = -1;
	const struct pg_occurrence **roots = pg_alloc(&scratch, (maps + 4) * sizeof(*roots));
	const struct pg_scope **selected = pg_alloc(&scratch, (maps + 4) * sizeof(*selected));
	if (!roots || !selected) goto done;
	size_t count = 0;
	roots[count++] = work->source;
	unsigned flags = (work->current != NULL) | ((work->result != NULL) << 1)
		| ((work->action != NULL) << 2) | ((work->effective != NULL) << 3);
	if (work->current) roots[count++] = work->current;
	if (work->result) roots[count++] = work->result;
	for (const struct input_map *frame = work->maps; frame; frame = frame->next)
		roots[count++] = anchor(work, frame);
	for (size_t i = 0; i < count; ++i) {
		selected[i] = scopes ? scopes[i] : pg_evidence_scope(
			pg_evidence_for_context(work->typing, roots[i]->context));
		if (roots[i]->context != (selected[i] ? selected[i]->context : NULL)) goto done;
	}
	if (fwrite(magic, 1, 8, file) != 8 || pg_wire_write_u64(file, work->steps)
		|| pg_wire_write_u64(file, flags) || pg_wire_write_u64(file, maps)) goto done;
	const struct pg_occurrence_action *action = work->action;
	const struct pg_term *terms[3];
	size_t term_count = 0;
	unsigned outputs = 0;
	if (action) {
		for (size_t i = 0; i < 3; ++i) {
			const struct pg_term *output = action->outputs[i];
			if (action->substitution && i == action->next) output = pg_substitution_result(action->substitution);
			if (!output) continue;
			outputs |= 1u << i;
			terms[term_count++] = output;
		}
		if (pg_wire_write_u64(file, action->steps) || pg_wire_write_u64(file, action->next)
			|| pg_wire_write_u64(file, outputs)) goto done;
	}
	if (pg_scoped_occurrences_write_with_terms(file, count, selected, roots,
		term_count, terms, codec, owner)) goto done;
	status = 0;
done:
	pg_graph_destroy(&scratch);
	return status;
}

int pg_occurrence_type_pending_read(FILE *file, struct pg_typing *typing, size_t limit,
	size_t name_limit, const struct pg_graph_codec *codec, void *owner,
	const struct pg_scope *const **scopes, struct pg_occurrence_input **output)
{
	if (!file || !typing || !scopes || !output) return -1;
	*scopes = NULL; *output = NULL;
	char header[8];
	uint64_t steps, flags, maps, action_steps = 0, next = 0, outputs = 0;
	if (fread(header, 1, 8, file) != 8 || memcmp(header, magic, 8)
		|| pg_wire_read_u64(file, &steps) || pg_wire_read_u64(file, &flags) || flags > 15
		|| pg_wire_read_u64(file, &maps) || maps > limit || maps > SIZE_MAX - 4) return -1;
	if ((flags & 3) == 3 || ((flags & 8) && !maps)
		|| ((flags & 4) && ((flags & 1) || !(flags & 2) || !(flags & 8)))) return -1;
	if (flags & 4) {
		if (pg_wire_read_u64(file, &action_steps) || pg_wire_read_u64(file, &next) || next > 3
			|| pg_wire_read_u64(file, &outputs) || outputs > 7 || (outputs >> (next + 1))) return -1;
	}
	size_t count, term_count;
	const struct pg_scope *const *selected;
	const struct pg_occurrence *const *roots;
	const struct pg_term *const *terms;
	if (pg_scoped_occurrences_read_with_terms(file, typing, limit, name_limit, codec, owner,
		&count, &selected, &roots, &term_count, &terms)) return -1;
	size_t expected = 1 + !!(flags & 1) + !!(flags & 2) + (size_t)maps;
	unsigned nterms = !!(outputs & 1) + !!(outputs & 2) + !!(outputs & 4);
	if (count != expected || term_count != nterms) return -1;
	struct pg_occurrence_input input = {0};
	struct pg_occurrence_input *work = &input;
	work->index = SIZE_MAX;
	work->steps = steps;
	size_t cursor = 0;
	work->source = roots[cursor++];
	if (flags & 1) work->current = roots[cursor++];
	if (flags & 2) work->result = roots[cursor++];
	if (flags & 4) {
		work->action = pg_alloc(typing->graph, sizeof(*work->action));
		if (!work->action) return -1;
		work->action->source = work->result;
		work->action->steps = action_steps;
		work->action->next = (size_t)next;
		for (size_t i = 0, t = 0; i < 3; ++i)
			if (outputs & (1u << i)) work->action->outputs[i] = terms[t++];
	}
	struct input_map **tail = &work->maps;
	for (size_t i = 0; i < maps; ++i) {
		const struct pg_occurrence *source = roots[cursor++];
		if (!source->map) goto failed;
		struct input_map *frame = pg_alloc(typing->graph, sizeof(*frame));
		if (!frame) goto failed;
		*frame = (struct input_map){source->map, source->core, NULL};
		*tail = frame; tail = &frame->next;
	}
	if (flags & 8) work->effective = work->maps->map;
	if (work->action) {
		work->action->map = work->effective;
	}
	if (!shape(work)) goto failed;
	for (const struct input_map *frame = work->maps; frame; frame = frame->next)
		if (!anchor(work, frame)) goto failed;
	struct pg_occurrence_input *native = pg_occurrence_type_pending_import(typing, work);
	if (!native) goto failed;
	*scopes = selected; *output = native;
	return 0;
failed:
	return -1;
}

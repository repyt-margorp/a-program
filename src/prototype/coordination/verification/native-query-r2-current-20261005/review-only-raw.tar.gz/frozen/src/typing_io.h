#ifndef __TYPING_IO_H__
#define __TYPING_IO_H__

#include "occurrence_io.h"

/* Genuine unfinished classifier-input work. The existing input cursor and
 * optional context action own the progress. No checking occurs in
 * this codec. Selected operands, lifted input telescopes and failed/completed
 * work reject; they require their corresponding owner transports. An unfinished
 * substitution also rejects. A completed one retains only its Core result in
 * the action's existing slot; its executor/caches are not another snapshot.
 * scopes == NULL selects live checked context owners. For inert resave pass the
 * exact scope array returned by read, in its unchanged root order. */
int pg_occurrence_type_pending_write(FILE *, const struct pg_occurrence_input *,
	const struct pg_scope *const *scopes, const struct pg_graph_codec *, void *);
/* Read one inert native cursor into the existing input index. It cannot advance
 * until explicit owner admission; copied cursors cannot reconnect. Duplicate
 * keys reject without replacing existing work. All decoded storage belongs to
 * the ordinary graph; no external executor resource or cleanup wrapper exists.
 * Scope views remain transport roots, not accepted context facts. */
int pg_occurrence_type_pending_read(FILE *, struct pg_typing *, size_t limit,
	size_t name_limit, const struct pg_graph_codec *, void *,
	const struct pg_scope *const **scopes, struct pg_occurrence_input **);

#endif

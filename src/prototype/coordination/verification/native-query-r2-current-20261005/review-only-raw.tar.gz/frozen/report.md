# Native query and Source frontier r2

This prototype increment extends immutable native-frontier r1. It retains the
actual canonical typing cursor in its existing index and transports unfinished
checking through the existing Source/shared Core codec. Completed substitution
executors and their copied caches are deleted from this transport; their Core
result occupies the action's existing output slot. Truly unfinished substitutions
refuse. No additional Evidence/Oracle graph, acceptance authority or index exists.

Source I/O retains a started lexical definition body independently of materialized
output. Artifact preparation validates an already reconnected exact child; it
does not attach that body twice. Wrong body and duplicate direct resume reject.
Loading remains inert and locally unaccepted. Positive raw cursor advancement
refuses until the actual Source is ordinarily checked. Explicit authentic reuse
requires retained-computation provenance and never makes arbitrary input trusted.
Controls charge validation against one total B and cap R before useful progress.

Fresh exact129/671 local verification: unskipped serial O2 acceptance exit0;
all seven affected SAN gates0; query/Source checkpoint/Lambda O2/SAN16 records0.
Real List query has3 cuts, mapped query8, two Source owners share the same8-cut
cursor; destroyed producer, cold abandonment, duplicate/copy rejection, step0,
inert bytes, ordinary Universe judgement and continuation fuel are checked.
The same Source closure control distinguishes r1 parent1 from candidate0 under
O2/SAN. Original link/build and actual preparation134 evidence remains pinned.

Imported ordinary-result Sorted is DONE at955410 steps in both variants. Both
actual strict public gates remain FAILED exit1: 1000:1000,1600:1600,completed1915:0.
All40 verdict/fuel/byte rows and all52 images equal r1. No expected-pass waiver.
The historic1921 completed-cut failure remains historical, not erased.

General Source application/qualified/Match continuation, unfinished substitution
transport, temporary native construction selector, current-producer joint checks
and matched time/peak memory remain open. The application-frontier trial is
excluded. Existing reusable/escaped evaluator pointers remain preserved; no
Performance eval/readback code is edited. Added transport fields and native owner
overhead are real costs; no speed, net memory or Goal-completion claim follows.

The manifest lists only this durable publication set. External evidence hashes
reference immutable local raw logs, images, binaries and original failures.
Full snapshots are authoritative; applied.diff is review-only. Merge owns exact
task publication/current integration. No accepted code or Git metadata is changed.

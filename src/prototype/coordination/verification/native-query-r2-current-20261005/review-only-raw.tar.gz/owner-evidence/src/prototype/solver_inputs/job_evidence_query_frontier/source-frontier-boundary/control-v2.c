#include "program.h"
#include "synthesis_source.h"
#include "synthesis_work.h"
#include "artifact/source.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

/* Inspect the actual public-cut owners. This supplies no result, admission,
 * new runtime index or substitute checkpoint. */
int main(int argc, char **argv)
{
	assert(argc == 3);
	FILE *file = fopen(argv[1], "rb");
	assert(file && !fseek(file, 0, SEEK_END));
	long size = ftell(file);
	assert(size >= 0 && !fseek(file, 0, SEEK_SET));
	char *text = malloc((size_t)size + 1);
	assert(text && fread(text, 1, (size_t)size, file) == (size_t)size && !fclose(file));
	struct pg_program *program = pg_program_create(text, (size_t)size, PG_DEFINITION_IMPLICIT_THUNK);
	free(text);
	assert(program && program->root && !program->parser.error);
	char *end;
	uint64_t budget = strtoull(argv[2], &end, 10);
	assert(*argv[2] && !*end);
	pg_synthesis_advance(&program->synthesis, budget);
	struct pg_synthesis *synthesis = &program->synthesis;
	size_t count = synthesis->jobs.count, index = 0;
	struct pg_synthesis_job **jobs = malloc(count * sizeof(*jobs));
	assert(jobs);
	for (size_t i = 0; i < synthesis->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = synthesis->jobs.buckets[i]; entry; entry = entry->next)
			jobs[index++] = (void *)entry;
	assert(index == count);
	size_t source_count = 0, unsupported = 0;
	for (size_t i = 0; i < count; ++i) {
		struct pg_synthesis_job *job = jobs[i], *child;
		if (job->status != PG_SYNTHESIS_PENDING) continue;
		const struct pg_source_scope *scope;
		const struct pg_syntax *syntax, *definitions;
		struct pg_synthesis_input body;
		struct pg_typed_query *query;
		int source = !pg_synthesis_source_input(synthesis, job, &scope, &syntax);
		int definition = !pg_synthesis_definition_input(synthesis, job, &scope, &definitions, &syntax);
		int special = pg_synthesis_body_frontier(synthesis, job, &body) == 1
			|| pg_synthesis_domain_frontier(synthesis, job, &child) == 1
			|| pg_synthesis_binding_domain(synthesis, job, &child) == 1
			|| pg_synthesis_classifier_formation_frontier(synthesis, job, &query) == 1;
		if (!source && !definition && !special) continue;
		struct pg_graph scratch = {0};
		const struct pg_artifact_source *saved = pg_artifact_source_capture(&scratch,
			synthesis, count, jobs, 1, &job);
		++source_count; unsupported += saved == NULL;
		if (!saved)
			printf("unsupported-source syntax=%d definition=%d specialized=%d token=%.*s dependency=%d\n",
				source || definition ? (int)syntax->kind : -1, definition, special,
				source || definition ? (int)syntax->token.length : 0,
				(source || definition) && syntax->token.text ? syntax->token.text : "", job->dependency != NULL);
		pg_graph_destroy(&scratch);
	}
	printf("public-cut solve=%" PRIu64 " root-status=%d pending-source=%zu unsupported=%zu jobs=%zu\n",
		synthesis->steps, program->root->status, source_count, unsupported, count);
	free(jobs);
	pg_program_destroy(program);
	return 0;
}

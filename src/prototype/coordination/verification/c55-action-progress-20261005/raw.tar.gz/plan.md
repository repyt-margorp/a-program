# C Backend Actual Acc Creation Products

Date:2026-10-05 UTC. Status:C55 private continuation after sealed C54.

## Problem List

1. Make source-selected actual Acc/LT creation available through one saved-image
   command producing ordinary C source, objects and archives.

## 1. Saved-Image Source and Creation Recipes

### Subjective (User)

Inherited2026-10-04 conveyed human requirement via inquiry desk/Merge, English
paraphrase: deliver readable executable C faithfully following actual admitted
Acc QuickSort, preserving Acc/down recursion, indices, partition and captures.
A labeled faithful manual candidate is acceptable; no substitute algorithm or
false generalized-native claim. Preserve sealed C32, defer List conveniences,
continue the original Goal/model. Existing2026-10-03 user clarifications
prioritize downstream ordinary external C modules, without target-driven .a/
schema/checker/source-erasure authority, and permit independent worker epochs
while Merge owns integration. These are inherited paraphrases, not new human
approval; original wording was not supplied.

### Objective (Code)

Fresh initial C55 result: native R1 strict O2 driver/fault-driver build0;
direct source emission0 creates seven fresh bodies plus full3168-byte creation
recipe. One-image source command0 and ordinary C client build/run0 produce the
actual fixture0,1,2,2,3,|. Fresh body/recipe hashes match product receipt inputs;
all1053-line C59224615/header246364a1/provenance59a0756c match C54. No failed
initial gate observed. Full product/refusal/I-O/source-SAN qualification pending.
Exact argv/exits/logs/source pins are retained in
src/prototype/c_backend/.evidence/epoch55-image-creation-products-20261005/.

Previous turn was concrete progress: C54 frozen15 manifestaf067016/archive
5659fbbf/READYd15db7ba derives actual prior-field/result recipes for LT creation
before allocation. Native R1 source126441cbd69 and acceptedfc52755b/runtime120c206
each O2/full source SAN61 expected rows pass; source1053-line C59224615 retains
all seven actual algorithm sections/public header/C53 prefix. Initial test
missing string.h compiler1 retained and corrected only that include. C54 task/
independent review/Main pending at turn start; C53 exact task3b97c0fe/Main7a0b8480
and independent qualification consumed. No live command from previous turn.

Current acc_command/ emits seven fresh source bodies plus the C51 down/action
recipe from one admitted image and packages only955-line C51 products. It
does not yet expose C54 source-selected constructor result/prior creation.
Its source-owner/advancement guards, staging streams, no-replace publication,
status/refusal/I-O/resource/ordinary-client controls remain relevant.

### Assessment

Agent implementation: a separate command emitter reads the complete C54 recipe
while retaining all seven existing source body emitters. Recompose each private
target stage from this invocation's fresh bodies and qualified recipe prefixes;
historical modules qualify bytes rather than supply algorithms. Ordinary
source/object/archive expose the unchanged gs_sort ABI and1053-line C54 source.
Keep fixed/mockup versus generalized/native extent explicit and preserve atomic
visibility/cleanup/status behavior. No new producer fields/authority, private
checker, source erasure or broader policy. Pinned source126/legacy, not separate
query trial129. Keep C54 submitted archive exact and work in a new subtree.

### Plan

- [x] Implement source-image driver and packaging from seven fresh bodies plus
  complete source-derived constructor/action recipe, without historical bodies.
- [ ] Verify ordinary source/object/archive and receipt/input/source-owner guards.
- [ ] Retain source/parameter/refusal/Core/resource/I-O/prior-output controls;
  run serial focused O2/full affected-source SAN on pinned native/legacy inputs.
- [ ] Preserve failures/old snapshots, style check and exact reviewable handoff.
- [ ] General native Acc/QuickSort/full61/adoption/cost/full Goal remain open.

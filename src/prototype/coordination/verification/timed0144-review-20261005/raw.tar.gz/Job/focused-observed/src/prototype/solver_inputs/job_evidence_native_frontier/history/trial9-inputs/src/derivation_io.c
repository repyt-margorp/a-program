#include "derivation_io.h"
#include "dag.h"
#include "graph_io.h"
#include "wire.h"
#include "effect_inference.h"
#include "iadt.h"
#include "context_payload.h"
#include "host.h"

#include <string.h>

static const char magic[8] = {'A', 'P', 'G', 'D', 'R', 'V', 0, 16};
static const char header_magic[8] = {'A', 'P', 'G', 'D', 'R', 'H', 0, 1};

struct proof_view {
	const struct pg_typing *typing;
	const struct pg_evidence *const *roots;
};

static const void *proof_root(const void *owner, size_t index)
{
	const struct proof_view *view = owner;
	return view->roots[index];
}

static int proof_header(const void *unused, const void *key, struct pg_derivation_input *header)
{
	(void)unused;
	return pg_derivation_input_header(key, header);
}

static int proof_child(const void *owner, const void *key, size_t index, const void **child)
{
	const struct proof_view *view = owner;
	const struct pg_evidence *input = NULL;
	int status = pg_derivation_input_dependency(view->typing, key, index, &input);
	*child = input;
	return status;
}

static const void *input_root(const void *owner, size_t index)
{
	const struct pg_derivation_input *const *roots = owner;
	return roots ? roots[index] : NULL;
}

static int input_header(const void *unused, const void *key, struct pg_derivation_input *header)
{
	(void)unused;
	if (!key) return -1;
	*header = *(const struct pg_derivation_input *)key;
	return 0;
}

static int input_child(const void *unused, const void *key, size_t index, const void **child)
{
	(void)unused;
	const struct pg_derivation_input *input = key;
	if (!input || index > input->count) return -1;
	if (index == input->count) return 0;
	*child = input->premises[index];
	return *child ? 1 : -1;
}

struct pg_derivation_view pg_derivation_input_view(size_t count,
	const struct pg_derivation_input *const *roots)
{
	return (struct pg_derivation_view){count, roots, input_root, input_header, input_child};
}

static int view_child(void *owner, const void *key, size_t index, const void **child)
{
	const struct pg_derivation_view *const *view = owner;
	return (*view)->child((*view)->owner, key, index, child);
}

static int term_reference(FILE *file, const struct pg_term *term,
	struct pg_dag *terms)
{
	if (!term) return pg_wire_write_u64(file, 0);
	if (pg_dag_add(terms, term)) return -1;
	return pg_wire_write_u64(file, pg_dag_find(terms, term)->id);
}

static int input_terms(struct pg_graph *scratch, const struct pg_derivation_input *input,
	const struct pg_term **terms)
{
	const struct pg_derivation_parameters *p = &input->parameters;
	const struct pg_object *objects[PG_DERIVATION_TERM_SLOTS] = {
		p->binder, input->effect_parameter, NULL, NULL, p->operation_label, NULL,
		p->declaration ? pg_data_declaration_family(p->declaration) : NULL, p->constructor, p->constant
	};
	for (size_t i = 0; i < PG_DERIVATION_TERM_SLOTS; ++i) {
		terms[i] = objects[i] ? pg_reference(scratch, objects[i]) : NULL;
		if (objects[i] && !terms[i]) return -1;
	}
	if (!input->effect_parameter && p->effects) {
		terms[1] = pg_effect_reference(scratch, p->effects);
		if (!terms[1]) return -1;
	}
	terms[2] = input->source; terms[3] = input->target;
	terms[5] = pg_handler_signature_reference(scratch, p->handler);
	if (p->handler && !terms[5]) return -1;
	/* A reduction target may reference the same binder as a parameter wrapper.
	 * Canonicalize those wrappers in the payload arena, as image_roots_write does. */
	for (size_t i = 0; i < PG_DERIVATION_TERM_SLOTS; ++i) {
		if (!terms[i] || terms[i]->kind != PG_REFERENCE) continue;
		terms[i] = pg_reference(scratch, terms[i]->as.reference);
		if (!terms[i]) return -1;
	}
	return 0;
}

int pg_derivation_input_terms(struct pg_graph *scratch,
	const struct pg_derivation_input *input,
	struct pg_derivation_payload *payload)
{
	if (!scratch || !input || !payload) return -1;
	struct pg_derivation_payload result = {.count = PG_DERIVATION_TERM_SLOTS};
	const struct pg_term *const *extra = NULL;
	size_t extra_count = 0;
	const struct pg_induction_allocation *a = input->parameters.induction;
	if (a) {
		if (input->rule != PG_INDUCTION_ELIM) return -1;
		const struct pg_term *binders[] = {pg_reference(scratch, a->recursion),
			pg_reference(scratch, a->argument), pg_reference(scratch, a->self)};
		if (pg_contexts_pack(scratch, a->count, a->clauses, 3, binders,
			&result.metadata_count, &result.metadata, &extra_count, &extra)) return -1;
	}
	if (extra_count > SIZE_MAX / sizeof(void *) - result.count) return -1;
	result.count += extra_count;
	const struct pg_term **terms = pg_alloc(scratch, result.count * sizeof(*terms));
	if (!terms || input_terms(scratch, input, terms)) return -1;
	for (size_t i = 0; i < extra_count; ++i) {
		const struct pg_term *term = extra[i];
		if (term->kind == PG_REFERENCE) term = pg_reference(scratch, term->as.reference);
		if (!term) return -1;
		terms[PG_DERIVATION_TERM_SLOTS + i] = term;
	}
	result.terms = terms;
	*payload = result;
	return 0;
}

int pg_derivation_input_collect(struct pg_dag *terms, struct pg_dag *contexts,
	const struct pg_derivation_input *input)
{
	if (!terms || !contexts || !input) return -1;
	const struct pg_term *roots[PG_DERIVATION_TERM_SLOTS];
	if (input_terms(&terms->storage, input, roots)) return -1;
	for (size_t i = 0; i < PG_DERIVATION_TERM_SLOTS; ++i)
		if (roots[i] && pg_dag_add(terms, roots[i])) return -1;
	const struct pg_induction_allocation *a = input->parameters.induction;
	if (!a) return 0;
	if (input->rule != PG_INDUCTION_ELIM || (a->count && !a->clauses)) return -1;
	for (size_t i = 0; i < a->count; ++i)
		if (pg_context_collect(terms, contexts, a->clauses[i])) return -1;
	return pg_dag_add(terms, pg_reference(&terms->storage, a->recursion)) ||
		pg_dag_add(terms, pg_reference(&terms->storage, a->argument)) ||
		pg_dag_add(terms, pg_reference(&terms->storage, a->self)) ? -1 : 0;
}

int pg_derivation_inputs_collect_objects(struct pg_dag *objects, size_t count,
	const struct pg_derivation_input *const *roots, const struct pg_effect_inference *work,
	const struct pg_graph_codec *codec, void *owner)
{
	if (!objects || (count && !roots)) return -1;
	struct pg_dag inputs = {0}, terms = {0}, contexts = {0};
	struct pg_derivation_view view = pg_derivation_input_view(count, roots);
	const struct pg_derivation_view *reader = &view;
	int status = -1;
	if (pg_dag_init(&inputs, view_child, &reader) || pg_dag_init(&contexts, pg_context_dependency, NULL)
		|| pg_graph_dependencies_init(&terms, objects, codec, owner)) goto done;
	for (size_t i = 0; i < count; ++i) if (pg_dag_add(&inputs, roots[i])) goto done;
	for (const struct pg_dag_node *node = inputs.first; node; node = node->next)
		if (pg_derivation_input_collect(&terms, &contexts, node->key)) goto done;
	if (work && pg_effect_inference_collect(work, &terms)) goto done;
	status = 0;
done:
	pg_dag_destroy(&contexts);
	pg_dag_destroy(&terms); pg_dag_destroy(&inputs);
	return status;
}

int pg_derivations_write(FILE *file, const struct pg_typing *typing,
	size_t count, const struct pg_evidence *const *roots,
	const char *(*name)(void *, const struct pg_object *), void *owner)
{
	const struct pg_graph_codec codec = {.name = name};
	return pg_derivations_write_descriptors(file, typing, count, roots, &codec, owner);
}

static int write_dag(FILE *file, const struct pg_derivation_view *view, const struct pg_effect_inference *work,
	const struct pg_graph_codec *codec, void *owner, int headers)
{
	if (!file || !view || !view->root || !view->header || (!headers && !view->child)) return -1;
	size_t count = view->count;
	struct pg_dag dag = {0};
	struct pg_dag term_roots = {0};
	struct pg_graph arena = {0};
	int status = -1;
	if (pg_dag_init(&dag, headers ? NULL : view_child, &view) || pg_dag_init(&term_roots, NULL, NULL)
		|| pg_graph_init(&arena)) goto done;
	for (size_t i = 0; i < count; ++i)
		if (pg_dag_add(&dag, view->root(view->owner, i))) goto done;
	if (fwrite(headers ? header_magic : magic, 1, 8, file) != 8
		|| pg_wire_write_u64(file, dag.count) || pg_wire_write_u64(file, count)) goto done;
	for (const struct pg_dag_node *node = dag.first; node; node = node->next) {
		struct pg_derivation_input input = {0};
		if (view->header(view->owner, node->key, &input) || input.parameters.conversion || input.parameters.reduction) goto done;
		if (input.effect_parameter && (input.rule != PG_RETURN_TYPE_FORM || input.parameters.effects
			|| !pg_effect_equation_find(work, input.effect_parameter))) goto done;
		struct pg_derivation_parameters parameters = input.parameters;
		if (pg_wire_write_u64(file, input.rule)
			|| pg_wire_write_u64(file, parameters.level) || pg_wire_write_u64(file, parameters.direction)) goto done;
		if (pg_wire_write_u64(file, parameters.totality)) goto done;
		if (pg_wire_write_u64(file, input.reduction_kind)) goto done;
		struct pg_derivation_payload payload;
		if (pg_derivation_input_terms(&arena, &input, &payload)) goto done;
		for (size_t i = 0; i < PG_DERIVATION_TERM_SLOTS; ++i)
			if (term_reference(file, payload.terms[i], &term_roots)) goto done;
		if (pg_wire_write_u64(file, payload.metadata_count)
			|| pg_wire_write_u64(file, payload.count - PG_DERIVATION_TERM_SLOTS)) goto done;
		for (size_t i = 0; i < payload.metadata_count; ++i)
			if (pg_wire_write_u64(file, payload.metadata[i])) goto done;
		for (size_t i = PG_DERIVATION_TERM_SLOTS; i < payload.count; ++i)
			if (term_reference(file, payload.terms[i], &term_roots)) goto done;
		size_t arity = input.count;
		if (pg_wire_write_u64(file, arity)) goto done;
		for (size_t i = 0; !headers && i < arity; ++i) {
			const void *child;
			if (dag.child(dag.context, node->key, i, &child) != 1) goto done;
			const struct pg_dag_node *p = pg_dag_find(&dag, child);
			if (!p || pg_wire_write_u64(file, p->id)) goto done;
		}
		const void *past_end;
		if (!headers && dag.child(dag.context, node->key, arity, &past_end) != 0) goto done;
	}
	for (size_t i = 0; i < count; ++i) {
		const struct pg_dag_node *node = pg_dag_find(&dag, view->root(view->owner, i));
		if (!node || pg_wire_write_u64(file, node->id)) goto done;
	}
	size_t equations = 0, effect_count = 0;
	const struct pg_term *const *effect_roots = NULL;
	if (work && pg_effect_inference_pack(work, &arena, &equations, &effect_count, &effect_roots)) goto done;
	if (pg_wire_write_u64(file, equations) || pg_wire_write_u64(file, effect_count)) goto done;
	for (size_t i = 0; i < effect_count; ++i)
		if (term_reference(file, effect_roots[i], &term_roots)) goto done;
	if (term_roots.count > SIZE_MAX / sizeof(void *)) goto done;
	const struct pg_term **terms = pg_alloc(&arena, term_roots.count * sizeof(*terms));
	if (!terms) goto done;
	for (const struct pg_dag_node *node = term_roots.first; node; node = node->next)
		terms[node->id - 1] = node->key;
	status = pg_graph_write_descriptors(file, term_roots.count, terms, codec, owner);
done:
	pg_graph_destroy(&arena);
	pg_dag_destroy(&term_roots);
	pg_dag_destroy(&dag);
	return status;
}

int pg_derivations_write_descriptors(FILE *file, const struct pg_typing *typing,
	size_t count, const struct pg_evidence *const *roots,
	const struct pg_graph_codec *codec, void *owner)
{
	if (count && !roots) return -1;
	struct proof_view inputs = {typing, roots};
	struct pg_derivation_view view = {count, &inputs, proof_root, proof_header, proof_child};
	return pg_derivation_view_write(file, &view, NULL, codec, owner);
}

int pg_derivation_inputs_write(FILE *file, size_t count, const struct pg_derivation_input *const *roots,
	const struct pg_graph_codec *codec, void *owner)
{
	return pg_derivation_inputs_write_inference(file, count, roots, NULL, codec, owner);
}

int pg_derivation_inputs_write_inference(FILE *file, size_t count,
	const struct pg_derivation_input *const *roots, const struct pg_effect_inference *work,
	const struct pg_graph_codec *codec, void *owner)
{
	if (count && !roots) return -1;
	struct pg_derivation_view view = pg_derivation_input_view(count, roots);
	return pg_derivation_view_write(file, &view, work, codec, owner);
}

int pg_derivation_view_write(FILE *file, const struct pg_derivation_view *view,
	const struct pg_effect_inference *work, const struct pg_graph_codec *codec, void *owner)
{
	return write_dag(file, view, work, codec, owner, 0);
}

int pg_derivation_headers_write(FILE *file, size_t count,
	const struct pg_derivation_input *const *roots,
	const struct pg_graph_codec *codec, void *owner)
{
	if (count && !roots) return -1;
	struct pg_derivation_view view = pg_derivation_input_view(count, roots);
	return write_dag(file, &view, NULL, codec, owner, 1);
}

struct input_record {
	struct pg_derivation_input *input;
	uint64_t binder, effects, source, target, operation, handler, declaration, constructor, constant;
	size_t metadata_count, allocation_count;
	uint64_t *metadata, *allocation;
};

int pg_derivations_read(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_object *(*resolve)(void *, const char *), void *owner,
	size_t *count, const struct pg_derivation_input *const **roots)
{
	const struct pg_graph_codec codec = {.resolve = resolve};
	return pg_derivations_read_descriptors(file, typing, limit, name_limit, &codec, owner, count, roots);
}

static int read_dag(FILE *file, struct pg_typing *typing, struct pg_graph *inputs, size_t limit, size_t name_limit,
	struct pg_effect_inference *work, const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_derivation_input *const **roots, struct pg_graph *scratch, int headers)
{
	if (!typing || !typing->contexts.capacity || !inputs) return -1;
	struct pg_graph *graph = typing->graph;
	if (!file || !graph || !graph->terms.capacity || !count || !roots) return -1;
	if (work && (work->rows != graph || work->sealed || work->failed || work->row_sources.count)) return -1;
	char header[8];
	uint64_t n, nr;
	if (fread(header, 1, 8, file) != 8 || memcmp(header, headers ? header_magic : magic, 8)) return -1;
	if (pg_wire_read_u64(file, &n) || pg_wire_read_u64(file, &nr)) return -1;
	if (n > limit || nr > limit - n) return -1;
	struct input_record *records = pg_wire_array(scratch, n, sizeof(*records));
	if (!records) return -1;
	size_t available = limit - (size_t)n - (size_t)nr;
	for (size_t i = 0; i < n; ++i) {
		uint64_t rule, level, direction, totality, arity, reduction_kind;
		if (pg_wire_read_u64(file, &rule)) return -1;
		if (rule > PG_HOST_FUNCTION_INTRO) return -1;
		if (pg_wire_read_u64(file, &level) || pg_wire_read_u64(file, &direction) || direction > PG_IDENTITY_LEFT) return -1;
		if (pg_wire_read_u64(file, &totality) || totality > PG_TOTALITY_TOTAL) return -1;
		if (totality && rule != PG_RETURN_TYPE_FORM && rule != PG_RETURN_INTRO) return -1;
		if (pg_wire_read_u64(file, &reduction_kind) || reduction_kind > PG_REDUCTION_PREFIX) return -1;
		if (pg_wire_read_u64(file, &records[i].binder) || pg_wire_read_u64(file, &records[i].effects)
			|| pg_wire_read_u64(file, &records[i].source)
			|| pg_wire_read_u64(file, &records[i].target) || pg_wire_read_u64(file, &records[i].operation)
			|| pg_wire_read_u64(file, &records[i].handler)
			|| pg_wire_read_u64(file, &records[i].declaration) || pg_wire_read_u64(file, &records[i].constructor)) return -1;
		if (pg_wire_read_u64(file, &records[i].constant)) return -1;
		uint64_t nm, na;
		if (pg_wire_read_u64(file, &nm) || pg_wire_read_u64(file, &na)) return -1;
		if (nm > available || na > available - nm) return -1;
		if ((nm || na) && rule != PG_INDUCTION_ELIM) return -1;
		available -= (size_t)(nm + na);
		records[i].metadata_count = (size_t)nm;
		records[i].allocation_count = (size_t)na;
		records[i].metadata = pg_wire_array(scratch, nm, sizeof(uint64_t));
		records[i].allocation = pg_wire_array(scratch, na, sizeof(uint64_t));
		if (!records[i].metadata || !records[i].allocation) return -1;
		for (size_t j = 0; j < nm; ++j) if (pg_wire_read_u64(file, &records[i].metadata[j])) return -1;
		for (size_t j = 0; j < na; ++j) if (pg_wire_read_u64(file, &records[i].allocation[j])) return -1;
		if (pg_wire_read_u64(file, &arity)) return -1;
		if (arity > available || arity > (SIZE_MAX - sizeof(struct pg_derivation_input)) / sizeof(void *)) return -1;
		available -= (size_t)arity;
		size_t edges = headers ? 0 : (size_t)arity;
		struct pg_derivation_input *input = pg_alloc(inputs, sizeof(*input) + edges * sizeof(*input->premises));
		if (!input) return -1;
		records[i].input = input;
		input->rule = (enum pg_evidence_rule)rule;
		input->parameters.level = level;
		input->parameters.totality = (enum pg_totality)totality;
		input->parameters.direction = (enum pg_identity_direction)direction;
		input->reduction_kind = (enum pg_reduction_kind)reduction_kind;
		input->count = (size_t)arity;
		for (size_t j = 0; j < edges; ++j) {
			uint64_t id;
			if (pg_wire_read_u64(file, &id) || !id || id > i) return -1;
			input->premises[j] = records[id - 1].input;
		}
	}
	const struct pg_derivation_input **result = pg_wire_array(inputs, nr, sizeof(*result));
	if (!result) return -1;
	for (size_t i = 0; i < nr; ++i) {
		uint64_t id;
		if (pg_wire_read_u64(file, &id) || !id || id > n) return -1;
		result[i] = records[id - 1].input;
	}
	uint64_t equations, effect_count;
	if (pg_wire_read_u64(file, &equations) || pg_wire_read_u64(file, &effect_count)) return -1;
	if (effect_count > available || equations > effect_count / 2) return -1;
	if ((effect_count - 2 * equations) % 3 || (effect_count && !work)) return -1;
	uint64_t *effect_ids = pg_wire_array(scratch, effect_count, sizeof(*effect_ids));
	const struct pg_term **effect_roots = pg_wire_array(scratch, effect_count, sizeof(*effect_roots));
	if (!effect_ids || !effect_roots) return -1;
	for (size_t i = 0; i < effect_count; ++i)
		if (pg_wire_read_u64(file, &effect_ids[i])) return -1;
	size_t term_count;
	const struct pg_term *const *terms;
	if (pg_graph_read_descriptors(file, graph, limit, name_limit, codec, owner, &term_count, &terms)) return -1;
	for (size_t i = 0; i < effect_count; ++i) {
		if (!effect_ids[i] || effect_ids[i] > term_count) return -1;
		effect_roots[i] = terms[effect_ids[i] - 1];
	}
	if (work && pg_effect_inference_unpack(work, (size_t)equations, (size_t)effect_count, effect_roots)) return -1;
	for (size_t i = 0; i < n; ++i) {
		const struct input_record *r = &records[i];
		if (r->metadata_count || r->allocation_count) {
			const struct pg_term **allocation = pg_wire_array(scratch, r->allocation_count, sizeof(*allocation));
			struct pg_induction_allocation *a = pg_alloc(graph, sizeof(*a));
			if (!allocation || !a) return -1;
			for (size_t j = 0; j < r->allocation_count; ++j) {
				uint64_t id = r->allocation[j];
				if (!id || id > term_count) return -1;
				allocation[j] = terms[id - 1];
			}
			size_t nb;
			const struct pg_term *const *binders;
			if (pg_contexts_unpack(typing, r->metadata_count, r->metadata,
				r->allocation_count, allocation, &a->count, &a->clauses, &nb, &binders)) return -1;
			if (nb != 3) return -1;
			for (size_t j = 0; j < nb; ++j)
				if (binders[j]->kind != PG_REFERENCE || binders[j]->as.reference->kind != PG_BINDER) return -1;
			a->recursion = binders[0]->as.reference;
			a->argument = binders[1]->as.reference;
			a->self = binders[2]->as.reference;
			r->input->parameters.induction = a;
		}
		if (r->binder > term_count || r->effects > term_count || r->source > term_count || r->target > term_count) return -1;
		if (r->operation > term_count || r->handler > term_count) return -1;
		if (r->declaration > term_count || r->constructor > term_count) return -1;
		if (r->constant > term_count) return -1;
		if (r->input->rule == PG_HOST_TYPE_FORM || r->input->rule == PG_HOST_VALUE_INTRO
			|| r->input->rule == PG_HOST_FUNCTION_INTRO) {
			if (!r->constant || terms[r->constant - 1]->kind != PG_REFERENCE) return -1;
			r->input->parameters.constant = terms[r->constant - 1]->as.reference;
		} else if (r->constant) return -1;
		if (r->input->rule == PG_INDUCTIVE_FORM) {
			if (!r->declaration || terms[r->declaration - 1]->kind != PG_REFERENCE) return -1;
			r->input->parameters.declaration = pg_data_declaration_view(terms[r->declaration - 1]->as.reference);
			if (!r->input->parameters.declaration) return -1;
		} else if (r->declaration) return -1;
		if (r->input->rule == PG_CONSTRUCTOR_INTRO) {
			if (!r->constructor || terms[r->constructor - 1]->kind != PG_REFERENCE) return -1;
			r->input->parameters.constructor = terms[r->constructor - 1]->as.reference;
			const struct pg_data_layout *layout;
			size_t index, arity;
			if (!pg_data_constructor_view(r->input->parameters.constructor, &layout, &index, &arity)) return -1;
		} else if (r->constructor) return -1;
		if (r->input->rule == PG_REQUEST_INTRO) {
			if (!r->operation || terms[r->operation - 1]->kind != PG_REFERENCE) return -1;
			const struct pg_term *payload, *response;
			r->input->parameters.operation_label = terms[r->operation - 1]->as.reference;
			if (!pg_operation_label_types(r->input->parameters.operation_label, &payload, &response)) return -1;
		} else if (r->operation) return -1;
		if (r->input->rule == PG_HANDLER_ELIM) {
			if (!r->handler) return -1;
			r->input->parameters.handler = pg_handler_signature_view(terms[r->handler - 1]);
			if (!r->input->parameters.handler) return -1;
		} else if (r->handler) return -1;
		if (r->input->rule == PG_RETURN_TYPE_FORM) {
			if (!r->effects) return -1;
			const struct pg_term *row = terms[r->effects - 1];
			r->input->parameters.effects = pg_effect_row_view(row);
			if (!r->input->parameters.effects) {
				if (row->kind != PG_REFERENCE || !pg_effect_equation_find(work, row->as.reference)) return -1;
				r->input->effect_parameter = row->as.reference;
			}
		} else if (r->effects) return -1;
		if (r->binder) {
			const struct pg_term *binder = terms[r->binder - 1];
			if (binder->kind != PG_REFERENCE || binder->as.reference->kind != PG_BINDER) return -1;
			r->input->parameters.binder = binder->as.reference;
		}
		r->input->source = r->source ? terms[r->source - 1] : NULL;
		r->input->target = r->target ? terms[r->target - 1] : NULL;
		switch (r->input->rule) {
		case PG_TYPE_CONVERSION: case PG_PURE_NORMALIZATION:
			if (!r->source || !r->target) return -1;
			break;
		default:
			if (r->source || r->target) return -1;
			break;
		}
	}
	*count = (size_t)nr;
	*roots = result;
	return 0;
}

int pg_derivations_read_descriptors(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_derivation_input *const **roots)
{
	return pg_derivations_read_inference(file, typing, typing ? typing->graph : NULL, limit, name_limit, NULL, codec, owner, count, roots);
}

int pg_derivations_read_inference(FILE *file, struct pg_typing *typing, struct pg_graph *inputs, size_t limit, size_t name_limit,
	struct pg_effect_inference *work, const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_derivation_input *const **roots)
{
	/* The caller chooses the rule-input lifetime independently of semantic data. */
	struct pg_graph scratch = {0};
	int status = read_dag(file, typing, inputs, limit, name_limit, work, codec, owner, count, roots, &scratch, 0);
	pg_graph_destroy(&scratch);
	if (status && work) work->failed = 1;
	return status;
}

int pg_derivation_headers_read(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_derivation_input *const **roots)
{
	struct pg_graph scratch = {0};
	int status = read_dag(file, typing, typing ? typing->graph : NULL, limit, name_limit, NULL, codec, owner, count, roots, &scratch, 1);
	pg_graph_destroy(&scratch);
	return status;
}

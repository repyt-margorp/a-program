set pagination off
break core.c:3591
run
print ambient_identity
print checked_count
print native_admissions(&typing)
print *(struct pg_context_map *)ambient_identity
print *((struct pg_context_map *)ambient_identity)->images[0]
print *((struct pg_context_map *)ambient_identity)->images[63]
continue
bt

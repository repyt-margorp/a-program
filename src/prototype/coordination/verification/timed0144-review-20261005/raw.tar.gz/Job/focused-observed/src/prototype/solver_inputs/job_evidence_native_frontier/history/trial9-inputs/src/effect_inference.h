#ifndef A_PROGRAM_POINTER_EFFECT_INFERENCE_H
#define A_PROGRAM_POINTER_EFFECT_INFERENCE_H

#include "classifier.h"
#include "subscription.h"

struct pg_effect_equation;
struct pg_effect_dependency;
struct pg_dag;
struct pg_effect_inference {
	struct pg_graph arena;
	struct pg_graph *rows;
	struct pg_index dependencies;
	struct pg_index row_sources;
	struct pg_effect_equation *first_equation, *last_equation;
	struct pg_effect_dependency *first_dependency, *last_dependency;
	struct pg_effect_equation *head, *tail, *current;
	struct pg_effect_dependency *cursor;
	struct pg_subscription *waiters;
	int sealed, failed;
};

/* Finite positive set equations: target = seed union all (source \ mask)
 * incoming contributions. All seeds/masks are closed rows. Equation sites
 * have fresh pointer identity; identical dependency tuples are shared.
 * This is least-effect inference, NOT unification of arbitrary open row metas.
 * Seal only after every contribution is known. No result is exposed before
 * sealing and convergence; these results are not typing certificates.
 * rows and supplied seed/mask rows outlive this work; equation handles live
 * until destroy. Do not relocate/reinitialize work while handles are live. */
int pg_effect_inference_init(struct pg_effect_inference *work, struct pg_graph *rows);
void pg_effect_inference_destroy(struct pg_effect_inference *work);
struct pg_effect_equation *pg_effect_equation(struct pg_effect_inference *work,
	const struct pg_effect_row *seed);
/* Register a relocated plain parameter. Its immutable seed must agree on reuse.
 * Existing sites remain queryable after sealing; new sites do not. No saved
 * approximation or accepted-state flag is imported by this operation. */
struct pg_effect_equation *pg_effect_equation_at(struct pg_effect_inference *work,
	const struct pg_object *parameter, const struct pg_effect_row *seed);
struct pg_effect_equation *pg_effect_equation_find(const struct pg_effect_inference *work,
	const struct pg_object *parameter);
const struct pg_effect_row *pg_effect_equation_seed(const struct pg_effect_inference *work,
	const struct pg_effect_equation *equation);
/* Read immutable definitions in registration order, equations before edges,
 * once each. Neither hash layout nor solver progress changes this order. Callbacks
 * return zero to continue and must not mutate work. Queue/value approximations
 * and the disposable constant-source lookup cache are not exported. */
int pg_effect_inference_visit(const struct pg_effect_inference *work, void *context,
	int (*equation)(void *, const struct pg_effect_equation *, const struct pg_effect_row *),
	int (*dependency)(void *, const struct pg_effect_equation *, const struct pg_effect_row *, const struct pg_effect_equation *));
/* Collect roots directly into a dependency DAG with initialized term storage.
 * No wire payload, queue state or inferred solution is materialized. Descriptor
 * objects remain borrowed from rows; collection does not advance or seal work. */
int pg_effect_inference_collect(const struct pg_effect_inference *work, struct pg_dag *terms);
/* Image root slice: equation pairs (parameter, seed), then dependency triples
 * (source parameter, mask, target parameter). Pack allocates in storage and
 * borrows descriptor objects from rows. Include these roots in the SAME Core
 * relocation table as classifier/rule roots, not an independent effect file.
 * Unpack requires an empty initialized worker; failure poisons it until destroy.
 * It restores definitions only and leaves the worker unsealed. The image owner
 * decides when all contributions are known; no queue or solution is imported. */
int pg_effect_inference_pack(const struct pg_effect_inference *work, struct pg_graph *storage,
	size_t *equations, size_t *count, const struct pg_term *const **roots);
int pg_effect_inference_unpack(struct pg_effect_inference *work,
	size_t equations, size_t count, const struct pg_term *const *roots);
/* Structural parameter for unaccepted classifier spines. Its binder object
 * lives in rows, outliving the worker; it has no pointer back to work/equation.
 * Distinct equations have distinct parameters even for equal seeds/results.
 * This is not a value binder declaration, operation label or formation proof.
 * After convergence, ordinary substitution can replace its references by the
 * closed result's pg_effect_reference. The original graph remains unchanged.
 * The equation handle itself must still be live when calling this accessor. */
const struct pg_object *pg_effect_equation_parameter(const struct pg_effect_inference *work,
	const struct pg_effect_equation *equation);
/* Add (row_term minus mask) to target. row_term is either a closed row
 * reference or an exact parameter reference owned by this worker. Unknown
 * references are rejected, never interpreted as empty or as operation labels.
 * Constant sources and dependency edges are shared. This reads unaccepted
 * classifier structure only; it does not certify that structure as a type. */
int pg_effect_contribution(struct pg_effect_inference *work,
	const struct pg_term *row_term, const struct pg_effect_row *mask,
	struct pg_effect_equation *target);
int pg_effect_dependency(struct pg_effect_inference *work,
	struct pg_effect_equation *source, const struct pg_effect_row *mask,
	struct pg_effect_equation *target);
/* Deep-handler effect equation. Only the input edge subtracts handled labels;
 * return/clause effects escape this handler. A clause may depend on target
 * through its resumption. All equation handles must belong to work. */
int pg_effect_handler_dependencies(struct pg_effect_inference *work,
	struct pg_effect_equation *target, struct pg_effect_equation *input,
	const struct pg_effect_row *handled, struct pg_effect_equation *returned,
	size_t count, struct pg_effect_equation *const *clauses);
void pg_effect_inference_seal(struct pg_effect_inference *work);
/* Wake parked consumers without a second scheduling/result owner. */
void pg_effect_inference_fail(struct pg_effect_inference *work);
/* -1 failure, 0 pending, 1 converged. One transition processes one edge or
 * one empty adjacency list. Row set operations are not wall-time bounded. */
int pg_effect_inference_advance(struct pg_effect_inference *work, uint64_t budget);
const struct pg_effect_row *pg_effect_inference_result(const struct pg_effect_inference *work,
	const struct pg_effect_equation *equation);

#endif

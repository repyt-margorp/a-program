#include "program.h"
#include "source_io.h"
#include "synthesis_source.h"
#include "artifact/source.h"
#include "artifact/schedule.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int solving;
void __real_pg_synthesis_advance(struct pg_synthesis *, uint64_t);
void __wrap_pg_synthesis_advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	assert(solving);
	__real_pg_synthesis_advance(synthesis, fuel);
}

struct checkpoint {
	const struct pg_artifact_source *source;
	const struct pg_artifact_schedule *schedule;
};

static struct pg_program *start(const char *text)
{
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	struct pg_parser parser;
	pg_parser_init(&parser, &program->graph, text, strlen(text));
	const struct pg_syntax *syntax = pg_parser_program(&parser);
	assert(syntax && !parser.error && syntax->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, syntax->items[0].expression);
	assert(program->root);
	return program;
}

static void advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	solving = 1;
	pg_synthesis_advance(synthesis, fuel);
	solving = 0;
}

static size_t map(struct pg_program *program, struct pg_synthesis_job ***output)
{
	struct pg_synthesis *synthesis = &program->synthesis;
	size_t count = synthesis->jobs.count, next = 1;
	struct pg_synthesis_job **jobs = calloc(count, sizeof(*jobs));
	assert(jobs);
	jobs[0] = program->root;
	for (struct pg_synthesis_job *job = synthesis->ready; job; job = job->next) {
		if (job == program->root) continue;
		assert(next < count);
		jobs[next++] = job;
	}
	/* This boundary precedes all child dispatches. A later stage needs its
	 * real child owners; it must not silently drop dormant or checked work. */
	assert(next == count);
	*output = jobs;
	return count;
}

static int write_continuation(FILE *file, const struct pg_graph_codec *codec,
	void *objects, void *opaque)
{
	(void)codec;
	(void)objects;
	const struct checkpoint *checkpoint = opaque;
	return pg_artifact_source_write(file, checkpoint->source)
		|| pg_artifact_schedule_save(file, checkpoint->schedule);
}

static int read_continuation(FILE *file, struct pg_typing *typing, size_t limit,
	size_t name_limit, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	(void)name_limit;
	(void)codec;
	(void)objects;
	struct checkpoint *checkpoint = opaque;
	checkpoint->source = pg_artifact_source_read(file, typing->graph, limit);
	checkpoint->schedule = pg_artifact_schedule_read(file, typing->graph, limit);
	return !checkpoint->source || !checkpoint->schedule;
}

static uint64_t finish(struct pg_program *program)
{
	while (program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		advance(&program->synthesis, 1);
		assert(program->synthesis.steps < 10000);
	}
	assert(pg_synthesis_result(program->root));
	return program->synthesis.steps;
}

static void equal(FILE *left, FILE *right)
{
	rewind(left);
	rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); assert(a == b); } while (a != EOF);
	assert(!ferror(left) && !ferror(right));
}

static void check(const char *text, unsigned ordinal)
{
	struct pg_program *program = start(text);
	uint64_t total = finish(program);
	pg_program_destroy(program);
	program = start(text);
	advance(&program->synthesis, 1);
	assert(program->synthesis.steps == 1 && program->root->status == PG_SYNTHESIS_PENDING);
	struct pg_synthesis_job *rule = pg_synthesis_work_project(program->root).rule;
	assert(rule);
	struct pg_synthesis_job **jobs;
	size_t count = map(program, &jobs);
	struct checkpoint written = {
		.source = pg_artifact_source_capture(&program->graph, &program->synthesis,
			count, jobs, 1, &program->root),
		.schedule = pg_artifact_schedule_capture(&program->graph, &program->synthesis, count, jobs)
	};
	assert(written.source && written.schedule);
	FILE *file = tmpfile();
	assert(file);
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	assert(!pg_sources_write_with(file, &program->synthesis, 1, &root, 0,
		write_continuation, &written));
	assert(program->synthesis.steps == 1);
	free(jobs);
	pg_program_destroy(program);
	rewind(file);
	struct checkpoint loaded = {0};
	size_t roots;
	struct pg_synthesis_job *const *sources;
	program = pg_sources_read_with(file, 100000, &roots, &sources, read_continuation, &loaded);
	assert(program && roots == 1 && !program->synthesis.steps && fgetc(file) == EOF);
	program->root = sources[0];
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(&program->synthesis, program->root, &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	const struct pg_source_scope *inner = pg_synthesis_binding_scope(binding);
	struct pg_synthesis_job *body = pg_synthesis_request(&program->synthesis, inner, syntax->right);
	rule = pg_synthesis_lambda_body(&program->synthesis,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(binding)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)});
	assert(binding && inner && body && rule && !program->synthesis.steps);
	FILE *resave = tmpfile();
	assert(resave);
	root = (struct pg_synthesis_input){.pending = pg_synthesis_pending(program->root)};
	assert(!pg_sources_write_with(resave, &program->synthesis, 1, &root, 0,
		write_continuation, &loaded));
	equal(file, resave);
	assert(!fclose(resave) && !program->synthesis.steps);
	size_t restored_count = map(program, &jobs);
	assert(restored_count == count);
	assert(!pg_artifact_source_prepare(&program->synthesis, loaded.source, count, jobs));
	assert(!pg_artifact_source_attach(&program->synthesis, loaded.source, count, jobs));
	assert(!pg_artifact_schedule_attach(&program->synthesis, loaded.schedule, count, jobs));
	assert(!program->synthesis.steps && program->root->status == PG_SYNTHESIS_PENDING);
	advance(&program->synthesis, 0);
	assert(!program->synthesis.steps && program->root->status == PG_SYNTHESIS_PENDING);
	assert(pg_synthesis_work_project(program->root).rule == rule);
	uint64_t useful = finish(program);
	assert(useful == total - 1);
	printf("lambda-checkpoint=%u saved=1 validation=0 useful=%" PRIu64 " total=%" PRIu64 " jobs=%zu\n",
		ordinal, useful, total, count);
	free(jobs);
	pg_program_destroy(program);
	assert(!fclose(file));
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	check("main := \\x : @ => x;", 0);
	check("main := \\x : @ => @;", 1);
	check("main := \\x : @ => \\y : @ => x;", 2);
	return 0;
}

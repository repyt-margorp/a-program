#include "occurrence_io.h"
#include "context_io.h"
#include "wire.h"
#include "dag.h"

#include <string.h>

static const char magic[8] = "APGOCCA";
static const char scoped_magic[8] = "APGSCP4";

_Static_assert(offsetof(struct pg_scope, judgement) == offsetof(struct pg_occurrence, judgement),
	"typed input judgement offset");

static enum pg_evidence_judgement input_judgement(const void *key)
{
	enum pg_evidence_judgement judgement;
	memcpy(&judgement, (const char *)key + offsetof(struct pg_scope, judgement), sizeof(judgement));
	return judgement;
}

static size_t structure_arity(const struct pg_occurrence *source)
{
	return source->map ? 1 + source->map->count : source->operand_count + (source->origin != NULL);
}

static int operand(void *unused, const void *key, size_t index, const void **child)
{
	(void)unused;
	if (input_judgement(key) == PG_JUDGEMENT_CONTEXT) {
		const struct pg_scope *scope = key;
		if (index > 2) return 0;
		*child = index == 0 ? (const void *)scope->parent :
			index == 1 ? (const void *)scope->indices : (const void *)scope->type;
		return *child ? 1 : 2;
	}
	const struct pg_occurrence *source = key;
	size_t arity = structure_arity(source);
	if (index == arity && source->type) {
		*child = source->type;
		return 1;
	}
	if (index >= arity) {
		index -= arity + (source->type != NULL);
		const struct pg_context_map *const *maps = pg_occurrence_maps(source);
		for (size_t i = 0; i < source->map_count; ++i) {
			if (index < maps[i]->count) { *child = maps[i]->images[index]; return 1; }
			index -= maps[i]->count;
		}
		if (!index && source->scope) { *child = source->scope; return 1; }
		return 0;
	}
	if (source->map) {
		*child = index ? source->map->images[index - 1] : source->origin;
		return 1;
	}
	if (source->origin) {
		*child = index ? source->operands[index - 1] : source->origin;
		return 1;
	}
	*child = source->operands[index];
	return 1;
}

static int write_dag(FILE *file, size_t count, const struct pg_occurrence *const *roots,
	int scoped, const struct pg_scope *const *scopes,
	const struct pg_graph_codec *codec, void *owner)
{
	if (!file || (count && !roots)) return -1;
	struct pg_graph arena = {0};
	struct pg_dag dag = {0};
	int status = -1;
	if (pg_graph_init(&arena) || pg_dag_init(&dag, operand, NULL)) goto done;
	if (scoped) {
		if (count && !scopes) goto done;
		for (size_t i = 0; i < count; ++i) {
			if (!roots[i] || roots[i]->context != (scopes[i] ? scopes[i]->context : NULL)) goto done;
			if (scopes[i] && pg_dag_add(&dag, scopes[i])) goto done;
		}
	}
	for (size_t i = 0; i < count; ++i) {
		if (!roots[i] || roots[i]->judgement == PG_JUDGEMENT_CONTEXT ||
			pg_dag_add(&dag, roots[i])) goto done;
	}
	size_t size = dag.count, context_count = size;
	if (size > SIZE_MAX / sizeof(void *) / 3) goto done;
	size_t term_count = 0, induction_terms = 0;
	for (const struct pg_dag_node *r = dag.first; r; r = r->next) {
		if (input_judgement(r->key) == PG_JUDGEMENT_CONTEXT) continue;
		const struct pg_occurrence *o = r->key;
		term_count += 1 + (o->annotation != NULL) + (o->classifier != NULL);
		if (o->map_count > SIZE_MAX / sizeof(void *) - context_count) goto done;
		context_count += o->map_count;
		if (o->induction) {
			if (o->induction->count > SIZE_MAX / sizeof(void *) - context_count) goto done;
			if (induction_terms > SIZE_MAX / sizeof(void *) - 3) goto done;
			context_count += o->induction->count;
			induction_terms += 3;
		}
	}
	size_t header_terms = term_count;
	if (induction_terms > SIZE_MAX / sizeof(void *) - term_count) goto done;
	term_count += induction_terms;
	const struct pg_context **contexts = pg_alloc(&arena, context_count * sizeof(*contexts));
	const struct pg_term **terms = pg_alloc(&arena, term_count * sizeof(*terms));
	if (!contexts || !terms) goto done;
	size_t next_context = size, next_header = 0, next_term = header_terms;
	if (fwrite(scoped ? scoped_magic : magic, 1, 8, file) != 8 || pg_wire_write_u64(file, size) || pg_wire_write_u64(file, count)) goto done;
	if (scoped) {
		for (size_t i = 0; i < count; ++i) {
			const struct pg_dag_node *r = pg_dag_find(&dag, scopes[i]);
			if (pg_wire_write_u64(file, r ? r->id : 0)) goto done;
		}
	}
	for (const struct pg_dag_node *r = dag.first; r; r = r->next) {
		if (input_judgement(r->key) == PG_JUDGEMENT_CONTEXT) {
			const struct pg_scope *scope = r->key;
			contexts[r->id - 1] = scope->context;
			if (fputc(128, file) == EOF || fputc(PG_JUDGEMENT_CONTEXT, file) == EOF) goto done;
			for (size_t i = 0; i < 3; ++i) {
				const void *key = NULL;
				int present = operand(NULL, scope, i, &key);
				const struct pg_dag_node *child = present == 1 ? pg_dag_find(&dag, key) : NULL;
				if ((present == 1 && !child) || pg_wire_write_u64(file, child ? child->id : 0)) goto done;
			}
			continue;
		}
		const struct pg_occurrence *o = r->key;
		contexts[r->id - 1] = o->context;
		terms[next_header++] = o->core;
		if (o->annotation) terms[next_header++] = o->annotation;
		if (o->classifier) terms[next_header++] = o->classifier;
		int flags = (o->annotation != NULL) | ((o->classifier != NULL) << 1) |
			((o->map != NULL) << 2) | ((o->origin && !o->map) << 3) | ((o->type != NULL) << 4) |
			((o->induction != NULL) << 5) | ((o->scope != NULL) << 6);
		size_t arity = structure_arity(o) + (o->type != NULL) + (o->scope != NULL);
		const struct pg_context_map *const *maps = pg_occurrence_maps(o);
		for (size_t i = 0; i < o->map_count; ++i) {
			if (maps[i]->count > SIZE_MAX - arity) goto done;
			arity += maps[i]->count;
			contexts[next_context++] = maps[i]->source;
		}
		if (fputc(flags, file) == EOF || fputc(o->judgement, file) == EOF ||
			pg_wire_write_u64(file, arity) || pg_wire_write_u64(file, o->selection)) goto done;
		for (size_t i = 0; i < arity; ++i) {
			const void *key;
			if (!operand(NULL, o, i, &key)) goto done;
			const struct pg_dag_node *child = pg_dag_find(&dag, key);
			if (!child || pg_wire_write_u64(file, child->id)) goto done;
		}
		if (pg_wire_write_u64(file, o->map_count)) goto done;
		for (size_t i = 0; i < o->map_count; ++i)
			if (pg_wire_write_u64(file, maps[i]->count)) goto done;
		if (o->induction) {
			const struct pg_induction_allocation *a = o->induction;
			if (pg_wire_write_u64(file, a->count)) goto done;
			for (size_t i = 0; i < a->count; ++i) contexts[next_context++] = a->clauses[i];
			terms[next_term++] = pg_reference(&arena, a->recursion);
			terms[next_term++] = pg_reference(&arena, a->argument);
			terms[next_term++] = pg_reference(&arena, a->self);
		}
	}
	for (size_t i = 0; i < count; ++i) {
		const struct pg_dag_node *r = pg_dag_find(&dag, roots[i]);
		if (!r || pg_wire_write_u64(file, r->id)) goto done;
	}
	status = pg_contexts_write_descriptors(file, context_count, contexts, term_count, terms, codec, owner);
done:
	pg_dag_destroy(&dag);
	pg_graph_destroy(&arena);
	return status;
}

int pg_occurrences_write(FILE *file, size_t count, const struct pg_occurrence *const *roots,
	const char *(*name)(void *, const struct pg_object *), void *owner)
{
	const struct pg_graph_codec codec = {.name = name};
	return pg_occurrences_write_descriptors(file, count, roots, &codec, owner);
}

int pg_occurrences_write_descriptors(FILE *file, size_t count, const struct pg_occurrence *const *roots,
	const struct pg_graph_codec *codec, void *owner)
{
	return write_dag(file, count, roots, 0, NULL, codec, owner);
}

int pg_scoped_occurrences_write(FILE *file, size_t count,
	const struct pg_scope *const *scopes, const struct pg_occurrence *const *roots,
	const char *(*name)(void *, const struct pg_object *), void *owner)
{
	const struct pg_graph_codec codec = {.name = name};
	return pg_scoped_occurrences_write_descriptors(file, count, scopes, roots, &codec, owner);
}

int pg_scoped_occurrences_write_descriptors(FILE *file, size_t count,
	const struct pg_scope *const *scopes, const struct pg_occurrence *const *roots,
	const struct pg_graph_codec *codec, void *owner)
{
	return write_dag(file, count, roots, 1, scopes, codec, owner);
}

struct input {
	size_t count, structural, map_count, clause_count, selection;
	size_t *map_sizes;
	int flags;
	enum pg_evidence_judgement judgement;
	uint64_t *operands;
};

static int read_dag(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_scope *const **scopes, const struct pg_occurrence *const **roots, struct pg_graph *scratch)
{
	if (!file || !typing || !typing->occurrences.capacity || !count || !roots) return -1;
	char header[8];
	uint64_t n, nr;
	if (fread(header, 1, 8, file) != 8 || memcmp(header, scopes ? scoped_magic : magic, 8)) return -1;
	if (pg_wire_read_u64(file, &n) || pg_wire_read_u64(file, &nr)) return -1;
	if (n > limit || nr > limit - n) return -1;
	if (n > SIZE_MAX / 3) return -1;
	struct pg_graph *graph = typing->graph;
	struct input *inputs = pg_wire_array(scratch, n, sizeof(*inputs));
	uint64_t *ids = pg_wire_array(scratch, nr, sizeof(*ids));
	const void **all = pg_wire_array(scratch, n, sizeof(*all));
	if (!inputs || !ids || !all) return -1;
	size_t available = limit - (size_t)n - (size_t)nr, max_arity = 0, max_maps = 0, context_count = (size_t)n;
	uint64_t *scope_ids = NULL;
	if (scopes) {
		if (nr > available) return -1;
		available -= (size_t)nr;
		scope_ids = pg_wire_array(scratch, nr, sizeof(*scope_ids));
		if (!scope_ids) return -1;
		for (size_t i = 0; i < nr; ++i)
			if (pg_wire_read_u64(file, &scope_ids[i]) || scope_ids[i] > n) return -1;
	}
	size_t term_count = 0, induction_terms = 0;
	for (size_t i = 0; i < n; ++i) {
		inputs[i].flags = fgetc(file);
		inputs[i].judgement = fgetc(file);
		if (inputs[i].judgement == PG_JUDGEMENT_CONTEXT) {
			if (inputs[i].flags != 128 || available < 3) return -1;
			available -= 3;
			inputs[i].count = 3;
			inputs[i].operands = pg_wire_array(scratch, 3, sizeof(uint64_t));
			if (!inputs[i].operands) return -1;
			for (size_t j = 0; j < 3; ++j)
				if (pg_wire_read_u64(file, &inputs[i].operands[j]) || inputs[i].operands[j] > i) return -1;
			continue;
		}
		uint64_t arity, selection;
		if (inputs[i].flags < 0 || inputs[i].flags > 127 || (inputs[i].flags & 12) == 12) return -1;
		if ((inputs[i].flags & 32) && (inputs[i].flags & 12)) return -1;
		term_count += 1 + !!(inputs[i].flags & 1) + !!(inputs[i].flags & 2);
		if (pg_wire_read_u64(file, &arity) || arity > available) return -1;
		if (pg_wire_read_u64(file, &selection) || selection > SIZE_MAX) return -1;
		if (selection && !(inputs[i].flags & 8)) return -1;
		inputs[i].selection = (size_t)selection;
		available -= (size_t)arity;
		inputs[i].count = (size_t)arity;
		if (arity > max_arity) max_arity = (size_t)arity;
		inputs[i].operands = pg_wire_array(scratch, arity, sizeof(uint64_t));
		if (!inputs[i].operands) return -1;
		for (size_t j = 0; j < arity; ++j) {
			uint64_t *id = &inputs[i].operands[j];
			if (pg_wire_read_u64(file, id) || !*id || *id > i) return -1;
		}
		uint64_t maps;
		if (pg_wire_read_u64(file, &maps) || maps > available) return -1;
		available -= (size_t)maps;
		context_count += (size_t)maps;
		inputs[i].map_count = (size_t)maps;
		if (maps > max_maps) max_maps = (size_t)maps;
		inputs[i].map_sizes = pg_wire_array(scratch, maps, sizeof(size_t));
		if (!inputs[i].map_sizes) return -1;
		size_t structural = (size_t)arity;
		for (size_t j = 0; j < maps; ++j) {
			uint64_t images;
			if (pg_wire_read_u64(file, &images) || images > structural) return -1;
			inputs[i].map_sizes[j] = (size_t)images;
			structural -= (size_t)images;
		}
		if ((inputs[i].flags & 64) && !structural) return -1;
		structural -= !!(inputs[i].flags & 64);
		if ((inputs[i].flags & 16) && (!structural || !(inputs[i].flags & 2))) return -1;
		structural -= !!(inputs[i].flags & 16);
		if ((inputs[i].flags & 4) && !structural) return -1;
		if (inputs[i].flags & 8) {
			if (!structural || structural > 1 + (selection != 0) || (inputs[i].flags & 1)) return -1;
		}
		inputs[i].structural = structural;
		inputs[i].clause_count = 0;
		if (inputs[i].flags & 32) {
			uint64_t clauses;
			if (available < 3) return -1;
			available -= 3;
			if (pg_wire_read_u64(file, &clauses) || clauses > available) return -1;
			available -= (size_t)clauses;
			inputs[i].clause_count = (size_t)clauses;
			context_count += (size_t)clauses;
			if (induction_terms > SIZE_MAX - 3) return -1;
			induction_terms += 3;
		}
	}
	size_t header_terms = term_count;
	if (induction_terms > SIZE_MAX - term_count) return -1;
	term_count += induction_terms;
	for (size_t i = 0; i < nr; ++i)
		if (pg_wire_read_u64(file, &ids[i]) || !ids[i] || ids[i] > n) return -1;
	size_t nc, nt;
	const struct pg_context *const *contexts;
	const struct pg_term *const *terms;
	if (pg_contexts_read_descriptors(file, typing, limit, name_limit, codec, owner, &nc, &contexts, &nt, &terms)) return -1;
	if (nc != context_count || nt != term_count) return -1;
	const struct pg_occurrence **operands = pg_wire_array(scratch, max_arity, sizeof(*operands));
	const struct pg_context_map **maps = pg_wire_array(scratch, max_maps, sizeof(*maps));
	if (!operands || !maps) return -1;
	size_t next_context = (size_t)n, next_header = 0, next_term = header_terms;
	for (size_t i = 0; i < n; ++i) {
		if (inputs[i].judgement == PG_JUDGEMENT_CONTEXT) {
			uint64_t parent = inputs[i].operands[0], indices = inputs[i].operands[1], type = inputs[i].operands[2];
			if ((parent && inputs[parent - 1].judgement != PG_JUDGEMENT_CONTEXT) ||
				(indices && inputs[indices - 1].judgement != PG_JUDGEMENT_CONTEXT) ||
				(type && inputs[type - 1].judgement == PG_JUDGEMENT_CONTEXT)) return -1;
			all[i] = pg_scope_intern(typing, contexts[i], parent ? all[parent - 1] : NULL,
				indices ? all[indices - 1] : NULL, type ? all[type - 1] : NULL);
			if (!all[i]) return -1;
			continue;
		}
		for (size_t j = 0; j < inputs[i].count; ++j) {
			uint64_t id = inputs[i].operands[j];
			int scope_input = (inputs[i].flags & 64) && j + 1 == inputs[i].count;
			if ((inputs[id - 1].judgement == PG_JUDGEMENT_CONTEXT) != scope_input) return -1;
			if (!scope_input) operands[j] = all[id - 1];
		}
		size_t arity = inputs[i].structural;
		const struct pg_term *core = terms[next_header++];
		size_t annotation = next_header;
		next_header += !!(inputs[i].flags & 1);
		size_t classifier = next_header;
		next_header += !!(inputs[i].flags & 2);
		struct pg_occurrence header = {.judgement = inputs[i].judgement, .context = contexts[i],
			.core = core, .classifier = inputs[i].flags & 2 ? terms[classifier] : NULL,
			.annotation = inputs[i].flags & 1 ? terms[annotation] : NULL,
			.operand_count = arity, .map_count = inputs[i].map_count};
		if (inputs[i].flags & 64) header.scope = all[inputs[i].operands[inputs[i].count - 1] - 1];
		const struct pg_occurrence *const *children = operands;
		if (inputs[i].flags & 4) {
			header.origin = operands[0];
			header.map = pg_context_map(typing, operands[0]->context,
				contexts[i], arity - 1, operands + 1);
			if (!header.map) return -1;
			header.operand_count = 0;
		} else if (inputs[i].flags & 8) {
			if (contexts[i] != operands[0]->context) return -1;
			header.origin = operands[0];
			header.selection = inputs[i].selection;
			header.operand_count = arity - 1;
			children = operands + 1;
		}
		if (inputs[i].flags & 16) header.type = operands[arity];
		size_t first_image = arity + !!(inputs[i].flags & 16);
		for (size_t j = 0; j < inputs[i].map_count; ++j) {
			maps[j] = pg_context_map(typing, contexts[next_context++], contexts[i],
				inputs[i].map_sizes[j], operands + first_image);
			if (!maps[j]) return -1;
			first_image += inputs[i].map_sizes[j];
		}
		struct pg_induction_allocation allocation;
		if (inputs[i].flags & 32) {
			for (size_t j = 0; j < 3; ++j)
				if (terms[next_term + j]->kind != PG_REFERENCE) return -1;
			allocation = (struct pg_induction_allocation){
				.recursion = terms[next_term]->as.reference,
				.argument = terms[next_term + 1]->as.reference,
				.self = terms[next_term + 2]->as.reference,
				.count = inputs[i].clause_count, .clauses = contexts + next_context};
			header.induction = &allocation;
			next_context += allocation.count;
			next_term += 3;
		}
		all[i] = pg_occurrence_intern(typing, &header, children, maps);
		if (!all[i]) return -1;
	}
	const struct pg_occurrence **result = pg_wire_array(graph, nr, sizeof(*result));
	if (!result) return -1;
	for (size_t i = 0; i < nr; ++i) {
		if (inputs[ids[i] - 1].judgement == PG_JUDGEMENT_CONTEXT) return -1;
		result[i] = all[ids[i] - 1];
	}
	if (scopes) {
		const struct pg_scope **selected = pg_wire_array(graph, nr, sizeof(*selected));
		if (!selected) return -1;
		for (size_t i = 0; i < nr; ++i) {
			uint64_t id = scope_ids[i];
			if (id && inputs[id - 1].judgement != PG_JUDGEMENT_CONTEXT) return -1;
			selected[i] = id ? all[id - 1] : NULL;
			if (result[i]->context != (selected[i] ? selected[i]->context : NULL)) return -1;
		}
		*scopes = selected;
	}
	*count = (size_t)nr;
	*roots = result;
	return 0;
}

int pg_occurrences_read(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_object *(*resolve)(void *, const char *), void *owner,
	size_t *count, const struct pg_occurrence *const **roots)
{
	const struct pg_graph_codec codec = {.resolve = resolve};
	return pg_occurrences_read_descriptors(file, typing, limit, name_limit, &codec, owner, count, roots);
}

int pg_occurrences_read_descriptors(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_occurrence *const **roots)
{
	/* Wire IDs and assembly arrays are not part of the retained typed graph. */
	struct pg_graph scratch = {0};
	int status = read_dag(file, typing, limit, name_limit, codec, owner, count, NULL, roots, &scratch);
	pg_graph_destroy(&scratch);
	return status;
}

int pg_scoped_occurrences_read(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_object *(*resolve)(void *, const char *), void *owner,
	size_t *count, const struct pg_scope *const **scopes, const struct pg_occurrence *const **roots)
{
	const struct pg_graph_codec codec = {.resolve = resolve};
	return pg_scoped_occurrences_read_descriptors(file, typing, limit, name_limit, &codec, owner, count, scopes, roots);
}

int pg_scoped_occurrences_read_descriptors(FILE *file, struct pg_typing *typing, size_t limit, size_t name_limit,
	const struct pg_graph_codec *codec, void *owner,
	size_t *count, const struct pg_scope *const **scopes, const struct pg_occurrence *const **roots)
{
	if (!scopes) return -1;
	struct pg_graph scratch = {0};
	int status = read_dag(file, typing, limit, name_limit, codec, owner, count, scopes, roots, &scratch);
	pg_graph_destroy(&scratch);
	return status;
}

include $(OVERLAY)/src/Makefile

$(BUILD)/native_owners: $(SOURCES) $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(CONTROL_IO) $(CONTROL) -o $@

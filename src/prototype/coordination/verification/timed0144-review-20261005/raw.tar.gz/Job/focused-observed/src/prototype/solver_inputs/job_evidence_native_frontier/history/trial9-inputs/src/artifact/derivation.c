#include "derivation.h"
#include "../derivation.h"
#include "file.h"
#include "synthesis_source.h"
#include "dag.h"
#include "wire.h"
#include "effect_inference.h"
#include <string.h>

static const char magic[8] = "APGDRC\5";

struct premise_links {
	size_t count;
	uint64_t *slots;
};

struct pg_artifact_derivations {
	/* External owners precede direct checking rules. */
	size_t external_count, checked_count, count, root_count;
	const struct pg_derivation_input *const *inputs;
	uint64_t *next, *status, *roots;
	struct premise_links *links;
};

static struct pg_artifact_derivations *allocate(struct pg_graph *storage,
	size_t external, size_t count, size_t roots)
{
	if (external >= count || !roots) return NULL;
	struct pg_artifact_derivations *c = pg_alloc(storage, sizeof(*c));
	if (!c) return NULL;
	c->external_count = external; c->count = count; c->root_count = roots;
	c->next = pg_wire_array(storage, count, sizeof(*c->next));
	c->status = pg_wire_array(storage, count, sizeof(*c->status));
	c->roots = pg_wire_array(storage, roots, sizeof(*c->roots));
	c->links = pg_wire_array(storage, count, sizeof(*c->links));
	return c->next && c->status && c->roots && c->links ? c : NULL;
}

/* Imported and source-built rules use the same checking owners. */
struct rule_closure {
	const struct pg_synthesis *synthesis;
	struct pg_dag external, checked;
};

static int rule_child(void *owner, const void *key, size_t i, const void **child)
{
	const struct rule_closure *closure = owner;
	const struct pg_synthesis_job *job = key;
	if (pg_dag_find(&closure->external, job)) return 0;
	const struct pg_derivation_input *input = pg_synthesis_plain_derivation(job);
	if (!input || job->pending.owner != closure->synthesis->owner_key || job->inputs[1] || input->effect_parameter) return -1;
	/* Checked premises are leaves in the enclosing data graph, not jobs. */
	if (i == input->count) return 0;
	struct pg_synthesis_input premise = pg_synthesis_work_dependency(job, 3 + 2 * i);
	if (premise.checked) return pg_dag_find(&closure->checked, premise.checked) ? 2 : -1;
	*child = premise.pending;
	return *child ? 1 : -1;
}

static struct pg_artifact_derivations *capture_frontier(struct pg_graph *storage,
	const struct pg_synthesis *s, const struct pg_dag *jobs, size_t external, size_t count,
	struct pg_synthesis_job *const *roots, const struct rule_closure *closure, struct pg_synthesis_job ***output)
{
	struct pg_artifact_derivations *c = allocate(storage, external, jobs->count, count);
	struct pg_synthesis_job **mapping = pg_wire_array(storage, jobs->count, sizeof(*mapping));
	const struct pg_derivation_input **headers = pg_wire_array(storage, jobs->count - external, sizeof(*headers));
	if (!c || !mapping || !headers) return NULL;
	c->inputs = headers;
	c->checked_count = closure->checked.count;
	for (const struct pg_dag_node *n = jobs->first; n; n = n->next) {
		struct pg_synthesis_job *job = (void *)n->key;
		size_t i = n->id - 1, next;
		mapping[i] = job;
		if (i < external) continue;
		if (job->status != PG_SYNTHESIS_PENDING && job->status != PG_SYNTHESIS_DONE) return NULL;
		c->status[i] = job->status;
		const struct pg_derivation_input *header = pg_synthesis_plain_derivation(job);
		headers[i - external] = header;
		c->links[i].count = header->count;
		c->links[i].slots = pg_wire_array(storage, header->count, sizeof(uint64_t));
		if (!c->links[i].slots) return NULL;
		for (size_t k = 0; k < header->count; ++k) {
			struct pg_synthesis_input premise = pg_synthesis_work_dependency(job, 3 + 2 * k);
			const struct pg_dag_node *link = premise.checked
				? pg_dag_find(&closure->checked, premise.checked) : pg_dag_find(jobs, premise.pending);
			if (!link) return NULL;
			c->links[i].slots[k] = link->id - 1 + (premise.checked ? 0 : c->checked_count);
		}
		if (job->status == PG_SYNTHESIS_PENDING) {
			if (pg_synthesis_rule_frontier(s, job, &next) != 1) return NULL;
			c->next[i] = next;
		}
	}
	for (size_t i = 0; i < count; ++i) c->roots[i] = pg_dag_find(jobs, roots[i])->id - 1;
	*output = mapping;
	return c;
}

static const struct pg_artifact_derivations *capture_rules(struct pg_graph *storage,
	const struct pg_synthesis *s, size_t count, struct pg_synthesis_job *const *roots,
	const struct pg_artifact_derivation_dependencies *dependencies,
	struct pg_synthesis_job ***output)
{
	struct rule_closure closure = {.synthesis = s};
	struct pg_dag jobs = {0};
	const struct pg_artifact_derivations *result = NULL;
	if (pg_dag_init(&closure.external, NULL, NULL) || pg_dag_init(&closure.checked, NULL, NULL)
		|| pg_dag_init(&jobs, rule_child, &closure)) goto done;
	size_t external_count = dependencies ? dependencies->job_count : 0;
	struct pg_synthesis_job *const *external = dependencies ? dependencies->jobs : NULL;
	for (size_t i = 0; dependencies && i < dependencies->checked_count; ++i) {
		const struct pg_evidence *proof = dependencies->checked[i];
		if (!pg_evidence_owned_by(proof, s->typing)) goto done;
		if (pg_dag_add(&closure.checked, proof) || closure.checked.count != i + 1) goto done;
	}
	for (size_t i = 0; i < external_count; ++i) {
		if (!external[i] || external[i]->pending.owner != s->owner_key) goto done;
		if (pg_dag_add(&closure.external, external[i]) || closure.external.count != i + 1) goto done;
		if (pg_dag_add(&jobs, external[i])) goto done;
	}
	for (size_t i = 0; i < count; ++i) {
		if (!roots[i] || pg_dag_find(&closure.external, roots[i])) goto done;
		if (pg_dag_add(&jobs, roots[i])) goto done;
	}
	struct pg_synthesis_job **mapping;
	struct pg_artifact_derivations *c = capture_frontier(storage, s, &jobs, external_count, count, roots, &closure, &mapping);
	if (!c) goto done;
	*output = mapping;
	result = c;
done:
	pg_dag_destroy(&jobs); pg_dag_destroy(&closure.external); pg_dag_destroy(&closure.checked);
	return result;
}

const struct pg_artifact_derivations *pg_artifact_derivations_capture(struct pg_graph *storage,
	const struct pg_synthesis *s, size_t count, struct pg_synthesis_job *const *roots,
	struct pg_synthesis_job ***output)
{
	return pg_artifact_derivations_capture_with_dependencies(storage, s, count, roots, NULL, output);
}

static int dependencies_valid(const struct pg_artifact_derivation_dependencies *d)
{
	return !d || ((!d->job_count || d->jobs) && (!d->checked_count || d->checked));
}

const struct pg_artifact_derivations *pg_artifact_derivations_capture_with_dependencies(struct pg_graph *storage,
	const struct pg_synthesis *s, size_t count, struct pg_synthesis_job *const *roots,
	const struct pg_artifact_derivation_dependencies *dependencies, struct pg_synthesis_job ***output)
{
	if (!storage || !s || !count || !roots || !roots[0] || !output) return NULL;
	if (!dependencies_valid(dependencies)) return NULL;
	return capture_rules(storage, s, count, roots, dependencies, output);
}

size_t pg_artifact_derivations_job_count(const struct pg_artifact_derivations *c)
{
	return c ? c->count : 0;
}

const struct pg_derivation_input *const *pg_artifact_derivations_inputs(
	const struct pg_artifact_derivations *c, size_t *count)
{
	if (!c || !count || !c->inputs) return NULL;
	*count = c->count - c->external_count;
	return c->inputs;
}

int pg_artifact_derivations_write(FILE *file, const struct pg_artifact_derivations *c)
{
	if (!file || !c) return -1;
	if (fwrite(magic, 1, 8, file) != 8 || pg_wire_write_u64(file, c->count) || pg_wire_write_u64(file, c->root_count)
		|| pg_wire_write_u64(file, c->external_count) || pg_wire_write_u64(file, c->checked_count)) return -1;
	for (size_t i = c->external_count; i < c->count; ++i) {
		if (pg_wire_write_u64(file, c->next[i]) || pg_wire_write_u64(file, c->status[i])) return -1;
		if (pg_wire_write_u64(file, c->links[i].count)) return -1;
		for (size_t k = 0; k < c->links[i].count; ++k)
			if (pg_wire_write_u64(file, c->links[i].slots[k])) return -1;
	}
	for (size_t i = 0; i < c->root_count; ++i) if (pg_wire_write_u64(file, c->roots[i])) return -1;
	return 0;
}

const struct pg_artifact_derivations *pg_artifact_derivations_read(FILE *file, struct pg_graph *storage, size_t limit)
{
	if (!file || !storage) return NULL;
	char header[8];
	uint64_t count, roots, external, checked;
	if (fread(header, 1, 8, file) != 8 || memcmp(header, magic, 8)) return NULL;
	if (pg_wire_read_u64(file, &count) || pg_wire_read_u64(file, &roots)) return NULL;
	if (pg_wire_read_u64(file, &external)) return NULL;
	if (pg_wire_read_u64(file, &checked) || checked > limit) return NULL;
	if (count > limit || roots > limit || external >= count) return NULL;
	if (checked > limit - (size_t)count) return NULL;
	struct pg_artifact_derivations *c = allocate(storage, (size_t)external, (size_t)count, (size_t)roots);
	if (!c) return NULL;
	c->checked_count = (size_t)checked;
	size_t available = limit - (size_t)count - c->checked_count;
	for (size_t i = (size_t)external; i < count; ++i) {
		if (pg_wire_read_u64(file, &c->next[i]) || c->next[i] > limit) return NULL;
		if (pg_wire_read_u64(file, &c->status[i]) || c->status[i] > PG_SYNTHESIS_DONE) return NULL;
		if (c->status[i] == PG_SYNTHESIS_DONE && c->next[i]) return NULL;
		uint64_t arity;
		if (pg_wire_read_u64(file, &arity) || arity > available) return NULL;
		available -= (size_t)arity;
		c->links[i].count = (size_t)arity;
		c->links[i].slots = pg_wire_array(storage, arity, sizeof(uint64_t));
		if (!c->links[i].slots || c->next[i] > arity) return NULL;
		for (size_t k = 0; k < arity; ++k)
			if (pg_wire_read_u64(file, &c->links[i].slots[k]) || c->links[i].slots[k] >= checked + i) return NULL;
	}
	for (size_t i = 0; i < roots; ++i)
		if (pg_wire_read_u64(file, &c->roots[i]) || c->roots[i] < external || c->roots[i] >= count) return NULL;
	return c;
}

int pg_artifact_derivations_prepare(struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	size_t count, const struct pg_derivation_input *const *inputs,
	struct pg_synthesis_job ***result)
{
	return pg_artifact_derivations_prepare_with_dependencies(s, c, count, inputs, NULL, result);
}

static struct pg_synthesis_input linked_input(const struct pg_artifact_derivations *c,
	uint64_t slot, struct pg_synthesis_job *const *jobs,
	const struct pg_artifact_derivation_dependencies *dependencies)
{
	return slot < c->checked_count
		? (struct pg_synthesis_input){.checked = dependencies->checked[slot]}
		: (struct pg_synthesis_input){.pending = pg_synthesis_pending(jobs[slot - c->checked_count])};
}

static int dependencies_match(const struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	const struct pg_artifact_derivation_dependencies *d)
{
	if (!dependencies_valid(d)) return 0;
	if (c->external_count != (d ? d->job_count : 0)) return 0;
	if (c->checked_count != (d ? d->checked_count : 0)) return 0;
	for (size_t i = 0; i < c->checked_count; ++i)
		if (!pg_evidence_owned_by(d->checked[i], s->typing)) return 0;
	return 1;
}

static int prepare_rules(struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	const struct pg_derivation_input *const *inputs, const struct pg_artifact_derivation_dependencies *dependencies,
	struct pg_synthesis_job **jobs)
{
	struct pg_dag unique;
	if (pg_dag_init(&unique, NULL, NULL)) return -1;
	int status = -1;
	for (size_t i = 0; i < c->count; ++i) {
		if (i < c->external_count) jobs[i] = dependencies->jobs[i];
		else {
			const struct pg_derivation_input *header = inputs[i - c->external_count];
			const struct premise_links *links = &c->links[i];
			if (!header || header->effect_parameter || header->count != links->count) goto done;
			struct pg_synthesis_input *premises = pg_wire_array(&unique.storage, links->count, sizeof(*premises));
			if (!premises) goto done;
			for (size_t k = 0; k < links->count; ++k) premises[k] = linked_input(c, links->slots[k], jobs, dependencies);
			jobs[i] = pg_synthesis_rule_inputs(s, header, premises, NULL, NULL);
		}
		if (!jobs[i] || jobs[i]->pending.owner != s->owner_key) goto done;
		if (pg_dag_add(&unique, jobs[i]) || unique.count != i + 1) goto done;
	}
	status = 0;
done:
	pg_dag_destroy(&unique);
	return status;
}

int pg_artifact_derivations_prepare_with_dependencies(struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	size_t count, const struct pg_derivation_input *const *inputs,
	const struct pg_artifact_derivation_dependencies *dependencies, struct pg_synthesis_job ***result)
{
	if (!s || !c || count != c->count - c->external_count || !inputs || !result) return -1;
	if (!dependencies_match(s, c, dependencies)) return -1;
	struct pg_synthesis_job **jobs = pg_wire_array(s->typing->graph, c->count, sizeof(*jobs));
	if (!jobs) return -1;
	if (prepare_rules(s, c, inputs, dependencies, jobs)) return -1;
	*result = jobs;
	return 0;
}

size_t pg_artifact_derivations_validation(const struct pg_artifact_derivations *c, size_t *out)
{
	if (!c || !out) return 0;
	size_t count = 0;
	for (size_t i = c->external_count; i < c->count; ++i)
		if (c->status[i] == PG_SYNTHESIS_DONE) out[count++] = i;
	return count;
}

static int mapping_valid(const struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	struct pg_synthesis_job *const *jobs, const struct pg_artifact_derivation_dependencies *dependencies)
{
	if (!s || !c || !jobs) return 0;
	if (!dependencies_match(s, c, dependencies)) return 0;
	for (size_t i = 0; i < c->count; ++i)
		if (!jobs[i] || jobs[i]->pending.owner != s->owner_key) return 0;
	for (size_t i = 0; i < c->external_count; ++i) if (jobs[i] != dependencies->jobs[i]) return 0;
	for (size_t i = c->external_count; i < c->count; ++i) {
		const struct pg_derivation_input *header = pg_synthesis_plain_derivation(jobs[i]);
		if (!header || header->count != c->links[i].count) return 0;
		for (size_t k = 0; k < header->count; ++k) {
			struct pg_synthesis_input actual = pg_synthesis_work_dependency(jobs[i], 3 + 2 * k);
			struct pg_synthesis_input expected =
				linked_input(c, c->links[i].slots[k], jobs, dependencies);
			if (actual.checked != expected.checked || actual.pending != expected.pending) return 0;
		}
	}
	return 1;
}

enum pg_synthesis_status pg_artifact_derivations_revalidate(struct pg_program *p,
	const struct pg_artifact_derivations *c, struct pg_synthesis_job *const *jobs,
	const struct pg_artifact_derivation_dependencies *dependencies,
	uint64_t budget, uint64_t limit, uint64_t *spent)
{
	if (!p || !spent || !mapping_valid(&p->synthesis, c, jobs, dependencies)) return PG_SYNTHESIS_ERROR;
	*spent = 0;
	uint64_t available = budget < limit ? budget : limit;
	for (size_t i = c->external_count; i < c->count; ++i) {
		if (c->status[i] != PG_SYNTHESIS_DONE) continue;
		uint64_t used = 0;
		enum pg_synthesis_status status = pg_artifact_revalidate(p, jobs[i], available, available, &used);
		*spent += used; available -= used;
		if (status != PG_SYNTHESIS_DONE) return status;
	}
	return PG_SYNTHESIS_DONE;
}

int pg_artifact_derivations_attach(struct pg_synthesis *s, const struct pg_artifact_derivations *c,
	struct pg_synthesis_job *const *jobs, const struct pg_artifact_derivation_dependencies *dependencies)
{
	if (!mapping_valid(s, c, jobs, dependencies)) return -1;
	for (size_t i = c->external_count; i < c->count; ++i) {
		if (c->status[i] != PG_SYNTHESIS_DONE) continue;
		if (!pg_synthesis_result(jobs[i])) return -1;
	}
	for (size_t i = c->external_count; i < c->count; ++i)
		if (c->status[i] == PG_SYNTHESIS_PENDING && pg_synthesis_rule_resume(s, jobs[i], c->next[i])) return -1;
	return 0;
}

struct pg_synthesis_job *pg_artifact_derivations_root(const struct pg_artifact_derivations *c,
	struct pg_synthesis_job *const *jobs, size_t index)
{
	return c && jobs && index < c->root_count ? jobs[c->roots[index]] : NULL;
}

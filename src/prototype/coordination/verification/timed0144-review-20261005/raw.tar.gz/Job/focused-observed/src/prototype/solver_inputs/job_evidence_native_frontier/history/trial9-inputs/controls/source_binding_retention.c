#include "../tests/native_admissions.h"
#include "program.h"
#include "source_io.h"
#include "synthesis_source.h"
#include "derivation_io.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>

struct saved_rule {
	const struct pg_derivation_input *header;
};

static int write_rule(FILE *file, const struct pg_graph_codec *codec,
	void *objects, void *opaque)
{
	const struct saved_rule *saved = opaque;
	return pg_derivation_headers_write(file, 1, &saved->header, codec, objects);
}

static int read_rule(FILE *file, struct pg_typing *typing, size_t limit,
	size_t names, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	struct saved_rule *saved = opaque;
	size_t count;
	const struct pg_derivation_input *const *headers;
	if (pg_derivation_headers_read(file, typing, limit, names, codec, objects, &count, &headers)
		|| count != 1) return -1;
	saved->header = headers[0];
	return 0;
}

int main(void)
{
	const char text[] = "main := \\x : @ => x;";
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *parsed = pg_parser_program(&program->parser);
	assert(parsed && !program->parser.error && parsed->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, parsed->items[0].expression);
	assert(program->root);
	pg_synthesis_advance(&program->synthesis, 5);
	assert(program->synthesis.steps == 5);
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(&program->synthesis, program->root, &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	struct pg_synthesis_job *body = pg_synthesis_request(&program->synthesis,
		pg_synthesis_binding_scope(binding), syntax->right);
	struct pg_reference_frontier reference;
	assert(pg_synthesis_reference_frontier(&program->synthesis, body, &reference) == 1);
	struct saved_rule saved = {.header = pg_synthesis_plain_derivation(reference.rule)};
	assert(saved.header && saved.header->rule == PG_VARIABLE);
	FILE *file = tmpfile();
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	assert(file && !pg_sources_write_with(file, &program->synthesis, 1, &root, 0, write_rule, &saved));
	pg_program_destroy(program);
	rewind(file);
	size_t count;
	struct pg_synthesis_job *const *roots;
	program = pg_sources_read_with(file, 100000, &count, &roots, read_rule, &saved);
	assert(program && count == 1 && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	assert(!pg_synthesis_source_input(&program->synthesis, roots[0], &scope, &syntax));
	binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	assert(binding && pg_synthesis_binding_scope(binding)->binder == saved.header->parameters.binder);
	assert(!program->synthesis.steps && native_admissions(&program->typing) == 1);
	puts("single Source root retains its canonical lexical binder: load/factory steps0, untrusted");
	pg_program_destroy(program);
	assert(!fclose(file));
	return 0;
}

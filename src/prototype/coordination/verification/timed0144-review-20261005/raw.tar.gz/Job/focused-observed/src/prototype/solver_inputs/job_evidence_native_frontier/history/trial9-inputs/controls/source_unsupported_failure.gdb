set pagination off
break pg_synthesis_finish if status >= PG_SYNTHESIS_UNSUPPORTED
commands
silent
printf "terminal job=%p status=%d steps=%lu role=%p\n", job, status, synthesis->steps, job->pending.role
bt 4
continue
end
run indexed-families
bt

set pagination off
break synthesis_function.c:692 if !local->query
commands
silent
printf "classifier missing query steps=%lu\n", synthesis->steps
print context
print input
print pg_synthesis_input_result(context)
print pg_synthesis_input_result(input)
print *(struct pg_occurrence *)pg_synthesis_input_result(input)
bt 3
continue
end
run indexed-families
bt

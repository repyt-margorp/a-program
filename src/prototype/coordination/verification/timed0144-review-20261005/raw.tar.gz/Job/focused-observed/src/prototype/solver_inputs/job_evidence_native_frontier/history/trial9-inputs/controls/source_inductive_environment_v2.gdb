set pagination off
set print elements 8
break evidence.c:2169 if !local->environment
commands
silent
printf "inductive environment absent query=%p\n", work
print formation
print context
print pg_evidence_premise(formation, 0)
print *(struct pg_scope *)pg_evidence_premise(formation, 0)
print pg_evidence_owned_by(pg_evidence_premise(formation, 0), typing)
print pg_context_parent_input(typing, pg_evidence_premise(formation, 0))
bt 4
continue
end
run indexed-families
bt

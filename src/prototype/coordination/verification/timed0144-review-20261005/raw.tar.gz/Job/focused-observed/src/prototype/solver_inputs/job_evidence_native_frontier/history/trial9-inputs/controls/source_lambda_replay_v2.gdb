set pagination off
set print elements 8
break synthesis_function.c:87
commands
silent
printf "source lambda steps=%lu status=%d imported=%d rule_status=%d\n", synthesis->steps, job->status, job->imported_complete, local->rule->status
print body
print proof
if proof
print pg_evidence_judgement(proof)
end
print pg_synthesis_pending_status(body.pending)
print *((struct pg_syntax *)job->inputs[1])
continue
end
run indexed-families
bt

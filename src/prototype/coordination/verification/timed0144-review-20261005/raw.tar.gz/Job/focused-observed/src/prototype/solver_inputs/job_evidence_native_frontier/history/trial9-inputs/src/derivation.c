#include "derivation.h"
#include "iadt.h"
#include "action.h"
#include "scope.h"
#include "evidence_structure.h"

static size_t typed_inputs(const struct pg_evidence *proof,
	const struct pg_occurrence **inputs)
{
	if (pg_evidence_rule(proof) == PG_TYPE_FROM_VALUE || pg_evidence_rule(proof) == PG_VALUE_FROM_TYPE) {
		inputs[0] = pg_evidence_subject(proof)->origin;
		return 1;
	}
	size_t count = pg_function_proof_inputs(proof, inputs);
	if (!count) count = pg_cbpv_proof_inputs(proof, inputs);
	return count ? count : pg_identity_proof_inputs(proof, inputs);
}

static size_t input_count(const struct pg_evidence *proof)
{
	if (pg_evidence_binding_scope(proof)) return 2;
	const struct pg_scope *scope = pg_evidence_scope(proof);
	if (scope) return scope->indices ? 3 : 2;
	const struct pg_occurrence *inputs[3];
	size_t count = typed_inputs(proof, inputs);
	return count ? count : pg_evidence_premise_count(proof);
}

int pg_derivation_input_dependency(const struct pg_typing *typing,
	const struct pg_evidence *proof, size_t index, const struct pg_evidence **child)
{
	if (!child || !pg_evidence_owned_by(proof, typing)) return -1;
	if (index >= input_count(proof)) return 0;
	const struct pg_scope *binding = pg_evidence_binding_scope(proof);
	const struct pg_scope *scope = pg_evidence_scope(proof);
	const struct pg_evidence *input;
	if (binding) {
		size_t body = pg_evidence_rule(proof) == PG_PI_FORM ? 1 : 0;
		input = index ? pg_evidence_for_subject(typing, pg_evidence_subject(proof)->operands[body], NULL)
			: pg_evidence_for_scope(typing, binding);
	} else if (!scope) {
		const struct pg_occurrence *inputs[3];
		if (typed_inputs(proof, inputs)) {
			input = pg_evidence_for_subject(typing, inputs[index], NULL);
		} else input = pg_evidence_premise(proof, index);
	}
	else if (!index) input = pg_context_parent_input(typing, proof);
	else if (index == 1 && scope->indices) input = pg_context_indices_input(typing, proof);
	else input = pg_context_declared_input(typing, proof);
	if (!input) return -1;
	*child = input;
	return 1;
}

int pg_derivation_input_header(const struct pg_evidence *proof, struct pg_derivation_input *input)
{
	if (!proof || !input) return -1;
	struct pg_derivation_input header = {0};
	header.rule = pg_evidence_rule(proof);
	header.count = input_count(proof);
	if (pg_derivation_parameters(proof, &header.parameters)) return -1;
	if (header.parameters.conversion) {
		header.source = pg_conversion_left(header.parameters.conversion);
		header.target = pg_conversion_right(header.parameters.conversion);
	}
	if (header.parameters.reduction) {
		header.source = pg_reduction_source(header.parameters.reduction);
		header.target = pg_reduction_target(header.parameters.reduction);
		header.reduction_kind = pg_reduction_kind(header.parameters.reduction);
	}
	header.parameters.conversion = NULL;
	header.parameters.reduction = NULL;
	*input = header;
	return 0;
}

int pg_derivation_parameters(const struct pg_evidence *evidence,
	struct pg_derivation_parameters *parameters)
{
	if (!evidence || !parameters) return -1;
	struct pg_derivation_parameters result = {0};
	const struct pg_occurrence *subject = pg_evidence_subject(evidence);
	switch (pg_evidence_rule(evidence)) {
	case PG_HOST_TYPE_FORM: case PG_HOST_VALUE_INTRO: case PG_HOST_FUNCTION_INTRO:
		result.constant = subject->core->as.reference; break;
	case PG_RETURN_TYPE_FORM: {
		const struct pg_term *value;
		if (!pg_computation_type_view(subject->core, &result.totality, &result.effects, &value)) return -1;
		break;
	}
	case PG_RETURN_INTRO: {
		const struct pg_effect_row *effects;
		const struct pg_term *value;
		if (!pg_computation_type_view(pg_evidence_classifier(evidence), &result.totality, &effects, &value)) return -1;
		break;
	}
	case PG_CONSTRUCTOR_INTRO:
		result.constructor = pg_evidence_constructor(evidence); break;
	case PG_INDUCTION_ELIM:
		result.induction = pg_evidence_induction_allocation(evidence); break;
	case PG_INDUCTIVE_FORM:
		result.declaration = pg_data_schema_declaration(pg_evidence_inductive_schema(evidence)); break;
	case PG_HANDLER_ELIM:
		result.handler = pg_evidence_handler_signature(evidence); break;
	case PG_REQUEST_INTRO:
		result.operation_label = pg_operation_label(pg_evidence_request_declaration(evidence)); break;
	case PG_CONTEXT_EXTEND: case PG_CONTEXT_FAMILY_EXTEND:
		result.binder = pg_evidence_context(evidence)->binder; break;
	case PG_VARIABLE:
		result.binder = subject->core->as.reference; break;
	case PG_UNIVERSE_FORM:
		if (!pg_universe_level(subject->core, &result.level)) return -1;
		break;
	case PG_IDENTITY_TRANSPORT: case PG_IDENTITY_LIFT: {
		int lift;
		if (!pg_identity_field_view(subject->core, NULL, NULL, &result.direction, &lift)) return -1;
		if (lift != (pg_evidence_rule(evidence) == PG_IDENTITY_LIFT)) return -1;
		break;
	}
	case PG_TYPE_CONVERSION: result.conversion = pg_evidence_conversion(evidence); break;
	case PG_PURE_NORMALIZATION: result.reduction = pg_evidence_normalization(evidence); break;
	default: break;
	}
	*parameters = result;
	return 0;
}

/* Result formation is checked by exact typed subject, not receipt history.
 * Other supplied inputs still belong to the rule-specific contract. */
static const struct pg_evidence *checked_premises(const struct pg_evidence *result,
	enum pg_evidence_rule rule, size_t count, const void *owner,
	const struct pg_evidence *(*premise)(const void *, size_t))
{
	if (rule == PG_CONTEXT_SUBSTITUTION) {
		const struct pg_context_map *map = pg_evidence_context_map(result);
		if (!map || count < 2 || map->source != pg_evidence_context(premise(owner, 0)) ||
			map->destination != pg_evidence_context(premise(owner, 1))) return NULL;
		if (pg_evidence_premise(result, 0) != premise(owner, 0) ||
			pg_evidence_premise(result, 1) != premise(owner, 1)) return NULL;
		/* An unchanged zero-extension has no extra prefix input. Preserve
		 * arity rejection while pending extensions still request their real
		 * prefix and new images through the ordinary extension factory. */
		if (count == 3 && result == premise(owner, 2)) return NULL;
		/* The ordinary map rule already checks every supplied prefix/image.
		 * Native admission has no prefix receipt-history identity to compare. */
		return result;
	}
	if (!result || pg_evidence_rule(result) != rule || input_count(result) != count) return NULL;
	const struct pg_occurrence *inputs[3];
	if (typed_inputs(result, inputs)) {
		for (size_t i = 0; i < count; ++i)
			if (inputs[i] != pg_evidence_subject(premise(owner, i))) return NULL;
		return result;
	}
	size_t formation = count;
	switch (rule) {
	case PG_CONSTRUCTOR_INTRO: formation = 0; break;
	case PG_MATCH_ELIM: case PG_INDUCTION_ELIM: formation = count - 1; break;
	default: break;
	}
	for (size_t i = 0; i < count; ++i) {
		if (i == formation) {
			if (pg_evidence_subject(result)->type != pg_evidence_subject(premise(owner, i))) return NULL;
		} else if (pg_evidence_premise(result, i) != premise(owner, i)) return NULL;
	}
	return result;
}

static const struct pg_evidence *array_premise(const void *owner, size_t i)
{
	return ((const struct pg_evidence *const *)owner)[i];
}

struct handler_inputs {
	struct pg_typing *typing;
	const struct pg_handler_signature *signature;
	const void *owner;
	const struct pg_evidence *(*premise)(const void *, size_t);
};

static struct pg_handler_clause handler_clause(const void *owner, size_t i)
{
	const struct handler_inputs *inputs = owner;
	return (struct pg_handler_clause){pg_operation_declaration_at(inputs->typing,
		pg_handler_signature_label(inputs->signature, i),
		inputs->premise(inputs->owner, 3 + 3 * i), inputs->premise(inputs->owner, 4 + 3 * i)),
		inputs->premise(inputs->owner, 5 + 3 * i)};
}

/* Arity selection is plumbing only: semantic checks stay in the named rules. */
#define RULE(tag, arity, call) case tag: if (count != arity) return NULL; result = (call); break

const struct pg_evidence *pg_prove_derivation(struct pg_typing *typing,
	enum pg_evidence_rule rule,
	const struct pg_derivation_parameters *parameters, size_t count,
	const struct pg_evidence *const *p)
{
	if (count && !p) return NULL;
	return pg_prove_derivation_inputs(typing, rule, parameters, count, p, array_premise);
}

const struct pg_evidence *pg_prove_derivation_inputs(struct pg_typing *typing,
	enum pg_evidence_rule rule,
	const struct pg_derivation_parameters *parameters, size_t count,
	const void *owner, const struct pg_evidence *(*p)(const void *, size_t))
{
	if (!typing || !parameters) return NULL;
	if (count && !p) return NULL;
	if (parameters->declaration && rule != PG_INDUCTIVE_FORM) return NULL;
	if (parameters->constructor && rule != PG_CONSTRUCTOR_INTRO) return NULL;
	if (parameters->constant && rule != PG_HOST_TYPE_FORM && rule != PG_HOST_VALUE_INTRO
		&& rule != PG_HOST_FUNCTION_INTRO) return NULL;
	if (parameters->induction && rule != PG_INDUCTION_ELIM) return NULL;
	if ((unsigned)parameters->totality > PG_TOTALITY_TOTAL) return NULL;
	if (parameters->totality != PG_TOTALITY_UNSPECIFIED && rule != PG_RETURN_TYPE_FORM && rule != PG_RETURN_INTRO) return NULL;
	for (size_t i = 0; i < count; ++i) if (!pg_evidence_owned_by(p(owner, i), typing)) return NULL;
	const struct pg_evidence *result = NULL;
	struct pg_evidence_inputs tail = {.owner = owner, .at = p};
	struct pg_identity_boundary boundary;
	switch (rule) {
	RULE(PG_HOST_TYPE_FORM, 1, pg_prove_host_type(typing, p(owner, 0), parameters->constant));
	RULE(PG_HOST_VALUE_INTRO, 1, pg_prove_host_value(typing, p(owner, 0), parameters->constant));
	RULE(PG_HOST_FUNCTION_INTRO, 1, pg_prove_host_function(typing, p(owner, 0), parameters->constant));
	RULE(PG_CONSTRUCTOR_INTRO, 4, pg_prove_constructor_instance(typing, p(owner, 1), parameters->constructor, p(owner, 2), p(owner, 3)));
	case PG_MATCH_ELIM: case PG_INDUCTION_ELIM:
		if (count < 6) return NULL;
		tail.first = 5;
		result = rule == PG_MATCH_ELIM
			? pg_prove_match(typing, p(owner, 1), p(owner, 2), p(owner, 3), p(owner, 4), p(owner, 0), count - 6, tail)
			: pg_prove_induction_at(typing, p(owner, 1), p(owner, 2), p(owner, 3), p(owner, 4), p(owner, 0),
				count - 6, tail, parameters->induction);
		break;
	case PG_TYPE_CASE:
		if (count < 4) return NULL;
		tail.first = 3;
		result = pg_prove_type_case(typing, p(owner, 0), p(owner, 1), p(owner, 2), count - 3, tail);
		break;
	case PG_INDUCTIVE_FORM: {
		if (!count || !parameters->declaration) return NULL;
		size_t prefix = pg_evidence_rule(p(owner, 0)) == PG_CONTEXT_FAMILY_EXTEND ? 2 : 1;
		if (count < prefix) return NULL;
		tail.first = prefix;
		const struct pg_data_signature *signature = pg_data_signature(typing, p(owner, 0), p(owner, prefix == 2 ? 1 : 0));
		const struct pg_data_schema *schema = pg_data_schema_check(typing, parameters->declaration,
			signature, count - prefix, tail);
		result = pg_prove_inductive_type(typing, schema);
		break;
	}
	RULE(PG_CONTEXT_EMPTY, 0, pg_prove_empty_context(typing));
	RULE(PG_CONTEXT_EXTEND, 2, pg_prove_context_extension(typing, p(owner, 0), parameters->binder, p(owner, 1)));
	RULE(PG_CONTEXT_FAMILY_EXTEND, 3, pg_prove_family_context_extension(typing, p(owner, 0), parameters->binder, p(owner, 1), p(owner, 2)));
	RULE(PG_TYPE_FAMILY_APP, 2, pg_prove_family_application(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_TYPE_FAMILY_ABSTRACT, 2, pg_prove_family_abstraction(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_UNIVERSE_FORM, 1, pg_prove_universe(typing, p(owner, 0), parameters->level));
	case PG_VARIABLE:
		if (count != 1 && count != 2) return NULL;
		result = count == 1 ? pg_prove_variable(typing, p(owner, 0), parameters->binder)
			: pg_check_variable(typing, p(owner, 0), parameters->binder, p(owner, 1));
		break;
	RULE(PG_TYPE_FROM_VALUE, 1, pg_prove_value_type(typing, p(owner, 0)));
	RULE(PG_VALUE_FROM_TYPE, 1, pg_prove_type_value(typing, p(owner, 0)));
	RULE(PG_RETURN_TYPE_FORM, 1, pg_prove_computation_type(typing, parameters->totality, parameters->effects, p(owner, 0)));
	RULE(PG_THUNK_TYPE_FORM, 1, pg_prove_thunk_type(typing, p(owner, 0)));
	RULE(PG_TERMINATION_FORM, 2, pg_prove_termination_type(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_TERMINATION_INTRO, 2, pg_prove_termination(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_PI_FORM, 2, pg_prove_pi(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_RETURN_INTRO, 1, pg_prove_return_contract(typing, parameters->totality, p(owner, 0)));
	RULE(PG_THUNK_INTRO, 1, pg_prove_thunk(typing, p(owner, 0)));
	RULE(PG_FORCE_ELIM, 1, pg_prove_force(typing, p(owner, 0)));
	RULE(PG_LAMBDA_INTRO, 2, pg_prove_lambda(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_APP_ELIM, 2, pg_prove_application(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_TYPE_CONVERSION, 2, pg_prove_conversion(typing, p(owner, 0), p(owner, 1), parameters->conversion));
	RULE(PG_PURE_NORMALIZATION, 1, pg_prove_normalization(typing, p(owner, 0), parameters->reduction));
	RULE(PG_CONTEXT_PROJECTION, 2, pg_prove_projection(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_REINDEX, 2, pg_prove_reindex(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_THUNK_CONTENT, 1, pg_prove_thunk_content(typing, p(owner, 0)));
	RULE(PG_RETURN_CONTENT, 1, pg_prove_return_content(typing, p(owner, 0)));
	RULE(PG_PI_CODOMAIN, 2, pg_prove_pi_codomain(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_PI_DOMAIN, 1, pg_prove_pi_domain(typing, p(owner, 0)));
	RULE(PG_PI_CONSTANT_CODOMAIN, 1, pg_prove_pi_constant_codomain(typing, p(owner, 0)));
	RULE(PG_FOLD_ELIM, 2, pg_prove_fold(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_REQUEST_INTRO, 4, pg_prove_request(typing,
		pg_operation_declaration_at(typing, parameters->operation_label, p(owner, 0), p(owner, 1)), p(owner, 2), p(owner, 3)));
	case PG_HANDLER_ELIM: {
		size_t clauses = pg_handler_signature_count(parameters->handler);
		if (!clauses || clauses > (SIZE_MAX - 3) / 3 || count != 3 + 3 * clauses) return NULL;
		const struct handler_inputs inputs = {typing, parameters->handler, owner, p};
		result = pg_prove_handler_inputs(typing, p(owner, 0), p(owner, 1), p(owner, 2),
			clauses, &inputs, handler_clause);
		break;
	}
	RULE(PG_EFFECT_SUBSUMPTION, 2, pg_prove_effect_subsumption(typing, p(owner, 0), p(owner, 1)));
	RULE(PG_IDENTITY_FORM, 3, pg_prove_identity_type(typing, p(owner, 0), p(owner, 1), p(owner, 2)));
	RULE(PG_IDENTITY_INSTANCE, 3, pg_prove_identity_instance(typing, p(owner, 0), p(owner, 1), p(owner, 2)));
	RULE(PG_IDENTITY_LEFT_TYPE, 1, pg_prove_identity_endpoint_type(typing, p(owner, 0), rule));
	RULE(PG_IDENTITY_RIGHT_TYPE, 1, pg_prove_identity_endpoint_type(typing, p(owner, 0), rule));
	RULE(PG_IDENTITY_TRANSPORT, 3, pg_prove_identity_transport(typing, p(owner, 1), p(owner, 2), parameters->direction));
	RULE(PG_RETURN_VALUE, 1, pg_prove_return_value(typing, p(owner, 0)));
	RULE(PG_TOTAL_PURE_VALUE, 1, pg_prove_total_pure_value(typing, p(owner, 0)));
	RULE(PG_THUNK_COMPUTATION, 1, pg_prove_thunk_computation(typing, p(owner, 0)));
	case PG_REFLEXIVITY:
		if (count != 2) return NULL;
		if (!pg_identity_boundary_view(pg_evidence_subject(p(owner, 0)), &boundary)) return NULL;
		if (boundary.left_substitution || boundary.family->judgement == PG_JUDGEMENT_VALUE) return NULL;
		result = pg_prove_reflexivity(typing, pg_prove_structural_subject(typing, boundary.family), p(owner, 1)); break;
	case PG_IDENTITY_LIFT: {
		if (count != 2) return NULL;
		const struct pg_occurrence *transport = pg_evidence_subject(p(owner, 1));
		int lift;
		if (!transport || transport->operand_count != 2 ||
			!pg_identity_field_view(transport->core, NULL, NULL, NULL, &lift) || lift) return NULL;
		result = pg_prove_identity_lift(typing,
			pg_evidence_for_subject(typing, transport->operands[0], NULL),
			pg_evidence_for_subject(typing, transport->operands[1], NULL), parameters->direction); break;
	}
	case PG_CONTEXT_SUBSTITUTION:
		if (count < 2) return NULL;
		if (count == 2) result = pg_prove_substitution_projection(typing, p(owner, 0), p(owner, 1));
		else if (pg_evidence_judgement(p(owner, 2)) == PG_JUDGEMENT_SUBSTITUTION) {
			tail.first = 3;
			result = pg_prove_substitution_extension(typing, p(owner, 0), p(owner, 1), p(owner, 2), count - 3, tail);
		} else {
			/* The native saved map contains its complete image tuple. Source
			 * requests may still supply an already checked prefix explicitly. */
			tail.first = 2;
			result = pg_prove_substitution_inputs(typing, p(owner, 0), p(owner, 1), count - 2, tail);
		}
		break;
	case PG_FAMILY_IDENTITY_FORM:
		if (count < 5) return NULL;
		tail.first = 3;
		result = pg_prove_family_identity_type(typing, p(owner, 0), p(owner, 1), p(owner, 2), count - 5, tail,
			p(owner, count - 2), p(owner, count - 1)); break;
	case PG_FAMILY_ACTION:
		if (count != 2 || pg_evidence_rule(p(owner, 0)) != PG_FAMILY_IDENTITY_FORM) return NULL;
		if (!pg_identity_boundary_view(pg_evidence_subject(p(owner, 0)), &boundary)) return NULL;
		result = pg_identity_boundary_action(typing, &boundary,
			pg_prove_structural_subject(typing, boundary.family), p(owner, 1)); break;
	default: return NULL;
	}
	/* Rule inputs are requests, including after loading. Ordinary constructors
	 * may return an existing proof (identity projection, content inversion).
	 * The serializer records that resulting proof, not the original request. */
	switch (rule) {
	case PG_IDENTITY_TRANSPORT: case PG_REFLEXIVITY:
	case PG_IDENTITY_LIFT: case PG_FAMILY_ACTION:
	case PG_CONTEXT_SUBSTITUTION:
	case PG_REQUEST_INTRO: case PG_HANDLER_ELIM:
	case PG_CONSTRUCTOR_INTRO: case PG_MATCH_ELIM: case PG_INDUCTION_ELIM: case PG_TYPE_CASE:
		result = checked_premises(result, rule, count, owner, p); break;
	default: break;
	}
	return result;
}

#undef RULE

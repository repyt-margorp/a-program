Nat := @{
	zero : *;
	succ : * -> *;
};

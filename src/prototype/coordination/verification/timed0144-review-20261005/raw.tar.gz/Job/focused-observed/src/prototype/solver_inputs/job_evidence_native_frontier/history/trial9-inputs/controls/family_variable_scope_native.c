#include "evidence.h"
#include "occurrence_io.h"
#include "descriptor_io.h"
#include "derivation.h"
#include "typed_query.h"
#include <assert.h>
#include <stdio.h>

static void native_scope_control(struct pg_typing *, struct pg_graph *,
	const struct pg_evidence *const *, const struct pg_evidence *const *);

#define FAMILY_SCOPE_CONTROL native_scope_control
#include "family_variable_scope.c"

static int same_bytes(FILE *left, FILE *right)
{
	rewind(left);
	rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); } while (a != EOF && a == b);
	return a == EOF && b == EOF;
}

static void native_scope_control(struct pg_typing *typing, struct pg_graph *graph,
	const struct pg_evidence *const *scopes, const struct pg_evidence *const *variables)
{
	const struct pg_occurrence *subjects[] = {
		pg_evidence_subject(variables[0]), pg_evidence_subject(variables[1])};
	assert(subjects[0] != subjects[1]);
	for (size_t i = 0; i < 2; ++i) {
		assert(subjects[i]->scope == pg_evidence_scope(scopes[i]));
		assert(pg_prove_variable(typing, scopes[i], subjects[i]->core->as.reference) == variables[i]);
		size_t before = typing->occurrences.count, maps = typing->context_maps.count;
		assert(pg_occurrence_weaken(typing, subjects[i]->context, subjects[i]) == subjects[i]);
		assert(typing->occurrences.count == before && typing->context_maps.count == maps);
	}
	const struct pg_occurrence *raw = pg_occurrence(typing, subjects[0]->judgement,
		subjects[0]->context, subjects[0]->core, subjects[0]->classifier, NULL, 0, NULL);
	assert(raw == subjects[0]);
	struct pg_scope copied = *subjects[1]->scope;
	struct pg_occurrence header = *subjects[1];
	header.scope = &copied;
	assert(!pg_occurrence_intern(typing, &header, NULL, NULL));
	struct pg_scope copied_indices = *subjects[1]->scope->indices;
	const struct pg_scope *scratch_tail = pg_scope_intern(typing, copied.context,
		copied.parent, &copied_indices, copied.type);
	assert(scratch_tail && pg_scope_owned_by(scratch_tail, typing));
	header.scope = scratch_tail;
	assert(!pg_occurrence_intern(typing, &header, NULL, NULL));
	const struct pg_object *extra = pg_binder(graph);
	const struct pg_evidence *ambient[2], *extended[2];
	for (size_t i = 0; i < 2; ++i) {
		const struct pg_evidence *domain = pg_prove_universe(typing, scopes[1], i ? 3 : 0);
		const struct pg_evidence *unused = pg_prove_context_extension(typing, scopes[1],
			pg_binder(graph), domain);
		const struct pg_evidence *pi = pg_prove_pi(typing, unused,
			pg_prove_return_type(typing, pg_prove_projection(typing, unused,
				pg_prove_universe(typing, scopes[1], 0))));
		const struct pg_evidence *type = pg_prove_return_content(typing,
			pg_prove_pi_constant_codomain(typing, pi));
		ambient[i] = pg_prove_context_extension(typing, scopes[1], extra, type);
		extended[i] = pg_prove_variable(typing, ambient[i], subjects[1]->core->as.reference);
		assert(ambient[i] && extended[i]);
		assert(pg_evidence_subject(extended[i])->scope == subjects[1]->scope);
		assert(pg_evidence_premise_count(extended[i]) == 2 &&
			pg_evidence_premise(extended[i], 1) == scopes[1]);
		assert(pg_occurrence_weaken(typing, pg_evidence_context(ambient[i]), subjects[1]) ==
			pg_evidence_subject(extended[i]));
		assert(pg_occurrence_unproject(typing, pg_evidence_subject(extended[i]),
			subjects[1]->context) == subjects[1]);
	}
	assert(ambient[0] != ambient[1] && pg_evidence_context(ambient[0]) == pg_evidence_context(ambient[1]));
	assert(extended[0] == extended[1]);
	struct pg_context copied_context = *pg_evidence_context(ambient[1]);
	header = *pg_evidence_subject(extended[1]);
	header.context = &copied_context;
	assert(!pg_occurrence_intern(typing, &header, NULL, NULL));
	const struct pg_context *scratch_use = pg_context_bind(typing, &copied_context,
		pg_binder(graph), pg_universe(graph, 0), PG_JUDGEMENT_VALUE);
	assert(scratch_use && pg_context_owned_by(scratch_use, typing));
	header.context = scratch_use;
	assert(!pg_occurrence_intern(typing, &header, NULL, NULL));
	struct pg_derivation_input variable_header;
	const struct pg_evidence *variable_inputs[2];
	assert(!pg_derivation_input_header(extended[1], &variable_header));
	assert(variable_header.rule == PG_VARIABLE && variable_header.count == 2);
	for (size_t i = 0; i < 2; ++i)
		assert(pg_derivation_input_dependency(typing, extended[1], i, &variable_inputs[i]) == 1);
	assert(pg_prove_derivation(typing, PG_VARIABLE, &variable_header.parameters,
		2, variable_inputs) == extended[1]);
	const struct pg_evidence *invalid_inputs[] = {ambient[1], (const void *)&copied};
	size_t before = typing->occurrences.count;
	assert(!pg_prove_derivation(typing, PG_VARIABLE, &variable_header.parameters, 2, invalid_inputs));
	invalid_inputs[1] = ambient[1];
	assert(!pg_prove_derivation(typing, PG_VARIABLE, &variable_header.parameters, 2, invalid_inputs));
	assert(typing->occurrences.count == before);

	FILE *initial = tmpfile(), *resaved = tmpfile(), *again = tmpfile();
	assert(initial && resaved && again);
	assert(!pg_occurrences_write_descriptors(initial, 2, subjects, &pg_builtin_graph_codec, graph));
	struct pg_graph loaded_graph;
	struct pg_typing loaded_typing;
	assert(!pg_graph_init(&loaded_graph) && !pg_typing_init(&loaded_typing, &loaded_graph));
	rewind(initial);
	size_t count;
	const struct pg_occurrence *const *loaded;
	assert(!pg_occurrences_read_descriptors(initial, &loaded_typing, 100000, 256,
		&pg_builtin_graph_codec, &loaded_graph, &count, &loaded));
	assert(count == 2 && loaded[0] != loaded[1]);
	for (size_t i = 0; i < count; ++i) {
		assert(loaded[i]->scope && !loaded[i]->admission_owner && !loaded[i]->scope->admission_owner);
		assert(!pg_evidence_for_subject(&loaded_typing, loaded[i], NULL));
	}
	assert(!pg_occurrences_write_descriptors(resaved, count, loaded, &pg_builtin_graph_codec, &loaded_graph));
	assert(same_bytes(initial, resaved));
	rewind(resaved);
	struct pg_graph again_graph;
	struct pg_typing again_typing;
	assert(!pg_graph_init(&again_graph) && !pg_typing_init(&again_typing, &again_graph));
	const struct pg_occurrence *const *twice;
	assert(!pg_occurrences_read_descriptors(resaved, &again_typing, 100000, 256,
		&pg_builtin_graph_codec, &again_graph, &count, &twice));
	assert(!pg_occurrences_write_descriptors(again, count, twice, &pg_builtin_graph_codec, &again_graph) &&
		same_bytes(resaved, again));
	for (size_t i = 0; i < count; ++i) {
		const struct pg_evidence *proof = pg_prove_structural_subject(&again_typing, twice[i]);
		assert(proof && pg_evidence_subject(proof) == twice[i]);
		struct pg_typed_query *query = pg_family_parameter_request(&again_typing, proof, 0);
		assert(query && !pg_typed_query_advance(query, 0) && !pg_typed_query_steps(query));
		while (!pg_typed_query_advance(query, 1)) assert(pg_typed_query_steps(query) < 1000);
		const struct pg_evidence *domain = pg_context_declared_input(&again_typing, pg_typed_query_result(query));
		assert(pg_evidence_classifier(domain) == pg_universe(&again_graph, i ? 4 : 1));
	}
	pg_typing_destroy(&again_typing);
	pg_graph_destroy(&again_graph);
	pg_typing_destroy(&loaded_typing);
	pg_graph_destroy(&loaded_graph);
	assert(!fclose(initial) && !fclose(resaved) && !fclose(again));
	printf("native family Scope ownership/inert twice-resave/ordinary bound controls pass\n");
}

#include "scope.h"

const struct pg_scope *pg_scope_intern(struct pg_typing *typing,
	const struct pg_context *context, const struct pg_scope *parent,
	const struct pg_scope *indices, const struct pg_occurrence *type)
{
	if (!typing) return NULL;
	if (!context) {
		if (parent || indices || type) return NULL;
	} else {
		if (!type) return NULL;
		if (context->parent != (parent ? parent->context : NULL)) return NULL;
		if (context->indices != (indices ? indices->context : NULL)) return NULL;
		if (type->context != (indices ? indices->context : context->parent)) return NULL;
		if (type->judgement != PG_JUDGEMENT_VALUE_TYPE) return NULL;
		if (!indices && type->core != context->declared_type) return NULL;
	}
	uint64_t hash = (uintptr_t)context;
	hash = (hash ^ (uintptr_t)parent) * UINT64_C(1099511628211);
	hash = (hash ^ (uintptr_t)indices) * UINT64_C(1099511628211);
	if (type) {
		hash = (hash ^ (uintptr_t)type->core) * UINT64_C(1099511628211);
		hash = (hash ^ (uintptr_t)type->classifier) * UINT64_C(1099511628211);
	}
	if (!typing->scopes.capacity && pg_index_init(&typing->scopes)) return NULL;
	for (struct pg_index_entry *p = pg_index_candidates(&typing->scopes, hash); p; p = p->next) {
		const struct pg_scope *scope = (const void *)p;
		if (p->hash != hash || scope->context != context || scope->parent != parent) continue;
		if (scope->indices != indices) continue;
		if (scope->type != type && (!scope->type || !type ||
			scope->type->core != type->core || scope->type->classifier != type->classifier)) continue;
		/* A declaration retains its checked typed fact, not alternative
		 * formation history. Raw transport stays unaccepted; only a canonical
		 * admitted input can replace its descriptive type before admission. */
		if (!scope->admission_owner && type && type->admission_owner == typing->owner_key &&
			pg_occurrence_owned_by(type, typing)) ((struct pg_scope *)scope)->type = type;
		return scope;
	}
	struct pg_scope *scope = pg_alloc(typing->graph, sizeof(*scope));
	if (!scope) return NULL;
	*scope = (struct pg_scope){.judgement = PG_JUDGEMENT_CONTEXT,
		.context = context, .parent = parent, .indices = indices, .type = type};
	return pg_index_insert(&typing->scopes, &scope->index, hash) ? NULL : scope;
}

int pg_scope_owned_by(const struct pg_scope *scope, const struct pg_typing *typing)
{
	if (!scope || !typing || !typing->scopes.capacity) return 0;
	for (const struct pg_index_entry *p = pg_index_candidates(&typing->scopes, scope->index.hash);
		p; p = p->next)
		if (p == &scope->index) return 1;
	return 0;
}

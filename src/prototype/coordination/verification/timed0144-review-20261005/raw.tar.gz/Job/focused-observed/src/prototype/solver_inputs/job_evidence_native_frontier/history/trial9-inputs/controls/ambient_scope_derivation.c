#include "evidence.h"
#include "derivation.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
	struct pg_graph graph;
	struct pg_typing typing;
	assert(!pg_graph_init(&graph) && !pg_typing_init(&typing, &graph));
	const struct pg_evidence *empty = pg_prove_empty_context(&typing);
	const struct pg_evidence *u0 = pg_prove_universe(&typing, empty, 0);
	const struct pg_evidence *unused = pg_prove_context_extension(&typing, empty,
		pg_binder(&graph), pg_prove_universe(&typing, empty, 3));
	const struct pg_evidence *pi = pg_prove_pi(&typing, unused,
		pg_prove_return_type(&typing, pg_prove_projection(&typing, unused, u0)));
	const struct pg_evidence *wide = pg_prove_return_content(&typing,
		pg_prove_pi_constant_codomain(&typing, pi));
	const struct pg_object *binder = pg_binder(&graph);
	const struct pg_evidence *scopes[] = {
		pg_prove_context_extension(&typing, empty, binder, u0),
		pg_prove_context_extension(&typing, empty, binder, wide)};
	assert(scopes[0] && scopes[1] && scopes[0] != scopes[1] &&
		pg_evidence_context(scopes[0]) == pg_evidence_context(scopes[1]));
	for (size_t i = 0; i < 2; ++i) {
		const struct pg_evidence *universe = pg_prove_derivation(&typing, PG_UNIVERSE_FORM,
			&(struct pg_derivation_parameters){.level = 0}, 1, scopes + i);
		printf("ambient selected Scope %zu ordinary Universe derivation accepted=%d\n", i, universe != NULL);
		fflush(stdout);
		assert(universe && pg_evidence_context(universe) == pg_evidence_context(scopes[i]) &&
			pg_evidence_subject(universe)->core == pg_universe(&graph, 0));
	}
	assert(!pg_prove_derivation(&typing, PG_UNIVERSE_FORM,
		&(struct pg_derivation_parameters){.level = 0}, 0, NULL));
	struct pg_typing foreign;
	assert(!pg_typing_init(&foreign, &graph));
	assert(!pg_prove_derivation(&foreign, PG_UNIVERSE_FORM,
		&(struct pg_derivation_parameters){.level = 0}, 1, scopes));
	pg_typing_destroy(&foreign);
	pg_typing_destroy(&typing);
	pg_graph_destroy(&graph);
	return 0;
}

set pagination off
set print elements 6
break synthesis_work.c:128 if synthesis->steps > 1300
commands
silent
set $query = pg_pending_query(pending)
if $query
printf "failed query steps=%lu status=%d query=%p\n", synthesis->steps, $query->status, $query
info symbol $query->pending.role
print *$query
print ((struct pg_occurrence *)$query->inputs[0])
if $query->inputs[0]
print *(struct pg_occurrence *)$query->inputs[0]
end
bt 4
end
continue
end
run indexed-families
bt

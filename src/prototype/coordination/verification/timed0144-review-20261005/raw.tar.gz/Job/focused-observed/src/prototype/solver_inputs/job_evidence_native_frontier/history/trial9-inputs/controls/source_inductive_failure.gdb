set pagination off
set print elements 8
python
class InductiveReturn(gdb.FinishBreakpoint):
    def __init__(self, frame, work, local):
        super().__init__(frame, internal=True)
        self.work = work
        self.local = local
    def stop(self):
        if self.return_value is not None and int(self.return_value) < 0:
            gdb.write('inductive failed query=%s\n' % self.work)
            gdb.write(str(self.local.dereference()) + '\n')
            state = self.local.dereference()['inductive']
            gdb.write(str(state.dereference()) + '\n')
            current = self.local.dereference()['current']
            gdb.write(str(current.dereference()) + '\n')
            gdb.execute('bt 3')
        return False
class InductiveEntry(gdb.Breakpoint):
    def stop(self):
        InductiveReturn(gdb.newest_frame(), gdb.parse_and_eval('work'), gdb.parse_and_eval('local'))
        return False
InductiveEntry('evidence.c:2104', internal=True)
end
run indexed-families
bt

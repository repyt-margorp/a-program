set pagination off
set print elements 5
break evidence.c:658
commands
silent
set $bad = 0
set $i = 0
while $i < map->count
if !images[$i]
set $bad = 1
printf "map image missing index=%lu map=%p\n", $i, map
print *map->images[$i]
print *(struct pg_scope *)source
print *(struct pg_scope *)destination
end
set $i = $i + 1
end
if $bad
bt 4
end
continue
end
run indexed-families
bt

#!/usr/bin/env python3
"""Preserve fresh-process Source resave bytes and ordinary check outcomes."""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


def digest(path):
	return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
	binary = Path(sys.argv[1]).resolve()
	directory = Path(sys.argv[2]).resolve()
	directory.mkdir(parents=True, exist_ok=False)
	fixtures = sys.argv[3:] or ["lambda", "family", "append", "index-alias",
		"function-field", "nominal", "nullary", "application", "constructor",
		"specialized-constructor", "match", "computed-match", "fold"]
	report = {"binary": str(binary), "binary_sha256": digest(binary), "cases": []}
	failed = False
	for writer in ("retained-write-typed", "retained-write"):
		for fixture in fixtures:
			stem = writer + "-" + fixture
			images = [directory / (stem + "-" + str(i) + ".a") for i in range(3)]
			commands = [[str(binary), writer, str(images[0]), fixture],
				[str(binary), "retained-resave", str(images[0]), str(images[1])],
				[str(binary), "retained-resave", str(images[1]), str(images[2])],
				[str(binary), "retained-check", str(images[2])],
				[str(binary), "retained-recompute", str(images[2])]]
			case = {"writer": writer, "fixture": fixture, "commands": []}
			for i, command in enumerate(commands):
				with (directory / (stem + "-" + str(i) + ".stdout")).open("wb") as out, \
					(directory / (stem + "-" + str(i) + ".stderr")).open("wb") as err:
					result = subprocess.run(command, stdout=out, stderr=err)
				case["commands"].append({"argv": command, "returncode": result.returncode})
				if result.returncode:
					failed = True
					break
			case["images"] = [{"path": image.name, "bytes": image.stat().st_size,
				"sha256": digest(image)} for image in images if image.exists()]
			if len(case["images"]) == 3:
				case["initial_equal_resave"] = images[0].read_bytes() == images[1].read_bytes()
				case["two_inert_resaves_equal"] = images[1].read_bytes() == images[2].read_bytes()
				failed |= not case["initial_equal_resave"] or not case["two_inert_resaves_equal"]
			report["cases"].append(case)
			(directory / "report.json").write_text(json.dumps(report, indent=2) + "\n")
	report["exit_code"] = int(failed)
	(directory / "report.json").write_text(json.dumps(report, indent=2) + "\n")
	return int(failed)


if __name__ == "__main__":
	sys.exit(main())

include $(OVERLAY)/src/Makefile

CHECKPOINT_IO := $(addprefix $(ROOT),machine_io.c computation_io.c identity_io.c comparison_io.c eval_io.c)

$(BUILD)/source_binding_retention: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CONTROL) -o $@

$(BUILD)/lambda_frontier: $(SOURCES) $(ROOT)reader.c $(ROOT)syntax.c $(SYNTHESIS_SOURCES) $(ROOT)program.c $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(ROOT)reader.c $(ROOT)syntax.c $(SYNTHESIS_SOURCES) $(ROOT)program.c $(CONTROL) -Wl,--wrap=pg_synthesis_advance -o $@

$(BUILD)/lambda_checkpoint: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(ROOT)artifact/source.c $(ROOT)artifact/schedule.c $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(ROOT)artifact/source.c $(ROOT)artifact/schedule.c $(CONTROL) -Wl,--wrap=pg_synthesis_advance -o $@

$(BUILD)/lambda_checked_frontier: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)artifact/source.c $(ROOT)artifact/derivation.c $(ROOT)artifact/schedule.c $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(CHECKPOINT_IO) $(ROOT)artifact/source.c $(ROOT)artifact/derivation.c $(ROOT)artifact/schedule.c $(CONTROL) -Wl,--wrap=pg_synthesis_advance -Wl,--wrap=pg_whnf_advance -Wl,--wrap=pg_typed_query_advance -o $@

#include "evidence.h"
#include "scope.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
	struct pg_graph graph;
	struct pg_typing typing;
	assert(!pg_graph_init(&graph) && !pg_typing_init(&typing, &graph));
	const struct pg_evidence *empty = pg_prove_empty_context(&typing);
	const struct pg_evidence *u = pg_prove_universe(&typing, empty, 0);
	const struct pg_evidence *other = pg_prove_universe(&typing, empty, 1);
	assert(u && other);
	/* An inert descriptor carries an unverified normalization history. Its
	 * declared fact may be selected only from an actual checked input. */
	const struct pg_occurrence *description = pg_occurrence_derived(&typing,
		pg_evidence_subject(other), PG_JUDGEMENT_VALUE_TYPE,
		pg_evidence_subject(u)->core, pg_evidence_classifier(u));
	assert(description && !pg_evidence_owned_by((const void *)description, &typing));
	const struct pg_object *binder = pg_binder(&graph);
	const struct pg_context *context = pg_context_bind(&typing, NULL, binder,
		pg_evidence_subject(u)->core, PG_JUDGEMENT_VALUE);
	const struct pg_scope *raw = pg_scope_intern(&typing, context, NULL, NULL, description);
	assert(raw && !pg_evidence_for_scope(&typing, raw) && raw->type == description);
	size_t scopes = typing.scopes.count;
	struct pg_occurrence copied = *pg_evidence_subject(u);
	const struct pg_scope *copied_input = pg_scope_intern(&typing, context, NULL, NULL, &copied);
	assert(copied_input && !pg_evidence_for_scope(&typing, copied_input));
	assert(raw->type == description && !pg_evidence_for_scope(&typing, raw));
	const struct pg_evidence *checked = pg_prove_context_extension(&typing, empty, binder, u);
	assert(checked && pg_evidence_scope(checked) == raw && typing.scopes.count == scopes);
	assert(raw->type == pg_evidence_subject(u));
	assert(!pg_evidence_owned_by((const void *)description, &typing));
	assert(pg_context_declared_input(&typing, checked) == u);
	assert(pg_scope_intern(&typing, context, NULL, NULL, description) == raw);
	assert(raw->type == pg_evidence_subject(u));
	/* Universe bounds remain distinct despite the same erased declaration. */
	struct pg_occurrence wider = *description;
	wider.classifier = pg_universe(&graph, 2);
	const struct pg_occurrence *wide = pg_occurrence_intern(&typing, &wider, NULL, NULL);
	const struct pg_scope *different = pg_scope_intern(&typing, context, NULL, NULL, wide);
	assert(different && different != raw && !pg_evidence_for_scope(&typing, different));
	struct pg_scope copy = *raw;
	assert(!pg_evidence_for_scope(&typing, &copy));
	printf("canonical declared fact selected; raw history remains unaccepted\n");
	pg_typing_destroy(&typing);
	pg_graph_destroy(&graph);
	return 0;
}

#include "typed_query.h"

struct pg_synthesis_job *pg_pending_job(struct pg_pending *pending)
{
	return pending && pending->role->ops->job ? pending->role->ops->job(pending) : NULL;
}

struct pg_typed_query *pg_pending_query(struct pg_pending *pending)
{
	return pending && pending->role->ops->query ? pending->role->ops->query(pending) : NULL;
}

const struct pg_evidence *pg_pending_result(const struct pg_pending *pending)
{
	return pending ? pending->role->ops->result(pending) : NULL;
}

static struct pg_typed_query *query_owner(struct pg_pending *pending)
{
	return (void *)pending;
}

static const struct pg_evidence *query_result(const struct pg_pending *pending)
{
	return pg_typed_query_result((const void *)pending);
}

const struct pg_pending_ops pg_typed_query_pending_ops = {
	.query = query_owner, .result = query_result
};

const struct pg_typed_query_class *pg_typed_query_role(const struct pg_typed_query *query)
{
	return query ? (const void *)query->pending.role : NULL;
}

struct pg_typing *pg_typed_query_typing(const struct pg_typed_query *query)
{
	return query ? (void *)query->pending.owner : NULL;
}

int pg_typed_query_owned_by(const struct pg_typed_query *query, const struct pg_typing *typing)
{
	if (!typing || pg_typed_query_typing(query) != typing || !typing->typed_queries.capacity) return 0;
	/* The typing container's address can be reused after reinitialization.
	 * Its current interner, not that address alone, identifies live requests. */
	for (const struct pg_index_entry *entry = pg_index_candidates(&typing->typed_queries, query->pending.index.hash);
		entry; entry = entry->next)
		if (entry == &query->pending.index) return 1;
	return 0;
}

static size_t state_extent(const struct pg_typed_query_class *role)
{
	size_t alignment = _Alignof(struct pg_typed_query);
	return (role->size + alignment - 1) / alignment * alignment;
}

struct pg_typed_query *pg_typed_query_request(struct pg_typing *typing,
	const struct pg_typed_query_class *role, size_t ordinal,
	const void *const *inputs, int *created)
{
	if (created) *created = 0;
	if (!typing || !role || !role->advance) return NULL;
	if (role->input_count && !inputs) return NULL;
	if (role->input_count > (SIZE_MAX - sizeof(struct pg_typed_query)) / sizeof(*inputs)) return NULL;
	if (role->size > SIZE_MAX - (_Alignof(struct pg_typed_query) - 1)) return NULL;
	uint64_t hash = ((uintptr_t)role ^ ordinal) * UINT64_C(1099511628211);
	for (size_t i = 0; i < role->input_count; ++i)
		hash = (hash ^ (uintptr_t)inputs[i]) * UINT64_C(1099511628211);
	for (struct pg_index_entry *entry = pg_index_candidates(&typing->typed_queries, hash); entry; entry = entry->next) {
		if (entry->hash != hash) continue;
		struct pg_typed_query *query = (void *)entry;
		if (pg_typed_query_role(query) != role || query->ordinal != ordinal) continue;
		size_t i = 0;
		while (i < role->input_count && query->inputs[i] == inputs[i]) ++i;
		if (i == role->input_count) return query;
	}
	size_t bytes = sizeof(struct pg_typed_query) + role->input_count * sizeof(*inputs);
	size_t offset = state_extent(role);
	if (bytes > SIZE_MAX - offset) return NULL;
	char *storage = pg_alloc(typing->graph, offset + bytes);
	if (!storage) return NULL;
	struct pg_typed_query *query = (void *)(storage + offset);
	query->pending.owner = typing;
	query->pending.role = &role->pending;
	query->ordinal = ordinal;
	for (size_t i = 0; i < role->input_count; ++i) query->inputs[i] = inputs[i];
	if (pg_index_insert(&typing->typed_queries, &query->pending.index, hash)) return NULL;
	if (created) *created = 1;
	return query;
}

void *pg_typed_query_state(const struct pg_typed_query *query)
{
	return (char *)query - state_extent(pg_typed_query_role(query));
}

static void query_cleanup(struct pg_typed_query *query)
{
	const struct pg_typed_query_class *role = pg_typed_query_role(query);
	if (role->destroy) role->destroy(query);
}

void pg_typed_query_destroy(struct pg_typing *typing)
{
	for (size_t i = 0; i < typing->typed_queries.capacity; ++i)
		for (struct pg_index_entry *entry = typing->typed_queries.buckets[i]; entry; entry = entry->next) {
			struct pg_typed_query *query = (void *)entry;
			if (!query->status) query_cleanup(query);
		}
}

int pg_typed_query_advance(struct pg_typed_query *work, uint64_t budget)
{
	if (!work) return -1;
	while (!work->status && budget--) {
		struct pg_typed_query *current = work->waiting ? work->waiting->work : work;
		++work->steps;
		if (!current->status && (!current->dependency || current->dependency->status)) {
			if (current != work) ++current->steps;
			current->status = pg_typed_query_role(current)->advance(current);
			if (current->status) query_cleanup(current);
		}
		if (current->status) {
			pg_typing_wait_clear(pg_typed_query_typing(work), &current->waiting);
			pg_typing_wait_pop(pg_typed_query_typing(work), &work->waiting);
		} else if (current->dependency && !current->dependency->status) {
			if (pg_typing_wait_push(pg_typed_query_typing(work), &work->waiting, current->dependency)) {
				work->status = -1;
				query_cleanup(work);
			}
		}
	}
	if (work->status) pg_typing_wait_clear(pg_typed_query_typing(work), &work->waiting);
	return work->status;
}

const struct pg_evidence *pg_typed_query_result(const struct pg_typed_query *work)
{
	return work && work->status == 1 ? work->result : NULL;
}

uint64_t pg_typed_query_steps(const struct pg_typed_query *work)
{
	return work ? work->steps : 0;
}

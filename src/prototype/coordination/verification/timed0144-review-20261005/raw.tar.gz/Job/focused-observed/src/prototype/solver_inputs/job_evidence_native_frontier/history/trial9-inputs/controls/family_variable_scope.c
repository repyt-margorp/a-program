#include "evidence.h"
#include "scope.h"
#include "typed_query.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
	struct pg_graph graph;
	struct pg_typing typing;
	assert(!pg_graph_init(&graph) && !pg_typing_init(&typing, &graph));
	const struct pg_evidence *empty = pg_prove_empty_context(&typing);
	const struct pg_evidence *u0 = pg_prove_universe(&typing, empty, 0);
	const struct pg_evidence *unused = pg_prove_context_extension(&typing, empty,
		pg_binder(&graph), pg_prove_universe(&typing, empty, 3));
	const struct pg_evidence *pi = pg_prove_pi(&typing, unused,
		pg_prove_return_type(&typing, pg_prove_projection(&typing, unused, u0)));
	const struct pg_evidence *wide = pg_prove_return_content(&typing,
		pg_prove_pi_constant_codomain(&typing, pi));
	assert(pg_evidence_classifier(wide) == pg_universe(&graph, 4));
	const struct pg_object *index = pg_binder(&graph), *family = pg_binder(&graph);
	const struct pg_evidence *indices[] = {
		pg_prove_context_extension(&typing, empty, index, u0),
		pg_prove_context_extension(&typing, empty, index, wide)};
	const struct pg_evidence *scopes[2], *variables[2];
	for (size_t i = 0; i < 2; ++i) {
		scopes[i] = pg_prove_family_context_extension(&typing, empty, family, indices[i],
			pg_prove_universe(&typing, indices[i], 0));
		const struct pg_occurrence *raw = pg_occurrence(&typing, PG_JUDGEMENT_TYPE_FAMILY,
			pg_evidence_context(scopes[i]), pg_reference(&graph, family),
			pg_evidence_context(scopes[i])->declared_type, NULL, 0, NULL);
		variables[i] = pg_prove_variable(&typing, scopes[i], family);
		assert(scopes[i] && variables[i]);
		if (!i) assert(pg_evidence_subject(variables[i]) == raw);
	}
	assert(scopes[0] != scopes[1] && pg_evidence_context(scopes[0]) == pg_evidence_context(scopes[1]));
#ifdef FAMILY_SCOPE_CONTROL
	FAMILY_SCOPE_CONTROL(&typing, &graph, scopes, variables);
#endif
	for (size_t i = 0; i < 2; ++i) {
		struct pg_typed_query *query = pg_family_parameter_request(&typing, variables[i], 0);
		assert(query);
		while (!pg_typed_query_advance(query, 1)) assert(pg_typed_query_steps(query) < 1000);
		const struct pg_evidence *parameter = pg_typed_query_result(query);
		const struct pg_evidence *domain = pg_context_declared_input(&typing, parameter);
		printf("family variable %zu same_raw_context=1 actual_bound_matches=%d\n", i,
			pg_evidence_classifier(domain) == pg_universe(&graph, i ? 4 : 1));
		fflush(stdout);
		assert(pg_evidence_classifier(domain) == pg_universe(&graph, i ? 4 : 1));
	}
	pg_typing_destroy(&typing);
	pg_graph_destroy(&graph);
	return 0;
}

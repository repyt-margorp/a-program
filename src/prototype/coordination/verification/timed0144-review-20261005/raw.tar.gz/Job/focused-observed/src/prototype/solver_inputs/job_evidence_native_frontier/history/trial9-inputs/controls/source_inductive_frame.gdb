set pagination off
set print elements 6
break evidence.c:2183 if !local->environment
commands
silent
printf "inductive frame failed query=%p\n", work
print *frame
if frame->map
print *frame->map
print pg_prove_context_map(typing, frame->map)
print *(struct pg_scope *)frame->map->source_scope
print *(struct pg_scope *)frame->map->destination_scope
end
print *local
print *state
bt 4
continue
end
run indexed-families
bt

set pagination off
set print elements 6
break evidence.c:5901 if !work->result
commands
silent
printf "typed classifier missing result query=%p\n", work
print *subject
print local->input
print pg_occurrence_input_result(local->input)
if local->input
print *local->input
end
bt 4
continue
end
run indexed-families
bt

set pagination off
set print elements 6
break evidence.c:5902
commands
silent
if pg_evidence_context(work->result) != subject->context || pg_alpha_equal(pg_evidence_subject(work->result)->core, subject->classifier) != 1
printf "typed classifier boundary mismatch query=%p\n", work
print *subject
print *(struct pg_occurrence *)work->result
print local->input
print pg_occurrence_input_result(local->input)
print pg_alpha_equal(pg_evidence_subject(work->result)->core, subject->classifier)
print pg_evidence_context(work->result) == subject->context
bt 4
end
continue
end
run indexed-families
bt

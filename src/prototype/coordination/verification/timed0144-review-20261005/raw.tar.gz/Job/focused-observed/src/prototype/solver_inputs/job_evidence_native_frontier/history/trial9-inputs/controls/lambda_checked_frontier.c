#include "../tests/native_admissions.h"
#include "program.h"
#include "source_io.h"
#include "synthesis_source.h"
#include "synthesis_conversion.h"
#include "derivation_io.h"
#include "computation_io.h"
#include "eval_internal.h"
#include "typed_query.h"
#include "artifact/source.h"
#include "artifact/derivation.h"
#include "artifact/schedule.h"
#include "artifact/file.h"
#include "wire.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int solving;
int __real_pg_typed_query_advance(struct pg_typed_query *, uint64_t);
int __wrap_pg_typed_query_advance(struct pg_typed_query *query, uint64_t fuel)
{
	assert(solving);
	return __real_pg_typed_query_advance(query, fuel);
}

void __real_pg_synthesis_advance(struct pg_synthesis *, uint64_t);
void __wrap_pg_synthesis_advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	assert(solving);
	__real_pg_synthesis_advance(synthesis, fuel);
}

enum pg_eval_status __real_pg_whnf_advance(struct pg_whnf_job *, uint64_t);
enum pg_eval_status __wrap_pg_whnf_advance(struct pg_whnf_job *job, uint64_t fuel)
{
	assert(solving);
	return __real_pg_whnf_advance(job, fuel);
}

struct checkpoint {
	const struct pg_artifact_source *source;
	const struct pg_artifact_derivations *rules;
	const struct pg_artifact_schedule *schedule;
	const struct pg_derivation_input *const *headers;
	size_t header_count;
	const struct pg_whnf_job *whnf;
	struct pg_whnf_job *restored;
	int normalized_done;
};

static void advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	solving = 1;
	pg_synthesis_advance(synthesis, fuel);
	solving = 0;
}

static struct pg_program *start(const char *text)
{
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *syntax = pg_parser_program(&program->parser);
	assert(syntax && !program->parser.error && syntax->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, syntax->items[0].expression);
	assert(program->root);
	return program;
}

static uint64_t finish(struct pg_program *program)
{
	while (program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		advance(&program->synthesis, 1);
		assert(program->synthesis.steps < 10000);
	}
	assert(pg_synthesis_result(program->root));
	return program->synthesis.steps;
}

/* Temporary test mapping of the first ordinary factory closure. */
static size_t map(struct pg_program *program, struct pg_synthesis_job ***output,
	struct pg_synthesis_job ***external, size_t *external_count,
	struct pg_synthesis_job ***roots, size_t *root_count)
{
	size_t count = program->synthesis.jobs.count, next = 1;
	struct pg_synthesis_job **jobs = calloc(3 * count, sizeof(*jobs));
	assert(jobs);
	jobs[0] = program->root;
	for (struct pg_synthesis_job *job = program->synthesis.ready; job; job = job->next) {
		if (job == program->root) continue;
		assert(next < count);
		jobs[next++] = job;
	}
	assert(next == count);
	*external = jobs + count;
	*roots = jobs + 2 * count;
	*external_count = *root_count = 0;
	for (size_t i = 0; i < count; ++i) {
		if (pg_synthesis_plain_derivation(jobs[i])) (*roots)[(*root_count)++] = jobs[i];
		else (*external)[(*external_count)++] = jobs[i];
	}
	*output = jobs;
	return count;
}

static void extend(struct pg_program *program, struct pg_synthesis_job ***mapping,
	struct pg_synthesis_job ***external, size_t *external_count,
	struct pg_synthesis_job ***roots, size_t *root_count,
	struct pg_synthesis_job *normalized)
{
	size_t count = program->synthesis.jobs.count, next = 0;
	struct pg_synthesis_job **jobs = calloc(3 * count, sizeof(*jobs));
	assert(jobs);
	/* The existing canonical index supplies membership. Only the known native
	 * normalization is another external owner at these cuts; every remaining
	 * new member must have the existing direct-rule transport. */
	for (size_t i = 0; i < *external_count; ++i) jobs[next++] = (*external)[i];
	for (size_t i = 0; i < *root_count; ++i) jobs[next++] = (*roots)[i];
	if (normalized) jobs[next++] = normalized;
	for (size_t i = 0; i < program->synthesis.jobs.capacity; ++i)
		for (struct pg_index_entry *entry = program->synthesis.jobs.buckets[i]; entry; entry = entry->next) {
			struct pg_synthesis_job *job = (void *)entry;
			size_t j = 0;
			while (j < next && jobs[j] != job) ++j;
			if (j < next) continue;
			assert(next < count && pg_synthesis_plain_derivation(job));
			jobs[next++] = job;
		}
	assert(next == count);
	free(*mapping);
	*mapping = jobs;
	*external = jobs + count;
	*roots = jobs + 2 * count;
	*external_count = *root_count = 0;
	for (size_t i = 0; i < count; ++i) {
		if (pg_synthesis_plain_derivation(jobs[i])) (*roots)[(*root_count)++] = jobs[i];
		else (*external)[(*external_count)++] = jobs[i];
	}
}

static void prepare(struct pg_program *program)
{
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(&program->synthesis, program->root, &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	const struct pg_source_scope *inner = pg_synthesis_binding_scope(binding);
	struct pg_synthesis_job *body = pg_synthesis_request(&program->synthesis, inner, syntax->right);
	struct pg_synthesis_job *rule = pg_synthesis_lambda_body(&program->synthesis,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(binding)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)});
	assert(binding && inner && body && rule && !program->synthesis.steps);
}

static int write_continuation(FILE *file, const struct pg_graph_codec *codec,
	void *objects, void *opaque)
{
	const struct checkpoint *checkpoint = opaque;
	return pg_artifact_source_write(file, checkpoint->source)
		|| pg_artifact_derivations_write(file, checkpoint->rules)
		|| pg_derivation_headers_write(file, checkpoint->header_count, checkpoint->headers, codec, objects)
		|| pg_wire_write_u64(file, 2 * (uint64_t)checkpoint->normalized_done + (checkpoint->whnf != NULL))
		|| (checkpoint->whnf && pg_whnf_pending_write(file, checkpoint->whnf, codec, objects))
		|| pg_artifact_schedule_save(file, checkpoint->schedule);
}

static int read_continuation(FILE *file, struct pg_typing *typing, size_t limit,
	size_t name_limit, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	struct checkpoint *checkpoint = opaque;
	checkpoint->source = pg_artifact_source_read(file, typing->graph, limit);
	checkpoint->rules = pg_artifact_derivations_read(file, typing->graph, limit);
	if (!checkpoint->source || !checkpoint->rules || pg_derivation_headers_read(file,
		typing, limit, name_limit, codec, objects, &checkpoint->header_count, &checkpoint->headers)) return -1;
	uint64_t pending;
	if (pg_wire_read_u64(file, &pending) || pending > 2) return -1;
	checkpoint->normalized_done = pending == 2;
	if (pending == 1) {
		checkpoint->restored = pg_alloc(typing->graph, sizeof(*checkpoint->restored));
		if (!checkpoint->restored || pg_whnf_pending_read(file, checkpoint->restored,
			typing->graph, limit, name_limit, codec, objects)) return -1;
		checkpoint->whnf = checkpoint->restored;
	}
	checkpoint->schedule = pg_artifact_schedule_read(file, typing->graph, limit);
	return checkpoint->schedule ? 0 : -1;
}

static void equal(FILE *left, FILE *right)
{
	rewind(left);
	rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); assert(a == b); } while (a != EOF);
	assert(!ferror(left) && !ferror(right));
}

static void check(const char *text, unsigned ordinal, uint64_t cut, int wrong_domain)
{
	struct pg_program *program = start(text);
	uint64_t total = finish(program);
	pg_program_destroy(program);
	program = start(text);
	advance(&program->synthesis, 1);
	struct pg_synthesis_job **initial, **external, **roots;
	size_t external_count, root_count;
	size_t count = map(program, &initial, &external, &external_count, &roots, &root_count);
	advance(&program->synthesis, cut - 1);
	assert(program->synthesis.steps == cut);
	struct pg_synthesis_job *binding, *domain = NULL, *normalized = NULL;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(&program->synthesis, program->root, &scope, &syntax));
	binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	assert(pg_synthesis_binding_domain(&program->synthesis, binding, &domain) == 1 && domain);
	assert(pg_synthesis_domain_frontier(&program->synthesis, domain, &normalized) == 1);
	struct pg_synthesis_job copy = *binding, *rejected = NULL;
	assert(pg_synthesis_binding_domain(&program->synthesis, &copy, &rejected) == -1 && !rejected);
	copy = *domain;
	assert(pg_synthesis_domain_frontier(&program->synthesis, &copy, &rejected) == -1 && !rejected);
	if (cut >= 4) {
		assert(normalized && domain->status == PG_SYNTHESIS_DONE
			&& pg_synthesis_status(domain) == pg_synthesis_status(normalized));
		extend(program, &initial, &external, &external_count, &roots, &root_count, normalized);
		count = program->synthesis.jobs.count;
	} else assert(!normalized);
	assert(program->synthesis.jobs.count == count);
	const struct pg_evidence *context = pg_synthesis_scope_context(program->scope);
	struct pg_artifact_derivation_dependencies dependencies = {
		.job_count = external_count, .jobs = external, .checked_count = 1, .checked = &context
	};
	struct pg_synthesis_job **jobs;
	struct checkpoint written = {0};
	if (normalized) written.whnf = pg_synthesis_normalization_pending(&program->synthesis, normalized);
	written.normalized_done = normalized && normalized->status == PG_SYNTHESIS_DONE;
	if (cut >= 10 && !written.normalized_done) assert(written.whnf && !written.whnf->certificate);
	else assert(!written.whnf);
	uint64_t saved_whnf_steps = written.whnf ? written.whnf->steps : 0;
	written.rules = pg_artifact_derivations_capture_with_dependencies(&program->graph,
		&program->synthesis, root_count, roots, &dependencies, &jobs);
	assert(written.rules && pg_artifact_derivations_job_count(written.rules) == count);
	written.headers = pg_artifact_derivations_inputs(written.rules, &written.header_count);
	struct pg_synthesis_job *body = pg_synthesis_request(&program->synthesis,
		pg_synthesis_binding_scope(binding), syntax->right);
	struct pg_synthesis_job *lambda = pg_synthesis_work_project(program->root).rule;
	struct pg_synthesis_job *adapter = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, lambda, 1).pending);
	struct pg_synthesis_job *pi = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, lambda, 0).pending);
	struct pg_synthesis_job *classifier = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, pi, 1).pending);
	struct pg_typed_query *query = NULL;
	assert(pg_synthesis_classifier_formation_frontier(&program->synthesis, classifier, &query) == 1);
	copy = *classifier;
	assert(pg_synthesis_classifier_formation_frontier(&program->synthesis, &copy, &query) == -1);
	struct pg_synthesis_input adapted;
	assert(pg_synthesis_body_frontier(&program->synthesis, adapter, &adapted) == 1);
	copy = *adapter;
	assert(pg_synthesis_body_frontier(&program->synthesis, &copy, &adapted) == -1
		&& pg_synthesis_body_resume(&program->synthesis, &copy));
	struct pg_synthesis_job *owners[] = {program->root, domain, adapter, binding, classifier, body};
	struct pg_reference_frontier referenced;
	size_t owner_count = pg_synthesis_reference_frontier(&program->synthesis, body, &referenced) == 1 ? 6 : 5;
	written.source = pg_artifact_source_capture(&program->graph, &program->synthesis,
		count, jobs, owner_count, owners);
	written.schedule = pg_artifact_schedule_capture(&program->graph, &program->synthesis, count, jobs);
	assert(written.source && written.schedule);
	FILE *file = tmpfile();
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	/* Source retains the existing binding scope from its canonical request key;
	 * the child no longer needs a redundant exported producer root. */
	assert(file && !pg_sources_write_with(file, &program->synthesis, 1, &root, 0,
		write_continuation, &written));
	free(initial);
	pg_program_destroy(program);
	rewind(file);
	struct checkpoint loaded = {0};
	size_t source_count;
	struct pg_synthesis_job *const *sources;
	program = pg_sources_read_with(file, 100000, &source_count, &sources, read_continuation, &loaded);
	assert(program && source_count == 1 && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	assert(!loaded.restored || (!loaded.restored->request.work
		&& !loaded.restored->certificate && loaded.restored->steps == saved_whnf_steps));
	program->root = sources[0];
	prepare(program);
	FILE *resave = tmpfile();
	root = (struct pg_synthesis_input){.pending = pg_synthesis_pending(program->root)};
	assert(resave && !pg_sources_write_with(resave, &program->synthesis, 1, &root, 0,
		write_continuation, &loaded));
	equal(file, resave);
	assert(!fclose(resave) && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	size_t initial_count = map(program, &initial, &external, &external_count, &roots, &root_count);
	assert(initial_count + (cut >= 4) <= count);
	context = pg_synthesis_scope_context(program->scope);
	assert(!pg_synthesis_source_input(&program->synthesis, program->root, &scope, &syntax));
	binding = pg_synthesis_binding(&program->synthesis, scope, syntax);
	assert(pg_synthesis_binding_domain(&program->synthesis, binding, &domain) == 1 && domain);
	uint64_t budget = total, initial_cap = cut <= 4 ? 2 : (cut < 15 ? 4 : total), cap = initial_cap, validated = 0, spent = UINT64_MAX;
	uint64_t validated_kernel = 0;
	if (cut >= 4) {
		struct pg_synthesis_job *annotation = pg_synthesis_request(&program->synthesis, scope, syntax->left);
		size_t target = 0;
		while (target < initial_count && initial[target] != annotation) ++target;
		assert(target < initial_count);
		const struct pg_artifact_schedule *validation = pg_artifact_schedule_ready(&program->graph,
			initial_count, 1, &target);
		assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, initial_count, initial));
		solving = 1;
		assert(pg_artifact_revalidate(program, annotation, budget, 0, &spent) == PG_SYNTHESIS_PENDING);
		assert(!spent && !program->synthesis.steps && native_admissions(&program->typing) == 1);
		assert(pg_artifact_revalidate(program, annotation, budget, 1, &spent) == PG_SYNTHESIS_DONE && spent == 1);
		solving = 0;
		budget -= spent;
		cap -= spent;
		validated += spent;
		/* Native-first normalization keeps the actual checked input key. A raw
		 * pending-annotation request would add a different forwarding owner. */
		const struct pg_evidence *annotation_result = pg_synthesis_result(annotation);
		assert(pg_evidence_judgement(annotation_result) == PG_JUDGEMENT_VALUE_TYPE);
		normalized = pg_synthesis_normalize(&program->synthesis, context, annotation_result);
		assert(normalized && !pg_synthesis_result(normalized));
		external[external_count++] = normalized;
	}
	dependencies = (struct pg_artifact_derivation_dependencies){
		.job_count = external_count, .jobs = external, .checked_count = 1, .checked = &context
	};
	assert(!pg_artifact_derivations_prepare_with_dependencies(&program->synthesis, loaded.rules,
		loaded.header_count, loaded.headers, &dependencies, &jobs));
	assert(program->synthesis.jobs.count == count && program->synthesis.steps == validated);
	assert(cut >= 4 || native_admissions(&program->typing) == 1);
	assert(!pg_artifact_source_prepare(&program->synthesis, loaded.source, count, jobs));
	size_t *targets = calloc(count, sizeof(*targets));
	assert(targets);
	const struct pg_artifact_schedule *validation;
	enum pg_synthesis_status status;
	if (cut >= 4) {
		size_t target = 0;
		while (target < count && jobs[target] != domain) ++target;
		assert(target < count && domain->status == PG_SYNTHESIS_PENDING);
		validation = pg_artifact_schedule_ready(&program->graph, count, 1, &target);
		assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, count, jobs));
		/* DONE here means domain discovery, while its checked normalization is
		 * still pending. Validate that discovery by one ordinary charged step;
		 * do not turn the saved status into normalization acceptance. */
		assert(budget && cap);
		advance(&program->synthesis, 1);
		--budget;
		--cap;
		++validated;
		assert(domain->status == PG_SYNTHESIS_DONE && pg_synthesis_status(domain) == PG_SYNTHESIS_PENDING);
		struct pg_synthesis_job *selected;
		assert(pg_synthesis_domain_frontier(&program->synthesis, domain, &selected) == 1 && selected == normalized);
	}
	if (loaded.normalized_done) {
		size_t target = 0;
		while (target < count && jobs[target] != normalized) ++target;
		assert(target < count && normalized->status == PG_SYNTHESIS_PENDING && !loaded.restored);
		validation = pg_artifact_schedule_ready(&program->graph, count, 1, &target);
		assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, count, jobs));
		solving = 1;
		status = pg_artifact_revalidate(program, normalized, budget, cap, &spent);
		solving = 0;
		assert(status == PG_SYNTHESIS_DONE && spent && spent <= budget && spent <= cap);
		budget -= spent;
		cap -= spent;
		validated += spent;
		assert(pg_synthesis_result(normalized) && pg_synthesis_status(domain) == PG_SYNTHESIS_DONE);
	}
	size_t source_done = pg_artifact_source_validation(loaded.source, targets);
	for (size_t i = 0; i < source_done; ++i) {
		if (jobs[targets[i]] != binding) continue;
		validation = pg_artifact_schedule_ready(&program->graph, count, 1, &targets[i]);
		assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, count, jobs));
		solving = 1;
		status = pg_artifact_revalidate(program, binding, budget, cap, &spent);
		solving = 0;
		assert(status == PG_SYNTHESIS_DONE && spent && spent <= budget && spent <= cap);
		budget -= spent;
		cap -= spent;
		validated += spent;
		assert(pg_synthesis_result(binding));
	}
	size_t ready = pg_artifact_derivations_validation(loaded.rules, targets);
	size_t pending = 0;
	for (size_t i = 0; i < ready; ++i)
		if (!pg_synthesis_result(jobs[targets[i]])) targets[pending++] = targets[i];
	/* Completed rules may depend on completed Source discovery/context owners.
	 * Put both sets in the ordinary scheduler, rather than leave those owners
	 * dormant while revalidating only their consumers. Imported claims remain
	 * untrusted and every dispatch is charged to this same budget. */
	size_t *source_targets = calloc(count, sizeof(*source_targets));
	assert(source_targets);
	source_done = pg_artifact_source_validation(loaded.source, source_targets);
	size_t validation_ready = pending;
	for (size_t i = 0; i < source_done; ++i)
		if (jobs[source_targets[i]]->status == PG_SYNTHESIS_PENDING)
			targets[validation_ready++] = source_targets[i];
	assert(validation_ready <= count);
	free(source_targets);
	validation = pg_artifact_schedule_ready(&program->graph, count, validation_ready, targets);
	assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, count, jobs));
	solving = 1;
	status = pg_artifact_derivations_revalidate(program, loaded.rules,
		jobs, &dependencies, budget, 0, &spent);
	solving = 0;
	assert(!spent && program->synthesis.steps == validated);
	assert(status == (pending ? PG_SYNTHESIS_PENDING : PG_SYNTHESIS_DONE));
	if (pending) assert(pg_artifact_derivations_attach(&program->synthesis, loaded.rules, jobs, &dependencies));
	while (status == PG_SYNTHESIS_PENDING) {
		assert(cap);
		solving = 1;
		status = pg_artifact_derivations_revalidate(program, loaded.rules, jobs, &dependencies, budget, 1, &spent);
		solving = 0;
		assert(spent && spent <= 1 && spent <= budget);
		budget -= spent;
		cap -= spent;
		validated += spent;
	}
	assert(status == PG_SYNTHESIS_DONE && program->synthesis.steps == validated);
	body = pg_synthesis_request(&program->synthesis, pg_synthesis_binding_scope(binding), syntax->right);
	lambda = pg_synthesis_lambda_body(&program->synthesis,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(binding)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)});
	adapter = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, lambda, 1).pending);
	pi = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, lambda, 0).pending);
	classifier = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, pi, 1).pending);
	struct pg_synthesis_job *source_order[] = {body, adapter, classifier, program->root};
	source_done = pg_artifact_source_validation(loaded.source, targets);
	for (size_t i = 0; i < sizeof(source_order) / sizeof(*source_order); ++i) {
		for (size_t j = 0; j < source_done; ++j) {
			struct pg_synthesis_job *job = source_order[i];
			if (jobs[targets[j]] != job) continue;
			if (job->status == PG_SYNTHESIS_DONE) continue;
			validation = pg_artifact_schedule_ready(&program->graph, count, 1, &targets[j]);
			assert(validation && !pg_artifact_schedule_attach(&program->synthesis, validation, count, jobs));
			struct pg_synthesis_input selected;
			if (pg_synthesis_body_frontier(&program->synthesis, job, &selected) == 1
				|| pg_synthesis_classifier_formation_frontier(&program->synthesis, job, &query) == 1) {
				/* Body completion is discovery/context checking. Its selected rule
				 * can still be pending; do not validate future work as saved progress. */
				assert(budget && cap);
				advance(&program->synthesis, 1);
				spent = 1;
				assert(job->status == PG_SYNTHESIS_DONE);
			} else {
				solving = 1;
				status = pg_artifact_revalidate(program, job, budget, cap, &spent);
				solving = 0;
				assert(status == PG_SYNTHESIS_DONE && spent && spent <= budget && spent <= cap);
			}
			budget -= spent;
			cap -= spent;
			validated += spent;
		}
	}
	size_t query_done = pg_artifact_source_query_validation(loaded.source, targets);
	for (size_t i = 0; i < query_done; ++i) {
		assert(pg_synthesis_classifier_formation_frontier(&program->synthesis, jobs[targets[i]], &query) == 1
			&& pg_typed_query_owned_by(query, &program->typing));
		uint64_t before = query->steps, available = budget < cap ? budget : cap;
		solving = 1;
		int before_status = query->status;
		assert(pg_typed_query_advance(query, 0) == before_status && query->steps == before);
		assert(pg_typed_query_advance(query, available) == 1 && pg_typed_query_result(query));
		solving = 0;
		spent = query->steps - before;
		assert(spent <= budget && spent <= cap);
		budget -= spent;
		cap -= spent;
		validated += spent;
		validated_kernel += spent;
	}
	assert(program->synthesis.steps == validated - validated_kernel);
	assert(!pg_artifact_derivations_attach(&program->synthesis, loaded.rules, jobs, &dependencies));
	if (wrong_domain) {
		struct pg_synthesis_job *selected_owner = domain;
		if (wrong_domain == 3) {
			assert(cut == 23 && !pg_artifact_source_attach(&program->synthesis, loaded.source, count, jobs));
			selected_owner = classifier;
		} else if (wrong_domain == 2) {
			assert(cut == 6 && !pg_artifact_source_attach(&program->synthesis, loaded.source, count, jobs));
			lambda = pg_synthesis_work_project(program->root).rule;
			selected_owner = pg_pending_job(pg_synthesis_rule_input(&program->synthesis, lambda, 1).pending);
		} else assert(cut == 4);
		const struct pg_artifact_source *bad = pg_artifact_source_capture(&program->graph,
			&program->synthesis, count, jobs, 1, &selected_owner);
		FILE *malformed = tmpfile();
		assert(bad && malformed && !pg_artifact_source_write(malformed, bad));
		/* One W3 record: replace only its selected child ordinal with another
		 * genuine local owner. A matching owner tag is insufficient. */
		assert(!fseek(malformed, 24 + 32, SEEK_SET) && !pg_wire_write_u64(malformed, wrong_domain == 3 ? 2 : 1));
		rewind(malformed);
		bad = pg_artifact_source_read(malformed, &program->graph, 100000);
		assert(bad);
		uint64_t before = program->synthesis.steps;
		size_t proofs = native_admissions(&program->typing), job_count = program->synthesis.jobs.count;
		assert(pg_artifact_source_attach(&program->synthesis, bad, count, jobs));
		assert(program->synthesis.steps == before && native_admissions(&program->typing) == proofs
			&& program->synthesis.jobs.count == job_count);
		if (wrong_domain != 3) assert(!pg_synthesis_result(normalized));
		puts(wrong_domain == 3 ? "classifier frontier: forged completion rejected without Solve/proof/status admission"
			: wrong_domain == 2 ? "body frontier: wrong canonical child rejected without Solve/proof/status admission"
			: "domain frontier: wrong canonical child rejected without Solve/proof/status admission");
		assert(!fclose(malformed));
		/* Attachment errors discard this unpublished import. */
		free(targets);
		free(initial);
		pg_program_destroy(program);
		assert(!fclose(file));
		return;
	}
	assert(!pg_artifact_source_attach(&program->synthesis, loaded.source, count, jobs));
	if (loaded.restored) {
		assert(cut >= 10 && !loaded.restored->request.work && !loaded.restored->certificate);
		copy = *normalized;
		assert(!pg_synthesis_normalization_pending(&program->synthesis, &copy));
		assert(pg_synthesis_normalization_attach(&program->synthesis, &copy, loaded.restored));
		assert(!loaded.restored->request.work && program->synthesis.steps == validated - validated_kernel);
		/* This enclosing control selected continuation reuse explicitly. Typed
		 * inputs were checked above; loading alone neither attaches nor checks
		 * the machine. Reuse the existing pending codec and native owner. */
		assert(!pg_synthesis_normalization_attach(&program->synthesis, normalized, loaded.restored));
		assert(pg_synthesis_normalization_pending(&program->synthesis, normalized) == loaded.restored);
	}
	assert(!pg_artifact_schedule_attach(&program->synthesis, loaded.schedule, count, jobs));
	advance(&program->synthesis, 0);
	assert(program->synthesis.steps == validated - validated_kernel);
	assert(!loaded.restored || loaded.restored->steps == saved_whnf_steps);
	assert(validated == initial_cap - cap && validated <= total);
	uint64_t remaining = budget;
	while (remaining && program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		advance(&program->synthesis, 1);
		--remaining;
	}
	if (!pg_synthesis_result(program->root)) {
		fprintf(stderr, "frontier stalled: cut=%" PRIu64 " validated=%" PRIu64
			" useful=%" PRIu64 " remaining=%" PRIu64 " ready=%p root=%d\n",
			cut, validated, program->synthesis.steps - (validated - validated_kernel), remaining,
			(void *)program->synthesis.ready, pg_synthesis_status(program->root));
		for (size_t i = 0; i < count; ++i) {
			const struct pg_derivation_input *header = pg_synthesis_plain_derivation(jobs[i]);
			size_t cursor = SIZE_MAX;
			int direct = pg_synthesis_rule_frontier(&program->synthesis, jobs[i], &cursor);
			fprintf(stderr, "job=%zu raw=%d logical=%d rule=%d cursor=%zu direct=%d dependency=%p\n",
				i, jobs[i]->status, pg_synthesis_status(jobs[i]), header ? (int)header->rule : -1,
				cursor, direct, (void *)jobs[i]->dependency);
		}
	}
	assert(pg_synthesis_result(program->root));
	uint64_t useful = program->synthesis.steps - (validated - validated_kernel);
	assert(useful == total - cut && useful <= budget);
	printf("lambda-checked=%u cut=%" PRIu64 " validation=%" PRIu64 " useful=%" PRIu64
		" total=%" PRIu64 " completed-rules=%zu jobs=%zu saved-whnf-steps=%" PRIu64 "\n",
		ordinal, cut, validated, useful, total, ready, count, saved_whnf_steps);
	free(targets);
	free(initial);
	pg_program_destroy(program);
	assert(!fclose(file));
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	const char *fixtures[] = {"main := \\x : @ => x;", "main := \\x : @ => @;",
		"main := \\x : @ => \\y : @ => x;"};
	for (unsigned i = 0; i < sizeof(fixtures) / sizeof(*fixtures); ++i)
		for (uint64_t cut = 1; cut <= (i == 2 ? 4 : 26); ++cut) check(fixtures[i], i, cut, 0);
	check(fixtures[0], 0, 4, 1);
	check(fixtures[0], 0, 6, 2);
	check(fixtures[0], 0, 23, 3);
	return 0;
}

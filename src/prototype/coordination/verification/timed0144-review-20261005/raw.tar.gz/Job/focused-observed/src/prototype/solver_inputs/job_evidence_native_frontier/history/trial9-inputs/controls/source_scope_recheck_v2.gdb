set pagination off
set print elements 5
break evidence_scope.c:47 if !type
commands
silent
printf "scope missing typed declaration scope=%p\n", scope
print *scope
print *scope->type
bt 4
continue
end
run indexed-families
bt

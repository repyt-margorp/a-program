set pagination off
break pg_synthesis_finish
commands
silent
if status == PG_SYNTHESIS_REJECTED
printf "rejected job=%p inputs=%lu steps=%lu\n", job, job->input_count, synthesis->steps
bt 4
end
continue
end
run indexed-families
bt

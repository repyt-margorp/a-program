set pagination off
set print elements 12
break synthesis_function.c:692 if !local->query
commands
silent
printf "classifier missing query steps=%lu\n", synthesis->steps
set $body_job = pg_pending_job(body.pending)
print *$body_job
info symbol $body_job->pending.role
print pg_synthesis_work_output($body_job)
print pg_synthesis_plain_derivation($body_job)
set $parent = job->waiters
while $parent
print *(struct waiter *)$parent
set $parent_job = ((struct waiter *)$parent)->parent
info symbol $parent_job->pending.role
print pg_synthesis_plain_derivation($parent_job)
print pg_synthesis_work_output($parent_job)
set $parent = $parent->next
end
bt 3
continue
end
run indexed-families
bt

#include "evidence.h"
#include "derivation.h"
#include "scope.h"
#include <assert.h>
#include <stdio.h>

int main(void)
{
	struct pg_graph graph;
	struct pg_typing typing;
	assert(!pg_graph_init(&graph));
	assert(!pg_typing_init(&typing, &graph));
	const struct pg_evidence *empty = pg_prove_empty_context(&typing);
	const struct pg_evidence *universe = pg_prove_universe(&typing, empty, 0);
	assert(empty && universe && pg_evidence_owned_by(universe, &typing));
	assert((const void *)universe == (const void *)pg_evidence_subject(universe));
	assert(pg_evidence_premise(universe, 0) == empty);
	const struct pg_object *binder = pg_binder(&graph);
	const struct pg_evidence *context = pg_prove_context_extension(&typing, empty, binder, universe);
	const struct pg_evidence *variable = pg_prove_variable(&typing, context, binder);
	const struct pg_evidence *returned = pg_prove_return(&typing, variable);
	const struct pg_evidence *formation = pg_prove_classifier(&typing, context, returned);
	const struct pg_evidence *pi = pg_prove_pi(&typing, context, formation);
	const struct pg_evidence *lambda = pg_prove_lambda(&typing, pi, returned);
	const struct pg_evidence *quote = pg_prove_type_value(&typing, universe);
	/* The argument of this function is a type, not a computation. */
	const struct pg_evidence *application = pg_prove_application(&typing, lambda, quote);
	assert(context && variable && returned && formation && pi && lambda);
	assert(!application);
	assert((const void *)lambda == (const void *)pg_evidence_subject(lambda));
	assert((const void *)context == (const void *)pg_evidence_scope(context));
	assert(!pg_evidence_retained_premise_count(lambda));
	assert(pg_prove_structural_subject(&typing, pg_evidence_subject(lambda)) == lambda);
	const struct pg_evidence *extended = pg_prove_context_extension(&typing, context,
		pg_binder(&graph), pg_prove_projection(&typing, context, universe));
	const struct pg_evidence *projected = pg_prove_projection(&typing, extended, variable);
	assert(projected && pg_evidence_rule(projected) == PG_VARIABLE);
	assert(pg_evidence_subject(projected)->core == pg_evidence_subject(variable)->core);
	struct pg_derivation_input projected_header;
	assert(!pg_derivation_input_header(projected, &projected_header));
	assert(projected_header.rule == PG_VARIABLE && projected_header.count == 1);
	const struct pg_evidence *projected_scope;
	assert(pg_derivation_input_dependency(&typing, projected, 0, &projected_scope) == 1);
	assert(projected_scope == extended);
	struct pg_occurrence copied = *pg_evidence_subject(lambda);
	assert(!pg_evidence_owned_by((const void *)&copied, &typing));
	struct pg_scope copied_scope = *pg_evidence_scope(context);
	assert(!pg_evidence_owned_by((const void *)&copied_scope, &typing));
	const struct pg_evidence *map = pg_prove_substitution_projection(&typing, context, context);
	assert(map && (const void *)map == (const void *)pg_evidence_context_map(map));
	struct pg_context_map copied_map = *pg_evidence_context_map(map);
	assert(!pg_evidence_owned_by((const void *)&copied_map, &typing));
	struct pg_typing foreign;
	assert(!pg_typing_init(&foreign, &graph));
	assert(!pg_evidence_owned_by(lambda, &foreign));
	assert(!pg_prove_lambda(&foreign, pi, returned));
	pg_typing_destroy(&foreign);
	const struct pg_evidence *u1 = pg_prove_universe(&typing, empty, 1);
	const struct pg_evidence *unused = pg_prove_context_extension(&typing, empty,
		pg_binder(&graph), pg_prove_universe(&typing, empty, 3));
	const struct pg_evidence *wide_pi = pg_prove_pi(&typing, unused,
		pg_prove_projection(&typing, unused, pg_prove_return_type(&typing, universe)));
	const struct pg_evidence *widened = pg_prove_return_content(&typing,
		pg_prove_pi_constant_codomain(&typing, wide_pi));
	const struct pg_evidence *high = pg_prove_context_extension(&typing, empty, binder, widened);
	assert(high && high != context && pg_evidence_context(high) == pg_evidence_context(context));
	assert(pg_evidence_classifier(widened) != pg_evidence_classifier(universe));
	const struct pg_context_map *raw = pg_evidence_context_map(map);
	const struct pg_evidence *selected = pg_prove_substitution_projection(&typing, high, high);
	assert(selected && selected != map);
	assert(pg_evidence_context_map(selected)->images == raw->images);
	assert(pg_evidence_premise(map, 0) == context && pg_evidence_premise(map, 1) == context);
	assert(pg_evidence_premise(selected, 0) == high && pg_evidence_premise(selected, 1) == high);
	assert(pg_context_map_projection(&typing, raw->source, raw->destination) == raw);
	size_t maps = typing.context_maps.count;
	assert(pg_prove_substitution_projection(&typing, high, high) == selected);
	assert(typing.context_maps.count == maps);
	assert(!pg_context_map_scoped(&typing, raw, &copied_scope, pg_evidence_scope(context)));
	assert(!pg_context_map_scoped(&typing, &copied_map, pg_evidence_scope(context), pg_evidence_scope(context)));
	const struct pg_object *type_binder = pg_binder(&graph);
	const struct pg_evidence *type_context = pg_prove_context_extension(&typing, empty, type_binder, u1);
	const struct pg_evidence *type_variable = pg_prove_variable(&typing, type_context, type_binder);
	const struct pg_evidence *type_body = pg_prove_return(&typing, type_variable);
	const struct pg_evidence *identity = pg_prove_lambda(&typing,
		pg_prove_pi(&typing, type_context, pg_prove_classifier(&typing, type_context, type_body)), type_body);
	const struct pg_evidence *applied = pg_prove_application(&typing, identity, quote);
	const struct pg_evidence *body = pg_prove_application_body(&typing, identity, quote);
	const struct pg_evidence *value = pg_prove_return_value(&typing, body);
	assert(identity && applied && body && value);
	assert(pg_evidence_subject(value)->core == pg_evidence_subject(quote)->core);
	assert(pg_evidence_classifier(value) == pg_evidence_classifier(quote));
	struct pg_occurrence forged = *pg_evidence_subject(identity);
	forged.annotation = pg_reference(&graph, pg_binder(&graph));
	const struct pg_occurrence *unadmitted = pg_occurrence_intern(&typing, &forged,
		pg_evidence_subject(identity)->operands, pg_occurrence_maps(pg_evidence_subject(identity)));
	assert(unadmitted && pg_occurrence_owned_by(unadmitted, &typing));
	assert(!unadmitted->admission_owner);
	assert(!pg_evidence_owned_by((const void *)unadmitted, &typing));
	assert(!pg_evidence_for_subject(&typing, unadmitted, NULL));
	printf("native owners: occurrence=%zu scope=%zu map=%zu; no allocated Evidence node\n",
		sizeof(struct pg_occurrence), sizeof(struct pg_scope), sizeof(struct pg_context_map));
	pg_typing_destroy(&typing);
	pg_graph_destroy(&graph);
	return 0;
}

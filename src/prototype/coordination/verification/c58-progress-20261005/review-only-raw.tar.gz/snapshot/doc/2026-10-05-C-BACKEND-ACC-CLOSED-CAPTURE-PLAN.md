# Actual Acc QuickSort Closed Comparator Capture

Date: 2026-10-05
Status: distinct C58 source/capture implementation; immutable C57 untouched.
Baseline: worker cc3cba3495; C56 taska99fbcbf/Main01ae6856.
Submitted C57 manifest2ce9d7ac/archivee2bf0ea4 remains exact.
Related: open #61, [owning Goal](2026-10-03-C-BACKEND-GOAL.md).

## Problem List

1. Emit the actual closed source comparator capture for QuickSort rather than
 requiring an ordinary C client to interpret the captured function manually.

## 1. Source-Selected Capture and Executable Products

### Subjective (User)

Inherited2026-10-04 conveyed human clarification via inquiry desk/Merge, English
paraphrase; original wording not supplied: readable executable C must faithfully
follow actual admitted Acc QuickSort, including Acc/down, indices, partition and
captured parameters. A labeled faithful manual candidate is acceptable; no
alternate sorter or false generalized-native success. Preserve sealed C32,
original Goal/model and defer List conveniences.
Inherited2026-10-03 human paraphrase: downstream .a/LinkerScript products should
serve ordinary C modules without changing producer/schema/checker/source-erasure
authority. Lanes continue independently while Merge integrates.
These inherited requirements do not approve a new source policy, ABI or costs.

### Objective (Code)

C57 actual parameter products passed local native126/legacy120 O2/full affected
SAN85 plus parent67, original link/I-O19 and exact25 freeze. It preserves actual
algorithm bodies, adds a borrowed gs_sort_with interpreter boundary and retains
closed source selection refusal in that parameter-only profile.
Actual descending_sort := quickSort Nat &reverse_compare is ordinarily admitted
in the exact C57 image; reverse_compare applies actual natLessOrEqual right left.
Current C41 closed-entry reader only accepts the direct known comparator by
static carrier projection/alpha identity. No closed-capture emission/runtime
success is claimed yet. C57 remains an immutable submitted epoch.

### Assessment

Agent bounded next choice: inspect the closed admitted application and require
its remaining QuickSort lambda/captured type to correspond to the existing
parameter source. Emit only a direct known Nat comparator or its two-bound-Nat
argument permutation. Keep the same actual comparison/partition/Acc/down/indices/
measure bodies and manual array/runtime contract. A source-derived tiny adapter
should choose operands, replacing foreign interpretation for this closed entry.
No alternate sorting loop or effect/closure erasure. More complex captured
functions remain refusal4; concrete producer/view gaps route through Merge.

Use a separate target command and the existing candidate LinkerScript grammar/
profile with an explicit closed-entry selection. Preserve existing C56/C57
commands and their expected refusals; do not broaden Main native lowering or
change .a. The prototype may still use fixed roles/body/recipe qualifiers.
Source admission/classifier/carrier correspondence is evidence for this bounded
path, not a private checker/full Scope/source-equivalence proof.

### Plan

- [ ] Inspect actual admitted closed capture and prove source association.
- [ ] Emit selected comparator operands and execute actual QuickSort C.
- [ ] Expose closed-entry source/object/archive through the labeled target route.
- [ ] Verify source correspondence, capture/direction, old controls, failures/
 resources/publication O2/affected SAN on pinned producers, serial j1.
- [ ] Preserve C32-C57 snapshots/style/initial failures and exact reviewable handoff.
- [ ] Merge task publication/current audit/integration separately.
- [ ] General native/full61/full Scope/source equivalence/adoption/cost stay open.


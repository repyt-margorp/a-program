include $(OVERLAY)/controls/query_frontier.mk

$(BUILD)/application_composed_checkpoint: $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(SOURCE_FRONTIER_IO) $(ROOT)artifact/source.c $(ROOT)artifact/schedule.c $(ROOT)artifact/derivation.c $(CONTROL)
	mkdir -p $(BUILD)
	$(CC) $(CFLAGS) -I$(ROOT) $(SOURCES) $(filter-out $(ROOT)main.c,$(CLI_SOURCES)) $(SOURCE_FRONTIER_IO) $(ROOT)artifact/source.c $(ROOT)artifact/schedule.c $(ROOT)artifact/derivation.c $(CONTROL) -Wl,--wrap=pg_synthesis_advance -o $@

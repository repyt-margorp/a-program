# Native application frame deletion r3

This prototype increment extends the exact native query r2. Application bind
frames duplicate existing canonical CONTEXT_EXTEND / RETURN_CONTENT / classifier
input links. Their separate allocation and copied linked chain are deleted.
The application borrows the exact existing context owner, verifies each immutable
parent/computation and its lexical boundary, and unwinds through those owners.
Transport retains one context ordinal; flattened decoding scratch and owned frame
copies are deleted. No index, owner/state fields, proof checker or graph is added.

Actual Application/Constructor/Spine private layout moves unchanged to an internal
header so the existing Source transport can borrow the application cursor. This
supports virgin pending stages0/2/6, open constraints and canonical frame tails.
Copied/foreign owners, started constructor/spine/callable/family and advanced
application stages refuse. Completed reusable results and escaped pointers remain
owned by their existing stores. APGSRCW6 supersedes private unpublished W5; native
r1/r2 format retirement remains separately documented. Loading remains inert;
explicit authentic frontier reuse is distinct from local typing acceptance.

Exact130 runtime/675 inputs: unskipped serial O2 acceptance0; seven affected SAN
gates0; focused O2/SAN four build/run records0. Candidate406 cuts/621 restorations,
15 frame tails and111 intrinsic cursors preserve ordinary result bytes and exact
remaining charged fuel. Parent/new fixture totals84/84,210/207,112/112 explicitly
differ. Imported ordinary-result Sorted is DONE955410/955248. Public completion
is1915/1912. Both actual strict public recipes FAIL1 on the same original three
classes:1000:1000,1600:1600,completed+0. All52 images equal after explicit budget
filename correspondence; the full TSVs differ in actual charged fuel. Original
equal-TSV assertion failure is preserved, not relabelled as a runtime pass.

Whole-Program structural/declaration/schema/qualified/Match closure and original
strict3 remain open. Separate schema trials are excluded. Current-producer joint
checks, publication/Main, net time and peak memory are pending; final layout or
dispatch counts do not establish peak RSS. No accepted code or Git metadata edits.

Full frozen snapshots are authoritative; applied.diff is review-only. The durable
manifest lists only publication files; external hashes pin raw evidence without
copying build logs or full plans. Merge owns exact task/current integration.

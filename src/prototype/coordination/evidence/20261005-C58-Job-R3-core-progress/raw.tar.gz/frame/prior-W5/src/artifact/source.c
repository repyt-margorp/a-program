#include "source.h"
#include "synthesis_source.h"
#include "synthesis_function_internal.h"
#include "synthesis_work.h"
#include "typed_query.h"
#include "typing_io.h"
#include "graph.h"
#include "wire.h"
#include <string.h>

static const char magic[8] = "APGSRCW3";
static const char frontier_magic[8] = "APGSRCW4";
static const char application_magic[8] = "APGSRCW5";
enum source_record_kind { DEFINITION, MODULE, REFERENCE, LAMBDA, DOMAIN, BODY, BINDING, CLASSIFIER, APPLICATION };

struct source_record {
	enum source_record_kind kind;
	size_t job, count;
	uint64_t *data;
	enum pg_synthesis_status status;
	const struct pg_occurrence_input *input;
	const struct pg_scope *const *scopes;
};

struct pg_artifact_source {
	size_t job_count, count;
	struct source_record *records;
};

/* Capture needs ordinals and selected-owner uniqueness, not traversal state.
 * Entries borrow canonical Jobs only for this synchronous transport operation. */
struct source_job {
	struct pg_index_entry index;
	const struct pg_synthesis_job *job;
	size_t slot;
	int selected;
};

static int kind(const struct pg_synthesis *s, const struct pg_synthesis_job *job)
{
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax, *definitions;
	struct pg_synthesis_job *rule;
	struct pg_synthesis_input adapted;
	struct pg_typed_query *query;
	if (pg_synthesis_source_application_cursor(s, job)) return APPLICATION;
	if (pg_synthesis_classifier_formation_frontier(s, job, &query) == 1) return CLASSIFIER;
	if (pg_synthesis_binding_domain(s, job, &rule) == 1) return BINDING;
	if (pg_synthesis_body_frontier(s, job, &adapted) == 1) return BODY;
	if (pg_synthesis_domain_frontier(s, job, &rule) == 1) return DOMAIN;
	if (!pg_synthesis_definition_input(s, job, &scope, &definitions, &syntax)) return DEFINITION;
	if (pg_synthesis_source_input(s, job, &scope, &syntax)) return -1;
	if (pg_synthesis_lambda_frontier(s, job, &rule) == 1) return LAMBDA;
	if (syntax->kind == PG_SYNTAX_DEFINITIONS) return MODULE;
	if (syntax->kind == PG_SYNTAX_QUALIFIED && syntax->left->kind == PG_SYNTAX_DEFINITIONS) return MODULE;
	struct pg_reference_frontier reference;
	return pg_synthesis_reference_frontier(s, job, &reference) == 1 ? REFERENCE : -1;
}

static struct source_job *find_job(const struct pg_index *jobs, const struct pg_synthesis_job *job)
{
	if (!job) return NULL;
	for (struct pg_index_entry *entry = pg_index_candidates(jobs, (uintptr_t)job); entry; entry = entry->next) {
		struct source_job *candidate = (void *)entry;
		if (candidate->job == job) return candidate;
	}
	return NULL;
}

static uint64_t reference(const struct pg_index *jobs, const struct pg_synthesis_job *job)
{
	if (!job) return 0;
	const struct source_job *entry = find_job(jobs, job);
	return entry ? entry->slot : UINT64_MAX;
}

static size_t application_words(const struct source_application_work *cursor)
{
	if (!cursor || cursor->callable || cursor->application.constructor || cursor->application.spine
		|| (cursor->stage && cursor->stage != 2 && cursor->stage != APPLICATION_RULE_READY)) return 0;
	size_t frames = 0;
	for (const struct pg_synthesis_sequence_frame *frame = cursor->application.frames; frame; frame = frame->parent) {
		if (frames >= cursor->application.binding_count || frame->binds != 1
			|| frame->context.checked || !frame->context.pending) return 0;
		++frames;
	}
	return frames > (SIZE_MAX - 11) / 2 ? 0 : 11 + frames * 2;
}

static int capture_application(const struct pg_synthesis *synthesis, const struct source_job *entry,
	const struct pg_index *jobs, struct source_record *record)
{
	const struct source_application_work *cursor = pg_synthesis_source_application_cursor(synthesis, entry->job);
	const struct application_state *state = &cursor->application;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	if (pg_synthesis_source_input(synthesis, entry->job, &scope, &syntax)) return -1;
	if (!cursor->stage) {
		if (cursor->left || state->context.checked || state->context.pending || state->callee
			|| state->argument || state->tail || state->constraint_source || state->constraint_type
			|| state->constraint_check || state->binding_count || state->frames) return -1;
	} else if (!cursor->left) {
		if (cursor->stage != APPLICATION_RULE_READY || !state->argument || !state->tail
			|| state->callee || state->context.checked || state->context.pending
			|| state->constraint_source || state->constraint_type || state->constraint_check
			|| state->binding_count || state->frames) return -1;
	} else if (!state->callee || !state->argument
		|| (!state->context.checked && !state->context.pending)
		|| (cursor->stage == APPLICATION_RULE_READY && !state->tail)) return -1;
	if ((state->constraint_source == NULL) != (state->constraint_type == NULL)
		|| (state->constraint_check && !state->constraint_source)) return -1;
	if (state->context.checked && state->context.checked != scope->context.checked) return -1;
	uint64_t *data = record->data;
	data[0] = cursor->stage; data[1] = reference(jobs, cursor->left);
	data[2] = reference(jobs, pg_pending_job(state->context.pending));
	data[3] = reference(jobs, state->callee); data[4] = reference(jobs, state->argument);
	data[5] = reference(jobs, state->tail); data[6] = reference(jobs, state->constraint_source);
	data[7] = reference(jobs, state->constraint_type); data[8] = reference(jobs, state->constraint_check);
	data[9] = state->binding_count; data[10] = (record->count - 11) / 2;
	size_t index = 11;
	for (const struct pg_synthesis_sequence_frame *frame = state->frames; frame; frame = frame->parent) {
		data[index++] = reference(jobs, frame->input);
		data[index++] = reference(jobs, pg_pending_job(frame->context.pending));
	}
	for (size_t i = 1; i < record->count; ++i)
		if (i != 9 && i != 10 && data[i] == UINT64_MAX) return -1;
	return 0;
}

static struct pg_artifact_source *allocate(struct pg_graph *storage, size_t jobs, size_t count)
{
	if (!jobs || count > jobs) return NULL;
	struct pg_artifact_source *c = pg_alloc(storage, sizeof(*c));
	if (!c) return NULL;
	c->job_count = jobs; c->count = count;
	c->records = pg_wire_array(storage, count, sizeof(*c->records));
	return c->records ? c : NULL;
}

const struct pg_artifact_source *pg_artifact_source_capture(struct pg_graph *storage,
	const struct pg_synthesis *s, size_t job_count, struct pg_synthesis_job *const *jobs,
	size_t count, struct pg_synthesis_job *const *owners)
{
	if (!storage || !s || !job_count || count > job_count || !jobs || (count && !owners)) return NULL;
	struct pg_artifact_source *c = NULL;
	struct pg_graph scratch = {0};
	struct pg_index map = {0};
	int failed = 1;
	if (pg_index_init(&map)) goto done;
	for (size_t i = 0; i < job_count; ++i) {
		if (!pg_synthesis_input_owned(s,
			(struct pg_synthesis_input){.pending = pg_synthesis_pending(jobs[i])})) goto done;
		if (find_job(&map, jobs[i])) goto done;
		struct source_job *entry = pg_alloc(&scratch, sizeof(*entry));
		if (!entry) goto done;
		*entry = (struct source_job){.job = jobs[i], .slot = i + 1};
		if (pg_index_insert(&map, &entry->index, (uintptr_t)jobs[i])) goto done;
	}
	/* Rejected caller mappings must not leave permanent transport records. */
	c = allocate(storage, job_count, count);
	if (!c) goto done;
	for (size_t i = 0; i < count; ++i) {
		struct pg_synthesis_job *job = owners[i], *child = NULL;
		struct source_job *entry = find_job(&map, job);
		if (!entry || !entry->slot || entry->slot > job_count || entry->selected) goto done;
		entry->selected = 1;
		uint64_t slot = entry->slot;
		int type = kind(s, job);
		if (type < 0 || job->status > PG_SYNTHESIS_DONE) goto done;
		struct source_record *r = &c->records[i];
		*r = (struct source_record){.kind = (enum source_record_kind)type, .job = (size_t)slot - 1, .status = job->status};
		struct pg_module_frontier module;
		struct pg_reference_frontier source;
		switch (r->kind) {
		case APPLICATION:
			r->count = application_words(pg_synthesis_source_application_cursor(s, job));
			if (!r->count || r->status != PG_SYNTHESIS_PENDING) goto done;
			break;
		case MODULE:
			r->count = pg_synthesis_module_frontier(s, job, &module) ? 0 : 3;
			break;
		case REFERENCE: r->count = 2; break;
		case CLASSIFIER: {
			struct pg_typed_query *query;
			if (pg_synthesis_classifier_formation_frontier(s, job, &query) != 1) goto done;
			r->count = query && !query->status && query->steps ? 2 : 1;
			break;
		}
		default: r->count = 1; break;
		}
		r->data = pg_wire_array(storage, r->count, sizeof(*r->data));
		if (!r->data) goto done;
		switch (r->kind) {
		case APPLICATION:
			if (capture_application(s, entry, &map, r)) goto done;
			continue;
		case DEFINITION:
			pg_synthesis_definition_body(s, job, &child);
			r->data[0] = reference(&map, child);
			break;
		case LAMBDA:
			if (pg_synthesis_lambda_frontier(s, job, &child) != 1) goto done;
			r->data[0] = reference(&map, child);
			break;
		case DOMAIN:
			if (pg_synthesis_domain_frontier(s, job, &child) != 1) goto done;
			r->data[0] = reference(&map, child);
			break;
		case BINDING:
			if (pg_synthesis_binding_domain(s, job, &child) != 1) goto done;
			r->data[0] = reference(&map, child);
			break;
		case CLASSIFIER: {
			struct pg_typed_query *query;
			if (pg_synthesis_classifier_formation_frontier(s, job, &query) != 1) goto done;
			if (query && (!pg_typed_query_owned_by(query, s->typing) || query->status < 0
				|| query->dependency || query->waiting)) goto done;
			r->data[0] = !query ? 0 : query->status ? 2 : 1;
			if (query && !query->status && query->steps) {
				r->input = pg_classifier_pending_input(query);
				if (!r->input) goto done;
				r->data[0] = 3; r->data[1] = query->steps;
				for (size_t j = 0; j < i; ++j) {
					const struct source_record *previous = &c->records[j];
					if (previous->kind == CLASSIFIER && previous->data[0] == 3
						&& previous->input == r->input) {
						r->data[0] = 4; r->data[1] = j;
						break;
					}
				}
			}
			break;
		}
		case BODY: {
			struct pg_synthesis_input adapted;
			if (pg_synthesis_body_frontier(s, job, &adapted) != 1 || adapted.checked) goto done;
			r->data[0] = reference(&map, pg_pending_job(adapted.pending));
			break;
		}
		case MODULE:
			if (!r->count) break;
			const struct pg_source_scope *scope = pg_synthesis_prepared_environment(job);
			if (!scope) goto done;
			r->data[0] = reference(&map, scope->registration);
			r->data[1] = module.position; r->data[2] = reference(&map, module.previous);
			break;
		case REFERENCE:
			if (pg_synthesis_reference_frontier(s, job, &source) != 1) goto done;
			if (source.value.checked) goto done;
			r->data[0] = reference(&map, pg_pending_job(source.value.pending));
			r->data[1] = reference(&map, source.rule);
			break;
		}
		for (size_t j = 0; j < r->count; ++j) if (r->data[j] == UINT64_MAX) goto done;
	}
	failed = 0;
done:
	pg_index_destroy(&map); pg_graph_destroy(&scratch);
	return failed ? NULL : c;
}

int pg_artifact_source_write(FILE *file, const struct pg_artifact_source *c)
{
	return pg_artifact_source_write_with(file, c, NULL, NULL);
}

int pg_artifact_source_write_with(FILE *file, const struct pg_artifact_source *c,
	const struct pg_graph_codec *codec, void *owner)
{
	if (!file || !c) return -1;
	int frontiers = 0, applications = 0;
	for (size_t i = 0; i < c->count; ++i) {
		frontiers |= c->records[i].kind == CLASSIFIER && c->records[i].data[0] >= 3;
		applications |= c->records[i].kind == APPLICATION;
	}
	if ((frontiers && !codec) || fwrite(applications ? application_magic : frontiers ? frontier_magic : magic, 1, 8, file) != 8) return -1;
	if (pg_wire_write_u64(file, c->job_count) || pg_wire_write_u64(file, c->count)) return -1;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (pg_wire_write_u64(file, r->kind) || pg_wire_write_u64(file, r->job)
			|| pg_wire_write_u64(file, r->status) || pg_wire_write_u64(file, r->count)) return -1;
		for (size_t j = 0; j < r->count; ++j) if (pg_wire_write_u64(file, r->data[j])) return -1;
		if (r->kind == CLASSIFIER && r->data[0] == 3
			&& (!codec || pg_occurrence_type_pending_write(file, r->input, r->scopes, codec, owner))) return -1;
	}
	return 0;
}

static const struct pg_artifact_source *read_source(FILE *file, struct pg_graph *storage,
	struct pg_typing *typing, size_t limit, size_t names, const struct pg_graph_codec *codec, void *owner)
{
	char header[8];
	uint64_t jobs, count;
	if (!file || !storage || fread(header, 1, 8, file) != 8) return NULL;
	int applications = !memcmp(header, application_magic, 8);
	int frontiers = applications || !memcmp(header, frontier_magic, 8);
	if (!frontiers && memcmp(header, magic, 8)) return NULL;
	if (frontiers && !applications && (!typing || !codec)) return NULL;
	if (pg_wire_read_u64(file, &jobs) || pg_wire_read_u64(file, &count) || jobs > limit || count > jobs) return NULL;
	struct pg_artifact_source *c = allocate(storage, (size_t)jobs, (size_t)count);
	unsigned char *seen = pg_wire_array(storage, jobs, 1);
	if (!c || !seen) return NULL;
	size_t available = limit;
	for (size_t i = 0; i < c->count; ++i) {
		uint64_t type, slot, status, n;
		if (pg_wire_read_u64(file, &type) || type > (applications ? APPLICATION : CLASSIFIER)
			|| pg_wire_read_u64(file, &slot) || slot >= jobs) return NULL;
		if (pg_wire_read_u64(file, &status) || status > PG_SYNTHESIS_DONE) return NULL;
		if (seen[slot]++ || pg_wire_read_u64(file, &n) || n > available) return NULL;
		available -= (size_t)n;
		struct source_record *r = &c->records[i];
		*r = (struct source_record){.kind = (enum source_record_kind)type, .job = (size_t)slot,
			.status = (enum pg_synthesis_status)status, .count = (size_t)n};
		r->data = pg_wire_array(storage, n, sizeof(*r->data));
		if (!r->data) return NULL;
		for (size_t j = 0; j < n; ++j) if (pg_wire_read_u64(file, &r->data[j])) return NULL;
		size_t first = 0;
		switch (r->kind) {
		case APPLICATION:
			if (status != PG_SYNTHESIS_PENDING || n < 11
				|| r->data[9] > limit || r->data[10] > r->data[9]
				|| r->data[10] > (SIZE_MAX - 11) / 2 || n != 11 + 2 * r->data[10]) return NULL;
			if (r->data[0] != 0 && r->data[0] != 2 && r->data[0] != APPLICATION_RULE_READY) return NULL;
			if (!r->data[0]) {
				for (size_t j = 1; j < n; ++j) if (r->data[j]) return NULL;
			} else if (!r->data[1]) {
				if (r->data[0] != APPLICATION_RULE_READY || !r->data[4] || !r->data[5]
					|| r->data[2] || r->data[3] || r->data[6] || r->data[7]
					|| r->data[8] || r->data[9] || r->data[10]) return NULL;
			} else if (!r->data[3] || !r->data[4]
				|| (r->data[0] == APPLICATION_RULE_READY && !r->data[5])) return NULL;
			if ((!r->data[6]) != (!r->data[7]) || (r->data[8] && !r->data[6])) return NULL;
			for (size_t j = 1; j < n; ++j)
				if (j != 9 && j != 10 && r->data[j] > jobs) return NULL;
			for (size_t j = 11; j < n; ++j) if (!r->data[j]) return NULL;
			first = (size_t)n;
			break;
		case MODULE:
			if (n && n != 3) return NULL;
			if (n && (!r->data[0] || r->data[0] > jobs || !r->data[2] || r->data[2] > jobs)) return NULL;
			first = (size_t)n;
			break;
		case REFERENCE:
			if (n != 2 || (r->data[0] && !r->data[1])) return NULL;
			break;
		case CLASSIFIER:
			if (!n || r->data[0] > (frontiers ? 4u : 2u) || (!r->data[0] && status == PG_SYNTHESIS_DONE)) return NULL;
			if (r->data[0] && status != PG_SYNTHESIS_DONE) return NULL;
			if (r->data[0] == 3) {
				struct pg_occurrence_input *input;
				if (n != 2 || !r->data[1] || !typing || !codec
					|| pg_occurrence_type_pending_read(file, typing, limit, names, codec, owner,
						&r->scopes, &input)) return NULL;
				r->input = input;
			} else if (r->data[0] == 4) {
				if (n != 2 || r->data[1] >= i) return NULL;
				const struct source_record *previous = &c->records[r->data[1]];
				if (previous->kind != CLASSIFIER || previous->data[0] != 3 || !previous->input) return NULL;
				r->input = previous->input; r->scopes = previous->scopes;
			} else if (n != 1) return NULL;
			first = (size_t)n;
			break;
		default: if (n != 1) return NULL; break;
		}
		for (size_t j = first; j < n; ++j) if (r->data[j] > jobs) return NULL;
	}
	return c;
}

const struct pg_artifact_source *pg_artifact_source_read(FILE *file, struct pg_graph *storage, size_t limit)
{
	return read_source(file, storage, NULL, limit, 0, NULL, NULL);
}

const struct pg_artifact_source *pg_artifact_source_read_with(FILE *file, struct pg_typing *typing,
	size_t limit, size_t names, const struct pg_graph_codec *codec, void *owner)
{
	return typing ? read_source(file, typing->graph, typing, limit, names, codec, owner) : NULL;
}

const struct pg_occurrence_input *pg_artifact_source_query_frontier(
	const struct pg_artifact_source *c, size_t slot, const struct pg_scope *const **scopes,
	uint64_t *steps)
{
	if (!c || !scopes || !steps) return NULL;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->job != slot || r->kind != CLASSIFIER || r->data[0] < 3) continue;
		*scopes = r->scopes;
		*steps = r->data[0] == 3 ? r->data[1] : c->records[r->data[1]].data[1];
		return r->input;
	}
	return NULL;
}

static struct pg_synthesis_job *resolve(struct pg_synthesis_job *const *jobs, uint64_t slot)
{
	return slot ? jobs[slot - 1] : NULL;
}

static int mapping_valid(const struct pg_synthesis *s, const struct pg_artifact_source *c,
	size_t count, struct pg_synthesis_job *const *jobs)
{
	if (!s || !c || count != c->job_count || !jobs) return 0;
	for (size_t i = 0; i < count; ++i)
		if (!pg_synthesis_input_owned(s,
			(struct pg_synthesis_input){.pending = pg_synthesis_pending(jobs[i])})) return 0;
	for (size_t i = 0; i < c->count; ++i)
		if (kind(s, jobs[c->records[i].job]) != (int)c->records[i].kind) return 0;
	return 1;
}

static int attach_application(struct pg_synthesis *synthesis, const struct source_record *record,
	struct pg_synthesis_job *const *jobs)
{
	const uint64_t *data = record->data;
	struct pg_synthesis_job *job = jobs[record->job];
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	if (pg_synthesis_source_input(synthesis, job, &scope, &syntax)) return -1;
	struct source_application_work cursor = {.stage = (unsigned)data[0], .left = resolve(jobs, data[1])};
	cursor.application = (struct application_state){
		.context = data[2] ? (struct pg_synthesis_input){.pending = pg_synthesis_pending(resolve(jobs, data[2]))}
			: data[0] && data[1] ? scope->context : (struct pg_synthesis_input){0},
		.callee = resolve(jobs, data[3]), .argument = resolve(jobs, data[4]),
		.tail = resolve(jobs, data[5]), .constraint_source = resolve(jobs, data[6]),
		.constraint_type = resolve(jobs, data[7]), .constraint_check = resolve(jobs, data[8]),
		.binding_count = (size_t)data[9]};
	struct pg_graph scratch = {0};
	size_t count = (size_t)data[10];
	struct pg_synthesis_sequence_frame *frames = pg_wire_array(&scratch, count, sizeof(*frames));
	if (!frames) { pg_graph_destroy(&scratch); return -1; }
	for (size_t i = 0; i < count; ++i) {
		frames[i] = (struct pg_synthesis_sequence_frame){.input = resolve(jobs, data[11 + i * 2]),
			.context = {.pending = pg_synthesis_pending(resolve(jobs, data[12 + i * 2]))},
			.parent = i + 1 < count ? &frames[i + 1] : NULL, .binds = 1};
	}
	cursor.application.frames = count ? frames : NULL;
	int result = pg_synthesis_source_application_resume(synthesis, job, &cursor);
	pg_graph_destroy(&scratch);
	return result;
}

int pg_artifact_source_prepare(struct pg_synthesis *s, const struct pg_artifact_source *c,
	size_t count, struct pg_synthesis_job *const *jobs)
{
	if (!mapping_valid(s, c, count, jobs)) return -1;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		struct pg_synthesis_job *job = jobs[r->job];
		if (job->status != PG_SYNTHESIS_PENDING) return -1;
		if (r->kind == MODULE && r->count && pg_synthesis_prepare_module(s, job) != resolve(jobs, r->data[0])) return -1;
	}
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->kind != DEFINITION) continue;
		struct pg_synthesis_job *child = resolve(jobs, r->data[0]);
		if (!child) continue;
		struct pg_synthesis_job *current;
		if (pg_synthesis_definition_body(s, jobs[r->job], &current)) return -1;
		/* Source I/O can already reconnect this exact lexical body. Validate
		 * that single owner instead of attempting a second attachment. */
		if (current ? current != child : pg_synthesis_definition_resume_body(s, jobs[r->job], child)) return -1;
	}
	return 0;
}

size_t pg_artifact_source_validation(const struct pg_artifact_source *c, size_t *slots)
{
	if (!c || !slots) return 0;
	size_t count = 0;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->status == PG_SYNTHESIS_DONE) slots[count++] = r->job;
	}
	return count;
}

size_t pg_artifact_source_query_validation(const struct pg_artifact_source *c, size_t *slots)
{
	if (!c || !slots) return 0;
	size_t count = 0;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->kind == CLASSIFIER && r->data[0] == 2) slots[count++] = r->job;
	}
	return count;
}

static int attach_source(struct pg_synthesis *s, const struct pg_artifact_source *c,
	size_t count, struct pg_synthesis_job *const *jobs, int reuse)
{
	if (!mapping_valid(s, c, count, jobs)) return -1;
	for (size_t i = 0; i < c->count; ++i)
		if (jobs[c->records[i].job]->status != c->records[i].status) return -1;
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->kind == APPLICATION) {
			if (!reuse || attach_application(s, r, jobs)) return -1;
			continue;
		}
		if (r->kind == CLASSIFIER) {
			struct pg_typed_query *query;
			if (pg_synthesis_classifier_formation_frontier(s, jobs[r->job], &query) != 1) return -1;
			if (!r->data[0]) { if (query) return -1; }
			else if (r->data[0] == 3) {
				if (!reuse || !r->input || !pg_typed_query_owned_by(query, s->typing)
					|| pg_classifier_resume(query, (struct pg_occurrence_input *)r->input, r->data[1])) return -1;
			}
			else if (r->data[0] == 4) {
				if (!reuse || !pg_typed_query_owned_by(query, s->typing) || query->status
					|| pg_classifier_pending_input(query) != r->input
					|| query->steps != c->records[r->data[1]].data[1]) return -1;
			}
			else if (!pg_typed_query_owned_by(query, s->typing)
				|| (r->data[0] == 1 && (query->status || query->steps || query->dependency || query->waiting))
				|| (r->data[0] == 2 && !pg_typed_query_result(query))) return -1;
			continue;
		}
		if (r->kind == BINDING) {
			struct pg_synthesis_job *current;
			if (pg_synthesis_binding_domain(s, jobs[r->job], &current) != 1
				|| current != resolve(jobs, r->data[0])) return -1;
			continue;
		}
		if (r->kind == DOMAIN) {
			struct pg_synthesis_job *current;
			/* Ordinary validation reconstructs this discovery edge. An imported
			 * ordinal never makes a type input checked or marks its owner DONE. */
			if (pg_synthesis_domain_frontier(s, jobs[r->job], &current) != 1
				|| current != resolve(jobs, r->data[0])) return -1;
			continue;
		}
		if (r->kind == LAMBDA) {
			struct pg_synthesis_job *rule = resolve(jobs, r->data[0]);
			if (r->status == PG_SYNTHESIS_PENDING) {
				if (pg_synthesis_lambda_resume(s, jobs[r->job], rule)) return -1;
			} else {
				struct pg_synthesis_job *current;
				if (pg_synthesis_lambda_frontier(s, jobs[r->job], &current) != 1 || current != rule) return -1;
			}
			continue;
		}
		if (r->kind == REFERENCE) {
			struct pg_reference_frontier view = {{.pending = pg_synthesis_pending(resolve(jobs, r->data[0]))}, resolve(jobs, r->data[1])};
			if (r->status == PG_SYNTHESIS_PENDING) {
				if (pg_synthesis_reference_resume(s, jobs[r->job], &view)) return -1;
			} else {
				struct pg_reference_frontier current;
				if (pg_synthesis_reference_frontier(s, jobs[r->job], &current) != 1
					|| current.value.checked != view.value.checked || current.value.pending != view.value.pending
					|| current.rule != view.rule) return -1;
			}
			continue;
		}
		if (r->kind != MODULE || !r->count || r->status != PG_SYNTHESIS_PENDING) continue;
		struct pg_module_frontier view = {r->data[1], resolve(jobs, r->data[2])};
		if (pg_synthesis_module_resume(s, jobs[r->job], &view)) return -1;
	}
	/* Body selection depends on the restored source input's polarity. Restore
	 * source edges first, then reuse the ordinary adaptation factory; saved
	 * ordinals must identify that exact local rule, never authorize checking. */
	for (size_t i = 0; i < c->count; ++i) {
		const struct source_record *r = &c->records[i];
		if (r->kind != BODY) continue;
		struct pg_synthesis_input current;
		struct pg_synthesis_job *job = jobs[r->job], *rule = resolve(jobs, r->data[0]);
		if (pg_synthesis_body_frontier(s, job, &current) != 1 || current.checked) return -1;
		if (rule && !current.pending && r->status == PG_SYNTHESIS_PENDING) {
			if (pg_synthesis_body_resume(s, job)
				|| pg_synthesis_body_frontier(s, job, &current) != 1) return -1;
		}
		if (current.checked || pg_pending_job(current.pending) != rule) return -1;
	}
	return 0;
}

int pg_artifact_source_attach(struct pg_synthesis *s, const struct pg_artifact_source *c,
	size_t count, struct pg_synthesis_job *const *jobs)
{
	return attach_source(s, c, count, jobs, 0);
}

int pg_artifact_source_attach_with_frontiers(struct pg_synthesis *s, const struct pg_artifact_source *c,
	size_t count, struct pg_synthesis_job *const *jobs)
{
	return attach_source(s, c, count, jobs, 1);
}

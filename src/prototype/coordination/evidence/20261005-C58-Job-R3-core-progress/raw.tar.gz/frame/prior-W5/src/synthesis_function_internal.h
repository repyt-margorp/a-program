#ifndef __SYNTHESIS_FUNCTION_INTERNAL_H__
#define __SYNTHESIS_FUNCTION_INTERNAL_H__

#include "synthesis_source.h"
#include "synthesis_schema.h"

/* Actual application owner state, shared with its existing Source transport.
 * These are necessary unfinished choices/edges, not a second recipe or evidence
 * graph. Constructor and sequencing owners remain explicit until transported. */
struct application_state {
	struct pg_synthesis_input context;
	struct pg_synthesis_job *callee, *argument, *tail;
	struct pg_synthesis_job *constraint_source, *constraint_type, *constraint_check;
	struct constructor_application *constructor;
	struct constructor_spine *spine;
	const struct pg_synthesis_sequence_frame *frames;
	size_t binding_count;
};

struct constructor_application {
	struct constructor_callable input, output;
	struct pg_synthesis_input context;
	struct pg_synthesis_job *function;
	struct pg_pending *instance;
	size_t next;
};

struct constructor_spine {
	struct constructor_application specialization;
	size_t count, next;
	struct pg_synthesis_job **arguments;
};

struct source_application_work {
	struct pg_synthesis_job *left;
	const struct constructor_callable *callable;
	unsigned stage;
	struct application_state application;
};

enum { APPLICATION_RULE_READY = 6, APPLICATION_FAMILY_DOMAIN };

/* Borrow only an exact local canonical application's actual private cursor.
 * No allocation, dispatch, result copying or admission occurs. */
const struct source_application_work *pg_synthesis_source_application_cursor(
	const struct pg_synthesis *, const struct pg_synthesis_job *);
/* Unpublished, explicitly authenticated continuation reuse only. Ordinals
 * have already been relocated to canonical local Jobs. This checks membership
 * and the original Source key, owns sequencing frames, and imports no results
 * or completion flags. Constructor/callable/spine and a started family-domain
 * typed query still reject; their actual owners need transport first. */
int pg_synthesis_source_application_resume(struct pg_synthesis *,
	struct pg_synthesis_job *, const struct source_application_work *);

#endif

import difflib
import hashlib
import json
from pathlib import Path
import shutil

base = Path(__file__).resolve().parent
tested = base / "history/trial1-inputs"
parent_base = base.parent / "job_evidence_query_frontier"
parent = parent_base / "history/trial19-inputs"
r2 = base.parent / "epochs/job_evidence_native_query_frontier_r2"
epoch = base.parent / "epochs/job_evidence_native_application_frames_r3"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(root, manifest):
    for line in manifest.read_text().splitlines():
        expected, relative = line.split("  ", 1)
        assert digest(root / relative) == expected, relative


def write(name, data):
    path = epoch / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n")


verify(tested, base / "trial1-inputs.sha256")
verify(parent, parent_base / "trial19-inputs.sha256")
verify(r2, r2 / "manifest.sha256")
assert digest(r2 / "manifest.sha256") == "352efeb6355cb40d7f491ec5aaa682a0cbf6d42a2f86728fe5971cfb7355b5f5"
broad = json.loads((base / "trial1-broad/terminal.json").read_text())
focused = json.loads((base / "trial1-owner/terminal.json").read_text())
final = json.loads((base / "reviews/frame-deletion-qualified-local.json").read_text())
assert broad["returncode"] == 0 and broad["all675_inputs_exact_after"]
assert len(focused["records"]) == 4 and all(r["returncode"] == 0 for r in focused["records"])
assert final["matched_image_equal_count"] == 52 and not final["public_tsv_equal"]
epoch.mkdir()
selected = []
for line in (base / "trial1-code.sha256").read_text().splitlines():
    _, relative = line.split("  ", 1)
    old = parent / relative
    if not old.is_file() or old.read_bytes() != (tested / relative).read_bytes():
        selected.append(relative)
assert len(selected) == 6
selected += ["controls/application_owner_checkpoint.c", "controls/query_frontier.mk"]
mapping, deltas, patch = [], [], []
for relative in selected:
    old = parent / relative
    source, target = tested / relative, epoch / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)
    before = old.read_bytes() if old.is_file() else b""
    delta = list(difflib.unified_diff(before.decode().splitlines(keepends=True),
        source.read_text().splitlines(keepends=True), fromfile="a/" + relative, tofile="b/" + relative))
    patch.extend(delta)
    mapping.append({"snapshot": relative, "overlay": relative, "sha256": digest(source),
        "parent_sha256": digest(old) if old.is_file() else None})
    deltas.append({"file": relative,
        "added": sum(x.startswith("+") and not x.startswith("+++") for x in delta),
        "deleted": sum(x.startswith("-") and not x.startswith("---") for x in delta)})
(epoch / "applied.diff").write_text("".join(patch))
for category, prefix in (("runtime", "src/"), ("test", "controls/")):
    rows = [r for r in deltas if r["file"].startswith(prefix)]
    write(category + "-delta.json", {"files": rows, "added": sum(r["added"] for r in rows),
        "deleted": sum(r["deleted"] for r in rows)})
write("projection.json", {"parent_freeze": str(r2), "parent_manifest_sha256": digest(r2 / "manifest.sha256"),
    "parent_runtime129": digest(parent_base / "trial19-code.sha256"),
    "candidate_runtime130": digest(base / "trial1-code.sha256"), "mapping": mapping,
    "publication": "Prototype frozen snapshots only; Merge exact publication. applied.diff is review-only; no live staging.",
    "exclusions": "Separate application W5, structure/schema frontier trials, E25/E26/E27 and mutable canonical code"})
for source, name in ((base / "trial1-code.sha256", "runtime130.sha256"),
        (base / "trial1-inputs.sha256", "inputs675.sha256"),
        (base / "trial1-broad/terminal.json", "broad-terminal.json"),
        (base / "trial1-final-qualification/records.json", "affected-san-public-records.json"),
        (base / "trial1-final-qualification/query-public/partitions.tsv", "query-strict-public.tsv"),
        (base / "trial1-final-qualification/frame-public/partitions.tsv", "frame-strict-public.tsv")):
    shutil.copyfile(source, epoch / name)
write("focused-records.json", {k: v for k, v in focused.items() if k != "pins"})
write("verification-summary.json", {k: v for k, v in final.items() if k != "all52_images"})
write("public-image-comparison.json", final["all52_images"])
raw = {}
for directory in (base / "trial1-owner", base / "trial1-broad", base / "trial1-final-qualification"):
    for path in directory.rglob("*"):
        if path.is_file() and "temporary" not in path.parts:
            raw[str(path)] = digest(path)
for label in ("o2", "san"):
    binary = base / ("build-trial1-owner-" + label) / "typed_query_checkpoint"
    raw[str(binary)] = digest(binary)
for record in final["affected_san_and_actual_recipes"]:
    if "binary_sha256" not in record:
        continue
    argv = record["argv"]
    binary = Path(argv[2] if record["label"].endswith("strict-public") else
        argv[0] if not record["label"].endswith("-san") else argv[-1])
    assert digest(binary) == record["binary_sha256"]
    raw[str(binary)] = record["binary_sha256"]
raw[str(base / "qualify_trial1.py")] = digest(base / "qualify_trial1.py")
raw[str(base / "reviews/frame-deletion-qualified-local.json")] = digest(base / "reviews/frame-deletion-qualified-local.json")
application = base.parent / "job_evidence_application_frontier"
history = []
for number in range(1, 9):
    manifest = application / f"trial{number}-inputs.sha256"
    if manifest.is_file():
        raw[str(manifest)] = digest(manifest)
        history.append({"trial": number, "input_manifest": str(manifest), "sha256": digest(manifest)})
write("history.json", {"original_application_trials": history,
    "preserved_failures": ["Unsuspended TERMINATION_FORM fixture4/5 SIGABRT; explicit quote correction, no runtime waiver",
        "Missing control-wrapper link build2", "Application-only cold Program cut1 Source export134",
        "Original actual strict three failures, historic1921 then query1915 now candidate1912",
        "Frame final driver all40 TSV equality assertion1; actual dispatch reductions require distinct fuel columns"],
    "application_parent_focused": "W5 actual84/210/112 versus W6 frame-deletion84/207/112",
    "candidate_focused": "406 cuts/621 restorations/15 canonical tails/111 intrinsic cursors; each actual remaining candidate budget exact",
    "not_claimed": "Whole-Program resume, current joint gates, equal parent fuel, time/peak or Goal completion"})
(epoch / "external-evidence.sha256").write_text("".join(f"{value}  {name}\n" for name, value in sorted(raw.items())))
write("inputs.json", {"candidate_overlay": str(tested), "input675_sha256": digest(base / "trial1-inputs.sha256"),
    "parent_overlay": str(parent), "parent_input671_sha256": digest(parent_base / "trial19-inputs.sha256"),
    "ordinary_sorted": str(base.parent / "job_evidence_native_frontier/sorted-result-controls/inputs/manifest.sha256"),
    "raw_all_children_reaped": True})
(epoch / "report.md").write_text("""# Native application frame deletion r3

This prototype increment extends the exact native query r2. Application bind
frames duplicate existing canonical CONTEXT_EXTEND / RETURN_CONTENT / classifier
input links. Their separate allocation and copied linked chain are deleted.
The application borrows the exact existing context owner, verifies each immutable
parent/computation and its lexical boundary, and unwinds through those owners.
Transport retains one context ordinal; flattened decoding scratch and owned frame
copies are deleted. No index, owner/state fields, proof checker or graph is added.

Actual Application/Constructor/Spine private layout moves unchanged to an internal
header so the existing Source transport can borrow the application cursor. This
supports virgin pending stages0/2/6, open constraints and canonical frame tails.
Copied/foreign owners, started constructor/spine/callable/family and advanced
application stages refuse. Completed reusable results and escaped pointers remain
owned by their existing stores. APGSRCW6 supersedes private unpublished W5; native
r1/r2 format retirement remains separately documented. Loading remains inert;
explicit authentic frontier reuse is distinct from local typing acceptance.

Exact130 runtime/675 inputs: unskipped serial O2 acceptance0; seven affected SAN
gates0; focused O2/SAN four build/run records0. Candidate406 cuts/621 restorations,
15 frame tails and111 intrinsic cursors preserve ordinary result bytes and exact
remaining charged fuel. Parent/new fixture totals84/84,210/207,112/112 explicitly
differ. Imported ordinary-result Sorted is DONE955410/955248. Public completion
is1915/1912. Both actual strict public recipes FAIL1 on the same original three
classes:1000:1000,1600:1600,completed+0. All52 images equal after explicit budget
filename correspondence; the full TSVs differ in actual charged fuel. Original
equal-TSV assertion failure is preserved, not relabelled as a runtime pass.

Whole-Program structural/declaration/schema/qualified/Match closure and original
strict3 remain open. Separate schema trials are excluded. Current-producer joint
checks, publication/Main, net time and peak memory are pending; final layout or
dispatch counts do not establish peak RSS. No accepted code or Git metadata edits.

Full frozen snapshots are authoritative; applied.diff is review-only. The durable
manifest lists only publication files; external hashes pin raw evidence without
copying build logs or full plans. Merge owns exact task/current integration.
""")
manifest = epoch / "manifest.sha256"
manifest.write_text("".join(f"{digest(p)}  {p.relative_to(epoch)}\n"
    for p in sorted(epoch.rglob("*")) if p.is_file() and p != manifest))
verify(epoch, manifest)
for path, expected in raw.items():
    assert digest(Path(path)) == expected, path
print(json.dumps({"epoch": str(epoch), "manifest_sha256": digest(manifest),
    "files": len(manifest.read_text().splitlines()), "external_evidence_records": len(raw)}))

# Native Source closure r4

This increment extends exact native application frame deletion r3. It reconnects
existing Source, direct-rule and native structural/schema owners through their
ordinary factories and the one scheduler. No second codec/evidence authority,
index, checker or retained graph is added. Generic structural resume shares the
ordinary factory selector restricted to already canonical Jobs. A declaration
borrows its actual declared Universe fact from the locally checked Self Scope;
there is no copied Domain proof record. Existing Source producer transport keeps
the untouched schema's actual scope/syntax key in its seven-word record.

Loading remains inert and untrusted. Canonical lexical-index ancestry guards raw,
copied and returned-frame scope pointers before dereference. Explicit authentic
cursor reuse still needs local typed premises; it does not skip their checking.
The actual Self rule closure and lexical forwarding owner use ordinary charged
Solve. Zero/one-cap validation stays pending and continues the same cursor. One
total B, v<=min(B,R) and useful<=B-v are checked. No saved DONE flag is restored.
APGSRC-G seeds and private APGSRCW8 declaration records are deliberate new shapes;
ordinary images keep their earlier bytes when these shapes are absent.

Fresh destroyed-producer cold cuts2/3/4 pass O2/SAN, including decoded scratch
destruction, inert resave, zero fuel, original Scope/binder identity and ordinary
result bytes. Validation0/4/4 plus useful82/81/80 preserves the producer's84 total
dispatches. Copy/foreign/raw/escaped-scope/wrong-child/duplicate controls reject
without count/ready/step/admission mutation. Earlier incorrect cut3 count and
validation-queue assertions are frozen; actual child discovery uses the owner
getter, not a cut-number assumption.

Exact runtime130 a8700490: full unskipped serial O2 acceptance0; seven affected SAN
gates0. New bounded-validation control separately passes O2/SAN on the same runtime;
only this unused broad-control file differs between678 input projections. Imported
ordinary Sorted is DONE955248 in both r3/new. Both actual strict public recipes
FAIL1 on original1000:1000,1600:1600,completed1912:0; all40 TSV/all52 images exact.
No expected-pass waiver or general public continuation/current-joint/cost claim.

Later schema/telescope/constructor/qualified/Match and endpoint/WHNF states remain
unsupported until their actual progress is retained. The constructor spine's
argument array remains a real cursor: forward consumption and implicit-index
recovery use it over the backward source AST. No array deletion or extra traversal
is claimed. Scope membership scanning and new transport/state costs need joint
matched timing/peak verification; no net gain follows from layout counts.

Exact frozen full snapshots are authoritative; applied.diff is review-only.
The durable manifest lists only publication files; external evidence pins raw
history without copying logs/plans. Merge owns task/current publication. No
accepted, Performance eval/readback or shared Git changes; overall Goal remains open.

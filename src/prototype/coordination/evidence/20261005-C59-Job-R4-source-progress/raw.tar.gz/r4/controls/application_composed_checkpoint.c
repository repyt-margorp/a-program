#include "program.h"
#include "source_io.h"
#include "synthesis_source.h"
#include "synthesis_schema.h"
#include "synthesis_function_internal.h"
#include "derivation_io.h"
#include "artifact/source.h"
#include "artifact/derivation.h"
#include "artifact/schedule.h"
#include "wire.h"
#include "../tests/native_admissions.h"
#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct checkpoint {
	const struct pg_artifact_source *source;
	const struct pg_artifact_derivations *rules;
	const struct pg_artifact_schedule *schedule;
	const struct pg_derivation_input *const *headers;
	size_t header_count;
};

static int solving;
void __real_pg_synthesis_advance(struct pg_synthesis *, uint64_t);
void __wrap_pg_synthesis_advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	assert(!fuel || solving);
	__real_pg_synthesis_advance(synthesis, fuel);
}

static void advance(struct pg_synthesis *synthesis, uint64_t fuel)
{
	solving = 1;
	pg_synthesis_advance(synthesis, fuel);
	solving = 0;
}

static struct pg_program *start(void)
{
	const char *text = "v := (\\x : @ => x) (@{unit:*;});";
	struct pg_program *program = pg_program_allocate_empty(PG_DEFINITION_EXPLICIT_THUNK);
	assert(program);
	pg_parser_init(&program->parser, &program->graph, text, strlen(text));
	const struct pg_syntax *syntax = pg_parser_program(&program->parser);
	assert(syntax && !program->parser.error && syntax->item_count == 1);
	program->root = pg_synthesis_request(&program->synthesis, program->scope, syntax->items[0].expression);
	assert(program->root);
	return program;
}

static uint64_t finish(struct pg_program *program)
{
	while (program->synthesis.ready && pg_synthesis_status(program->root) == PG_SYNTHESIS_PENDING) {
		advance(&program->synthesis, 1);
		assert(program->synthesis.steps < 10000);
	}
	assert(pg_synthesis_result(program->root));
	return program->synthesis.steps;
}

/* This fixture's ordinary Lambda factory supplies native keys. It introduces
 * no codec, checker or retained mapping: all arrays below are test scratch. */
static void factory_closure(struct pg_program *program, struct pg_synthesis_job **sources,
	struct pg_synthesis_job **external, struct pg_synthesis_job **owners, size_t source_count, int structure_started)
{
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(s, sources[1], &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(s, scope, syntax), *domain = NULL;
	assert(binding && pg_synthesis_binding_domain(s, binding, &domain) == 1 && domain);
	struct pg_synthesis_job *body = pg_synthesis_request(s, pg_synthesis_binding_scope(binding), syntax->right);
	assert(body == sources[3]);
	struct pg_synthesis_job *lambda = pg_synthesis_lambda_body(s,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(binding)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)});
	assert(lambda);
	struct pg_synthesis_job *adapter = pg_pending_job(pg_synthesis_rule_input(s, lambda, 1).pending);
	struct pg_synthesis_job *pi = pg_pending_job(pg_synthesis_rule_input(s, lambda, 0).pending);
	struct pg_synthesis_job *classifier = pg_pending_job(pg_synthesis_rule_input(s, pi, 1).pending);
	assert(adapter && classifier);
	for (size_t i = 0; i < 4; ++i) external[i] = sources[i];
	struct pg_synthesis_structure shape = pg_synthesis_classifier_structure(s, sources[1]);
	assert(shape.pending && !shape.term);
	external[4] = shape.pending;
	external[5] = binding; external[6] = domain; external[7] = adapter; external[8] = classifier;
	owners[0] = sources[0]; owners[1] = sources[1]; owners[2] = sources[3];
	owners[3] = binding; owners[4] = domain; owners[5] = adapter; owners[6] = classifier;
	owners[7] = shape.pending;
	owners[8] = sources[2];
	if (source_count == 5) external[9] = sources[4];
	if (structure_started) {
		shape = pg_synthesis_classifier_structure(s, lambda);
		assert(shape.pending && !shape.term);
		external[source_count + 5] = shape.pending;
	}
}

static void validation_closure(struct pg_synthesis *s, struct pg_synthesis_job *job,
	size_t count, struct pg_synthesis_job **jobs, unsigned char *seen,
	size_t *ready, size_t *ordinals)
{
	size_t slot = 0;
	while (slot < count && jobs[slot] != job) ++slot;
	assert(slot < count);
	if (seen[slot] || job->status == PG_SYNTHESIS_DONE) return;
	seen[slot] = 1;
	const struct pg_derivation_input *input = pg_synthesis_plain_derivation(job);
	size_t arity = input ? input->count : 1;
	for (size_t i = 0; i < arity; ++i) {
		struct pg_synthesis_input premise = input ? pg_synthesis_rule_input(s, job, i)
			: pg_synthesis_scope_context_input(job);
		if (premise.pending) validation_closure(s, pg_pending_job(premise.pending),
			count, jobs, seen, ready, ordinals);
		else assert(pg_evidence_owned_by(premise.checked, s->typing));
	}
	assert(*ready < count);
	ordinals[(*ready)++] = slot;
}

/* Imported Self is an ordinary unaccepted CONTEXT_EXTEND request. Validate it
 * under the same total B and cap R before borrowing its declared typed owner. */
static uint64_t validate_self(struct pg_program *program, struct pg_synthesis_job *schema,
	uint64_t *budget, uint64_t *cap)
{
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(pg_synthesis_schema_seed_input(s, schema, &scope, &syntax) == 1);
	struct pg_synthesis_job *self = pg_pending_job(scope->context.pending);
	assert(self && !scope->context.checked && !pg_synthesis_result(self));
	size_t count = s->jobs.count, next = 0, ready = 0;
	struct pg_synthesis_job **jobs = calloc(count, sizeof(*jobs));
	unsigned char *seen = calloc(count, 1);
	size_t *ordinals = calloc(count, sizeof(*ordinals));
	assert(jobs && seen && ordinals);
	for (size_t i = 0; i < s->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = s->jobs.buckets[i]; entry; entry = entry->next) {
			assert(next < count);
			jobs[next] = (void *)entry;
			++next;
		}
	assert(next == count);
	validation_closure(s, self, count, jobs, seen, &ready, ordinals);
	const struct pg_artifact_schedule *validation = pg_artifact_schedule_ready(&program->graph, count, ready, ordinals);
	assert(validation && !pg_artifact_schedule_attach(s, validation, count, jobs));
	uint64_t before = s->steps, available = *budget < *cap ? *budget : *cap;
	pg_synthesis_advance(s, 0);
	assert(s->steps == before && !pg_synthesis_result(self));
	while (self->status == PG_SYNTHESIS_PENDING && s->ready && s->steps - before < available) advance(s, 1);
	uint64_t spent = s->steps - before;
	assert(spent <= available && spent <= *budget && spent <= *cap);
	assert(self->status == PG_SYNTHESIS_PENDING || (self->status == PG_SYNTHESIS_DONE && pg_synthesis_result(self)));
	*budget -= spent; *cap -= spent;
	free(jobs); free(seen); free(ordinals);
	return spent;
}

static int write_extra(FILE *file, const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	const struct checkpoint *checkpoint = opaque;
	return pg_artifact_source_write_with(file, checkpoint->source, codec, objects)
		|| pg_artifact_derivations_write(file, checkpoint->rules)
		|| pg_derivation_headers_write(file, checkpoint->header_count, checkpoint->headers, codec, objects)
		|| pg_artifact_schedule_save(file, checkpoint->schedule);
}

static int read_extra(FILE *file, struct pg_typing *typing, size_t limit, size_t names,
	const struct pg_graph_codec *codec, void *objects, void *opaque)
{
	struct checkpoint *checkpoint = opaque;
	checkpoint->source = pg_artifact_source_read_with(file, typing, limit, names, codec, objects);
	checkpoint->rules = pg_artifact_derivations_read(file, typing->graph, limit);
	if (!checkpoint->source || !checkpoint->rules || pg_derivation_headers_read(file,
		typing, limit, names, codec, objects, &checkpoint->header_count, &checkpoint->headers)) return -1;
	checkpoint->schedule = pg_artifact_schedule_read(file, typing->graph, limit);
	return !checkpoint->schedule;
}

static void equal(FILE *left, FILE *right)
{
	rewind(left); rewind(right);
	int a, b;
	do { a = fgetc(left); b = fgetc(right); assert(a == b); } while (a != EOF);
	assert(!ferror(left) && !ferror(right));
}

static void check(uint64_t cut)
{
	struct pg_program *program = start();
	uint64_t total = finish(program);
	FILE *expected = tmpfile();
	struct pg_synthesis_input root = {.pending = pg_synthesis_pending(program->root)};
	assert(expected && !pg_sources_write(expected, &program->synthesis, 1, &root));
	pg_program_destroy(program);
	program = start();
	advance(&program->synthesis, cut);
	struct pg_synthesis *synthesis = &program->synthesis;
	const struct source_application_work *cursor = pg_synthesis_source_application_cursor(synthesis, program->root);
	assert(cursor && cursor->left && !cursor->application.tail);
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(synthesis, program->root, &scope, &syntax));
	struct pg_synthesis_job *sources[5] = {program->root, cursor->left,
		pg_synthesis_request(synthesis, scope, syntax->right)};
	struct pg_synthesis_structure shape = pg_synthesis_classifier_structure(synthesis, cursor->left);
	assert(shape.pending && !shape.term);
	assert(!pg_synthesis_source_input(synthesis, cursor->left, &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(synthesis, scope, syntax);
	sources[3] = pg_synthesis_request(synthesis, pg_synthesis_binding_scope(binding), syntax->right);
	struct pg_synthesis_job *schema = NULL;
	assert(pg_synthesis_declaration_frontier(synthesis, sources[2], &schema) == 1);
	size_t source_count = 4 + (schema != NULL);
	sources[4] = schema;
	struct pg_synthesis_job *structure_child = NULL;
	assert(pg_synthesis_structure_frontier(synthesis, shape.pending, &structure_child) == 1);
	int structure_started = structure_child != NULL;
	struct pg_synthesis_job *external[11], *owners[9];
	size_t external_count = source_count + 5 + structure_started;
	size_t count = synthesis->jobs.count;
	factory_closure(program, sources, external, owners, source_count, structure_started);
	assert(!structure_started || external[source_count + 5] == structure_child);
	assert(count == external_count + 3 && synthesis->jobs.count == count && synthesis->steps == cut);
	struct pg_synthesis_job *rules[3];
	size_t rule_count = 0;
	for (size_t i = 0; i < synthesis->jobs.capacity; ++i)
		for (struct pg_index_entry *entry = synthesis->jobs.buckets[i]; entry; entry = entry->next) {
			struct pg_synthesis_job *job = (void *)entry;
			if (!pg_synthesis_plain_derivation(job)) continue;
			assert(rule_count < 3);
			rules[rule_count++] = job;
		}
	assert(rule_count == 3);
	const struct pg_evidence *context = pg_synthesis_scope_context(program->scope);
	struct pg_artifact_derivation_dependencies dependencies = {
		.job_count = external_count, .jobs = external, .checked_count = 1, .checked = &context};
	struct pg_synthesis_job **jobs;
	struct checkpoint saved = {0};
	saved.rules = pg_artifact_derivations_capture_with_dependencies(&program->graph,
		synthesis, rule_count, rules, &dependencies, &jobs);
	assert(saved.rules && pg_artifact_derivations_job_count(saved.rules) == count);
	saved.headers = pg_artifact_derivations_inputs(saved.rules, &saved.header_count);
	saved.source = pg_artifact_source_capture(&program->graph, synthesis, count, jobs, 9, owners);
	saved.schedule = pg_artifact_schedule_capture(&program->graph, synthesis, count, jobs);
	assert(saved.source && saved.schedule);
	FILE *file = tmpfile();
	struct pg_synthesis_input inputs[5];
	for (size_t i = 0; i < source_count; ++i) inputs[i] = (struct pg_synthesis_input){.pending = pg_synthesis_pending(sources[i])};
	assert(file && !pg_sources_write_with(file, synthesis, source_count, inputs, 0, write_extra, &saved));
	assert(synthesis->steps == cut);
	pg_program_destroy(program);
	rewind(file);
	struct checkpoint loaded = {0};
	size_t loaded_count;
	struct pg_synthesis_job *const *restored;
	program = pg_sources_read_with(file, 100000, &loaded_count, &restored, read_extra, &loaded);
	assert(program && loaded_count == source_count && !program->synthesis.steps
		&& native_admissions(&program->typing) == 1 && fgetc(file) == EOF);
	program->root = restored[0];
	for (size_t i = 0; i < source_count; ++i) sources[i] = restored[i];
	factory_closure(program, sources, external, owners, source_count, structure_started);
	FILE *copy = tmpfile();
	for (size_t i = 0; i < source_count; ++i) inputs[i].pending = pg_synthesis_pending(sources[i]);
	assert(copy && !pg_sources_write_with(copy, &program->synthesis, source_count, inputs, 0, write_extra, &loaded));
	equal(file, copy);
	assert(!fclose(copy) && !program->synthesis.steps && native_admissions(&program->typing) == 1);
	uint64_t cap = 16, budget = total - cut + cap, validation = 0;
	if (source_count == 5) {
		assert(pg_synthesis_declaration_resume(&program->synthesis, sources[2], sources[4]));
		assert(!program->synthesis.steps && native_admissions(&program->typing) == 1);
		uint64_t zero_budget = 0, zero_cap = 0, one_budget = 1, one_cap = 1;
		assert(!validate_self(program, sources[4], &zero_budget, &zero_cap));
		assert(!program->synthesis.steps && native_admissions(&program->typing) == 1);
		assert(pg_synthesis_declaration_resume(&program->synthesis, sources[2], sources[4]));
		validation = validate_self(program, sources[4], &one_budget, &one_cap);
		assert(validation == 1 && !one_budget && !one_cap
			&& pg_synthesis_declaration_resume(&program->synthesis, sources[2], sources[4]));
		budget -= validation; cap -= validation;
		validation += validate_self(program, sources[4], &budget, &cap);
		assert(validation && validation <= 16 && program->synthesis.steps == validation);
	}
	context = pg_synthesis_scope_context(program->scope);
	dependencies.checked = &context;
	assert(!pg_artifact_derivations_prepare_with_dependencies(&program->synthesis, loaded.rules,
		loaded.header_count, loaded.headers, &dependencies, &jobs));
	assert(program->synthesis.jobs.count >= count);
	assert(!pg_artifact_source_prepare(&program->synthesis, loaded.source, count, jobs));
	assert(!pg_artifact_derivations_attach(&program->synthesis, loaded.rules, jobs, &dependencies));
	assert(pg_artifact_source_attach(&program->synthesis, loaded.source, count, jobs));
	/* Only this authentic image selects reuse. The import remains inert until
	 * its actual children, cursors and the single ordinary schedule reconnect. */
	assert(!pg_artifact_source_attach_with_frontiers(&program->synthesis, loaded.source, count, jobs));
	assert(!pg_artifact_schedule_attach(&program->synthesis, loaded.schedule, count, jobs));
	assert(program->synthesis.steps == validation);
	pg_synthesis_advance(&program->synthesis, 0);
	assert(program->synthesis.steps == validation);
	uint64_t useful = finish(program) - validation;
	assert(useful == total - cut && useful <= budget);
	root.pending = pg_synthesis_pending(program->root);
	copy = tmpfile();
	assert(copy && !pg_sources_write(copy, &program->synthesis, 1, &root));
	equal(expected, copy);
	assert(!fclose(file) && !fclose(copy) && !fclose(expected));
	pg_program_destroy(program);
	printf("composed-application cut=%" PRIu64 " validation=%" PRIu64 " useful=%" PRIu64 " total=%" PRIu64 " jobs=%zu\n",
		cut, validation, useful, total, count);
}

static void negative(void)
{
	struct pg_program *program = start();
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope;
	const struct pg_syntax *syntax;
	assert(!pg_synthesis_source_input(s, program->root, &scope, &syntax));
	struct pg_synthesis_job *source = pg_synthesis_request(s, scope, syntax->left);
	struct pg_synthesis_job *other = pg_synthesis_request(s, scope, syntax->right);
	assert(!pg_synthesis_source_input(s, source, &scope, &syntax));
	struct pg_synthesis_job *binding = pg_synthesis_binding(s, scope, syntax);
	struct pg_synthesis_job *body = pg_synthesis_request(s, pg_synthesis_binding_scope(binding), syntax->right);
	struct pg_synthesis_job *lambda = pg_synthesis_lambda_body(s,
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(binding)},
		(struct pg_synthesis_input){.pending = pg_synthesis_pending(body)});
	assert(source && other && binding && body && lambda && !pg_synthesis_lambda_resume(s, source, lambda));
	struct pg_synthesis_structure query = pg_synthesis_classifier_structure(s, source);
	struct pg_synthesis_structure expected = pg_synthesis_classifier_structure(s, lambda);
	struct pg_synthesis_structure wrong = pg_synthesis_classifier_structure(s, other);
	assert(query.pending && expected.pending && wrong.pending && expected.pending != wrong.pending);
	size_t count = s->jobs.count;
	struct pg_synthesis_job *ready = s->ready, *left = NULL;
	struct pg_synthesis_job copy = *query.pending;
	assert(pg_synthesis_structure_frontier(s, &copy, &left) == -1 && !left);
	assert(pg_synthesis_structure_resume(s, &copy, expected.pending));
	copy = *expected.pending;
	assert(pg_synthesis_structure_resume(s, query.pending, &copy));
	assert(pg_synthesis_structure_resume(s, query.pending, wrong.pending));
	assert(!s->steps && s->jobs.count == count && s->ready == ready
		&& native_admissions(&program->typing) == 1);
	assert(!pg_synthesis_structure_resume(s, query.pending, expected.pending));
	assert(pg_synthesis_structure_frontier(s, query.pending, &left) == 1 && left == expected.pending);
	assert(pg_synthesis_structure_resume(s, query.pending, expected.pending));
	assert(!s->steps && s->jobs.count == count && s->ready == ready);
	pg_program_destroy(program);
	puts("canonical structural child: copied owner/child, wrong child and duplicate rejected without allocation/Solve/admission");
}

__attribute__((noinline)) static struct pg_synthesis_job *escaped_schema(struct pg_synthesis *s,
	const struct pg_source_scope *scope, const struct pg_syntax *syntax)
{
	struct pg_source_scope raw = *scope;
	return pg_synthesis_data_schema(s, &raw, syntax);
}

static void declaration_negative(void)
{
	struct pg_program *program = start(), *foreign = start();
	advance(&program->synthesis, 3);
	struct pg_synthesis *s = &program->synthesis;
	const struct pg_source_scope *scope, *inner;
	const struct pg_syntax *syntax, *schema_syntax;
	assert(!pg_synthesis_source_input(s, program->root, &scope, &syntax));
	struct pg_synthesis_job *declaration = pg_synthesis_request(s, scope, syntax->right), *schema = NULL;
	assert(pg_synthesis_declaration_frontier(s, declaration, &schema) == 1 && schema);
	assert(pg_synthesis_schema_seed_input(s, schema, &inner, &schema_syntax) == 1);
	assert(!pg_synthesis_source_input(s, declaration, &scope, &syntax) && syntax == schema_syntax);
	struct pg_synthesis_job *fresh = pg_synthesis_source_declaration(s, pg_synthesis_binding_scope(
		pg_synthesis_binding(s, scope, ((const struct pg_syntax *)program->root->inputs[1])->left)), syntax);
	struct pg_synthesis_job *wrong = pg_synthesis_data_schema(s, scope, syntax);
	struct pg_source_scope raw = *inner;
	struct pg_synthesis_job *raw_schema = pg_synthesis_data_schema(s, &raw, syntax);
	struct pg_synthesis_job *escaped = escaped_schema(s, inner, syntax);
	assert(fresh && wrong && raw_schema && escaped);
	size_t count = s->jobs.count, admissions = native_admissions(&program->typing);
	uint64_t steps = s->steps;
	struct pg_synthesis_job *ready = s->ready, copy = *declaration, *left = NULL;
	assert(pg_synthesis_declaration_frontier(s, &copy, &left) == -1 && !left);
	assert(pg_synthesis_declaration_resume(s, &copy, schema));
	copy = *schema;
	assert(pg_synthesis_schema_seed_input(s, &copy, &inner, &schema_syntax) == -1);
	assert(pg_synthesis_declaration_resume(s, fresh, &copy));
	assert(pg_synthesis_declaration_resume(s, fresh, wrong));
	assert(pg_synthesis_schema_seed_input(s, raw_schema, &inner, &schema_syntax) == -1);
	assert(pg_synthesis_declaration_resume(s, fresh, raw_schema));
	assert(pg_synthesis_schema_seed_input(s, escaped, &inner, &schema_syntax) == -1);
	assert(pg_synthesis_schema_seed_input(&foreign->synthesis, schema, &inner, &schema_syntax) == -1);
	assert(pg_synthesis_declaration_resume(s, declaration, schema));
	assert(s->jobs.count == count && s->ready == ready && s->steps == steps
		&& native_admissions(&program->typing) == admissions);
	pg_program_destroy(foreign); pg_program_destroy(program);
	puts("declaration frontier: copied/foreign owners, raw/escaped lexical scope, wrong schema and duplicate reject without mutation");
}

int main(void)
{
	setvbuf(stdout, NULL, _IONBF, 0);
	negative();
	declaration_negative();
	check(2);
	check(3);
	check(4);
	return 0;
}
